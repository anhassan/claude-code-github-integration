import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { environment } from '@environments/environment';
import { AuthService } from '@services/auth.service';
import { filter, switchMap, take } from 'rxjs';

// by default the assumption is that all portal API endpoints require an auth header
const useAuthHeader = (url: string): boolean => {
  return url.startsWith(environment.portal_api_url);
};

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  if (!useAuthHeader(req.url)) return next(req);

  const authService = inject(AuthService);

  if (authService.isValidToken(authService.getAuthToken())) {
    return next(
      req.clone({
        setHeaders: {
          Authorization: authService.getAuthToken(),
        },
      })
    );
  }

  return authService.handleAuthState().pipe(
    filter((isInProgress: boolean) => !isInProgress),
    take(1),
    switchMap(() =>
      next(
        req.clone({
          setHeaders: {
            Authorization: authService.getAuthToken(),
          },
        })
      )
    )
  );
};
