import { TestBed } from '@angular/core/testing';

import { AssetService } from './asset.service';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './auth.interceptor';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('AssetsService', () => {
  let service: AssetService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClientTesting(),
        provideHttpClient(withInterceptors([authInterceptor])),
      ],
    });
    service = TestBed.inject(AssetService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
