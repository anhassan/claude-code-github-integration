import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root',
})
export class AlsService {
  BASE_URL = `${environment.portal_api_url}`;

  constructor(private readonly httpClient: HttpClient) {}

  createAlsRequest(assetId: string, email: string): Observable<any> {
    return this.httpClient.post<any>(
      `${this.BASE_URL}/entitlements/create_als_request`,
      {
        request: {
          asset_id: assetId,
          requestor_email: email,
        },
      }
    );
  }
}
