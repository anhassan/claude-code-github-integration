import { TestBed } from '@angular/core/testing';

import { RlsService } from './rls.service';

describe('RlsService', () => {
  let service: RlsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RlsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
