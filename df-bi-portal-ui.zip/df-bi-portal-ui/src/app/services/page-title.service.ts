import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';
import { AssetService } from './asset.service';
import { of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PageTitleService {
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private titleService: Title,
    private assetService: AssetService
  ) {
    this.listenForTitleChanges();
  }

  private listenForTitleChanges() {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        map(() => this.activatedRoute),
        map((route) => {
          while (route.firstChild) route = route.firstChild;
          return route;
        }),
        mergeMap((route) => route.data),
        mergeMap((data) => {
          const currentUrl = this.router.url;
          const params = this.activatedRoute.snapshot.firstChild?.params || {};
          const queryParams =
            this.activatedRoute.snapshot.firstChild?.queryParams || {};

          let title = data['title'] || 'FinSights';

          // Replace dynamic placeholders
          Object.keys(params).forEach((key) => {
            title = title.replace(`:${key}`, params[key]);
          });

          // Replace query params
          Object.keys(queryParams).forEach((key) => {
            title = title.replace(`:${key}`, queryParams[key]);
          });

          // Special logic for filters query param
          if (queryParams['filters']) {
            try {
              const filterData = JSON.parse(queryParams['filters']);
              if (filterData[0]?.terms?.['tags.keyword']?.[0]) {
                let domain = filterData[0].terms['tags.keyword'][0];

                // Capitalize each word
                domain = domain
                  .split(' ')
                  .map(
                    (word: string) =>
                      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                  )
                  .join(' ');

                title = `${domain} Domain`;
              }
            } catch (e) {
              console.error('Invalid filters JSON', e);
            }
          }

          // In case name query params do not go through
          if (
            (currentUrl.includes('metadata') ||
              currentUrl.includes('dashboard')) &&
            !queryParams['name'] &&
            params['asset_id']
          ) {
            return this.assetService
              .getAssetById(params['asset_id'])
              .pipe(
                map(
                  (asset) => `${asset._source.asset_display_name} | FinSights`
                )
              );
          }

          return of(`${title} | FinSights`);
        })
      )
      .subscribe((pageTitle) => {
        this.titleService.setTitle(pageTitle);
        window.dispatchEvent(new Event('titleUpdated'));
      });
  }
}
