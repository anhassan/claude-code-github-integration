import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RlsByClaims } from '@app/pages/request-rls/interfaces/rls-by-claim';
import { RlsByEmail } from '@app/pages/request-rls/interfaces/rls-by-email';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RlsService {
  BASE_URL = `${environment.portal_api_url}`;

  constructor(private readonly httpClient: HttpClient) {}

  createRequest(request: RlsByEmail | RlsByClaims): Observable<any> {
    return this.httpClient.post<any>(
      `${this.BASE_URL}/entitlements/create_request`,
      { requests: request }
    );
  }

  getMetadata(assetId: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/assets/${assetId}/metadata`
    );
  }

  getDatasetColumns(dataset_id: string): Observable<any> {
    return this.httpClient.get(
      `${this.BASE_URL}/dataset/${dataset_id}/columns`
    );
  }

  getRlsByEmail(dataset_id: string, workspace_id: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/dataset/${dataset_id}/${workspace_id}/rls_by_email`
    );
  }

  getRlsByClaims(dataset_id: string, workspace_id: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/dataset/${dataset_id}/${workspace_id}/rls_by_claims`
    );
  }
}
