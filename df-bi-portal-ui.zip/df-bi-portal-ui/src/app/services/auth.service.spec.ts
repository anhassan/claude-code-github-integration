import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './auth.interceptor';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { LocalStorageKeys } from '@app/shared/constants';
import ExpiredToken from '@assets/stubs/expired-auth-token.json';

describe('AuthService', () => {
  let service: AuthService;
  let mockRouter: any;

  beforeEach(() => {
    mockRouter = {
      navigateByUrl: jasmine.createSpy('navigateByUrl'),
    };

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([authInterceptor])),
        provideHttpClientTesting(),
        { provide: Router, useValue: mockRouter },
      ],
    });
    service = TestBed.inject(AuthService);
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call redirectToSSO if no refresh token is found', () => {
    const redirectToSSOMock = spyOn<any>(service, 'redirectToSSO').and.callFake(
      () => {}
    );
    const renewTokensMock = spyOn<any>(
      service,
      'renewTokens'
    ).and.callFake(() => {});

    localStorage.removeItem(LocalStorageKeys.REFRESH_TOKEN);
    service.handleAuthState();

    expect(redirectToSSOMock).toHaveBeenCalled();
    expect(renewTokensMock).not.toHaveBeenCalled();
  });

  it('should call renewTokens if id token is invalid', () => {
    const redirectToSSOMock = spyOn<any>(service, 'redirectToSSO').and.callFake(
      () => {}
    );
    const renewTokensMock = spyOn<any>(
      service,
      'renewTokens'
    ).and.callFake(() => {});
    const isValidTokenSpy = spyOn<any>(service, 'isValidToken');

    localStorage.setItem(LocalStorageKeys.REFRESH_TOKEN, 'dummy-refresh-token');
    localStorage.setItem(LocalStorageKeys.ID_TOKEN, ExpiredToken.token);

    service.handleAuthState();

    expect(redirectToSSOMock).not.toHaveBeenCalled();
    expect(isValidTokenSpy).toHaveBeenCalled();
    expect(renewTokensMock).toHaveBeenCalled();
  });

  it('should do nothing if auth code is in the URL', () => {
    const redirectToSSOMock = spyOn<any>(service, 'redirectToSSO').and.callFake(
      () => {}
    );
    const renewTokensMock = spyOn<any>(
      service,
      'renewTokens'
    ).and.callFake(() => {});
    spyOn<any>(service, 'getAuthCodeFromUrl').and.returnValue(
      'dummy-auth-code'
    );

    service.handleAuthState();

    expect(redirectToSSOMock).not.toHaveBeenCalled();
    expect(renewTokensMock).not.toHaveBeenCalled();
  });
});
