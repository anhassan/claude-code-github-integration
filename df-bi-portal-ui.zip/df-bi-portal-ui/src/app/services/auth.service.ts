import CryptoJS from 'crypto-js';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { TokenResponse } from '@app/shared/models/pkce-auth';
import {
  DEFAULT_TOKEN_EXPIRY_IN_SECONDS,
  LocalStorageKeys,
} from '@app/shared/constants';
import { jwtDecode } from 'jwt-decode';
import { Router } from '@angular/router';
import {
  BehaviorSubject,
  Observable,
  Subscription,
  catchError,
  finalize,
  interval,
  switchMap,
  tap,
  throwError,
} from 'rxjs';
import { UserService } from './user.service';
import { User } from '@app/shared/models/user';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly redirectUri = `${environment.app_url}/auth`;
  private readonly ssoEndpoint = `${environment.sso_url}/oauth2/authorize`;
  private readonly tokenEndpoint = `${environment.sso_url}/oauth2/token`;

  // ensures a single interval tracking when to refresh
  private refreshTokenIntervalSubscription?: Subscription;
  // prevents triggering additional auth requests when in progress
  private readonly authInProgressSubject: BehaviorSubject<boolean> =
    new BehaviorSubject(false);

  constructor(
    private readonly http: HttpClient,
    private readonly router: Router,
    private readonly userService: UserService
  ) {}

  private randomString(length: number): string {
    const chars =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  // doesn't set authInProgressSubject to false since this is only called when auth is in progress
  private resetAuthState(): void {
    this.refreshTokenIntervalSubscription?.unsubscribe();
    this.refreshTokenIntervalSubscription = undefined;

    localStorage.clear();
    sessionStorage.clear();
  }

  private redirectToSSO(): void {
    this.resetAuthState();

    const codeVerifier = this.randomString(128);

    sessionStorage.setItem('code_verifier', codeVerifier);
    sessionStorage.setItem('route_before_auth', window.location.pathname);

    const codeVerifierHash = CryptoJS.SHA256(codeVerifier).toString(
      CryptoJS.enc.Base64
    );

    const codeChallenge = codeVerifierHash
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');

    const params = new URLSearchParams();
    params.set('response_type', 'code');
    params.set('client_id', environment.sso_client_id);
    params.set('code_challenge', codeChallenge);
    params.set('code_challenge_method', 'S256');
    params.set('redirect_uri', this.redirectUri);

    this.authInProgressSubject.next(true);
    window.location.href = `${this.ssoEndpoint}?${params.toString()}`;
  }

  isValidToken(token: string | null): boolean {
    try {
      if (!token) return false;

      const timeRemaining: number = jwtDecode(token)?.exp ?? 0;
      const currentTimeInSeconds: number = Math.floor(Date.now() / 1000);

      // the token is still valid for more than 60 seconds
      return timeRemaining - currentTimeInSeconds > 60;
    } catch (error) {
      console.warn('Invalid token in local storage', error);
      return false;
    }
  }

  private storeTokens({
    access_token,
    id_token,
    refresh_token,
    expires_in,
  }: TokenResponse): void {
    localStorage.setItem(LocalStorageKeys.ACCESS_TOKEN, access_token);
    localStorage.setItem(LocalStorageKeys.ID_TOKEN, id_token);
    localStorage.setItem(LocalStorageKeys.EXPIRES_IN, String(expires_in));

    // refresh token not included in response for refresh_token grant_type
    if (refresh_token) {
      localStorage.setItem(LocalStorageKeys.REFRESH_TOKEN, refresh_token);
    }
  }

  // uses route saved in session to put user back on their route before auth redirection
  private restoreRouteBeforeAuth(): void {
    const originalRoute = sessionStorage.getItem('route_before_auth');
    sessionStorage.removeItem('route_before_auth');

    if (!originalRoute || originalRoute.includes('/auth')) {
      this.router.navigateByUrl('');
    } else {
      this.router.navigateByUrl(originalRoute);
    }
  }

  private fetchAuthTokens(payload: HttpParams): Observable<User | null> {
    this.authInProgressSubject.next(true);

    return this.http
      .post<TokenResponse>(this.tokenEndpoint, payload, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      })
      .pipe(
        tap((resp: TokenResponse | null): void => {
          if (!resp) {
            throw new Error(
              `Authentication failed! Expected to recieve token response object, instead got: ${resp}`
            );
          }

          this.storeTokens(resp);
        }),
        catchError((err) => {
          console.error(err);
          // if failed to get tokens, retry SSO
          this.redirectToSSO();
          return throwError(() => err);
        }),
        switchMap((_) => this.userService.initUser()),
        finalize(() => this.authInProgressSubject.next(false))
      );
  }

  private renewTokens(): void {
    this.authInProgressSubject.next(true);

    const refreshToken =
      localStorage.getItem(LocalStorageKeys.REFRESH_TOKEN) ?? '';

    const payload = new HttpParams().appendAll({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: environment.sso_client_id,
    });

    this.fetchAuthTokens(payload).subscribe();
  }

  private getAuthCodeFromUrl(): string | null {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('code');
  }

  retrieveTokensWithAuthCode(code: string): void {
    const codeVerifier = sessionStorage.getItem('code_verifier') ?? '';

    const payload = new HttpParams().appendAll({
      redirect_uri: this.redirectUri,
      client_id: environment.sso_client_id,
      code: code,
      code_verifier: codeVerifier,
      grant_type: 'authorization_code',
    });

    this.fetchAuthTokens(payload).subscribe({
      next: (_): void => {
        this.startBackgroundTokenRefresh();
        this.restoreRouteBeforeAuth();
      },
    });
  }

  startBackgroundTokenRefresh(): Subscription {
    this.refreshTokenIntervalSubscription?.unsubscribe();

    const existingExpiryInSeconds: number =
      Number(localStorage.getItem(LocalStorageKeys.EXPIRES_IN)) ||
      DEFAULT_TOKEN_EXPIRY_IN_SECONDS;

    const expiryInMilliseconds: number = existingExpiryInSeconds * 1000;

    this.refreshTokenIntervalSubscription = interval(expiryInMilliseconds)
      .pipe(tap(() => this.renewTokens()))
      .subscribe();

    return this.refreshTokenIntervalSubscription;
  }

  getAuthToken(): string {
    return localStorage.getItem('id_token') ?? '';
  }

  handleAuthState(): BehaviorSubject<boolean> {
    // if there's an authorization code in the url, or explicitly specified then the auth flow is in progress
    if (this.getAuthCodeFromUrl() || this.authInProgressSubject.getValue())
      return this.authInProgressSubject;

    const idToken = localStorage.getItem(LocalStorageKeys.ID_TOKEN);
    const refreshToken = localStorage.getItem(LocalStorageKeys.REFRESH_TOKEN);

    if (!refreshToken) {
      this.redirectToSSO();
    } else if (!this.isValidToken(idToken)) {
      this.renewTokens();
    }

    return this.authInProgressSubject;
  }
}
