import { TestBed } from '@angular/core/testing';

import { AlsService } from './als.service';

describe('AlsService', () => {
  let service: AlsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
