import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  AssetSearch,
  AssetSearchAutocomplete,
  BIAsset,
  MultiAssetByIdResponse,
} from '@app/shared/models/asset';
import { AssetEmbedUrlResponse } from '@app/shared/models/embed-url';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AssetService {
  BASE_RESOURCE = 'assets';
  CATALOG_RESOURCE = 'catalog';
  BASE_URL = `${environment.portal_api_url}/${this.BASE_RESOURCE}`;

  constructor(private readonly httpClient: HttpClient) {}

  getAssetEmbedUrl(assetId: string): Observable<AssetEmbedUrlResponse> {
    return this.httpClient.get<AssetEmbedUrlResponse>(
      `${this.BASE_URL}/${assetId}/embed_url`
    );
  }

  getAssetById(assetId: string): Observable<BIAsset> {
    return this.httpClient.get<BIAsset>(`${this.BASE_URL}/${assetId}`);
  }

  getAssetsByIds(assetIds: string[]): Observable<MultiAssetByIdResponse> {
    const params = new URLSearchParams();
    params.set('asset_ids', assetIds.join());

    return this.httpClient.get<MultiAssetByIdResponse>(
      `${this.BASE_URL}?${params.toString()}`
    );
  }

  getAssetSearchFilters(): Observable<any> {
    return this.httpClient.get(`${this.BASE_URL}/filters`);
  }

  search(
    searchText?: string,
    filters?: string,
    from: string = '0',
    size: string = '10'
  ): Observable<AssetSearch> {
    const params = new URLSearchParams();
    params.set('search_text', searchText ?? '');
    params.set('from', from);
    params.set('size', size);

    if (filters) {
      params.set('filters', filters);
    }

    return this.httpClient.get<AssetSearch>(
      `${this.BASE_URL}/search?${params.toString()}`
    );
  }

  searchAutocomplete(searchText: string): Observable<AssetSearchAutocomplete> {
    const params = new URLSearchParams();
    params.set('search_text', searchText);

    return this.httpClient.get<AssetSearchAutocomplete>(
      `${this.BASE_URL}/search/autocomplete?${params.toString()}`
    );
  }

  getInsights(
    from: string = '0',
    size: string = '100'
  ): Observable<AssetSearch> {
    const params = new URLSearchParams();
    params.set('from', from);
    params.set('size', size);
    return this.httpClient.get<AssetSearch>(
      `${this.BASE_URL}/${this.CATALOG_RESOURCE}/insights?${params.toString()}`
    );
  }

  getNonInsights(
    from: string = '0',
    size: string = '100'
  ): Observable<AssetSearch> {
    const params = new URLSearchParams();
    params.set('from', from);
    params.set('size', size);
    return this.httpClient.get<AssetSearch>(
      `${this.BASE_URL}/${
        this.CATALOG_RESOURCE
      }/non_insights?${params.toString()}`
    );
  }

  // getRecommendedInsights(
  //   from: string = '0',
  //   size: string = '100'
  // ): Observable<AssetSearch> {
  //   const params = new URLSearchParams();
  //   params.set('from', from);
  //   params.set('size', size);
  //   return this.httpClient.get<AssetSearch>(
  //     `${this.BASE_URL}/${
  //       this.CATALOG_RESOURCE
  //     }/recommended?${params.toString()}`
  //   );
  // }

  getRecommendedForDepartment(): Observable<AssetSearch> {
    return this.httpClient.get<AssetSearch>(
      `${this.BASE_URL}/${this.CATALOG_RESOURCE}/department`
    );
  }

  postWorkspaceEntitlement(
    base64File: string,
    fileName: string
  ): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application.json',
      }),
    };
    const body = {
      data: base64File,
      fileName: fileName,
    };
    return this.httpClient.post(
      `${this.BASE_URL}/workspace-entitlement`,
      body,
      options
    );
  }

  postDashboardEntitlement(
    base64File: string,
    fileName: string
  ): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application.json',
      }),
    };
    const body = {
      data: base64File,
      fileName: fileName,
    };
    return this.httpClient.post(
      `${this.BASE_URL}/dashboard-entitlement`,
      body,
      options
    );
  }

  getDepartmentHighlightStatus(assetIds: string[]): Observable<any> {
    const body = {
      asset_ids: assetIds,
    };
    return this.httpClient.post(`${this.BASE_URL}/departments`, body);
  }

  getQueue(assetId: string): Observable<any> {
    return this.httpClient.get(
      `${this.BASE_URL}/${assetId}/embed_q_gen_ai_qa_url`
    );
  }

  getUserDashboardAccess(user_id: string): Observable<any> {
    const params = new URLSearchParams();
    params.set('user_id', user_id);
    return this.httpClient.get(`${this.BASE_URL}/user?${params.toString()}`);
  }

  requestDashboardAccess(): Observable<any> {
    //TODO Verify API
    return this.httpClient.get(`${this.BASE_URL}/create_als_request`);
  }
}
