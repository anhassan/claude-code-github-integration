import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EntitlementsService {
  BASE_RESOURCE = 'entitlements';
  BASE_URL = `${environment.portal_api_url}/${this.BASE_RESOURCE}`;

  constructor(private readonly httpClient: HttpClient) {}

  approveRlsRequest(request_id: string, email: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/${request_id}/${email}/approve_request`
    );
  }

  denyRlsRequest(request_id: string, email: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/${request_id}/${email}/deny_request`
    );
  }

  approveAlsViewerRequest(request_id: string, email: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/${request_id}/${email}/approve_als_viewer_request`
    );
  }

  approveAlsWhitelistRequest(
    request_id: string,
    email: string
  ): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/${request_id}/${email}/approve_als_whitelist_request`
    );
  }

  denyAlsRequest(request_id: string, email: string): Observable<any> {
    return this.httpClient.get<any>(
      `${this.BASE_URL}/${request_id}/${email}/deny_als_request`
    );
  }
}
