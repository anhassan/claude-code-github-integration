import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '@app/shared/models/user';
import {
  FavouriteAssetResponse,
  LocalFavouriteAssets,
} from '@app/shared/models/favourite';
import { environment } from '@environments/environment';
import { BehaviorSubject, Observable, map, tap } from 'rxjs';
import { PopupContent } from '@app/pages/customize-popup-content/popup-content';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  userSubject = new BehaviorSubject<User | undefined>(undefined);

  RESOURCE = 'user';
  BASE_URL = `${environment.portal_api_url}/${this.RESOURCE}`;

  LOCAL_STORAGE_FAVOURITES = 'favourites';

  public userDepartment: string = '';
  public userEmail: string = '';

  user$ = this.userSubject.asObservable();

  constructor(private readonly httpClient: HttpClient) {}

  // Uses token from SSO to upsert a user and returns their details
  initUser(): Observable<User> {
    return this.httpClient.post<User>(`${this.BASE_URL}/login`, {}).pipe(
      tap((user: User) => {
        this.userSubject.next(user);
        this.userDepartment = user.department;
        this.userEmail = user.email;
      })
    );
  }

  getUser(): Observable<any> {
    return this.user$;
  }

  // fetches user favourites from source of truth dynamodb table and puts them in local storage
  // transforms the list of favourites into a map of ids to easily check if an asset is a favourite
  storeUserFavourites(): Observable<LocalFavouriteAssets> {
    return this.httpClient
      .get<FavouriteAssetResponse[]>(`${this.BASE_URL}/favourites`)
      .pipe(
        map(
          (favourites: FavouriteAssetResponse[]): LocalFavouriteAssets =>
            favourites.reduce(
              (
                acc: LocalFavouriteAssets,
                favourite: FavouriteAssetResponse
              ): LocalFavouriteAssets => {
                acc[favourite.asset_id] = favourite.created_at;
                return acc;
              },
              {}
            )
        ),
        tap((favourites: LocalFavouriteAssets): void => {
          localStorage.setItem(
            this.LOCAL_STORAGE_FAVOURITES,
            JSON.stringify(favourites)
          );
        })
      );
  }

  getLocalFavourites(): LocalFavouriteAssets {
    const localFavourites = localStorage.getItem(this.LOCAL_STORAGE_FAVOURITES);

    return localFavourites ? JSON.parse(localFavourites) : {};
  }

  updateLocalFavourites(isFavourite: boolean, assetId: string): void {
    const localFavourites = this.getLocalFavourites();

    if (isFavourite) {
      localFavourites[assetId] = new Date().getUTCDate().toString();
    } else {
      delete localFavourites[assetId];
    }

    localStorage.setItem(
      this.LOCAL_STORAGE_FAVOURITES,
      JSON.stringify(localFavourites)
    );
  }

  addFavourite(asset_id: string): Observable<any> {
    return this.httpClient.post(`${this.BASE_URL}/favourite`, { asset_id });
  }

  removeFavourite(asset_id: string): Observable<any> {
    return this.httpClient.delete(`${this.BASE_URL}/favourite/${asset_id}`);
  }

  checkPopupPermission(): Observable<any> {
    return this.httpClient.get(
      `${environment.portal_api_url}/popup-edit-permissions`
    );
  }

  getAllPopupPermissions(): Observable<any> {
    return this.httpClient.get(`${environment.portal_api_url}/popup-all-users`);
  }

  addPopupPermission(user: string): Observable<any> {
    return this.httpClient.post(
      `${environment.portal_api_url}/popup-add-user`,
      { email: user }
    );
  }

  removePopupPermissions(user: string): Observable<any> {
    return this.httpClient.delete(
      `${environment.portal_api_url}/popup-remove-user`,
      {
        body: { email: user },
      }
    );
  }

  getPopupContent(): Observable<PopupContent[]> {
    return this.httpClient
      .get<PopupContent[]>(`${environment.portal_api_url}/get-popup-content`)
      .pipe(
        map((content) =>
          content.map((page) => ({
            ...page,
            imageSize: Number(page.imageSize),
            initialImageSize: Number(page.initialImageSize),
          }))
        )
      );
  }

  updatePopupContent(updatedPopup: PopupContent[]): Observable<any> {
    const payload = updatedPopup.map((page) => ({
      ...page,
      imageSize: page.imageSize?.toString(),
      initialImageSize: page.initialImageSize?.toString(),
    }));

    return this.httpClient.post(
      `${environment.portal_api_url}/update-popup-content`,
      payload
    );
  }

  deletePopupContent(): Observable<any> {
    return this.httpClient.delete(
      `${environment.portal_api_url}/delete-popup-content`
    );
  }

  checkUploadEntitlementPermission(): Observable<any> {
    return this.httpClient.get(
      `${environment.portal_api_url}/upload-entitlement-permissions`
    );
  }

  checkAssetEntitlementPermission(): Observable<any> {
    return this.httpClient.get(
      `${environment.portal_api_url}/asset-entitlement-permissions`
    );
  }

  checkHiddenTabPermission(): Observable<any> {
    return this.httpClient.get(
      `${environment.portal_api_url}/hidden-tab-permissions`
    );
  }
}
