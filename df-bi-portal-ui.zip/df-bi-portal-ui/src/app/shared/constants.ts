export enum LocalStorageKeys {
  ACCESS_TOKEN = 'access_token',
  ID_TOKEN = 'id_token',
  REFRESH_TOKEN = 'refresh_token',
  EXPIRES_IN = 'expires_in',
}

// 3600 seconds === 1 hour
export const DEFAULT_TOKEN_EXPIRY_IN_SECONDS = 3600;

export const TABLE_PAGE_SIZE_OPTIONS = [5, 10, 20];

export const SEARCH_RESULTS_PAGE_SIZE_OPTIONS = [10, 15, 20];

export const DEFAULT_TOTAL_SEARCH_RESULTS = 100;

export const DEFAULT_DEPARTMENT = 'All Organization';
export const DYNAMIC_COLOUR_OPTIONS = [
  '#1d40ae',
  '#E5A000',
  '#EC221F',
  '#009951',
];
