import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router, RouterLinkActive } from '@angular/router';
import { BannerComponent } from '@app/pages/banner/banner.component';
import { AlsService } from '@app/services/als.service';
import { UserService } from '@app/services/user.service';
import { AssetDetail, AssetSource } from '@app/shared/models/asset';
import { User } from '@app/shared/models/user';
import { DynamicColourPipe } from '@app/shared/pipes/dynamic-colour.pipe';
import { switchMap } from 'rxjs';

interface CardFlags {
  isNewRelease: boolean;
}

@Component({
  selector: 'app-asset-card',
  standalone: true,
  imports: [
    CommonModule,
    RouterLinkActive,
    TitleCasePipe,
    DatePipe,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    DynamicColourPipe,
    MatProgressSpinnerModule,
    BannerComponent,
  ],
  templateUrl: './asset-card.component.html',
  styleUrl: './asset-card.component.scss',
})
export class AssetCardComponent implements OnInit {
  @Input()
  asset!: AssetSource;
  @Input()
  hasAccess: boolean = true;
  assetDetail?: AssetDetail;

  detailPageRoute: string = '';
  flags?: CardFlags;
  tags: string[] = [];
  primaryOwner: string = '';

  isLoadingRequest: boolean = false;
  text = '';
  success = false;
  action = '';
  isSuccessVisible = false;

  @Output() hiddenDashUrl = new EventEmitter<string>();

  constructor(
    private readonly router: Router,
    private readonly alsService: AlsService,
    private readonly userService: UserService,
    private cdf: ChangeDetectorRef
  ) {}

  // if the asset was updated less than 30 days ago, it's considered a new release
  private getIsNewReleaseFlag(asset: AssetDetail): boolean {
    try {
      const updated_at = asset?.updated_at;

      if (!updated_at) {
        return false;
      }
      const deltaMs = Math.abs(
        new Date().getTime() - new Date(updated_at).getTime()
      );
      const deltaDays = deltaMs / (24 * 60 * 60 * 1000);

      return deltaDays < 30;
    } catch (e) {
      console.error(e);
      return false;
    }
  }

  // get only the first 2 tags if specified
  private getTags(asset: AssetDetail): string[] {
    if (!asset?.tags) {
      return [];
    }

    return asset.tags.flatMap((tag: string) => tag.split(','));
  }

  private getPrimaryOwner(asset: AssetDetail): string {
    if (asset.finsights_detail?.product_owners?.length) {
      return asset.finsights_detail.product_owners[0].name;
    }

    return asset.owners[0];
  }

  cardClicked(_: unknown): void {
    this.router.navigateByUrl(this.detailPageRoute);
  }

  actionButtonClick(event: Event, route: string[], assetName: string): void {
    event.stopPropagation();
    this.router.navigate(route, {
      queryParams: { name: assetName },
      state: { hasAccess: this.hasAccess },
    });
  }

  onRequestAccessClick(event: Event): void {
    event.stopPropagation();
    this.requestAccess();
  }

  ngOnInit(): void {
    this.assetDetail = new AssetDetail(this.asset);

    this.detailPageRoute = `/dashboard/${this.assetDetail.asset_id}?name=${this.assetDetail.asset_display_name}`;

    this.flags = {
      isNewRelease: this.getIsNewReleaseFlag(this.assetDetail),
    };

    this.tags = this.getTags(this.assetDetail);

    this.primaryOwner = this.getPrimaryOwner(this.assetDetail);
  }

  requestAccess() {
    this.isLoadingRequest = true;
    this.userService
      .getUser()
      .pipe(
        switchMap((user: User) =>
          this.alsService.createAlsRequest(
            this.assetDetail?.asset_id!,
            user.email
          )
        )
      )
      .subscribe({
        next: () => {
          this.isLoadingRequest = false;
          this.showBanner(true);
        },
        error: (error) => {
          this.isLoadingRequest = false;
          if (error.status === 504) {
            this.showBanner(true);
          } else {
            this.showBanner(false);
          }
        },
      });
  }

  showBanner(success: boolean) {
    if (success) {
      this.text = 'Access Requested';
      this.success = true;
      this.isSuccessVisible = true;
      this.cdf.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdf.detectChanges();
      }, 10000);
    } else {
      this.text = 'There was an error creating requesting access';
      this.success = false;
      this.isSuccessVisible = true;
      this.cdf.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdf.detectChanges();
      }, 10000);
    }
  }
}
