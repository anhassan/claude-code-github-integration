import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { UserService } from '@app/services/user.service';
import {
  ContentOptions,
  createEmbeddingContext,
  EmbeddingContext,
  DashboardExperience,
  FrameOptions,
  InfoChangeEventName,
  Parameter,
} from 'amazon-quicksight-embedding-sdk';
import { camelCase } from 'lodash-es';

@Component({
  selector: 'app-embedded-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './embedded-dashboard.component.html',
  styleUrl: './embedded-dashboard.component.scss',
})
export class EmbeddedDashboardComponent implements OnChanges {
  @Input() dashboardName!: string;
  @Input() embedUrl!: string;
  @Input() contentOptions?: ContentOptions = {};
  @Input() frameOptions?: Partial<FrameOptions> = {};

  @Output() isDashboardLoading = new EventEmitter<boolean>(true);

  embeddingContext?: EmbeddingContext;
  dashboard?: DashboardExperience;

  constructor(private readonly userService: UserService) {}

  private getUserParameters(): Parameter[] {
    const user = this.userService.userSubject.getValue() ?? {};

    const parameters: Parameter[] = [];

    for (const [key, value] of Object.entries(user)) {
      parameters.push({
        Name: camelCase(`userParam ${key}`),
        Values: Array.isArray(value) ? value : [value],
      });
    }

    return parameters;
  }

  async embedDashboard(dashboardName: string, embedUrl: string): Promise<void> {
    const frameOptions: FrameOptions = {
      ...this.frameOptions,
      url: embedUrl,
      container: document.getElementById(dashboardName) || `#${dashboardName}`,
      resizeHeightOnSizeChangedEvent: true,
      withIframePlaceholder: true,
      height: '100%',
      onChange: (event) => {
        if (event.eventName === InfoChangeEventName.FRAME_LOADED) {
          this.isDashboardLoading.emit(false);
          console.timeEnd('performance-dashboard');
        }
      },
    };

    const contentOptions: ContentOptions = {
      ...this.contentOptions,
      sheetOptions: {
        emitSizeChangedEventOnSheetChange: true,
        singleSheet: true,
      },
      parameters: this.getUserParameters(),
    };

    if (!this.embeddingContext) {
      this.embeddingContext = await createEmbeddingContext();
      this.dashboard = undefined;
    }

    this.dashboard = await this.embeddingContext?.embedDashboard(
      frameOptions,
      contentOptions
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['embedUrl']?.currentValue) {
      this.isDashboardLoading.emit(true);
      this.embedDashboard(this.dashboardName, this.embedUrl);
    }
  }
}
