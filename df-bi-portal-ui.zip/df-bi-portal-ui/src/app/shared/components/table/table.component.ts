
import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { TABLE_PAGE_SIZE_OPTIONS } from '@app/shared/constants';
import { get } from 'lodash-es';

export interface TableColumn<T> {
  fieldKey: Extract<keyof T, string>;
  fallbackKey?: Extract<keyof T, string>;
  displayName?: string;
}

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [MatTableModule, MatPaginatorModule, MatSortModule],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
})
export class TableComponent<T> implements OnChanges, AfterViewInit {
  @Input() columnDefinitions: TableColumn<T>[] = [];
  @Input() data: T[] = [];

  pageSizeOptions: number[] = TABLE_PAGE_SIZE_OPTIONS;
  rowDataKeys: string[] = [];

  dataSource = new MatTableDataSource<T>();

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  initializeTable(): void {
    this.rowDataKeys = this.columnDefinitions.map(
      ({ fieldKey }: TableColumn<T>) => String(fieldKey)
    );

    this.dataSource.data = this.data;
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data'].currentValue?.length) {
      this.initializeTable();
    }
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  getColumnDisplayName({ displayName, fieldKey }: TableColumn<T>) {
    return displayName ?? String(fieldKey);
  }

  getFieldValue(row: T, fieldKey: keyof T, fallbackKey?: keyof T): unknown {
    const value = get(row, fieldKey);

    if (!value && fallbackKey) {
      return get(row, fallbackKey);
    }

    return value;
  }
}
