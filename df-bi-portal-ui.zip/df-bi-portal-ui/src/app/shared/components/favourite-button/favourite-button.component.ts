
import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '@app/services/user.service';
import { finalize, of, switchMap, take, tap } from 'rxjs';

@Component({
  selector: 'app-favourite-button',
  standalone: true,
  imports: [MatIconModule, MatProgressSpinnerModule],
  templateUrl: './favourite-button.component.html',
  styleUrl: './favourite-button.component.scss',
})
export class FavouriteButtonComponent implements OnInit {
  @Input()
  assetId: string = '';
  isFavourite: boolean = false;

  isLoading: boolean = false;

  constructor(
    private readonly userService: UserService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  toggleFavourite(): void {
    of(this.isFavourite)
      .pipe(
        take(1),
        tap(() => {
          this.isLoading = true;
        }),
        switchMap((isFavourite: boolean) =>
          isFavourite
            ? this.userService.removeFavourite(this.assetId)
            : this.userService.addFavourite(this.assetId)
        ),
        finalize(() => {
          this.isLoading = false;
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: () => {
          this.isFavourite = !this.isFavourite;
          this.userService.updateLocalFavourites(
            this.isFavourite,
            this.assetId
          );
        },
      });
  }

  ngOnInit(): void {
    this.isFavourite = !!this.userService.getLocalFavourites()[this.assetId];
  }
}
