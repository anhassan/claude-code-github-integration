import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {
  MatAutocompleteModule,
  MatAutocompleteSelectedEvent,
} from '@angular/material/autocomplete';
import { Router, RouterLink } from '@angular/router';
import { AssetService } from '@app/services/asset.service';
import {
  AssetSearchAutocomplete,
  AssetAutocompleteResponse,
} from '@app/shared/models/asset';
import { User } from '@app/shared/models/user';
import {
  Observable,
  debounceTime,
  distinctUntilChanged,
  of,
  switchMap,
  tap,
} from 'rxjs';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatMenu, MatMenuModule } from '@angular/material/menu';
import {
  EXTERNAL_TOOLS,
  EXTERNAL_DASHBOARDS,
} from '@app/shared/external_services';
import { environment } from '@environments/environment';
import { UserService } from '@app/services/user.service';
import { getAssetPath } from '@app/shared/utils';
import {
  EDIT_POPUP_LINK,
  HELP_LINKS,
  UPLOAD_ENTITLEMENTS,
  UPLOAD_DASHBOARD_ENTITLEMENTS
} from '@app/shared/help_links';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    RouterLink,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule,
    MatMenuModule,
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit, OnDestroy {
  user?: User;

  @ViewChildren('subMenus') subMenus!: QueryList<MatMenu>;
  submenuRefs: MatMenu[] = [];

  searchControl = new FormControl<string>('');
  suggestions: AssetAutocompleteResponse[] = [];
  suggestionsLoading = false;
  isOptionSelected = false;

  externalServices = EXTERNAL_TOOLS;
  externalDashboards = EXTERNAL_DASHBOARDS;

  helpLinks = HELP_LINKS;

  helpButtonMailToLink = `mailto:${environment.help_mailto_email}`;

  assetPath = getAssetPath('FinSights_Logo_Black.png');

  constructor(
    private readonly assetService: AssetService,
    private readonly router: Router,
    private readonly userService: UserService,
    private cdr: ChangeDetectorRef
  ) {
    this.searchControl.valueChanges
      .pipe(
        tap(() => {
          this.suggestionsLoading = true;
        }),
        debounceTime(200),
        distinctUntilChanged(),
        switchMap(
          (
            searchText: string | null | AssetAutocompleteResponse
          ): Observable<AssetSearchAutocomplete | null> =>
            searchText && typeof searchText === 'string'
              ? this.assetService.searchAutocomplete(searchText ?? '')
              : of(null)
        )
      )
      .subscribe((results: AssetSearchAutocomplete | null) => {
        if (results) {
          this.suggestions = results?.hits?.map(({ _source }) => _source);
        }
        this.suggestionsLoading = false;
      });
  }

  suggestionDisplay(asset: Partial<AssetAutocompleteResponse>): string {
    return asset?.asset_display_name ?? '';
  }

  onSelectSuggestion(event: MatAutocompleteSelectedEvent): void {
    this.isOptionSelected = true;
    this.router.navigateByUrl(`/dashboard/${event.option.value.asset_id}`);
  }

  onSubmitSearch(_?: unknown): void {
    const params = new URLSearchParams();

    const raw = this.searchControl.getRawValue();
    const objectSearch =
      typeof raw === 'object'
        ? (raw as unknown as AssetAutocompleteResponse)?.asset_display_name ??
          ''
        : raw ?? '';

    params.set('search_text', objectSearch);

    this.router.navigateByUrl(`/search-results?${params.toString()}`);
  }

  onSearchEnter(event: Event | MatOptionSelectionChange): void {
    if (event instanceof KeyboardEvent && this.isOptionSelected) {
      event.preventDefault();
      this.isOptionSelected = false;
    } else {
      this.onSubmitSearch();
    }
  }

  ngOnInit(): void {
    this.userService.getUser().subscribe((user: User) => {
      this.user = user;
      this.checkUserPermissionsToEditPopup();
      this.checkUserPermissionsToUploadEntitlements();
      this.checkUserPermissionsToUploadDashboardEntitlements()
    });
  }

  ngOnDestroy(): void {
    this.userService.userSubject.unsubscribe();
  }

  checkUserPermissionsToEditPopup() {
    this.userService.checkPopupPermission().subscribe((checkingPermission) => {
      if (
        checkingPermission.Items.length > 0 &&
        !this.helpLinks.some((link) => link.url === EDIT_POPUP_LINK.url)
      ) {
        this.helpLinks.push(EDIT_POPUP_LINK);
        this.cdr.detectChanges();
      }
    });
  }

  checkUserPermissionsToUploadEntitlements() {
    this.userService
      .checkUploadEntitlementPermission()
      .subscribe((checkingPermission) => {
        if (
          checkingPermission.Items.length > 0 &&
          !this.helpLinks.some((link) => link.url === UPLOAD_ENTITLEMENTS.url)
        ) {
          this.helpLinks.push(UPLOAD_ENTITLEMENTS);
          this.cdr.detectChanges();
        }
      });
  }

  checkUserPermissionsToUploadDashboardEntitlements() {
    this.userService
      .checkAssetEntitlementPermission()
      .subscribe((checkingPermission) => {
        if (
          checkingPermission.Items.length > 0 &&
          !this.helpLinks.some((link) => link.url === UPLOAD_DASHBOARD_ENTITLEMENTS.url)
        ) {
          this.helpLinks.push(UPLOAD_DASHBOARD_ENTITLEMENTS)
          this.cdr.detectChanges();
        }
      });
  }
}
