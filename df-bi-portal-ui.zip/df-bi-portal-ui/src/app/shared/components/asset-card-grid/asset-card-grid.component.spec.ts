import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetCardGridComponent } from './asset-card-grid.component';

describe('AssetCardGridComponent', () => {
  let component: AssetCardGridComponent;
  let fixture: ComponentFixture<AssetCardGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetCardGridComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssetCardGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
