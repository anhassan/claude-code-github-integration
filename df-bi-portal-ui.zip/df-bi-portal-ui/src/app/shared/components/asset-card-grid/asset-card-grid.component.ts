import { Component, Input, OnInit } from '@angular/core';
import { MatGridListModule } from '@angular/material/grid-list';
import { AssetSearch } from '@app/shared/models/asset';
import { AssetCardComponent } from '../asset-card/asset-card.component';
import { AssetService } from '@app/services/asset.service';
import { UserService } from '@app/services/user.service';
import { User } from '@app/shared/models/user';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { map, of, switchMap } from 'rxjs';

@Component({
  selector: 'app-asset-card-grid',
  standalone: true,
  imports: [MatGridListModule, AssetCardComponent, MatProgressSpinner],
  templateUrl: './asset-card-grid.component.html',
  styleUrl: './asset-card-grid.component.scss',
})
export class AssetCardGridComponent implements OnInit {
  @Input()
  assets?: AssetSearch | null;
  //userAccessChecked = false;
  isDepartmentPage = false;
  constructor(
    private router: Router,
    private userService: UserService,
    private assetService: AssetService
  ) {}

  ngOnInit(): void {
    this.router.events.subscribe((event) => {
      if (this.router.url.includes('dept=')) {
        this.isDepartmentPage = true;
      }
    });

    this.userService
      .getUser()
      .pipe(
        switchMap((user: User | null) => {
          if (!user) return of(null);
          return this.assetService
            .getUserDashboardAccess(user.email)
            .pipe(map((dashboards) => ({ dashboards })));
        })
      )
      .subscribe((result) => {
        if (result?.dashboards && this.assets?.hits) {
          this.assets.hits.forEach((asset) => {
            asset._source.hasAccess = result.dashboards.includes(
              asset._source.asset_id
            );
          });
          //this.userAccessChecked = true;
        }
      });
  }
}
