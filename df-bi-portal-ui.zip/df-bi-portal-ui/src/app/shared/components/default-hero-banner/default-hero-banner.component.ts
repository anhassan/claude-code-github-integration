import { Component } from '@angular/core';
import { getAssetPath } from '@app/shared/utils';

@Component({
  selector: 'app-default-hero-banner',
  standalone: true,
  imports: [],
  templateUrl: './default-hero-banner.component.html',
  styleUrl: './default-hero-banner.component.scss',
})
export class DefaultHeroBannerComponent {
  assetPath = getAssetPath('logo_name_white.png');
}
