import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultHeroBannerComponent } from './default-hero-banner.component';

describe('DefaultHeroBannerComponent', () => {
  let component: DefaultHeroBannerComponent;
  let fixture: ComponentFixture<DefaultHeroBannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DefaultHeroBannerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DefaultHeroBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
