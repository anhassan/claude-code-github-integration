import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetCardIOComponent } from './asset-card-io.component';

describe('AssetCardIOComponent', () => {
  let component: AssetCardIOComponent;
  let fixture: ComponentFixture<AssetCardIOComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssetCardIOComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AssetCardIOComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
