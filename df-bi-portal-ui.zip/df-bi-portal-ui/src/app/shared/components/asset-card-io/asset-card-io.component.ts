import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { Router, RouterLinkActive } from '@angular/router';
import { AssetDetail, AssetSource } from '@app/shared/models/asset';
import { DynamicColourPipe } from '@app/shared/pipes/dynamic-colour.pipe';

interface CardFlags {
  isNewRelease: boolean;
}

@Component({
  selector: 'app-asset-card-io',
  standalone: true,
  imports: [
    CommonModule,
    RouterLinkActive,
    TitleCasePipe,
    DatePipe,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    DynamicColourPipe,
  ],
  templateUrl: './asset-card-io.component.html',
  styleUrl: './asset-card-io.component.scss',
})
export class AssetCardIOComponent implements OnInit {
  @Input()
  asset!: AssetSource;

  isIo: boolean = false;

  assetDetail?: AssetDetail;

  detailPageRoute: string = '';
  flags?: CardFlags;
  tags: string[] = [];
  primaryOwner: string = '';

  @Output() hiddenDashUrl = new EventEmitter<string>();

  constructor(private readonly router: Router) {}

  // if the asset was updated less than 30 days ago, it's considered a new release
  private getIsNewReleaseFlag(asset: AssetDetail): boolean {
    try {
      const updated_at = asset?.updated_at;

      if (!updated_at) {
        return false;
      }
      const deltaMs = Math.abs(
        new Date().getTime() - new Date(updated_at).getTime()
      );
      const deltaDays = deltaMs / (24 * 60 * 60 * 1000);

      return deltaDays < 30;
    } catch (e) {
      console.error(e);
      return false;
    }
  }

  // get only the first 2 tags if specified
  private getTags(asset: AssetDetail): string[] {
    if (!asset?.tags) {
      return [];
    }

    return asset.tags.flatMap((tag: string) => tag.split(','));
  }

  private getPrimaryOwner(asset: AssetDetail): string {
    if (asset.finsights_detail?.product_owners?.length) {
      return asset.finsights_detail.product_owners[0].name;
    }

    return asset.owners[0];
  }

  cardClicked(_: unknown): void {
    this.router.navigateByUrl(this.detailPageRoute);
  }

  actionButtonClick(event: Event, route: string[], name: string): void {
    event.stopPropagation();
    this.router.navigate(route, { queryParams: { name: name } });
  }

  ngOnInit(): void {
    this.assetDetail = new AssetDetail(this.asset);

    this.detailPageRoute = `/dashboard/${this.assetDetail.asset_id}`;

    this.isIo = this.assetDetail.asset_id.startsWith('io');

    if (this.isIo) {
      this.hiddenDashUrl.emit(this.detailPageRoute);
    }

    this.flags = {
      isNewRelease: this.getIsNewReleaseFlag(this.assetDetail),
    };

    this.tags = this.getTags(this.assetDetail);

    this.primaryOwner = this.getPrimaryOwner(this.assetDetail);
  }
}
