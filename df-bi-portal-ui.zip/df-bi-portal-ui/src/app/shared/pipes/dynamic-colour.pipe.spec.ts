import { DynamicColourPipe } from './dynamic-colour.pipe';

describe('DynamicColourPipe', () => {
  it('create an instance', () => {
    const pipe = new DynamicColourPipe();
    expect(pipe).toBeTruthy();
  });
});
