import { Pipe, PipeTransform } from '@angular/core';
import { DEFAULT_DEPARTMENT, DYNAMIC_COLOUR_OPTIONS } from '../constants';

const hashString = (str: string): number => {
  let hash = 0;

  for (let i = 0; i < str.length; i++) {
    // polynomial rolling hash technique
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }

  return hash;
};

const getColourForName = (name: string): string => {
  if (!name) return DYNAMIC_COLOUR_OPTIONS[0];

  // subtract hash of default department to make DEFAULT_DEPARTMENT use default colour
  const hash = hashString(name) - hashString(DEFAULT_DEPARTMENT);
  const index = Math.abs(hash) % DYNAMIC_COLOUR_OPTIONS.length;

  return DYNAMIC_COLOUR_OPTIONS[index];
};

@Pipe({
  name: 'dynamicColour',
  standalone: true,
})
export class DynamicColourPipe implements PipeTransform {
  transform(value: string): string {
    return getColourForName(value);
  }
}
