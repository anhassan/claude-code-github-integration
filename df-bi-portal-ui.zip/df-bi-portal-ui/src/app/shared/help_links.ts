import { environment } from '@environments/environment';

interface HelpLink {
  label: string;
  url: string;
}

const helpButtonMailToLink = `mailto:${environment.help_mailto_email}`;

export const HELP_LINKS: HelpLink[] = [
  {
    label: 'User Guide',
    url: 'https://cppib.sharepoint.com/:w:/r/teams/PRJ-FinSights/Shared%20Documents/FinSights%20Portal%20User%20Guide.docx?d=w4b2182dfe4ef4abf8b377dabd61eafc4&csf=1&web=1&e=7xfPdX',
  },
  {
    label: 'Email Support',
    url: helpButtonMailToLink,
  },
  {
    label: 'New Feature and Content Requests',
    url: 'https://cppib.sharepoint.com/:l:/t/PRJ-FinSights/FPLYkkY9oPFIg3Vsh4YhAbMBXnvePICKBbdnsT2cJ6ZSDA?e=4qREoX',
  },
];

export const EDIT_POPUP_LINK: HelpLink = {
  label: 'Customize Popup Content',
  url: '/customize-popup-content',
};

export const UPLOAD_ENTITLEMENTS: HelpLink = {
  label: 'Upload Dataset/Workspace Entitlements',
  url: '/upload-entitlements',
};
export const UPLOAD_DASHBOARD_ENTITLEMENTS: HelpLink = {
  label: 'Upload Dashboard Entitlements',
  url: '/upload-dashboard-entitlements',
};
