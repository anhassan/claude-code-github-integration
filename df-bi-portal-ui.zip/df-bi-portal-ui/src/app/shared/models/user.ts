export interface User {
  email: string;
  display_name: string;
  last_seen: string;

  department: string;
  sub_department: string;
  geo: string;

  user_photo?: string;

  additional_departments: string[];
  additional_sub_departments: string[];
  additional_geos: string[];
}
