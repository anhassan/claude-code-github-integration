import { isEmpty, pickBy } from 'lodash-es';
import { DEFAULT_DEPARTMENT } from '../constants';

export type AssetAutocompleteResponse = Pick<
  AssetSource,
  'asset_id' | 'asset_display_name' | 'is_restricted'
>;

export interface AssetSearchAutocomplete {
  hits: {
    _source: AssetAutocompleteResponse;
  }[];
}

export interface MultiAssetByIdResponse {
  docs: Pick<BIAsset, Partial<'_source'>>[];
}

export interface BIAsset {
  _index: string;
  _type: string;
  _id: string;
  _version: number;
  _seq_no: number;
  _primary_term: number;
  found: boolean;
  _source: AssetSource;
}

export interface FinsightsProductOwner {
  name: string;
  email: string;
}

// the data in this object is dynamically populated by the author and passed through to the finsights portal
// therefore there may be fields beyond the extent of this interface
export interface FinsightsDetail {
  department?: string;
  description?: string;
  tags?: string[];
  product_owners?: FinsightsProductOwner[];
  [key: string]: unknown;
}

export interface AssetSource {
  asset_id: string;
  asset_url: string;
  is_restricted?: boolean;
  asset_display_name: string;
  asset_id_prefix: string;
  asset_type: string;
  artifact_source: string;
  source_account: string;
  source_region: string;
  target_account: string;
  created_at: string;
  updated_at: string;
  department: string;
  description?: string;
  env: string;
  owners: string[];
  datasets: Dataset[];
  associated_dp: string[];
  tags: string[];
  row_level_security: string[];
  sheets: Sheet[];
  calculated_fields: CalculatedField[];
  finsights_detail?: FinsightsDetail;
  isIo?: boolean;
  workspace_id?: string;
}

export interface TermsFilterRequest {
  terms: {
    [key in keyof Partial<AssetSource> as string]: string[];
  };
}
export interface FilterOptions {
  buckets: { key: string }[];
}

export interface AssetSearchFilters {
  aggregations: {
    [key in keyof Partial<AssetSource> as string]: FilterOptions;
  };
}

export interface Dataset {
  dataset_id: string;
  dataset_name: string;
  portal_url: string;
  is_data_product: boolean;
  dataset_description: string;
}

export interface Sheet {
  name: string;
  description: string;
  parameters: Parameter[];
  visualizations: Visualization[];
}

export interface Parameter {
  name: string;
  dataset_id: string;
  source_parameter_name: string;
  description: string;
}

export interface Visualization {
  visualization_type: string;
  visual_id: string;
  visual_name?: string;
  visual_description: string;
  visual_datasets?: VisualDataset[];
}

interface VisualDataset {
  name: string;
  column_name?: string;
  visual_dimension_fields: string[];
  visual_numerical_fields: string[];
}

export interface CalculatedField {
  dataset_identifier: string;
  name: string;
  expression: string;
}

export class AssetDetail implements Partial<AssetSource> {
  asset_id!: string;
  // an asset is restricted if only specific users are allowed to view its embedding

  is_restricted: boolean = false;
  isIo: boolean = false;
  asset_url: string = '';
  asset_display_name: string = '';
  asset_id_prefix: string = '';
  asset_type: string = 'Dashboard';
  artifact_source: string = 'Quicksight';
  source_account: string = '';
  source_region: string = '';
  target_account: string = '';
  created_at: string = '';
  updated_at: string = '';
  department: string = DEFAULT_DEPARTMENT;
  description: string = '';
  env: string = '';
  owners: string[] = ['CPPIB'];
  datasets: Dataset[] = [];
  associated_dp: string[] = [];
  tags: string[] = [];
  row_level_security: string[] = [];
  sheets: Sheet[] = [];
  calculated_fields: CalculatedField[] = [];
  finsights_detail: FinsightsDetail = {};
  hasAccess?: boolean;

  private sanitizeAssetSource = (obj: Partial<AssetSource>) => {
    obj.isIo = obj.asset_id?.startsWith('io');
    return pickBy(obj, (value) => {
      return (
        value !== null &&
        value !== undefined &&
        value !== '' &&
        (!Array.isArray(value) || value.length > 0)
      );
    });
  };

  constructor(private readonly assetSource: Partial<AssetSource>) {
    const sanitizedAssetSource = this.sanitizeAssetSource(assetSource);
    Object.assign(this, { ...this, ...sanitizedAssetSource });
  }
}

export interface AssetSearch {
  total?: {
    value: number;
    relation: string;
  };
  max_score?: number;
  hits: {
    _source: AssetDetail;
  }[];
}
