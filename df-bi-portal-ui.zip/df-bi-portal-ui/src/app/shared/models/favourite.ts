export interface FavouriteAssetResponse {
  email: string;
  asset_id: string;
  created_at: string;
}

export interface LocalFavouriteAssets {
  [asset_id: string]: string;
}
