export interface AssetEmbedUrlResponse {
  EmbedUrl: string;
  Status?: number;
  RequestId?: string;
  AnonymousUserArn?: string;
}
