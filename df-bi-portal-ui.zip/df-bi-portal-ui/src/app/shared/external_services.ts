interface ExternalService {
  type: 'report' | 'tool';
  label: string;
  url: string;
}

export const EXTERNAL_DASHBOARDS: ExternalService[] = [
  {
    type: 'tool',
    label: 'Capital Usage',
    url: 'https://tableau.cppib.com/views/CapitalUsageDashboard_16177226914930/Capitalvs_Budget',
  },
  {
    type: 'tool',
    label: 'Capital Reserve',
    url: 'https://tableau.cppib.com/views/CRRDashboard_16285447343160/CRRDashboard',
  },
  {
    type: 'tool',
    label: 'LCR',
    url: 'https://tableau.cppib.com/views/LCRDashboard/Summary',
  },
  {
    type: 'tool',
    label: 'Regional',
    url: 'https://tableau.cppib.com/views/RegionalDashboard2_0_17054225953510/ExecSummary',
  },
  {
    type: 'tool',
    label: 'Key Markets',
    url: 'https://tableau.cppib.com/views/MarketDashboardNew_16088211877630/KeyMarkets',
  },
  {
    type: 'tool',
    label: 'Portfolio Performance',
    url: 'https://tableau.cppib.com/views/PortfolioPerformanceDashboard/Table',
  },
  {
    type: 'tool',
    label: 'Active Equities Pnl',
    url: 'https://tableau.cppib.com/views/ActiveEquitiesPnLDashboard/AEIncome',
  },
  {
    type: 'tool',
    label: 'One Fund Multiplier',
    url: 'https://tableau.cppib.com/views/ToalFundMultiplier/Multiplier',
  },
  {
    type: 'tool',
    label: 'VDIP',
    url: 'https://tableau.cppib.com/views/VDIPDashboard_16599708755620/VDIP',
  },
  {
    type: 'tool',
    label: 'Perf Attribution AE',
    url: 'https://tableau.cppib.com/views/PerformanceDashboardAE_16820286047550/Performance',
  },
  {
    type: 'tool',
    label: 'Perf Attribution CMF',
    url: 'https://tableau.cppib.com/views/PerformanceDashboardCMF_16820598787290/Performance',
  },
  {
    type: 'tool',
    label: 'Perf Attribution CI',
    url: 'https://tableau.cppib.com/views/PerformanceDashboardCI_16820352561740/Performance',
  },
  {
    type: 'tool',
    label: 'Perf Attribution PE',
    url: 'https://tableau.cppib.com/views/PerformanceDashboardPE_16820482575480/Performance',
  },
  {
    type: 'tool',
    label: 'Perf Attribution RA',
    url: 'https://tableau.cppib.com/views/PerformanceDashboardRA_16820269971570/Performance',
  },
  {
    type: 'tool',
    label: 'Perf Attribution Total Fund',
    url: 'https://tableau.cppib.com/views/AttributionDashboard/Overview',
  },
  {
    type: 'tool',
    label: 'Net Assets Continuity',
    url: 'https://tableau.cppib.com/views/NetAssetsContinuity/Continuity',
  },
  {
    type: 'tool',
    label: 'Air Travel Emissions',
    url: 'https://tableau.cppib.com/#/views/TravelEmissionsDashboard/Summary',
  },
  {
    type: 'tool',
    label: 'CEO',
    url: 'https://tableau.cppib.com/views/CEODashboard/Executive',
  },
  {
    type: 'tool',
    label: 'CIO',
    url: 'https://tableau.cppib.com/views/CIODashboard/NetInvestments',
  },
  {
    type: 'tool',
    label: 'Risk',
    url: 'https://tableau.cppib.com/views/RiskDashboard_15900651325480/RiskDashboard',
  },
  {
    type: 'tool',
    label: 'Balancing Equity Attribution',
    url: 'https://tableau.cppib.com/views/BalancingEQAttributionDashboard/BalancingEQ',
  },
  {
    type: 'tool',
    label: 'SA Performance',
    url: 'tableau.cppib.com/#/views/SAPerformanceDashboard_16739668788300/SEGSAPerformance',
  },
  {
    type: 'tool',
    label: 'RA PAT',
    url: 'http://pipa/QvAJAXZfc/opendoc.htm?document=ra%5Cra_pat.qvw&host=QVS%40priappvmpipa01',
  },
  {
    type: 'tool',
    label: 'PI PAT',
    url: 'http://pipa/QvAJAXZfc/opendoc.htm?document=pat%5Cpat.qvw&host=QVS%40priappvmpipa01',
  },
  {
    type: 'tool',
    label: 'Enhanced Beta',
    url: 'https://tableau.cppib.com/views/EnhancedBetaDashboard_17259115650050/LandingPage',
  },
];

const EXTERNAL_REPORTS: ExternalService[] = [
  {
    type: 'report',
    label: 'All Reports',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/RBI%20Reports/Forms/AllItems.aspx?csf=1&web=1&e=0qSSPB&CID=eae4c069%2D1f93%2D4ee1%2Dbb80%2De30a450742d0&FolderCTID=0x012000D35EC3D7CE1469498BF362F9FAD05194&viewid=69d2f01a%2D0067%2D4eef%2Db923%2D6a725c2bc502',
  },
  {
    type: 'report',
    label: 'Peer Review Report',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/RBI%20Reports/Forms/AllItems.aspx?csf=1&web=1&e=IjXohj&CID=b57da2a8%2D8a05%2D4a30%2Da4d6%2D7db81dcfa0c1&FolderCTID=0x012000D35EC3D7CE1469498BF362F9FAD05194&id=%2Fsites%2FFAR%2DRBI%2FRBI%20Reports%2FPeer%20Review',
  },
  {
    type: 'report',
    label: 'Quarterly Risk Report',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fcppib%2Esharepoint%2Ecom%2Fsites%2FFAR%2DRBI%2FRBI%20Reports%2FQuarterly%20Risk%20Report%3Fcsf%3D1%26web%3D1%26e%3DLB1Bac%26CID%3D8ba9ff4d%2D02c6%2D4096%2Da3d2%2Dc3fb5bcb89c9&correlation=5a637aa1%2Da05e%2D7000%2D6646%2D56e892501886&Type=item&name=74fcc912%2Dd1f2%2D4971%2Daa09%2Df4b3685dc7d1&listItemId=13&listItemUniqueId=d4b9f87d%2D687b%2D4d9a%2Dad8b%2D8c14275f5c37',
  },
  {
    type: 'report',
    label: 'Attribution Management Report',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/RBI%20Reports/Forms/AllItems.aspx?csf=1&web=1&e=CqHwQx&CID=7e37c4b8%2Dc9c1%2D4321%2D9c3a%2D8a5d28aa7935&FolderCTID=0x012000D35EC3D7CE1469498BF362F9FAD05194&id=%2Fsites%2FFAR%2DRBI%2FRBI%20Reports%2FQuarterly%20Performance%20Attribution%20Report%20%26%20Detailed%20Performance%20Attribution%20Report',
  },
  {
    type: 'report',
    label: 'CEM Global Surveys',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/RBI%20Reports/Forms/AllItems.aspx?csf=1&web=1&e=3TtIbG&CID=00ee1875%2D90fa%2D4077%2D8ab8%2D64e19acc78ec&FolderCTID=0x012000D35EC3D7CE1469498BF362F9FAD05194&id=%2Fsites%2FFAR%2DRBI%2FRBI%20Reports%2FCEM%20Global%20Surveys',
  },
  {
    type: 'report',
    label: 'CEM Global Leaders Projects',
    url: 'https://cppib.sharepoint.com/sites/FAR-RBI/RBI%20Reports/Forms/AllItems.aspx?csf=1&web=1&e=0qSSPB&CID=d8a8fc56%2D4e55%2D46b5%2D8c4f%2Db13d95b07ff7&FolderCTID=0x012000D35EC3D7CE1469498BF362F9FAD05194&id=%2Fsites%2FFAR%2DRBI%2FRBI%20Reports%2FCEM%20Global%20Leaders%20Projects',
  },
];

export const EXTERNAL_TOOLS: ExternalService[] = [
  {
    type: 'tool',
    label: 'PACE',
    url: 'https://plotly-dash.attribution-analytics.prod.cppinvestments.io/piq-dash',
  },
  {
    type: 'tool',
    label: 'FAQ Bot',
    url: 'https://chat.awb.prod.cppinvestments.io/business-intelligence',
  },
  {
    type: 'tool',
    label: 'QuickSight Console (Author Only Access)',
    url: 'https://cppinvestments.awsapps.com/start/#/saml/default/DataFabric-Dev/ins-3552a455d41d2486',
  },
  {
    type: 'tool',
    label: 'RAS Calculator',
    url: 'http://business.rasg.sandbox.cppinvestments.io/risk_adjusted_spread/',
  },
  {
    type: 'tool',
    label: 'S2S Return Calc',
    url: 'http://business.rasg.sandbox.cppinvestments.io/systematic_spread/',
  },
  ...EXTERNAL_REPORTS,
];
