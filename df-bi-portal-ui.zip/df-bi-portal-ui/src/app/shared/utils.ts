import { environment } from '@environments/environment';

export const getAssetPath = (filename: string): string => {
  return `${environment.deployment_version}/assets/${filename}`;
};
