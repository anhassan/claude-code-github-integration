import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    data: { title: 'Home' },
    path: '',
    loadComponent: () =>
      import('@pages/home/home.component').then((m) => m.HomeComponent),
  },
  {
    path: 'auth',
    loadComponent: () =>
      import('@pages/auth/auth.component').then((m) => m.AuthComponent),
  },
  {
    data: { title: ':name - Metadata' },
    path: 'product-detail/:asset_id',
    loadComponent: () =>
      import('@pages/product-detail/product-detail.component').then(
        (m) => m.ProductDetailComponent
      ),
  },
  {
    data: { title: ':name - Dashboard' },
    path: 'dashboard/:asset_id',
    loadComponent: () =>
      import('@pages/dashboard/dashboard.component').then(
        (m) => m.DashboardComponent
      ),
  },
  {
    data: { title: 'Search Results' },
    path: 'search-results',
    loadComponent: () =>
      import('@pages/search-results/search-results.component').then(
        (m) => m.SearchResultsComponent
      ),
  },
  {
    data: { title: 'Favourites' },
    path: 'favourites',
    loadComponent: () =>
      import('@pages/favourites/favourites.component').then(
        (m) => m.FavouritesComponent
      ),
  },
  {
    data: { title: 'Release Notes' },
    path: 'release-notes',
    loadComponent: () =>
      import('@pages/release-notes/release-notes.component').then(
        (m) => m.ReleaseNotesComponent
      ),
  },
  {
    data: { title: 'Request Access' },
    path: 'request-access',
    loadComponent: () =>
      import('@pages/request-access/request-access.component').then(
        (m) => m.RequestAccessComponent
      ),
  },
  {
    data: { title: 'Customize Popup Content' },
    path: 'customize-popup-content',
    loadComponent: () =>
      import(
        '@pages/customize-popup-content/customize-popup-content.component'
      ).then((m) => m.CustomizePopupContentComponent),
  },
  {
    data: { title: 'Manage Popup Access' },
    path: 'customize-popup-content/manage-access',
    loadComponent: () =>
      import(
        '@pages/customize-popup-content/manage-customize-popup-access/manage-customize-popup-access.component'
      ).then((m) => m.ManageCustomizePopupAccessComponent),
  },
  {
    data: { title: 'Upload Dataset/Workspace Entitlements' },
    path: 'upload-entitlements',
    loadComponent: () =>
      import('@pages/upload-entitlements/upload-entitlements.component').then(
        (m) => m.UploadEntitlements
      ),
  },
  {
    data: { title: 'Upload Dashboard Entitlements' },
    path: 'upload-dashboard-entitlements',
    loadComponent: () =>
      import(
        '@pages/upload-dashboard-entitlements/upload-dashboard-entitlements.component'
      ).then((m) => m.UploadDashboardEntitlements),
  },
  {
    data: { title: ':dept' },
    path: 'dashboards',
    loadComponent: () =>
      import(
        '@app/pages/department-dashboards/department-dashboards.component'
      ).then((m) => m.DepartmentDashboardsComponent),
  },
  {
    data: { title: 'Approve/Deny Dataset' },
    path: 'approve-deny-rls/:requestId/:approveDeny',
    loadComponent: () =>
      import('@pages/approve-deny-rls/approve-deny-rls.component').then(
        (m) => m.ApproveDenyRls
      ),
  },
  {
    data: { title: 'Approve/Deny Dashboard' },
    path: 'approve-deny-als/:requestId/:approveDeny',
    loadComponent: () =>
      import('@pages/approve-deny-als/approve-deny-als.component').then(
        (m) => m.ApproveDenyAls
      ),
  },
];
