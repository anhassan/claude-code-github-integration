import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { AuthService } from '@services/auth.service';
import { of } from 'rxjs';
import { UserService } from '@services/user.service';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AssetService } from '@services/asset.service';

describe('AppComponent', () => {
  let mockAuthService: any;
  let mockUserService: any;

  beforeEach(async () => {
    mockAuthService = {
      handleAuthState: jasmine.createSpy('handleAuthState'),
      startBackgroundTokenRefresh: jasmine.createSpy(
        'startBackgroundTokenRefresh'
      ),
    };

    mockUserService = {
      initUser: jasmine.createSpy('initUser').and.returnValue(of(null)),
    };

    await TestBed.configureTestingModule({
      imports: [AppComponent],
      providers: [
        provideRouter(routes),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: mockAuthService },
        { provide: UserService, useValue: mockUserService },
        { provide: AssetService, useValue: {} },
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;

    app.ngOnInit();

    expect(app).toBeTruthy();
    expect(mockAuthService.handleAuthState).toHaveBeenCalled();
    expect(mockAuthService.startBackgroundTokenRefresh).toHaveBeenCalled();
    expect(mockUserService.initUser).toHaveBeenCalled();
  });
});
