import { Component, OnDestroy, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '@shared/components/header/header.component';
import { AuthService } from '@services/auth.service';
import { Subscription, switchMap, tap } from 'rxjs';
import { UserService } from './services/user.service';
import { User } from './shared/models/user';
import { ChatButtonComponent } from './pages/chat-button/chat-button.component';
import { PageTitleService } from './services/page-title.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, ChatButtonComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Finsights Portal';
  private readonly subscriptions = new Subscription();

  constructor(
    private readonly authService: AuthService,
    private readonly userService: UserService,
    private pageTitleService: PageTitleService
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(this.authService.handleAuthState());
    this.subscriptions.add(this.authService.startBackgroundTokenRefresh());
    this.subscriptions.add(
      this.userService
        .initUser()
        .pipe(
          tap((user: User) => {
            // if (window && (window as any).gtag) {
            //   (window as any).gtag('config', 'G-LYVQSGZSY4', {
            //     user_id: user.display_name,
            //   });

            //   (window as any).dataLayer = (window as any).dataLayer || [];
            //   (window as any).dataLayer.push({
            //     user_id: user.display_name,
            //     user_email: user.email,
            //     user_department: user.department,
            //     event: 'user_login',

            //   });

            // }

            (window as any).dataLayer = (window as any).dataLayer || [];
            (window as any).dataLayer.push({
              user_id: user.display_name,
              user_email: user.email,
              user_department: user.department,
              user_sub_department: user.sub_department,
              event: 'user_login',
            });
          }),
          switchMap(() => this.userService.storeUserFavourites())
        )
        .subscribe()
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    // // Clear any existing Matomo/Piwik instances
    // if ((window as any)._paq) {
    //   delete (window as any)._paq;
    // }
  }
}
