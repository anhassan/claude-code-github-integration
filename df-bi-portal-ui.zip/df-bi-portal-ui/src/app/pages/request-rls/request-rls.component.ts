import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RlsByEmail, RlsByEmailMappings } from './interfaces/rls-by-email';
import { RlsByClaims, RlsByClaimsMapping } from './interfaces/rls-by-claim';
import { UserService } from '@app/services/user.service';
import { RlsService } from '@app/services/rls.service';
import { AssetService } from '@app/services/asset.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { BannerComponent } from '../banner/banner.component';

@Component({
  selector: 'app-request-rls',
  standalone: true,
  imports: [
    MatRadioModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    MatTableModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    BannerComponent,
  ],
  templateUrl: './request-rls.component.html',
  styleUrl: './request-rls.component.scss',
})
export class RequestRlsComponent implements OnInit {
  // Constants
  BIF_COST_DATASETS = [
    {
      value: 'cost_insights_report',
      viewValue: 'cost_insights_report',
    },
    {
      value: 'cost_insights_transaction_detail',
      viewValue: 'cost_insights_transaction_detail',
    },
  ];
  // Dropdowns
  datasetsDropdown: { value: string; viewValue: string }[] = [];
  deptDropdown: { value: string; viewValue: string }[] = [];
  subDeptDropdown: { value: string; viewValue: string }[] = [];
  geoDropdown: { value: string; viewValue: string }[] = [];
  AccessTypeGroupingDropdown = [
    { value: 'Individual', viewValue: 'Individual' },
    { value: 'Group', viewValue: 'Group' },
  ];
  // bif-cost Dropdowns
  deptColumn: { value: string; viewValue: string }[] = [];
  groupingColumnName: { value: string; viewValue: string }[] = [];
  // Form Controls
  formIsValid = false;
  workspaceId = new FormControl<string>('');
  datasetId = new FormControl<string>('');
  requestType = new FormControl<string>('');
  datasetAccessRequest = new FormControl<string>('');
  departmentColumn = new FormControl('');
  groupingColumn = new FormControl('');
  // Variables
  defaultEnvironment = '';
  rlsByEmailSubmit: RlsByEmail = {
    workspace_id: '',
    dataset_id: '',
    requestor_email: '',
    rls_action: 'GRANT',
    rls_by_email_mappings: [],
  };
  rlsByClaimSubmit: RlsByClaims = {
    workspace_id: '',
    dataset_id: '',
    requestor_email: '',
    rls_action: 'GRANT',
    rls_mappings: [],
  };
  emailsRls: RlsByEmailMappings[] = [];
  visibleEmailsRls: RlsByEmailMappings[] = [];
  emailsRlsToSubmit: RlsByEmailMappings[] = [];
  claimsRls: RlsByClaimsMapping[][] = [];
  claimsRlsToSubmit: RlsByClaimsMapping[][] = [];
  isLoading: boolean = false;
  adClaimDept: string = '';
  adClaimSubDept: string = '';
  adClaimGeo: string = '';
  emailIsValid = true;
  disableSubmit = true;
  showSubDeptError = false;
  showClaimFormError = false;
  showDropdownSelectionError = false;
  isSuccessVisible = false;
  success = true;
  action = '';
  text = '';

  @Input() asset_id: string | null = '';

  constructor(
    readonly userService: UserService,
    readonly rlsService: RlsService,
    readonly assetService: AssetService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.groupingColumn.disable();
    this.isLoading = true;

    this.rlsService
      .getMetadata(this.asset_id!)
      .subscribe((result: { workspace_id: any; dataset_ids: [] }) => {
        this.workspaceId.setValue(result.workspace_id);
        if (result.workspace_id === 'bif-cost') {
          this.datasetsDropdown = this.BIF_COST_DATASETS;
        } else {
          result.dataset_ids.forEach((dataset: string) => {
            this.datasetsDropdown.push({ value: dataset, viewValue: dataset });
          });
        }
        this.isLoading = false;
        this.cdr.detectChanges();
      });
  }

  isValidEmailList(emailList: any): boolean {
    if (typeof emailList === 'string') {
      const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
      const emails = emailList.split(',').map((email) => email.trim());
      return emails.every((email) => emailRegex.test(email));
    } else {
      if (emailList.length > 0) {
        return true;
      } else {
        return false;
      }
    }
  }

  isValidColumnName(columnName: string): boolean {
    const validColumnName = columnName !== '' && columnName !== null;
    return validColumnName;
  }

  isValidColumnValue(columnValue: string): boolean {
    const validColumnValue = columnValue !== '' && columnValue !== null;
    return validColumnValue;
  }

  isValidGroupingName(groupingName: string, groupingValue: string) {
    const validGroupingName = groupingName !== '' && groupingName !== null;
    if (groupingValue !== '' && groupingValue !== null) {
      return validGroupingName;
    } else {
      return true;
    }
  }

  isValidGroupingValue(groupingName: string, groupingValue: string) {
    const validGroupingValue = groupingValue !== '' && groupingValue !== null;
    if (groupingName !== '' && groupingName !== null) {
      return validGroupingValue;
    } else {
      return true;
    }
  }

  removeRowAd(row: any) {
    const rlsToRemove = this.claimsRls.indexOf(row);
    if (rlsToRemove > -1) {
      this.claimsRls.splice(rlsToRemove, 1);
    }
    this.disableSubmit = false;
  }

  removeRowEmails(row: any) {
    const rlsToRemove = this.emailsRls.indexOf(row);
    if (rlsToRemove > -1) {
      this.emailsRls.splice(rlsToRemove, 1);
    }
    if (this.workspaceId.value === 'bif-cost') {
      this.filter();
    }
    this.disableSubmit = false;
  }

  filter() {
    this.visibleEmailsRls = [];
    if (this.emailsRls.length > 0) {
      let level1 = this.emailsRls.filter(
        (emailRls) =>
          emailRls.rule_groups[0].column_name === this.departmentColumn.value
      );
      let level2 = this.emailsRls.filter(
        (emailRls) =>
          emailRls.rule_groups[1].column_name === this.departmentColumn.value
      );
      if (level2) {
        level2.forEach(
          (item) =>
            (item.rule_groups = [item.rule_groups[1], ...[item.rule_groups[0]]])
        );
      }
      this.visibleEmailsRls = [...this.visibleEmailsRls, ...level1, ...level2];
    }
  }

  setGroupingColumn() {
    this.disableSubmit = false;
    if (!this.groupingColumn.value) {
      this.visibleEmailsRls.forEach((emailRls) => {
        emailRls.rule_groups[1].column_name = '';
        emailRls.rule_groups[1].authorized_values = '';
      });
    } else {
      this.visibleEmailsRls.forEach((emailRls) => {
        emailRls.rule_groups[1].column_name = this.groupingColumn.value || '';
        if (!emailRls.rule_groups[1].authorized_values) {
          emailRls.rule_groups[1].authorized_values = '*';
        }
      });
    }
  }

  addNew() {
    this.disableSubmit = true;
    if (this.workspaceId.value === 'bif-cost') {
      this.emailsRls.push({
        emails: [],
        rule_groups: [
          {
            authorized_values: '',
            column_name: this.departmentColumn.value!,
          },
          {
            authorized_values: '',
            column_name: this.groupingColumn.value || '',
          },
        ],
      });
      this.filter();
    } else {
      this.emailsRls.push({
        emails: [],
        rule_groups: [
          {
            authorized_values: '',
            column_name: this.departmentColumn.value!,
          },
        ],
      });
    }
  }

  addNewADClaim() {
    this.claimsRls.push([
      {
        authorized_group: '',
        authorized_values: '',
        tag_type: '',
        column_name: '',
      },
      {
        authorized_group: '',
        authorized_values: '',
        tag_type: '',
        column_name: '',
      },
      {
        authorized_group: '',
        authorized_values: '',
        tag_type: '',
        column_name: '',
      },
    ]);
  }

  getBifCostColumns() {
    this.isLoading = true;
    this.rlsService
      .getDatasetColumns(this.datasetId.value!)
      .subscribe((result) => {
        result.forEach((column: any) => {
          this.deptColumn.push({ value: column, viewValue: column });
        });
        result.forEach((column: any) => {
          this.groupingColumnName.push({ value: column, viewValue: column });
        });
        this.isLoading = false;
        this.cdr.detectChanges();
      });
  }

  getADClaimColumns() {
    this.isLoading = true;
    this.rlsService
      .getDatasetColumns(this.datasetId.value!)
      .subscribe((result) => {
        result.forEach((column: any) => {
          this.deptDropdown.push({ value: column, viewValue: column });
        });
        result.forEach((column: any) => {
          this.subDeptDropdown.push({ value: column, viewValue: column });
        });
        result.forEach((column: any) => {
          this.geoDropdown.push({ value: column, viewValue: column });
        });
        this.isLoading = false;
        this.cdr.detectChanges();
      });
  }

  getRls(event: any) {
    this.isLoading = true;
    if (event.value === 'Individual') {
      if (this.workspaceId.value === 'bif-cost') {
        this.getBifCostColumns();
        // console.log('Current RLS');
        this.rlsService
          .getRlsByEmail(this.datasetId.value!, this.workspaceId.value!)
          .subscribe((emailsRls: RlsByEmailMappings[]) => {
            // console.log(emailsRls);
            emailsRls.forEach((emailsRls) => {
              if (emailsRls.rule_groups.length < 2) {
                emailsRls.rule_groups.push({
                  authorized_values: '',
                  column_name: '',
                });
              }
            });
            this.emailsRls = emailsRls;
            this.isLoading = false;
            this.cdr.detectChanges();
          });
      } else {
        this.rlsService
          .getRlsByEmail(this.datasetId.value!, this.workspaceId.value!)
          .subscribe((emailsRls: RlsByEmailMappings[]) => {
            // console.log(emailsRls);
            this.emailsRls = emailsRls;
            this.isLoading = false;
            this.cdr.detectChanges();
          });
      }
    } else if (event.value === 'Group') {
      this.getADClaimColumns();
      this.rlsService
        .getRlsByClaims(this.datasetId.value!, this.workspaceId.value!)
        .subscribe((claimsRls: RlsByClaimsMapping[][]) => {
          if (claimsRls.length > 0) {
            claimsRls.forEach((rowOfDeptSubGeo, index, array) => {
              while (rowOfDeptSubGeo.length < 3) {
                rowOfDeptSubGeo.push({
                  authorized_group: '',
                  authorized_values: '',
                  tag_type: '',
                  column_name: '',
                });
              }
              rowOfDeptSubGeo = this.reorderArray(rowOfDeptSubGeo);
              array[index] = rowOfDeptSubGeo;
            });
          }
          // console.log(claimsRls);

          this.claimsRls = claimsRls;
          for (let i = 0; i < claimsRls.length; i++) {
            if (claimsRls[i][0].column_name) {
              this.adClaimDept = this.claimsRls[i][0].column_name;
            }
            if (claimsRls[i][1].column_name) {
              this.adClaimSubDept = this.claimsRls[i][1].column_name;
            }
            if (claimsRls[i][2].column_name) {
              this.adClaimGeo = this.claimsRls[i][2].column_name;
            }
          }

          this.isLoading = false;
          this.cdr.detectChanges();
        });
    }
  }

  reorderArray(arr: RlsByClaimsMapping[]): any {
    let dept: RlsByClaimsMapping = {
      authorized_group: '',
      authorized_values: '',
      tag_type: '',
      column_name: '',
    };
    let sub: RlsByClaimsMapping = {
      authorized_group: '',
      authorized_values: '',
      tag_type: '',
      column_name: '',
    };
    let geo: RlsByClaimsMapping = {
      authorized_group: '',
      authorized_values: '',
      tag_type: '',
      column_name: '',
    };

    arr.forEach((element) => {
      if (element.tag_type === 'department') {
        dept = element;
      }
      if (element.tag_type === 'sub_department') {
        sub = element;
      }
      if (element.tag_type === 'geo') {
        geo = element;
      }
    });

    let newArray = [dept, sub, geo];

    return newArray;
  }

  resetRequestAndPermission() {
    this.requestType.reset();
    this.datasetAccessRequest.reset();
    this.clearAll();
  }

  resetPermission() {
    this.datasetAccessRequest.reset();
    this.clearAll();
  }

  clearAll() {
    this.departmentColumn.reset();
    this.groupingColumn.reset();

    this.claimsRls = [];
    this.emailsRls = [];
    this.visibleEmailsRls = [];
    this.claimsRlsToSubmit = [];
    this.emailsRlsToSubmit = [];

    this.showClaimFormError = false;
    this.showDropdownSelectionError = false;
    this.showSubDeptError = false;
  }

  updateAdClaim() {
    if (this.adClaimDept) {
      this.claimsRls.forEach((row) => {
        row[0].tag_type = 'department';
        row[0].column_name = this.adClaimDept;
      });
    }
    if (this.adClaimSubDept) {
      this.claimsRls.forEach((row) => {
        row[1].tag_type = 'sub_department';
        row[1].column_name = this.adClaimSubDept;
      });
    }
    if (this.adClaimGeo) {
      this.claimsRls.forEach((row) => {
        row[2].tag_type = 'geo';
        row[2].column_name = this.adClaimGeo;
      });
    }
  }

  submit() {
    if (this.datasetAccessRequest.value === 'Individual') {
      //console.log('EMAILS');
      this.createSubmitByEmailPayload();
      this.submitPayload(this.rlsByEmailSubmit);
    } else {
      // console.log('CLAIMS');
      this.createSubmitByAdPayload();
      this.submitPayload(this.rlsByClaimSubmit);
    }
  }

  submitPayload(request: RlsByEmail | RlsByClaims) {
    // console.log('this is being sent to backend');
    // console.log(request);
    this.isLoading = true;
    this.rlsService.createRequest(request).subscribe({
      next: () => {
        this.isLoading = false;
        this.cdr.detectChanges();
        this.resetAfterSuccess();
        this.showSuccess(true, 'updated');
      },
      error: (err) => {
        this.isLoading = false;
        this.cdr.detectChanges();
        this.showSuccess(false, '', err.error?.error);
      },
    });
  }

  resetAfterSuccess() {
    this.datasetId.reset();
    this.resetRequestAndPermission();
    this.disableSubmit = true;
  }

  showSuccess(success: boolean, action: string, message: string = '') {
    if (success) {
      this.text = 'SUCCESS: Permissions successfully';
      this.success = true;
      this.action = action;
      this.isSuccessVisible = true;
      this.cdr.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdr.detectChanges();
      }, 10000);
    } else {
      this.text =
        message || 'ERROR: Permissions could not be successfully updated';
      this.success = false;
      this.action = action;
      this.isSuccessVisible = true;
      this.cdr.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdr.detectChanges();
      }, 10000);
    }
  }

  ensureEmailsInArry() {
    let emailRlsToConsolidate;
    this.workspaceId.value === 'bif-cost'
      ? (emailRlsToConsolidate = this.visibleEmailsRls)
      : (emailRlsToConsolidate = this.emailsRls);

    emailRlsToConsolidate.forEach((rls, index, array) => {
      if (Array.isArray(rls.emails)) {
        return;
      } else {
        let emailString: string = rls.emails;
        const emailArray = emailString
          .split(',')
          .map((email) => email.trim())
          .filter((email) => email !== '');
        array[index].emails = emailArray;
      }
    });
  }

  consolidateExactEmailGroups() {
    let emailRlsToConsolidate;
    this.workspaceId.value === 'bif-cost'
      ? (emailRlsToConsolidate = this.visibleEmailsRls)
      : (emailRlsToConsolidate = this.emailsRls);

    const result: RlsByEmailMappings[] = [];
    for (const item of emailRlsToConsolidate) {
      const sortedEmails = [...item.emails].sort();
      const key = sortedEmails.join(',');
      const existing = result.find((r) => r.emails.sort().join(',') === key);
      if (existing) {
        existing.rule_groups.push(...item.rule_groups);
      } else {
        result.push({
          emails: sortedEmails,
          rule_groups: [...item.rule_groups],
        });
      }
    }
    return result;
  }

  consolidateColumnName() {
    for (const item of this.emailsRlsToSubmit) {
      item.rule_groups = Object.values(
        item.rule_groups.reduce((acc, curr) => {
          const key = curr.column_name;
          if (!acc[key]) {
            acc[key] = { column_name: key, authorized_values: new Set() };
          }

          const values = curr.authorized_values.split(',').map((v) => v.trim());
          values.forEach((value) => acc[key].authorized_values.add(value));

          return acc;
        }, {} as Record<string, { column_name: string; authorized_values: Set<string> }>)
      ).map((group) => ({
        column_name: group.column_name,
        authorized_values: Array.from(group.authorized_values).join(','),
      }));
    }
  }

  removeBlanksClaimsRls() {
    this.claimsRlsToSubmit = [...this.claimsRls];
    this.claimsRlsToSubmit.forEach((claim, index) => {
      this.claimsRlsToSubmit[index] = claim.filter((claimDeptSubGeo) =>
        claimDeptSubGeo.authorized_values?.trim()
      );
    });
  }

  removeBlanksEmailRls() {
    this.emailsRlsToSubmit.forEach((email, index) => {
      this.emailsRlsToSubmit[index].rule_groups = email.rule_groups.filter(
        (emailColumnValue) => emailColumnValue.authorized_values?.trim()
      );
    });
  }

  createSubmitByEmailPayload() {
    this.ensureEmailsInArry();
    this.emailsRlsToSubmit = this.consolidateExactEmailGroups();
    this.consolidateColumnName();
    this.removeBlanksEmailRls();
    this.rlsByEmailSubmit = {
      workspace_id: this.workspaceId.value!,
      dataset_id: this.datasetId.value!,
      requestor_email: this.userService.userEmail,
      rls_action: 'GRANT',
      rls_by_email_mappings: this.emailsRlsToSubmit,
    };
    // console.log('Submit by Email:');
    // console.log(this.rlsByEmailSubmit);
  }

  createSubmitByAdPayload() {
    this.updateAdClaim();
    this.removeBlanksClaimsRls();
    this.rlsByClaimSubmit = {
      workspace_id: this.workspaceId.value!,
      dataset_id: this.datasetId.value!,
      requestor_email: this.userService.userEmail,
      rls_action: 'GRANT',
      rls_mappings: this.claimsRlsToSubmit,
    };
    // console.log('Submit by Claim:');
    // console.log(this.rlsByClaimSubmit);
  }

  validate() {
    if (
      // Individual Non Bif Cost
      this.datasetAccessRequest.value === 'Individual' &&
      this.workspaceId.value != 'bif-cost'
    ) {
      for (let i = 0; i < this.emailsRls.length; i++) {
        let emailRls = this.emailsRls[i];
        if (
          !emailRls.rule_groups[0].column_name &&
          emailRls.rule_groups[0].authorized_values
        ) {
          this.disableSubmit = true;
          break;
        } else if (
          !emailRls.rule_groups[0].authorized_values &&
          emailRls.rule_groups[0].column_name
        ) {
          this.disableSubmit = true;
          break;
        } else if (
          !emailRls.rule_groups[0].authorized_values &&
          !emailRls.rule_groups[0].column_name
        ) {
          this.disableSubmit = true;
          break;
        } else if (!this.isValidEmailList(emailRls.emails)) {
          this.disableSubmit = true;
          break;
        } else {
          this.disableSubmit = false;
        }
      }
    } else if (
      //Individual Bif Cost
      this.datasetAccessRequest.value === 'Individual' &&
      this.workspaceId.value === 'bif-cost'
    ) {
      for (let i = 0; i < this.emailsRls.length; i++) {
        let emailRls = this.emailsRls[i];
        if (!this.isValidEmailList(emailRls.emails)) {
          this.disableSubmit = true;
          break;
        } else {
          let errorFound = false;
          emailRls.rule_groups.forEach((rule) => {
            if (!rule.column_name && rule.authorized_values) {
              errorFound = true;
            }
            if (!rule.authorized_values && rule.column_name) {
              errorFound = true;
            }
          });
          if (errorFound) {
            this.disableSubmit = true;
            break;
          } else {
            this.disableSubmit = false;
          }
        }
      }
    } else {
      //Group
      if (this.adClaimSubDept && !this.adClaimDept) {
        this.showSubDeptError = true;
        this.showDropdownSelectionError = false;
        this.disableSubmit = true;
      } else if (
        !this.adClaimDept &&
        !this.adClaimGeo &&
        !this.adClaimSubDept
      ) {
        this.showSubDeptError = false;
        this.showDropdownSelectionError = true;
        this.disableSubmit = true;
      } else {
        this.showSubDeptError = false;
        this.showDropdownSelectionError = false;
        for (let i = 0; i < this.claimsRls.length; i++) {
          let claimRls = this.claimsRls[i];
          for (let j = 0; j < claimRls.length; j++) {
            let claimRlsRule = claimRls[j];
            let errorFoundClaim = false;
            if (
              (claimRlsRule.authorized_group === '' || null) &&
              claimRlsRule.authorized_values
            ) {
              errorFoundClaim = true;
            }
            if (
              (claimRlsRule.authorized_values === '' || null) &&
              claimRlsRule.authorized_group
            ) {
              errorFoundClaim = true;
            }
            if (errorFoundClaim) {
              this.showClaimFormError = true;
              this.disableSubmit = true;
              break;
            } else {
              this.showClaimFormError = false;
              this.disableSubmit = false;
            }
          }
          if (this.disableSubmit) {
            break;
          }
        }
      }
    }
  }
}
