export interface RuleGroup {
  authorized_values: string;
  column_name: string;
}

export interface RlsByEmailMappings {
  emails: string[];
  rule_groups: RuleGroup[];
}

export interface RlsByEmail {
  workspace_id: string;
  dataset_id: string;
  requestor_email: string;
  rls_action: 'REVOKE' | 'GRANT';
  rls_by_email_mappings: RlsByEmailMappings[];
}
