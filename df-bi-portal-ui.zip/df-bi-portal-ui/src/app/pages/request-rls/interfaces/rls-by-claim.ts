export interface RlsByClaimsMapping {
  authorized_group: string;
  authorized_values: string;
  tag_type: string;
  column_name: string;
}

export interface RlsByClaims {
  workspace_id: string;
  dataset_id: string;
  requestor_email: string;
  rls_action: 'REVOKE' | 'GRANT';
  rls_mappings: RlsByClaimsMapping[][];
}
