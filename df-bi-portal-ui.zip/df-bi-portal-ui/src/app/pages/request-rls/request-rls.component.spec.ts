import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestRlsComponent } from './request-rls.component';

describe('RequestRlsComponent', () => {
  let component: RequestRlsComponent;
  let fixture: ComponentFixture<RequestRlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RequestRlsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestRlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
