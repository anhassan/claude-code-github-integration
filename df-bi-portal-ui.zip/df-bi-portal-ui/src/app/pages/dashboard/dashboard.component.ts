import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap, RouterLink } from '@angular/router';
import { AssetService } from '@app/services/asset.service';
import { FrameOptions } from 'amazon-quicksight-embedding-sdk';
import { catchError, of, switchMap, tap } from 'rxjs';
import { AssetEmbedUrlResponse } from '@app/shared/models/embed-url';
import { EmbeddedDashboardComponent } from '@app/shared/components/embedded-dashboard/embedded-dashboard.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { HttpStatusCode } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FavouriteButtonComponent } from '@app/shared/components/favourite-button/favourite-button.component';
import { QuicksightEmbedQaComponent } from '../quicksight-embed-qa/quicksight-embed-qa.component';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    EmbeddedDashboardComponent,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatIconModule,
    RouterLink,
    FavouriteButtonComponent,
    QuicksightEmbedQaComponent,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit {
  isDashboardLoading: boolean = true;
  dashboardUrl?: string;
  dashboardName: string = 'DashboardPage';
  assetId: string = '';
  dashboardFrameOptions: Partial<FrameOptions> = {
    height: '1000px',
  };
  qUrl: string = '';
  qUrlLoaded: boolean = false;
  assetName: string = '';

  userHasDashboardAccess: boolean = true;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly assetService: AssetService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  setDashboardLoading(isDashboardLoading: boolean): void {
    this.isDashboardLoading = isDashboardLoading;
  }

  private cleanupExistingDashboard(oldAssetId?: string): void {
    if (!oldAssetId) return;

    const dashboardContainer = document.getElementById(oldAssetId);
    if (dashboardContainer) {
      dashboardContainer.innerHTML = '';
    }
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((params) => {
      this.assetName = params.get('name') || '';
    });
    this.route.paramMap
      .pipe(
        tap(() => {
          this.setDashboardLoading(true);
          this.userHasDashboardAccess = true;
        }),
        switchMap((paramMap: ParamMap) => {
          const assetId = paramMap.get('asset_id');
          if (!assetId) {
            throw new Error('Error no asset_id found in route!');
          }

          // on same page navigation, cleanup old dashboard
          this.cleanupExistingDashboard(this.dashboardName);

          this.assetId = assetId;
          return this.assetService.getAssetEmbedUrl(assetId).pipe(
            // prevent inner error from terminating outer observable subscription
            catchError((err) => {
              this.setDashboardLoading(false);
              if (err?.status === HttpStatusCode.Forbidden) {
                this.userHasDashboardAccess = false;
              } else {
                throw err;
              }

              return of({ EmbedUrl: '' });
            })
          );
        })
      )
      .subscribe({
        next: ({ EmbedUrl }: AssetEmbedUrlResponse): void => {
          this.dashboardUrl = EmbedUrl;
          this.assetService.getQueue(this.assetId).subscribe({
            next: (qUrl): void => {
              this.qUrl = qUrl.EmbedUrl;
              this.qUrlLoaded = true;
            },
            error: (err): void => {
              this.qUrlLoaded = true;
            },
          });
        },
        error: (err): void => {
          console.error(err);
          this.setDashboardLoading(false);
          this.router.navigateByUrl('/');
        },
      });
  }
}
