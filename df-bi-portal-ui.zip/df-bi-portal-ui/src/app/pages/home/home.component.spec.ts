import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { provideRouter } from '@angular/router';
import { routes } from '@app/app.routes';
import { AssetService } from '@app/services/asset.service';
import { of } from 'rxjs';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  let mockAssetService: any;

  beforeEach(async () => {
    mockAssetService = {
      getAssetEmbedUrl: jasmine
        .createSpy('getAssetEmbedUrl')
        .and.returnValue(of(new Error())),
      getRecommendedForUser: jasmine
        .createSpy('getRecommendedForUser')
        .and.returnValue(of(null)),
      getRecommendedForDepartment: jasmine
        .createSpy('getRecommendedForDepartment')
        .and.returnValue(of(null)),
    };

    await TestBed.configureTestingModule({
      imports: [HomeComponent],
      providers: [
        provideRouter(routes),
        { provide: AssetService, useValue: mockAssetService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
