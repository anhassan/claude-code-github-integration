import { AsyncPipe, TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { AssetService } from '@app/services/asset.service';
import { UserService } from '@app/services/user.service';
import {
  AssetDetail,
  AssetSearch,
  AssetSearchFilters,
  AssetSource,
  FilterOptions,
  TermsFilterRequest,
} from '@app/shared/models/asset';
import { Observable, map } from 'rxjs';

interface FilterConfig {
  fieldName: string;
  value: string;
}

@Component({
  selector: 'app-more-insights',
  standalone: true,
  imports: [AsyncPipe, TitleCasePipe, MatProgressSpinnerModule],
  templateUrl: './more-insights.component.html',
  styleUrl: './more-insights.component.scss',
})
export class MoreInsightsComponent implements OnInit {
  constructor(
    private readonly assetService: AssetService,
    private readonly router: Router,
    readonly userService: UserService
  ) {}

  filterConfigs$?: Observable<FilterConfig[] | null>;
  grouped: Record<string, AssetDetail[]> = {};
  groupedKeys: string[] = [];
  isLoading: boolean = true;
  assetIds: string[] = [];

  ngOnInit(): void {
    this.getDeptList();
    this.filterConfigs$ = this.assetService.getAssetSearchFilters().pipe(
      map(({ aggregations }: AssetSearchFilters) => aggregations),
      map(
        (options: {
          [key in keyof AssetSource as string]: FilterOptions;
        }): FilterConfig[] => {
          let configs: FilterConfig[] = [];
          for (const fieldName in options) {
            // create a filter config per option
            options[fieldName].buckets
              .map(({ key }) => key)
              .forEach((value: string) => {
                configs.push({ fieldName, value });
              });
          }
          // only get the first 10 to display
          return configs.slice(0, 10);
        }
      )
    );
  }

  getDeptList(): void {
    this.assetService.getNonInsights().subscribe((dashboards: AssetSearch) => {
      this.grouped = {};
      const assets = dashboards.hits;
      assets.forEach((dashboard) => {
        const asset = dashboard._source;
        const dept = asset.department;
        if (!this.grouped[dept]) {
          this.grouped[dept] = [];
        }
        this.grouped[dept].push(asset);
      });

      this.groupedKeys = Object.keys(this.grouped);
      this.isLoading = false;
      console.log('NEW Department Dashboards Loads');
      console.timeEnd('api-load-dept-dashboards');
    });
  }

  goToDeptDashboard(dept: string, assets: AssetDetail[]) {
    this.router.navigate(['/dashboards'], {
      queryParams: {
        dept: dept,
      },
      state: {
        assets: assets,
      },
    });
  }

  goToSearchWithFilter(config: FilterConfig): void {
    const termFilters: TermsFilterRequest[] = [
      {
        terms: {
          [config.fieldName]: [config.value],
        },
      },
    ];

    this.router.navigate(['/search-results'], {
      queryParams: {
        search_text: '',
        filters: JSON.stringify(termFilters),
      },
    });
  }
}
