import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreInsightsComponent } from './more-insights.component';

describe('MoreInsightsComponent', () => {
  let component: MoreInsightsComponent;
  let fixture: ComponentFixture<MoreInsightsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MoreInsightsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoreInsightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
