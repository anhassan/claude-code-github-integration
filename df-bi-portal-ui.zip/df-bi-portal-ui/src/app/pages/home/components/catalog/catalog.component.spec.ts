import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatalogComponent } from './catalog.component';
import { provideRouter } from '@angular/router';
import { routes } from '@app/app.routes';
import { of } from 'rxjs';
import { AssetService } from '@app/services/asset.service';

describe('CatalogComponent', () => {
  let component: CatalogComponent;
  let fixture: ComponentFixture<CatalogComponent>;
  let mockAssetService: any;

  beforeEach(async () => {
    mockAssetService = {
      getRecommendedForUser: jasmine
        .createSpy('getRecommendedForUser')
        .and.returnValue(of(null)),
      getRecommendedForDepartment: jasmine
        .createSpy('getRecommendedForDepartment')
        .and.returnValue(of(null)),
    };

    await TestBed.configureTestingModule({
      imports: [CatalogComponent],
      providers: [
        provideRouter(routes),
        { provide: AssetService, useValue: mockAssetService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(CatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
