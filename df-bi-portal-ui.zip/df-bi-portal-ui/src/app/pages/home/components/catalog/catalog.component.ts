import { AsyncPipe, CommonModule, ViewportScroller } from '@angular/common';
import {
  Component,
  OnInit,
  QueryList,
  TemplateRef,
  Type,
  ViewChildren,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AssetCardGridComponent } from '@app/shared/components/asset-card-grid/asset-card-grid.component';
import { HighlightedInsightsComponent } from '../highlighted-insights/highlighted-insights.component';
import { MoreInsightsComponent } from '../more-insights/more-insights.component';
import { Observable, forkJoin, map, switchMap, of } from 'rxjs';
import { AssetSearch } from '@app/shared/models/asset';
import { AssetService } from '@app/services/asset.service';
import { InsightsComponent } from '../insights/insights.component';

interface CatalogSection {
  jumpButtonLabel: string;
  fragment: string;
  sectionHeader: string;
  component?: Type<any>;
  data$?: Observable<AssetSearch | null>;
}

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule, AssetCardGridComponent, AsyncPipe],
  templateUrl: './catalog.component.html',
  styleUrl: './catalog.component.scss',
})
export class CatalogComponent implements OnInit {
  currentFragment?: string | null;

  sections: CatalogSection[] = [];

  @ViewChildren('sectionTemplate', { read: TemplateRef })
  sectionTemplates!: QueryList<TemplateRef<any>>;

  templateMap: { [key: string]: TemplateRef<any> } = {};

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly viewportScroller: ViewportScroller,
    private readonly assetService: AssetService
  ) {}

  jumpToSection(fragment: string): void {
    this.router.navigate([], { fragment });
    this.viewportScroller.scrollToAnchor(fragment);
  }

  ngOnInit(): void {
    this.route.fragment.subscribe((fragment: string | null): void => {
      this.currentFragment = fragment;
    });

    this.sections = [
      {
        jumpButtonLabel: 'Recommended Insights',
        fragment: 'recommended',
        sectionHeader: 'Insights',
        component: InsightsComponent,
      },
      {
        jumpButtonLabel: 'Trending Insights',
        fragment: 'trending',
        sectionHeader: 'Recommended Insights for Your Department',
        data$: this.assetService.getRecommendedForDepartment(),
      },
      {
        jumpButtonLabel: 'Highlighted Insights',
        fragment: 'highlighted',
        sectionHeader: 'Highlighted Insights by CPPIB',
        component: HighlightedInsightsComponent,
      },
      {
        jumpButtonLabel: 'More',
        fragment: 'more',
        sectionHeader: 'More',
        component: MoreInsightsComponent,
      },
    ];
  }
}
