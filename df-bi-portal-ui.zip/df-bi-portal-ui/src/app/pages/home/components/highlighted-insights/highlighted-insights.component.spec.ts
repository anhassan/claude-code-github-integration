import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HighlightedInsightsComponent } from './highlighted-insights.component';

describe('HighlightedInsightsComponent', () => {
  let component: HighlightedInsightsComponent;
  let fixture: ComponentFixture<HighlightedInsightsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HighlightedInsightsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HighlightedInsightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
