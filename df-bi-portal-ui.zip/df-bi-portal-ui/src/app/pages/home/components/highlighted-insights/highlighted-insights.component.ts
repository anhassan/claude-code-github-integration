import { AsyncPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { AssetService } from '@app/services/asset.service';
import { AssetDetail, MultiAssetByIdResponse } from '@app/shared/models/asset';
import { environment } from '@environments/environment';
import { Observable, map } from 'rxjs';

@Component({
  selector: 'app-highlighted-insights',
  standalone: true,
  imports: [AsyncPipe, MatCardModule, MatIconModule, RouterLink],
  templateUrl: './highlighted-insights.component.html',
  styleUrl: './highlighted-insights.component.scss',
})
export class HighlightedInsightsComponent implements OnInit {
  assets$?: Observable<AssetDetail[] | null>;

  constructor(private readonly assetService: AssetService) {}

  ngOnInit(): void {
    const ids = environment.highlighted_asset_ids;

    if (ids) {
      this.assets$ = this.assetService
        .getAssetsByIds(ids)
        .pipe(
          map((response: MultiAssetByIdResponse): AssetDetail[] =>
            response?.docs?.map(
              ({ _source }): AssetDetail => new AssetDetail(_source)
            )
          )
        );
    }
  }
}
