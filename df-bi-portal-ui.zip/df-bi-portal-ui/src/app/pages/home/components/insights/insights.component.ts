import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import {
  MatPaginator,
  MatPaginatorModule,
  PageEvent,
} from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AssetService } from '@app/services/asset.service';
import { AssetCardGridComponent } from '@app/shared/components/asset-card-grid/asset-card-grid.component';
import { AssetSearch } from '@app/shared/models/asset';

@Component({
  selector: 'app-insights',
  standalone: true,
  imports: [
    AssetCardGridComponent,
    MatProgressSpinnerModule,
    MatPaginator,
    MatPaginatorModule,
  ],
  templateUrl: './insights.component.html',
  styleUrl: './insights.component.scss',
})
export class InsightsComponent implements OnInit {
  constructor(
    private readonly assetService: AssetService,
    private cdr: ChangeDetectorRef
  ) {}
  ceoDashboardId = '';
  totalDashboardsToDisplay: AssetSearch | undefined;
  dashboardsToDisplay: AssetSearch | undefined;
  pageSizeOptions: number[] = [10];
  totalSearchResults: number = 0;
  pageIndex: number = 0;
  pageSize: number = 10;
  assetIds: string[] = [];
  isLoading = true;

  ngOnInit(): void {
    this.assetService.getInsights().subscribe((dashboards: AssetSearch) => {
      this.totalDashboardsToDisplay = { hits: [] };
      this.totalDashboardsToDisplay.hits = dashboards.hits;
      this.dashboardsToDisplay = { ...this.totalDashboardsToDisplay };
      this.totalSearchResults = this.dashboardsToDisplay.hits.length;
      this.dashboardsToDisplay.hits = this.dashboardsToDisplay.hits.slice(
        this.pageIndex,
        this.pageSize
      );
      this.isLoading = false;
      this.cdr.detectChanges();
      console.log('NEW Insights API Finished');
      console.timeEnd('api-load-insights');
    });
  }

  handlePageEvent(e: PageEvent) {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.dashboardsToDisplay = { ...this.totalDashboardsToDisplay! };
    this.dashboardsToDisplay.hits = this.dashboardsToDisplay.hits.slice(
      e.pageIndex * e.pageSize,
      e.pageIndex * e.pageSize + this.pageSize
    );
  }
}
