import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AssetService } from '@app/services/asset.service';
import { DefaultHeroBannerComponent } from '@app/shared/components/default-hero-banner/default-hero-banner.component';
import { EmbeddedDashboardComponent } from '@app/shared/components/embedded-dashboard/embedded-dashboard.component';
import { AssetEmbedUrlResponse } from '@app/shared/models/embed-url';
import { environment } from '@environments/environment';
import { CatalogComponent } from './components/catalog/catalog.component';
import { ContentOptions } from 'amazon-quicksight-embedding-sdk';
import { MatTabsModule } from '@angular/material/tabs';
import { Observable, catchError, map, of, tap } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { snakeCase } from 'lodash-es';
import { PopupComponent } from '../popup/popup.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { UserService } from '@app/services/user.service';
import { PopupContent } from '../customize-popup-content/popup-content';
import { User } from '@app/shared/models/user';

interface DashboardTab {
  tabTitle: string;
  dashboardName: string;
  embedUrl: Observable<string | null>;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    DefaultHeroBannerComponent,
    MatIconModule,
    EmbeddedDashboardComponent,
    MatProgressSpinnerModule,
    CatalogComponent,
    MatTabsModule,
    AsyncPipe,
    MatDialogModule,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit {
  dashboardTabs: DashboardTab[] = [];

  isDashboardLoading: boolean = false;
  homeDashboardContentOptions: ContentOptions = {
    sheetOptions: {
      singleSheet: true,
    },
  };

  user?: User;
  newTabAdded = false;

  setDashboardLoading(isDashboardLoading: boolean): void {
    this.isDashboardLoading = isDashboardLoading;
  }

  constructor(
    private readonly assetService: AssetService,
    private dialog: MatDialog,
    private readonly userService: UserService
  ) {}

  getDashboardTabEmbed(assetId: string) {
    return this.assetService.getAssetEmbedUrl(assetId).pipe(
      tap(() => {
        this.setDashboardLoading(true);
      }),
      map(({ EmbedUrl }: AssetEmbedUrlResponse) => EmbedUrl),
      catchError((err) => {
        console.error(err);
        this.setDashboardLoading(false);

        return of(null);
      })
    );
  }

  ngOnInit(): void {
    console.time('performance-dashboard');
    console.time('just-1-api-call');
    console.time('api-load-insights');
    console.time('api-load-dept-dashboards');
    this.createTabs();
    this.userService.getUser().subscribe((user: User) => {
      this.user = user;
      //this.checkHoldingsSearchTabPermissions();
    });

    const hidePopup = localStorage.getItem('hidePopup');
    if (hidePopup != 'true') {
      this.userService
        .getPopupContent()
        .subscribe((popupContent: PopupContent[]) => {
          const selectedPages = popupContent.filter((page) => page.selected);
          if (popupContent.length > 0 && selectedPages.length > 0) {
            this.openPopup(popupContent);
            sessionStorage.setItem('popupShown', 'true');
          }
        });
    }
  }

  createTabs() {
    this.dashboardTabs = environment.landing_page_dashboards.map(
      ({ tab_title, asset_id }) => ({
        tabTitle: tab_title,
        dashboardName: snakeCase(tab_title.toLowerCase()),
        embedUrl: this.getDashboardTabEmbed(asset_id),
      })
    );
  }

  // checkHoldingsSearchTabPermissions() {
  //   this.assetService
  //     .getAssetEmbedUrl(environment.holdings_search.asset_id)
  //     .subscribe({
  //       next: () => {
  //         if (
  //           !this.newTabAdded &&
  //           environment.landing_page_dashboards.length < 6
  //         ) {
  //           environment.landing_page_dashboards.push(
  //             environment.holdings_search
  //           );
  //           this.newTabAdded = true;
  //         }
  //         this.createTabs();
  //       },
  //       error: () => {
  //         this.createTabs();
  //       },
  //     });
  // }

  openPopup(popupContent: PopupContent[]) {
    this.dialog.open(PopupComponent, {
      data: {
        popup: popupContent,
      },
    });
  }
}
