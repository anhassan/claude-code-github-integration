import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveDenyAls } from './approve-deny-als.component';

describe('ApproveDenyDashboardAccessComponent', () => {
  let component: ApproveDenyAls;
  let fixture: ComponentFixture<ApproveDenyAls>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApproveDenyAls],
    }).compileComponents();

    fixture = TestBed.createComponent(ApproveDenyAls);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
