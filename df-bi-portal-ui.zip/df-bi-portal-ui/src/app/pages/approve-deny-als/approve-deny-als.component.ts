import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { EntitlementsService } from '@app/services/entitlements.service';
import { UserService } from '@app/services/user.service';
import {
  Observable,
  map,
  combineLatest,
  filter,
  switchMap,
  finalize,
} from 'rxjs';
import { RequestData } from '../approve-deny-rls/models/request-details';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-approve-deny-als',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    TextFieldModule,
    FormsModule,
    CommonModule,
    MatProgressSpinnerModule,
  ],
  templateUrl: './approve-deny-als.component.html',
  styleUrl: './approve-deny-als.component.scss',
})
export class ApproveDenyAls implements OnInit {
  constructor(
    private readonly route: ActivatedRoute,
    private readonly entitlementsService: EntitlementsService,
    private readonly userService: UserService
  ) {}

  pageData$?: Observable<RequestData | null>;
  emailedUser: string = '';
  isApiLoading = false;
  ngOnInit(): void {
    const params$ = this.route.paramMap.pipe(
      map((paramMap: ParamMap) => {
        const requestId = paramMap.get('requestId');
        if (!requestId) {
          throw new Error('Error no requestId found in route!');
        }
        const approveDeny = paramMap.get('approveDeny');
        if (!approveDeny) {
          throw new Error('Error no approveDeny found in route!');
        }
        return { requestId, approveDeny };
      })
    );

    this.pageData$ = combineLatest([
      params$,
      this.userService.userSubject.pipe(filter((user) => !!user)),
    ]).pipe(
      switchMap(([params, user]) => {
        this.isApiLoading = true;
        if (user) {
          this.emailedUser = user.email;
        }

        let apiCall$;

        switch (params.approveDeny) {
          case 'approve_whitelist':
            apiCall$ = this.entitlementsService.approveAlsWhitelistRequest(
              params.requestId,
              this.emailedUser
            );
            break;

          case 'approve_viewer':
            apiCall$ = this.entitlementsService.approveAlsViewerRequest(
              params.requestId,
              this.emailedUser
            );
            break;

          case 'deny':
            apiCall$ = this.entitlementsService.denyAlsRequest(
              params.requestId,
              this.emailedUser
            );
            break;

          default:
            throw new Error(`Unknown action: ${params.approveDeny}`);
        }

        return apiCall$.pipe(
          map((apiResponse) => ({
            apiResponse,
            requestId: params.requestId,
            approveDeny: params.approveDeny,
          })),
          finalize(() => {
            this.isApiLoading = false;
          })
        );
      })
    );
  }
}
