import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadEntitlements } from './upload-entitlements.component';

describe('UploadEntitlements', () => {
  let component: UploadEntitlements;
  let fixture: ComponentFixture<UploadEntitlements>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UploadEntitlements]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadEntitlements);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
