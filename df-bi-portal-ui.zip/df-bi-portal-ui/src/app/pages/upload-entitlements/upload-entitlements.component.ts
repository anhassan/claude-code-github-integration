import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { BannerComponent } from '../banner/banner.component';
import { CommonModule } from '@angular/common';
import { Observable, ReplaySubject } from 'rxjs';
import { AssetService } from '@app/services/asset.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '@app/services/user.service';
import { AccessDeniedComponent } from '@app/shared/components/access-denied/access-denied.component';
import { getAssetPath } from '@app/shared/utils';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-customize-popup-content',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    TextFieldModule,
    FormsModule,
    BannerComponent,
    CommonModule,
    MatProgressSpinnerModule,
    AccessDeniedComponent,
  ],
  templateUrl: './upload-entitlements.component.html',
  styleUrl: './upload-entitlements.component.scss',
})
export class UploadEntitlements implements OnInit {
  disableSubmitButton = true;
  fileTypeError = false;
  fileName = '';
  base64File = '';

  ruleAssertion = false;

  isSuccessVisible = false;
  success = true;
  action = '';
  text = '';

  isApiLoading = false;

  acceptedFileType =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

  accessGranted: boolean | undefined;
  checkingAccess = true;

  assetPathBifColumn = getAssetPath('bif_column.xlsx');
  assetPathBifDataset = getAssetPath('bif_dataset.xlsx');
  assetPathBifColumnDataset = getAssetPath('bif_columnDataset.xlsx');

  @ViewChild('fileUpload') fileUpload!: ElementRef;

  constructor(
    private readonly assetService: AssetService,
    private readonly userService: UserService
  ) {}

  ngOnInit(): void {
    this.checkingAccess = true;
    this.userService
      .checkUploadEntitlementPermission()
      .subscribe((checkingPermission) => {
        if (checkingPermission.Items.length > 0) {
          this.accessGranted = true;
        } else {
          this.accessGranted = false;
        }
        this.checkingAccess = false;
      });
  }

  uploadFile() {
    if (this.base64File.length > 1) {
      this.isApiLoading = true;
      this.assetService
        .postWorkspaceEntitlement(this.base64File, this.fileName)
        .subscribe({
          next: () => {
            this.fileUpload.nativeElement.value = '';
            this.ruleAssertion = false;
            this.showSuccess(true, 'uploaded');
            this.isApiLoading = false;
            this.disableSubmitButton = true;
          },
          error: () => {
            this.fileUpload.nativeElement.value = '';
            this.ruleAssertion = false;
            this.showSuccess(false, 'uploaded');
            this.isApiLoading = false;
            this.disableSubmitButton = true;
          },
        });
    }
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    if (file) {
      if (file.type != this.acceptedFileType) {
        this.fileTypeError = true;
        this.disableSubmitButton = true;
      } else {
        this.fileTypeError = false;
        this.fileName = file.name;
        this.convertFile(file).subscribe((output) => {
          this.base64File = output;
          if (this.ruleAssertion && this.base64File.length > 1) {
            this.disableSubmitButton = false;
          } else {
            this.disableSubmitButton = true;
          }
        });
      }
    }
  }

  onCheckboxChange(event: any) {
    this.ruleAssertion = event.target['checked'];
    if (this.ruleAssertion && this.base64File.length > 1) {
      this.disableSubmitButton = false;
    } else {
      this.disableSubmitButton = true;
    }
  }

  convertFile(file: File): Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsArrayBuffer(file);
    reader.onload = (event) => {
      const arrayBuffer = event.target?.result;
      if (arrayBuffer instanceof ArrayBuffer) {
        const bytes = new Uint8Array(arrayBuffer);
        let binary = '';
        for (const byte of bytes) {
          binary += String.fromCharCode(byte);
        }
        result.next(btoa(binary));
      }
    };
    return result;
  }

  showSuccess(success: boolean, action: string) {
    if (success) {
      this.text = 'SUCCESS! File has been successfully ';
      this.success = true;
      this.action = action;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 3000);
    } else {
      this.text = 'FAILURE! File has not been ';
      this.success = false;
      this.action = action;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 3000);
    }
  }
}
