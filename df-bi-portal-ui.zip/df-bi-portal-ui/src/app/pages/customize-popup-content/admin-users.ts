export const ADMIN_USERS = [
  'eturner@cppib.com',
  'liuruby@cppib.com',
  'jlei@cppib.com',
  'elowney@cppib.com',
  'ahassan@cppib.com',
  'ppolicepatil@cppib.com',
  'nkothari@cppib.com',
  'lingbozhao@cppib.com',
];
