import { SafeHtml } from '@angular/platform-browser';

export interface PopupContent {
  asset_id: string;
  header: string;
  body: any;
  safeBody?: SafeHtml;
  image: string;
  selected: boolean;
  imageSize?: number;
  initialImageSize?: number;
}
