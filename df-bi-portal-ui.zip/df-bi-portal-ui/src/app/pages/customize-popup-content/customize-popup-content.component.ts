import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { UserService } from '@app/services/user.service';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { PopupContent } from './popup-content';
import { BannerComponent } from '../banner/banner.component';
import { CommonModule } from '@angular/common';
import { AccessDeniedComponent } from '@app/shared/components/access-denied/access-denied.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { sortPagesByAssetId } from './popup.utils';
import { MatDialog } from '@angular/material/dialog';
import { RemovePopupModalComponent } from './remove-popup-modal/remove-popup-modal.component';
import { PopupComponent } from '../popup/popup.component';
import { Title } from '@angular/platform-browser';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NgxImageCompressService } from 'ngx-image-compress';
import { Router } from '@angular/router';
import { User } from '@app/shared/models/user';
import { ADMIN_USERS } from './admin-users';

@Component({
  selector: 'app-customize-popup-content',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    TextFieldModule,
    FormsModule,
    BannerComponent,
    CommonModule,
    AccessDeniedComponent,
    MatProgressSpinnerModule,
    DragDropModule,
    MatCheckboxModule,
  ],
  templateUrl: './customize-popup-content.component.html',
  styleUrl: './customize-popup-content.component.scss',
})
export class CustomizePopupContentComponent implements OnInit {
  @ViewChild('fileInput')
  fileInput!: ElementRef;
  isSuccessVisible = false;
  success = true;
  action = '';
  disableUpdateButton = false;
  text = '';
  isApiLoading: boolean = true;
  accessGranted: boolean | undefined;
  checkingAccess = true;
  blankPopupContent = {
    asset_id: 'pageX',
    header: '',
    body: '',
    image: '',
  };
  popupContent: PopupContent[] = [];
  isAdmin = false;

  constructor(
    private readonly userService: UserService,
    private dialog: MatDialog,
    private imageCompress: NgxImageCompressService,
    private router: Router
  ) {}

  ngOnInit(): void {
    document.body.classList.add('no-scrollblock');
    this.checkingAccess = true;
    this.userService.checkPopupPermission().subscribe((checkingPermission) => {
      if (checkingPermission.Items.length > 0) {
        this.accessGranted = true;
        this.userService.getUser().subscribe((user: User) => {
          this.isAdmin = ADMIN_USERS.some(
            (adminEmail) =>
              adminEmail.toLowerCase() === user.email.toLowerCase()
          );
        });
      } else {
        this.accessGranted = false;
      }
      this.checkingAccess = false;
    });
    this.getPopupContent();
  }

  getPopupContent() {
    this.isApiLoading = true;
    this.userService
      .getPopupContent()
      .subscribe((popupContent: PopupContent[]) => {
        this.popupContent = sortPagesByAssetId(popupContent).map((page) => ({
          ...page,
          selected: page.selected ?? true,
        }));

        this.popupContent.forEach((page, index) => {
          if (page.image && !page.imageSize) {
            const img = new Image();
            img.src = page.image;

            img.onload = () => {
              this.popupContent[index].imageSize = 100;
              this.popupContent[index].initialImageSize = 100;
            };
          } else if (page.image && page.imageSize) {
            this.popupContent[index].initialImageSize = page.imageSize;
          }
        });

        this.isApiLoading = false;
      });
  }

  drop(event: CdkDragDrop<PopupContent[]>) {
    moveItemInArray(this.popupContent, event.previousIndex, event.currentIndex);
    this.popupContent.forEach((page, index) => {
      page.asset_id = `page${index + 1}`;
    });
  }

  addPage() {
    let newPage = { ...this.blankPopupContent, selected: true };
    newPage.asset_id = `page${this.popupContent.length + 1}`;
    this.popupContent.push(newPage);
  }

  removePage(index: number) {
    if (index > -1 && index < this.popupContent.length) {
      this.popupContent.splice(index, 1);
    }
    this.popupContent.forEach((page, index) => {
      page.asset_id = `page${index + 1}`;
    });
  }

  deletePopupContent() {
    this.isApiLoading = true;
    const dialogRef = this.dialog.open(RemovePopupModalComponent);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.userService.deletePopupContent().subscribe({
          next: () => {
            this.fileInput.nativeElement.value = '';
            this.popupContent = [];
            this.showSuccess(true, 'deleted');
            this.isApiLoading = false;
          },
          error: () => {
            this.showSuccess(false, 'deleted');
            this.isApiLoading = false;
          },
        });
      }
    });
  }

  previewPopupContent() {
    const selectedPages = this.popupContent.filter((page) => page.selected);
    if (selectedPages.length === 0) {
      alert('Please select at least one page to preview.');
      return;
    }

    this.dialog.open(PopupComponent, {
      data: {
        popup: selectedPages,
      },
    });
  }

  updatePopupContent() {
    this.isApiLoading = true;
    this.userService.updatePopupContent(this.popupContent).subscribe({
      next: () => {
        this.showSuccess(true, 'updated');
        localStorage.setItem('hidePopup', 'false');
        this.isApiLoading = false;
      },
      error: () => {
        this.showSuccess(false, 'updated');
        this.isApiLoading = false;
      },
    });
  }

  removeImage(index: any) {
    this.popupContent[index].image = '';
    this.fileInput.nativeElement.value = '';
  }

  onFileSelected(event: any, index: any) {
    const file: File = event.target.files[0];
    const MAX_FILE_SIZE_KB = 300;

    const reader = new FileReader();
    reader.readAsDataURL(file);

    reader.onload = () => {
      const base64 = reader.result as string;
      const fileSizeKB = file.size / 1024;

      const setImageData = (imageData: string) => {
        const img = new Image();
        img.src = imageData;

        img.onload = () => {
          this.popupContent[index].image = imageData;
          this.popupContent[index].imageSize = 100;
          this.disableUpdateButton = false;
        };
      };

      if (fileSizeKB > MAX_FILE_SIZE_KB) {
        this.imageCompress
          .compressFile(base64, -1, 80, 100)
          .then((compressed) => {
            setImageData(compressed);
          });
      } else {
        setImageData(base64);
      }
    };
  }

  resetImageSize(index: number): void {
    const page = this.popupContent[index];
    if (page.initialImageSize) {
      page.imageSize = page.initialImageSize;
    }
  }

  showSuccess(success: boolean, action: string) {
    if (success) {
      this.text = 'SUCCESS: Popup successfully';
      this.success = true;
      this.action = action;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 3000);
    } else {
      this.text = 'ERROR: Popup could not be successfully';
      this.success = false;
      this.action = action;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 3000);
    }
  }

  goToManageAccess() {
    this.router.navigate(['/customize-popup-content/manage-access']);
  }
}
