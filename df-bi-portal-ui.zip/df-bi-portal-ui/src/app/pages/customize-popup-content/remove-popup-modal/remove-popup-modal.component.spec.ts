import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemovePopupModalComponent } from './remove-popup-modal.component';

describe('RemovePopupModalComponent', () => {
  let component: RemovePopupModalComponent;
  let fixture: ComponentFixture<RemovePopupModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RemovePopupModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RemovePopupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
