import { Component } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-remove-popup-modal',
  standalone: true,
  imports: [MatDialogModule],
  templateUrl: './remove-popup-modal.component.html',
  styleUrl: './remove-popup-modal.component.scss',
})
export class RemovePopupModalComponent {}
