import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '@app/services/user.service';
import { User } from '@app/shared/models/user';
import { ADMIN_USERS } from '../admin-users';
import { AccessDeniedComponent } from '@app/shared/components/access-denied/access-denied.component';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinner } from '@angular/material/progress-spinner';
import { BannerComponent } from '@app/pages/banner/banner.component';

@Component({
  selector: 'app-manage-customize-popup-access',
  standalone: true,
  imports: [
    AccessDeniedComponent,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    MatProgressSpinner,
    BannerComponent,
  ],
  templateUrl: './manage-customize-popup-access.component.html',
  styleUrl: './manage-customize-popup-access.component.scss',
})
export class ManageCustomizePopupAccessComponent implements OnInit {
  accessGranted = false;
  newUser: string = '';
  isLoading = true;
  allUsers: { email: string }[] = [];
  text = '';
  success = false;
  isSuccessVisible = false;

  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
    this.userService.getUser().subscribe((user: User) => {
      if (user) {
        this.accessGranted = ADMIN_USERS.some(
          (adminEmail) => adminEmail.toLowerCase() === user.email.toLowerCase()
        );
        if (!this.accessGranted) {
          this.isLoading = false;
        }
        if (this.accessGranted) {
          this.getAllUsers();
        }
      }
    });
  }

  getAllUsers() {
    this.userService.getAllPopupPermissions().subscribe((allUsers) => {
      this.allUsers = allUsers.map((u: any) => ({ email: u.email?.S }));
      this.isLoading = false;
    });
  }

  addUser() {
    this.userService.addPopupPermission(this.newUser).subscribe({
      next: () => {
        this.newUser = '';
        this.showBanner(true, 'SUCCESS: User Added');
        this.getAllUsers();
      },
      error: (error) => {
        this.showBanner(true, 'ERROR: User Could Not Be Added');
      },
    });
  }

  removeUser(email: string) {
    this.userService.removePopupPermissions(email).subscribe({
      next: () => {
        this.showBanner(true, 'SUCCESS: User Removed');
        this.getAllUsers();
      },
      error: (error) => {
        this.showBanner(true, 'ERROR: User Could Not Be Removed');
      },
    });
  }

  backToCustomize() {
    this.router.navigate(['/customize-popup-content']);
  }

  showBanner(success: boolean, text: string) {
    if (success) {
      this.text = text;
      this.success = true;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 10000);
    } else {
      this.text = text;
      this.success = false;
      this.isSuccessVisible = true;
      setTimeout(() => {
        this.isSuccessVisible = false;
      }, 10000);
    }
  }
}
