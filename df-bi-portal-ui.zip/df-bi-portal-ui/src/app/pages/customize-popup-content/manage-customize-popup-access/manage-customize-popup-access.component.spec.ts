import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageCustomizePopupAccessComponent } from './manage-customize-popup-access.component';

describe('ManageCustomizePopupAccessComponent', () => {
  let component: ManageCustomizePopupAccessComponent;
  let fixture: ComponentFixture<ManageCustomizePopupAccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageCustomizePopupAccessComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageCustomizePopupAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
