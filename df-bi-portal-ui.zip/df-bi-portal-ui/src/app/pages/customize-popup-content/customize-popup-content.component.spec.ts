import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomizePopupContentComponent } from './customize-popup-content.component';

describe('CustomizePopupContentComponent', () => {
  let component: CustomizePopupContentComponent;
  let fixture: ComponentFixture<CustomizePopupContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomizePopupContentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomizePopupContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
