import { PopupContent } from './popup-content';

export function sortPagesByAssetId(pages: PopupContent[]): PopupContent[] {
  return pages.sort((a, b) => {
    const numA = parseInt(a.asset_id.replace(/\D/g, ''), 10);
    const numB = parseInt(b.asset_id.replace(/\D/g, ''), 10);
    return numA - numB;
  });
}
