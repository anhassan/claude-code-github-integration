import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadDashboardEntitlements } from './upload-dashboard-entitlements.component';

describe('UploadEntitlements', () => {
  let component: UploadDashboardEntitlements;
  let fixture: ComponentFixture<UploadDashboardEntitlements>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UploadDashboardEntitlements]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadDashboardEntitlements);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
