import { ActivatedRoute, ParamMap, Router, RouterLink } from '@angular/router';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { TableComponent } from '@shared/components/table/table.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { ExpansionPanelComponent } from '@shared/components/expansion-panel/expansion-panel.component';
import { AssetService } from '@app/services/asset.service';
import {
  BIAsset,
  AssetDetail,
  TermsFilterRequest,
} from '@app/shared/models/asset';
import { AsyncPipe, TitleCasePipe } from '@angular/common';
import { Observable, catchError, finalize, map, of, switchMap } from 'rxjs';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ProductDetailService } from './services/product-detail.service';
import { PageData } from './models/product-detail';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FavouriteButtonComponent } from '@app/shared/components/favourite-button/favourite-button.component';
import { RequestRlsComponent } from '../request-rls/request-rls.component';
import { RlsService } from '@app/services/rls.service';
import { UserService } from '@app/services/user.service';
import { User } from '@app/shared/models/user';
import { BannerComponent } from '../banner/banner.component';
import { AlsService } from '@app/services/als.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [
    TableComponent,
    MatTabsModule,
    MatExpansionModule,
    ExpansionPanelComponent,
    AsyncPipe,
    MatButtonModule,
    MatIconModule,
    RouterLink,
    TitleCasePipe,
    MatProgressSpinnerModule,
    FavouriteButtonComponent,
    RequestRlsComponent,
    BannerComponent,
  ],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductDetailComponent implements OnInit {
  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly assetService: AssetService,
    private readonly productDetailService: ProductDetailService,
    private readonly alsService: AlsService,
    private readonly userService: UserService,
    private cdf: ChangeDetectorRef
  ) {}

  isLoading: boolean = true;
  isLoadingRequest: boolean = false;
  pageData$?: Observable<PageData | null>;
  assetId: string | null = '';
  workspace_id: string = '';
  hasAccess = false;
  text = '';
  success = false;
  action = '';
  isSuccessVisible = false;
  user!: User | null;
  assetName: string = '';

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((params) => {
      this.assetName = params.get('name') || '';
    });
    this.pageData$ = this.route.paramMap.pipe(
      switchMap((paramMap: ParamMap) => {
        this.assetId = paramMap.get('asset_id');
        if (!this.assetId) {
          throw new Error('Error no asset_id found in route!');
        }
        this.isLoading = true;

        return this.assetService.getAssetById(this.assetId).pipe(
          finalize(() => {
            this.isLoading = false;
          })
        );
      }),
      map((assetRaw: BIAsset): PageData => {
        if (!assetRaw.found || !assetRaw._source) {
          throw Error('No asset found matching that id!');
        }

        this.workspace_id = assetRaw._source.workspace_id || '';

        return this.productDetailService.getPageData(
          new AssetDetail(assetRaw._source)
        );
      }),
      catchError((err) => {
        console.error(err);
        this.router.navigateByUrl('/');
        return of(null);
      })
    );

    this.userService
      .getUser()
      .pipe(
        switchMap((user: User | null) => {
          this.user = user;
          if (!user) return of(null);
          return this.assetService
            .getUserDashboardAccess(user.email)
            .pipe(map((dashboards) => ({ dashboards })));
        })
      )
      .subscribe((result) => {
        if (result?.dashboards.includes(this.assetId)) {
          this.hasAccess = true;
          this.cdf.detectChanges();
        } else {
          this.hasAccess = false;
          this.cdf.detectChanges();
        }
      });
  }

  tagClicked(tagValue: string): void {
    const termFilters: TermsFilterRequest[] = [
      {
        terms: {
          'tags.keyword': [tagValue],
        },
      },
    ];

    this.router.navigate(['/search-results'], {
      queryParams: {
        search_text: '',
        filters: JSON.stringify(termFilters),
      },
    });
  }

  requestAccess() {
    this.isLoadingRequest = true;
    this.alsService
      .createAlsRequest(this.assetId!, this.user!.email)
      .subscribe({
        next: () => {
          this.isLoadingRequest = false;
          this.showBanner(true);
        },
        error: (error) => {
          this.isLoadingRequest = false;
          if (error.status === 504) {
            this.showBanner(true);
          } else {
            this.showBanner(false);
          }
        },
      });
  }

  showBanner(success: boolean) {
    if (success) {
      this.text = 'Access Requested';
      this.success = true;
      this.isSuccessVisible = true;
      this.cdf.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdf.detectChanges();
      }, 10000);
    } else {
      this.text = 'There was an error creating requesting access';
      this.success = false;
      this.isSuccessVisible = true;
      this.cdf.detectChanges();
      setTimeout(() => {
        this.isSuccessVisible = false;
        this.cdf.detectChanges();
      }, 10000);
    }
  }
}
