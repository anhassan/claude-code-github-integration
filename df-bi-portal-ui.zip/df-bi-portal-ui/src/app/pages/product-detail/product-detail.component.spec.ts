import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDetailComponent } from './product-detail.component';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { routes } from '@app/app.routes';
import { AssetService } from '@app/services/asset.service';
import { of } from 'rxjs';
import ASSET_DETAIL from '@assets/stubs/asset-detail.json';

describe('ProductDetailComponent', () => {
  let component: ProductDetailComponent;
  let fixture: ComponentFixture<ProductDetailComponent>;

  let mockAssetService: any;

  beforeEach(async () => {
    mockAssetService = {
      getAssetById: jasmine
        .createSpy('getAssetById')
        .and.returnValue(of(ASSET_DETAIL)),
    };

    await TestBed.configureTestingModule({
      imports: [ProductDetailComponent],
      providers: [
        provideAnimations(),
        provideRouter(routes),
        { provide: AssetService, useValue: mockAssetService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
