import { TableColumn } from '@app/shared/components/table/table.component';
import {
  CalculatedField,
  FinsightsProductOwner,
  Parameter,
  Visualization,
} from '@app/shared/models/asset';

export enum TabKeys {
  OVERVIEW = 'Overview',
  BUSINESS = 'Business Metadata',
  OPERATIONAL = 'Operational Metadata',
  LINEAGE = 'Lineage',
}

export interface VisualDataset {
  visualization_type: string;
  visual_name: string;
  dataset_name: string;
  column_name?: string;
  visual_dimension_fields: string[];
  visual_numerical_fields: string[];
}

export interface SheetTableColumns {
  visualizations: TableColumn<Visualization>[];
  parameters: TableColumn<Parameter>[];
  visualDatasets: TableColumn<VisualDataset>[];
}

export interface TableData<T> {
  title?: string;
  rows: T[];
  columnDef: TableColumn<T>[];
}

export interface SheetTableData {
  visualizations: Visualization[];
  parameters: Parameter[];
  visualDatasets: VisualDataset[];
}

export type TableSource =
  | Visualization
  | Parameter
  | VisualDataset
  | CalculatedField;

export interface PanelData {
  title: string;
  description?: string;
  tables: TableData<TableSource>[];
}

export interface BusinessMetadataTab {
  title: TabKeys.BUSINESS;
  panels: PanelData[];
}

export interface OperationalMetadataTab {
  title: TabKeys.OPERATIONAL;
  artifactSource: string;
  associatedDataProducts: string;
  rowLevelSecurity: string;
  panels: PanelData[];
}

export interface Tabs {
  overview?: {};
  businessMetadata: BusinessMetadataTab;
  operationalMetadata: OperationalMetadataTab;
  lineage?: {};
}

export interface PageData {
  assetId: string;
  isRestricted: boolean;
  assetType: string;
  dashboardName: string;
  productOwners: FinsightsProductOwner[];
  description: string;
  dashboardLastUpdated: string;
  sheetNames: string;
  tags: string[];
  tabs: Tabs;
}

/**
 * asset > page > tabs > general & panels
 * panels > title & description & tables
 * tables > title & tableData
 * tableData > rows & columnDef
 * columnDef > fieldKey & displayName
 * fieldKey & displayName > tabType
 *
 * Represents the table column mappings from sheets on each tab.
 * Each asset can have sheets. Using the mapping below and the data from a sheet,
 * a data object will be created to render the table from asset data.
 */
export const PER_TAB_SHEET_TABLES: Record<
  keyof Tabs,
  Partial<SheetTableColumns>
> = {
  overview: {},
  businessMetadata: {
    visualizations: [
      {
        fieldKey: 'visual_name',
        fallbackKey: 'visual_id',
        displayName: 'Name / Id',
      },
      { fieldKey: 'visual_description', displayName: 'Description' },
    ],
    parameters: [
      { fieldKey: 'name', displayName: 'Name' },
      { fieldKey: 'description', displayName: 'Description' },
    ],
  },
  operationalMetadata: {
    visualDatasets: [
      { fieldKey: 'visualization_type', displayName: 'Name' },
      { fieldKey: 'visual_name', displayName: 'Title' },
      { fieldKey: 'dataset_name', displayName: 'Dataset' },
      { fieldKey: 'column_name', displayName: 'Column Name' },
      {
        fieldKey: 'visual_dimension_fields',
        displayName: 'Dimension Fields',
      },
      {
        fieldKey: 'visual_numerical_fields',
        displayName: 'Numerical Fields',
      },
    ],
    parameters: [
      { fieldKey: 'name', displayName: 'Name' },
      { fieldKey: 'dataset_id', displayName: 'Dataset' },
      { fieldKey: 'source_parameter_name', displayName: 'Source' },
      { fieldKey: 'description', displayName: 'Description' },
    ],
  },
  lineage: {},
};

export const CALCULATED_FIELDS_TABLE: Record<
  keyof Tabs,
  Partial<{ calculatedFields: TableColumn<CalculatedField>[] }>
> = {
  overview: {},
  businessMetadata: {},
  operationalMetadata: {
    calculatedFields: [
      { fieldKey: 'dataset_identifier', displayName: 'Dataset' },
      { fieldKey: 'name', displayName: 'Name' },
      { fieldKey: 'expression', displayName: 'Expression' },
    ],
  },
  lineage: {},
};
