import {
  Visualization,
  Sheet,
  AssetDetail,
  CalculatedField,
  FinsightsProductOwner,
} from '@app/shared/models/asset';
import { Injectable } from '@angular/core';
import {
  VisualDataset,
  Tabs,
  PanelData,
  SheetTableData,
  TableData,
  BusinessMetadataTab,
  OperationalMetadataTab,
  PER_TAB_SHEET_TABLES,
  TabKeys,
  PageData,
  TableSource,
  CALCULATED_FIELDS_TABLE,
} from '../models/product-detail';
import { snakeCase } from 'lodash-es';

@Injectable({
  providedIn: 'root',
})
export class ProductDetailService {
  private getVisualDatasetData(
    visualizations: Visualization[] = []
  ): VisualDataset[] {
    const rows: VisualDataset[] = [];
    for (const visual of visualizations) {
      if (visual?.visual_datasets) {
        const { visual_datasets } = visual;

        for (const dataset of visual_datasets) {
          rows.push({
            visualization_type: visual.visualization_type,
            visual_name: visual.visual_name ?? visual.visual_id,
            dataset_name: dataset.name,
            column_name: dataset.column_name,
            visual_dimension_fields: dataset.visual_dimension_fields,
            visual_numerical_fields: dataset.visual_numerical_fields,
          });
        }
      }
    }

    return rows;
  }

  private getPanelDataFromSheet(tab: keyof Tabs, sheet: Sheet): PanelData {
    const sheetTableData: SheetTableData = {
      visualizations: sheet.visualizations,
      visualDatasets: this.getVisualDatasetData(sheet.visualizations),
      parameters: sheet.parameters,
    };

    const tabTables: TableData<TableSource>[] = [];

    for (const key in sheetTableData) {
      if (Object.hasOwn(sheetTableData, key)) {
        const fieldKey = key as keyof SheetTableData;
        const fieldValue = sheetTableData[fieldKey];

        // only add table tab table if specified in sheet table config and has data
        if (
          Object.hasOwn(PER_TAB_SHEET_TABLES, tab) &&
          Object.hasOwn(PER_TAB_SHEET_TABLES[tab], fieldKey) &&
          fieldValue?.length
        ) {
          tabTables.push({
            title: snakeCase(fieldKey).split('_').join(' '),
            rows: fieldValue,
            columnDef: Object(PER_TAB_SHEET_TABLES)[tab][fieldKey],
          });
        }
      }
    }

    return {
      title: sheet.name,
      description: sheet.description,
      tables: tabTables,
    };
  }

  private getPanelFromCalculatedFields(
    calculated_fields: CalculatedField[]
  ): PanelData {
    return {
      title: 'Calculated Fields',
      description:
        'Calculated fields are custom fields that you define using existing data, functions and operators to create new data insights.',
      tables: [
        {
          rows: calculated_fields,
          columnDef: Object(CALCULATED_FIELDS_TABLE)['operationalMetadata'][
            'calculatedFields'
          ],
        },
      ],
    };
  }

  private getBusinessMetadataTab(asset: AssetDetail): BusinessMetadataTab {
    const panels: PanelData[] = asset.sheets.map((sheet: Sheet) =>
      this.getPanelDataFromSheet('businessMetadata', sheet)
    );

    return {
      title: TabKeys.BUSINESS,
      panels: panels,
    };
  }

  private getOperationalMetadataTab(
    asset: AssetDetail
  ): OperationalMetadataTab {
    const panels: PanelData[] =
      asset?.sheets.map((sheet: Sheet) =>
        this.getPanelDataFromSheet('operationalMetadata', sheet)
      ) || [];

    panels.push(this.getPanelFromCalculatedFields(asset?.calculated_fields));

    return {
      title: TabKeys.OPERATIONAL,
      artifactSource: asset.artifact_source,
      associatedDataProducts: asset.associated_dp.join(),
      rowLevelSecurity: asset.row_level_security.join(),
      panels: panels,
    };
  }

  private getSheetNames(asset: AssetDetail): string[] {
    return asset?.sheets.map(({ name }): string => name);
  }

  // splits concatenated tags into separate ones
  private getTags(asset: AssetDetail): string[] {
    return asset?.tags.flatMap((tag: string) => tag.split(','));
  }

  private getProductOwners(asset: AssetDetail): FinsightsProductOwner[] {
    if (asset.finsights_detail?.product_owners?.length) {
      return asset.finsights_detail.product_owners;
    }

    return asset.owners.map(
      (name: string): FinsightsProductOwner => ({ name, email: '' })
    );
  }

  getPageData(asset: AssetDetail): PageData {
    return {
      assetId: asset.asset_id,
      isRestricted: !!asset?.is_restricted,
      assetType: asset.asset_type,
      dashboardName: asset.asset_display_name,
      productOwners: this.getProductOwners(asset),
      description: asset.description,
      dashboardLastUpdated: asset.updated_at,
      sheetNames: this.getSheetNames(asset).join(', '),
      tags: this.getTags(asset),
      tabs: {
        businessMetadata: this.getBusinessMetadataTab(asset),
        operationalMetadata: this.getOperationalMetadataTab(asset),
      },
    };
  }
}
