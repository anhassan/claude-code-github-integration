import { AsyncPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Title } from '@angular/platform-browser';
import { AssetService } from '@app/services/asset.service';
import { UserService } from '@app/services/user.service';
import { AssetCardGridComponent } from '@app/shared/components/asset-card-grid/asset-card-grid.component';
import {
  AssetDetail,
  AssetSearch,
  MultiAssetByIdResponse,
} from '@app/shared/models/asset';
import { LocalFavouriteAssets } from '@app/shared/models/favourite';
import { Observable, finalize, map, of, switchMap, tap } from 'rxjs';

@Component({
  selector: 'app-favourites',
  standalone: true,
  imports: [MatProgressSpinnerModule, AssetCardGridComponent, AsyncPipe],
  templateUrl: './favourites.component.html',
  styleUrl: './favourites.component.scss',
})
export class FavouritesComponent implements OnInit {
  isLoading: boolean = true;
  favouriteAssets$?: Observable<AssetSearch | null>;

  constructor(
    private readonly assetService: AssetService,
    private readonly userService: UserService
  ) {}

  ngOnInit(): void {
    this.favouriteAssets$ = this.userService.storeUserFavourites().pipe(
      tap(() => {
        this.isLoading = true;
      }),
      switchMap((favourites: LocalFavouriteAssets) => {
        const assetIds = Object.keys(favourites || {});

        if (assetIds.length) {
          return this.assetService.getAssetsByIds(assetIds);
        }

        return of({ docs: [] });
      }),
      map(
        (response: MultiAssetByIdResponse | null): AssetSearch => ({
          hits:
            response?.docs
              .filter((resp): boolean => !!resp?._source)
              .map(({ _source }) => ({
                _source: new AssetDetail(_source),
              })) ?? [],
        })
      ),
      finalize(() => {
        this.isLoading = false;
      })
    );
  }
}
