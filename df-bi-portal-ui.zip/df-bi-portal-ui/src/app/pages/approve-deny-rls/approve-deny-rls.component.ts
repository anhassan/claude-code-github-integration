import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { BannerComponent } from '../banner/banner.component';
import { CommonModule } from '@angular/common';
import {
  Observable,
  ReplaySubject,
  switchMap,
  map,
  catchError,
  of,
  combineLatest,
  filter,
  finalize,
} from 'rxjs';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserService } from '@app/services/user.service';
import { AccessDeniedComponent } from '@app/shared/components/access-denied/access-denied.component';
import { RequestData } from './models/request-details';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { EntitlementsService } from '@app/services/entitlements.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-approve-deny-rls',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    TextFieldModule,
    FormsModule,
    BannerComponent,
    CommonModule,
    MatProgressSpinnerModule,
    AccessDeniedComponent,
  ],
  templateUrl: './approve-deny-rls.component.html',
  styleUrl: './approve-deny-rls.component.scss',
})
export class ApproveDenyRls implements OnInit {
  constructor(
    private readonly route: ActivatedRoute,
    private readonly entitlementsService: EntitlementsService,
    private readonly userService: UserService
  ) {}

  pageData$?: Observable<RequestData | null>;
  emailedUser: string = '';
  isApiLoading = false;
  ngOnInit(): void {
    const params$ = this.route.paramMap.pipe(
      map((paramMap: ParamMap) => {
        const requestId = paramMap.get('requestId');
        if (!requestId) {
          throw new Error('Error no requestId found in route!');
        }
        const approveDeny = paramMap.get('approveDeny');
        if (!approveDeny) {
          throw new Error('Error no approveDeny found in route!');
        }
        return { requestId, approveDeny };
      })
    );

    this.pageData$ = combineLatest([
      params$,
      this.userService.userSubject.pipe(filter((user) => !!user)),
    ]).pipe(
      switchMap(([params, user]) => {
        this.isApiLoading = true;
        console.log('email:', user?.email);
        if (user) {
          this.emailedUser = user.email;
        }
        const apiCall$ =
          params.approveDeny == 'approve'
            ? this.entitlementsService.approveRlsRequest(
                params.requestId,
                this.emailedUser
              )
            : this.entitlementsService.denyRlsRequest(
                params.requestId,
                this.emailedUser
              );

        return apiCall$.pipe(
          map((apiResponse) => ({
            apiResponse,
            requestId: params.requestId,
            approveDeny: params.approveDeny,
          })),
          finalize(() => {
            this.isApiLoading = false;
          })
        );
      })
    );
  }
}
