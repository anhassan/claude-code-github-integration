import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveDenyRls } from './approve-deny-rls.component';

describe('UploadEntitlements', () => {
  let component: ApproveDenyRls;
  let fixture: ComponentFixture<ApproveDenyRls>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApproveDenyRls]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApproveDenyRls);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
