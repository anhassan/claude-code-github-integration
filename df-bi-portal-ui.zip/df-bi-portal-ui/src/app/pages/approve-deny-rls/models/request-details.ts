
export interface RequestData {
  requestId  : string;
  approveDeny  : string;
}
