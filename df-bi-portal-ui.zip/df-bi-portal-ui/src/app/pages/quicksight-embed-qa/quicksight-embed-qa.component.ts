import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, Input } from '@angular/core';
import * as QuickSightEmbedding from 'amazon-quicksight-embedding-sdk';

@Component({
  selector: 'app-quicksight-embed-qa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './quicksight-embed-qa.component.html',
  styleUrl: './quicksight-embed-qa.component.scss',
})
export class QuicksightEmbedQaComponent implements AfterViewInit {
  @Input() qUrl: string = '';
  isSearchOpened = false;
  async ngAfterViewInit() {
    const { createEmbeddingContext } = QuickSightEmbedding;

    const embeddingContext = await createEmbeddingContext({});

    const frameOptions = {
      url: this.qUrl,
      container: '#experience-container',
      height: '38px',
      width: '1000px',
      onChange: async (changeEvent: any, metadata: any) => {
        switch (changeEvent.eventName) {
          case 'FRAME_MOUNTED':
            break;
          case 'FRAME_LOADED':
            break;
        }
      },
    };

    const contentOptions = {
      panelOptions: {
        panelType: 'SEARCH_BAR' as const,
        focusedHeight: '250px',
        expandedHeight: '700px',
      },
      showTopicName: false,
      showPinboard: false,
      allowTopicSelection: false,
      allowFullscreen: true,
      searchPlaceholderText: 'Ask a question about this dashboard',

      onMessage: async (
        messageEvent: { eventName: any },
        experienceMetadata: any
      ) => {
        switch (messageEvent.eventName) {
          case 'Q_SEARCH_OPENED':
            this.isSearchOpened = true;
            break;
          case 'Q_SEARCH_FOCUSED':
            break;
          case 'Q_SEARCH_CLOSED':
            this.isSearchOpened = false;
            break;
          case 'Q_PANEL_ENTERED_FULLSCREEN':
            break;
          case 'Q_PANEL_EXITED_FULLSCREEN':
            break;
          case 'CONTENT_LOADED':
            break;
          case 'ERROR_OCCURRED':
            break;
        }
      },
    };

    await embeddingContext.embedGenerativeQnA(frameOptions, contentOptions);
  }
}
