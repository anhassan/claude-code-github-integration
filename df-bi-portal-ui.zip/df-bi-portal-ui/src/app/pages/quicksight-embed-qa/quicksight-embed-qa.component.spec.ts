import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuicksightEmbedQaComponent } from './quicksight-embed-qa.component';

describe('QuicksightEmbedQaComponent', () => {
  let component: QuicksightEmbedQaComponent;
  let fixture: ComponentFixture<QuicksightEmbedQaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuicksightEmbedQaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuicksightEmbedQaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
