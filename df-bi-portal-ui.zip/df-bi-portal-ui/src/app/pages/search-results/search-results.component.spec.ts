import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultsComponent } from './search-results.component';
import { provideRouter } from '@angular/router';
import { routes } from '@app/app.routes';
import { AssetService } from '@app/services/asset.service';
import { of } from 'rxjs';

describe('SearchResultsComponent', () => {
  let component: SearchResultsComponent;
  let fixture: ComponentFixture<SearchResultsComponent>;
  let mockAssetService: any;

  beforeEach(async () => {
    mockAssetService = {
      search: jasmine.createSpy('search').and.returnValue(of(null)),
    };

    await TestBed.configureTestingModule({
      imports: [SearchResultsComponent],
      providers: [
        provideRouter(routes),
        { provide: AssetService, useValue: mockAssetService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
