import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ActivatedRoute } from '@angular/router';
import { AssetService } from '@app/services/asset.service';
import { AssetCardGridComponent } from '@app/shared/components/asset-card-grid/asset-card-grid.component';
import { AssetSearch } from '@app/shared/models/asset';
import { of, switchMap } from 'rxjs';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import {
  DEFAULT_TOTAL_SEARCH_RESULTS,
  SEARCH_RESULTS_PAGE_SIZE_OPTIONS,
} from '@app/shared/constants';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-search-results',
  standalone: true,
  imports: [
    AssetCardGridComponent,
    MatProgressSpinnerModule,
    MatPaginator,
    MatPaginatorModule,
  ],
  templateUrl: './search-results.component.html',
  styleUrl: './search-results.component.scss',
})
export class SearchResultsComponent implements OnInit {
  constructor(
    private readonly route: ActivatedRoute,
    private readonly assetService: AssetService
  ) {}

  isLoading: boolean = true;
  searchResults?: AssetSearch | null;
  pageSizeOptions: number[] = SEARCH_RESULTS_PAGE_SIZE_OPTIONS;
  totalSearchResults: number = 0;
  searchText: string = '';
  filters: string = '';
  pageIndex: number = 0;
  pageSize: number = 10;

  ngOnInit(): void {
    this.route.queryParams
      .pipe(
        switchMap((params) => {
          this.searchText = params['search_text'];
          this.filters = params['filters'];

          const from: string =
            params['from'] || Math.abs(this.pageIndex * this.pageSize) + '';
          const size: string = params['size'] || this.pageSize + '';

          if (this.searchText || this.filters) {
            this.isLoading = true;
            return this.assetService.search(
              this.searchText,
              this.filters,
              from,
              size
            );
          }

          return of(null);
        })
      )
      .subscribe((resp: AssetSearch | null): void => {
        this.isLoading = false;
        this.searchResults = resp;
        this.totalSearchResults =
          resp?.total?.value || DEFAULT_TOTAL_SEARCH_RESULTS;
      });
  }

  handlePageEvent(e: PageEvent) {
    this.isLoading = true;
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    return this.assetService
      .search(
        this.searchText,
        this.filters,
        Math.abs(e.pageIndex * e.pageSize) + '',
        Math.abs(e.pageSize) + ''
      )

      .subscribe((resp: AssetSearch | null): void => {
        this.isLoading = false;
        this.searchResults = resp;
      });
  }
}
