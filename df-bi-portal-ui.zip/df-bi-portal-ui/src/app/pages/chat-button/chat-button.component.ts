import { CommonModule } from '@angular/common';
import {
  // AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  // ElementRef,
  // ViewChild,
} from '@angular/core';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
// import interact from 'interactjs';

@Component({
  selector: 'app-chat-button',
  standalone: true,
  imports: [CommonModule, MatIcon, MatIconModule],
  templateUrl: './chat-button.component.html',
  styleUrl: './chat-button.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChatButtonComponent {
  isChatOpen = false;
  safeUrl: SafeResourceUrl;
  firstLoad = true;

  constructor(private sanitizer: DomSanitizer) {
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl('');
  }

  private baseUrl =
    'https://chat.awb.prod.cppinvestments.io?kb=Sharepoint_FinSights&viewType=basic&assistantModel=openai%252Fgpt-5-chat-latest&assistantName=FinSights%2520Assistant&assistantWelcome=JIAgxghgdiAWCmAbADiAngewK4gO4EsAXWEY%252BEAMw0UQwKgHNS1l4BnEDCkfKARyz4ATvnYAuEAB4ARkIB8M%252BVLaEhGRnICMAOhAA5CADd8DCIXzqQ0ACYgsbCA3JcQAMV4BlE7EJtJAehU1DQAaEDYsMBIINgkEFDwiEloIa14mDCFKLCgwc3UIRB42CPYAbnCsAFsqiCE0Tm4yEABrXmsOF14qIVr8mCMIfEQIaURnGGaKYMIAWmRHcmsY2GkMOusK3AQhckIMSnbweCFCIZgq%252BFV8MA5eUgRKGfnFkGW2VfWhTbg6UgPdgJ2IQQFB4LhKPAzFhdp0smB1IR4FBCBVYH99iAnCCqplyN1Mn0LAM1lgQWxWGB8BQbv9qBxEPgWuQAIqCMAtLwMHxWKC2AAKAEEAMIAUW0ijkIEAvBuAQp2ZHIACrAfkSVyZB74DhtPmNHj8QT1MK8MCILDWcgAIncUC5PjYlv16GwWSBKmJEv80gUsh9SkkQXUDDkACZdMAoD0iZZRtgQc0ABLUNKMDg2EDCjAqN5mCAgZBqayRXxO5oAEVzblGIjAAUDoX1pvN6TeVyGiE6MDYLrA5DYaBU8CqbDCuxG-Q%252B%252BGQHGkV1w8GRObObwwtV4I95tns7D1zWWZzYVzYEt9Mvl3uVqrcGuIWtaRy6BuEaGNuTNFpAlv3eesq-OlrCL9KwLDAizyR0NUtCtl1casbkde5MBhEA3X6T1vSAA&foregroundColor=37%252C99%252C235&backgroundColor=255%252C255%252C255&robotIconBgColor=223%252C223%252C223&buttonBgColor=223%252C232%252C248&promptBarBgColor=223%252C232%252C248&promptBarFgColor=37%252C99%252C235%22';
  iframeSrc: string = this.baseUrl;

  toggleChat() {
    this.isChatOpen = !this.isChatOpen;
    if (this.firstLoad) {
      this.firstLoad = false;
      // force refresh by appending a timestamp query param
      this.iframeSrc = `${this.baseUrl}&ts=${Date.now()}`;
      this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
        this.iframeSrc
      );
    }
  }

  // @ViewChild('box', { static: true }) box!: ElementRef<HTMLElement>;
  // private destroy?: () => void;

  // ngAfterViewInit() {
  //   const el = this.box.nativeElement;
  //   const i = interact(el).resizable({
  //     edges: { left: true, right: true, bottom: true, top: true },
  //     listeners: {
  //       move: (event) => {
  //         const { width, height } = event.rect;
  //         el.style.width = `${Math.max(200, width)}px`;
  //         el.style.height = `${Math.max(140, height)}px`;
  //       },
  //     },
  //   });
  //   this.destroy = () => i.unset();
  // }
  // ngOnDestroy() {
  //   this.destroy?.();
  // }
}
