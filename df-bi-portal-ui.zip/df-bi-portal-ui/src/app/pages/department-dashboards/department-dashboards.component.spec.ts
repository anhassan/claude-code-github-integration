import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentDashboardsComponent } from './department-dashboards.component';

describe('ReleaseNotesComponent', () => {
  let component: DepartmentDashboardsComponent;
  let fixture: ComponentFixture<DepartmentDashboardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DepartmentDashboardsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DepartmentDashboardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
