import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ActivatedRoute } from '@angular/router';
import { AssetCardGridComponent } from '@app/shared/components/asset-card-grid/asset-card-grid.component';
import { AssetSearch } from '@app/shared/models/asset';

@Component({
  selector: 'app-io-dashboards',
  standalone: true,
  imports: [MatProgressSpinnerModule, AssetCardGridComponent, TitleCasePipe],
  templateUrl: './department-dashboards.component.html',
  styleUrl: './department-dashboards.component.scss',
})
export class DepartmentDashboardsComponent implements OnInit {
  department: string = '';
  dashboards: any[] = [];
  assetGrid: AssetSearch = { hits: [] };

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.department = params['dept'];
    });
    history.state.assets.forEach((asset: any) => {
      this.assetGrid.hits.push({ _source: asset });
    });
    this.dashboards = history.state.assets;
  }
}
