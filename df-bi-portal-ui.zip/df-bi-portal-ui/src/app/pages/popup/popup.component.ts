import { Component, Inject, OnInit } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import { PopupContent } from '../customize-popup-content/popup-content';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { sortPagesByAssetId } from '../customize-popup-content/popup.utils';

@Component({
  selector: 'app-popup',
  standalone: true,
  imports: [MatDialogModule, CommonModule, FormsModule, MatIconModule],
  templateUrl: './popup.component.html',
  styleUrl: './popup.component.scss',
})
export class PopupComponent implements OnInit {
  popupContent: PopupContent[] = [];
  contentLoaded = false;
  doNotShowAgain = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { popup: any[] },
    public dialogRef: MatDialogRef<PopupComponent>,
    public sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    const allPages = sortPagesByAssetId(this.data.popup);
    this.popupContent = allPages.filter((page) => page.selected);
    this.totalPages = this.popupContent.length;
    this.getPopupContent();
  }

  currentPage = 1;
  totalPages = 5;

  get pages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  getPopupContent() {
    this.popupContent.forEach((page, index) => {
      if (page.image && !page.imageSize) {
        const img = new Image();
        img.src = page.image;

        img.onload = () => {
          this.popupContent[index].imageSize = 100;
        };
      }

      if (page.body) {
        let safeBody = page.body
          .replace(/\n/g, '<br>')
          .replace(
            '<ol>',
            '<ol style="list-style: decimal; padding-left: 30px; text-align: left;">'
          )
          .replace(
            '<ul>',
            '<ul style="list-style: disc; padding-left: 30px; text-align: left;">'
          );
        page.safeBody = this.sanitizer.bypassSecurityTrustHtml(safeBody);
      }
    });
    this.contentLoaded = true;
  }

  closePopup() {
    this.dialogRef.close();
  }

  onCheckboxChange() {
    if (this.doNotShowAgain) {
      localStorage.setItem('hidePopup', 'true');
    } else {
      localStorage.setItem('hidePopup', 'false');
    }
  }
}
