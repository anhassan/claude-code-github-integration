import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { DASHBOARD_DATA } from './dashboard-tables';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-request-access',
  standalone: true,
  imports: [MatTableModule],
  templateUrl: './request-access.component.html',
  styleUrl: './request-access.component.scss',
})
export class RequestAccessComponent {
  constructor() {}

  displayedColumns: string[] = ['name', 'details', 'link'];
  dataSource = DASHBOARD_DATA;

  ngOnInit(): void {}
}
