import { DashboardInventory } from './dashboard-tables-interface';

export const DASHBOARD_DATA: DashboardInventory[] = [
  {
    name: 'Capital Usage',
    details:
      'Tracks capital usage against budgets/limits, encumbered capital balances and forward-looking capital pipeline for all active investment departments.',
    email: 'mbrasic@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Capital Reserve',
    details:
      'Tracks the amount of liquid capital, capital reserves and drivers of change in liquid capital.',
    email: 'mbrasic@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'LCR',
    details:
      'Tracks LCR, Net Coverage Assets, Net Cash Flows, Total Obligations, and Surplus Liquidity',
    email: 'ziranyang@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Regional',
    details:
      'Tracks performance, exposure, costs, and capital usage on a regional (non-CAD/US) and ID/strategy level on a quarterly basis',
    email: 'zz_totalfundinsights&analysis@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Key Markets',
    details:
      'Tracks key market index returns for global/regional equities, fixed income, FX and commodities over monthly, quarterly and FYTD/CYTD periods.',
  },
  {
    name: 'Portfolio Performance',
    details:
      'Provides a total Fund-wide view on department and strategy-level performance results against their Strategy Alternatives.',
  },

  {
    name: 'Active Equities PnL',
    details:
      'The Active Equities PnL dashboard provides day, month-to-date, quarter-to-date and fiscal year-to-date investment income/loss information.',
    email: 'jgilman@cppib.com;wdong@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'One Fund Multiplier',
    details:
      'Tracks the total fund returns for the fiscal year to date, and the previous four years, both for value-added and absolute performance, and a point-in-time One Fund multiplier.',
  },
  {
    name: 'VDIP',
    details:
      'Tracks the cumulative and election-year-to-date net returns on VDIP investments.',
  },
  {
    name: 'Performance Attribution - AE',
    details:
      'Tracks the information ratio, net income, and DVA on a 5-year, 4-year+, FYTD, and QTD basis at an ID, strategy, and sub-strategy level, along with notional assets, risk use, and encumbered capital trends.',
    email: 'jgilman@cppib.com;wdong@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Performance Attribution - CMF',
    details:
      'Tracks the information ratio, net income, and DVA on a 5-year, 4-year+, FYTD, and QTD basis at an ID, strategy, and sub-strategy level, along with risk use and encumbered capital trends.',
    email: 'carolynwu@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Performance Attribution - CI',
    details:
      'Tracks net income, net returns, performance targets, and DVA on a 5-year, 4-year+, FYTD, and QTD basis at an ID and strategy level.',
    email: 'mbrook@cppib.com;aan@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Performance Attribution - PE',
    details:
      'Tracks net income, net returns, performance targets, and DVA on a 5-year, 4-year+, FYTD, and QTD basis at an ID and strategy level, along with investment selection value-add and country/sector portfolio weighted data.',
    email: 'mbrook@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Performance Attribution - RA',
    details:
      'Tracks net income, net returns, performance targets, and DVA on a 5-year, 4-year+, FYTD, and QTD basis at an ID and strategy level, along with investment selection value-add and country/sector portfolio weighted data.',
    email: 'dmanriquechavez@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Net Assets Continuity',
    details:
      'Provides a continuity of opening and ending net investments by Department with details for purchases, sales, income, and expenses.',
    email: 'zz_totalfundinsights&analysis@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Air Travel Emissions',
    details:
      'Tracks the emissions from air travel at the department and firm-wide level.',
    email: 'dstewart@cppib.com;ZZ_PRA_BI@cppib.com',
  },
  {
    name: 'Cost Dashboard',
    details:
      'Tracks monthly department costs and key metrics over time by cost type (operating expenses, investment expenses and leverage related expenses) for each scenario (actual, budget/plan, forecast) in multiple periods (QTD, YTD, full year).  ',
    link: 'https://cppib.atlassian.net/wiki/spaces/BI/pages/309601815/Department+Cost+Dashboard+User+Guide',
  },
];
