export interface DashboardInventory {
  name: string;
  details: string;
  email?: string;
  link?: string;
}
