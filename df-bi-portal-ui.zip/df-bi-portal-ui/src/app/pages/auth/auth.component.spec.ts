import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthComponent } from './auth.component';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';
import { AuthService } from '@app/services/auth.service';

describe('AuthComponent', () => {
  let component: AuthComponent;
  let fixture: ComponentFixture<AuthComponent>;

  let mockRouter: any;
  let mockAuthService: any;
  let mockActivatedRoute: any;

  beforeEach(async () => {
    mockAuthService = {
      retrieveTokensWithAuthCode: jasmine.createSpy(
        'retrieveTokensWithAuthCode '
      ),
    };

    mockRouter = {
      navigateByUrl: jasmine.createSpy('navigateByUrl'),
    };

    mockActivatedRoute = {
      queryParams: of({
        code: 'abc123',
      }),
    };

    await TestBed.configureTestingModule({
      imports: [AuthComponent],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        {
          provide: ActivatedRoute,
          useValue: mockActivatedRoute,
        },
      ],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(AuthComponent);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
    component.ngOnInit();
    expect(mockAuthService.retrieveTokensWithAuthCode).toHaveBeenCalled();
  });
});
