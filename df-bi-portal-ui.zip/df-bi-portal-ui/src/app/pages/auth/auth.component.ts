import { Component, OnInit } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '@app/services/auth.service';
import { DefaultHeroBannerComponent } from '@app/shared/components/default-hero-banner/default-hero-banner.component';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [DefaultHeroBannerComponent, MatProgressSpinnerModule],
  templateUrl: './auth.component.html',
  styleUrl: './auth.component.scss',
})
export class AuthComponent implements OnInit {
  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params): void => {
      const authCode: string = params['code'];

      if (authCode) {
        this.authService.retrieveTokensWithAuthCode(authCode);
      } else {
        // if the user lands on this page without an authcode, redirect them to the homepage
        this.router.navigateByUrl('');
      }
    });
  }
}
