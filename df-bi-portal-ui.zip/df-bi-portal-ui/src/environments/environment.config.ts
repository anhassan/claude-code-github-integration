interface LandingPageDashboard {
  tab_title: string;
  asset_id: string;
}

export interface Environment {
  is_production: boolean;
  portal_api_url: string;
  app_url: string;
  sso_url: string;
  sso_client_id: string;
  landing_page_dashboards: LandingPageDashboard[];
  highlighted_asset_ids: string[];
  help_mailto_email: string;
  deployment_version: string;
  holdings_search: LandingPageDashboard;
}
