import { Environment } from './environment.config';

export const environment: Environment = {
  is_production: false,
  portal_api_url:
    'https://emqxwasjv6-vpce-0e69f5a9b799a2d77.execute-api.us-east-1.amazonaws.com/v1',
  sso_client_id: '4g4q34s23h5fgfvo9stm58niep',
  sso_url: 'https://cppib-central-userpool.auth.us-east-1.amazoncognito.com',
  app_url: 'https://finsights.dev.cppinvestments.io',
  landing_page_dashboards: [
    {
      tab_title: 'Performance',
      asset_id: '91cf1730-065e-4a96-a114-9350c0d1619b',
    },
    {
      tab_title: 'Holdings',
      asset_id: '31cf1891-e345-4992-96eb-8b5a20886f2c',
    },
    {
      tab_title: 'Cost',
      asset_id: '7e327c96-39ae-4d1f-9f3c-ddd33a039314',
    },
    {
      tab_title: 'Risk',
      asset_id: 'finsights_risk_dashboard-bif-ma-dev',
    },
    {
      tab_title: 'Markets',
      asset_id: '57fddfcd-39dc-4711-a680-676954bcc859',
    },
    {
      tab_title: 'Capital',
      asset_id: 'finsights_capital_dashboard-bif-ma-dev',
    },
    {
      tab_title: 'Holdings Search',
      asset_id: 'ma_holdings_search-bif-ma-bi-dev',
    },
  ],
  highlighted_asset_ids: [
    'finsights_performance_dashboard-bif-ma-dev',
    'finsights_cost_dashboard-bif-ma-dev',
  ],
  help_mailto_email: 'FinSights_Support@cppib.com',
  deployment_version: '/{DEPLOY_VERSION}', // replaced at build time to ensure build assets from the right version
  holdings_search: {
    tab_title: 'Holdings Search',
    asset_id: 'ma_holdings_search-bif-ma-bi-dev',
  },
};
