import { Environment } from './environment.config';

export const environment: Environment = {
  is_production: true,
  portal_api_url:
    'https://dhetaog6zh-vpce-0a2c1dab1e74eeb81.execute-api.us-east-1.amazonaws.com/v1',
  sso_client_id: '4g4q34s23h5fgfvo9stm58niep',
  sso_url: 'https://cppib-central-userpool.auth.us-east-1.amazoncognito.com',
  app_url: 'https://finsights.cppinvestments.io',
  landing_page_dashboards: [
    {
      tab_title: 'Performance',
      asset_id: 'finsights_performance_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Holdings',
      asset_id: 'finsights_holdings_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Cost',
      asset_id: 'finsights_cost_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Risk',
      asset_id: 'finsights_risk_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Markets',
      asset_id: 'finsights_markets_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Capital',
      asset_id: 'finsights_capital_dashboard-bif-ma-prod',
    },
    {
      tab_title: 'Holdings Search',
      asset_id: 'ma_holdings_search-bif-ma-bi-prod',
    },
  ],
  highlighted_asset_ids: [
    'finsights_performance_dashboard-bif-ma-prod',
    'finsights_cost_dashboard-bif-ma-prod',
  ],
  help_mailto_email: 'FinSights_Support@cppib.com',
  deployment_version: '/{DEPLOY_VERSION}', // replaced at build time to ensure build assets from the right version
  holdings_search: {
    tab_title: 'Holdings Search',
    asset_id: 'ma_holdings_search-bif-ma-bi-prod',
  },
};
