# Finsights Portal Frontend

## Urls

- prod: https://finsights.cppinvestments.io/
- uat: https://finsights.uat.cppinvestments.io/
- qa: https://finsights.qa.cppinvestments.io/
- dev: https://finsights.dev.cppinvestments.io/

## Associated Repos

- Backend: https://github.cppib.ca/CPPIB/bi-foundations
- IAC: https://github.cppib.ca/CPPIB/df-dashboard-service-tf
- Deployment: https://github.cppib.ca/CPPIB/dfp-tf-deploy

## Development

### Extensions

- PostCSS Language Support (csstools)
- Prettier - Code formatter (Prettier)
- Tailwind CSS IntelliSense (Tailwind Labs)

## Authentication Flow

The application is only intended to be accessed by authenticated users and therefore checks auth on startup.
https://docs.aws.amazon.com/cognito/latest/developerguide/using-pkce-in-authorization-code.html

### No Valid Tokens in LocalStorage

1. On app init or API request, check localstorage for valid tokens and find none.
2. Redirect to app auth page to initiate authentication flow.
3. Do initial PKCE auth code step and open browser to central Cognito for SSO.
4. Get redirected back to app auth page with authorization code in URL.
5. Using authorization code, make request for tokens (these are passed in the headers for all requests).
6. Persist the tokens in localstorage.
7. Redirect the user back to the original starting route with the authorization code omitted from the URL.

### Valid Refresh Token

1. On app init or API request, if expired/invalid id_token and valid refresh token.
2. Silently use refresh token to retrieve and persist valid tokens.

### Valid Tokens

1. On app init if valid tokens, do nothing.
2. On API request if valid tokens, intercept request and add token as authorization header.

## Deployment and Versioning

Deployments of the frontend application to their respective domain is handled in this repository through Github Actions.

### create_release_tag.yml

On each merge into the main branch, this Github Action workflow is triggered and will automatically generate a release for the commits merged in. The changes will also be automatically deployed to the dev environment.

The action can also be triggered manually to create a custom release. This is useful if you want to create a release to test frontend changes in a hosted environment prior to merging into main.

### deploy.yml

This action builds the frontend repo based on the specified release (if not specified it defaults to the latest). The build takes the release name and updates files in the repo to replace a placeholder. Specifically the deploy url and environment variables are updated dynamically at build time to reference the release. This is because the build files are then synced to an S3 bucket connect to cloudfront. All the build files are then put into a folder in the S3 bucket corresponding to the release name. The `index.html` from the build is put at the root of the s3 bucket, and has been dynamically updated to ensure that the javascript modules and assets will be pulled from the correct folder.

It was setup this way to ensure that people with an old version of the index.html can continue to use the application regardless of cloudfront invalidation and local cache busting.

### Higher Environments

Deployments to production require a change release, so the best practice is to create a targetted release which is used with the deploy action to move the specific intended changes for production deploy.

## Development server

Run `npm run start` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `npx ng generate component component-name` to generate a new component. You can also use `npx ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm run build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `npm run test` to execute the unit tests via [Karma](https://karma-runner.github.io).
