/** @type {import('tailwindcss').Config} */
module.exports = {
  mode: "jit",
  important: true,
  content: [
    "./src/app/pages/**/*.{html,ts}",
    "./src/app/shared/**/*.{html,ts}",
    "./src/app/*.{html,ts}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
