# v0.1

* Supports automation for: Datasets, RoleGroups, Dashboard promotion, Shared Folders
* Supports folder assignment for datasets
* Auto-configures Data Fabric data source connection
* Supports dataset refresh schedules
* Supports RLS via csv on datasets
* Supports branched dashboard promotion without url changes