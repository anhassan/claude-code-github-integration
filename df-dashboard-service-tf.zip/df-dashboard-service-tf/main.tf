locals {
  shared_conventions = jsondecode(file("${path.module}/modules/shared/quicksight_shared_naming.json"))
}

module "export_lambda" {
  for_each            = contains(["dev", "qa", "uat"], var.env_name) ? { "export" : true } : {}
  source              = "./modules/quicksight_export"
  env_name            = var.env_name
  account_id          = var.account_id
  service_name        = var.service_name
  base_tags           = var.base_tags
  aws_region          = var.aws_region
  acc_name            = var.acc_name
  associated_accounts = var.associated_accounts
  lambda_versions     = var.lambda_versions
  artifact_bucket     = var.artifact_bucket
}

module "estate" {
  source              = "./modules/estate"
  env_name            = var.env_name
  account_id          = var.account_id
  service_name        = var.service_name
  base_tags           = var.base_tags
  aws_region          = var.aws_region
  acc_name            = var.acc_name
  associated_accounts = var.associated_accounts
  admin_groups        = var.admin_groups
  vpc_info            = var.vpc_info
  vpc_id                   = var.vpc_id
  private_subnets          = var.private_subnets
  smtp_host                = var.smtp_host
  smtp_port                = var.smtp_port  
}


output "out" {
  value = {
    estate = module.estate.out
  }
}

output "quicksight_mgr_lambda" {
  value = module.estate.out.quicksight_mgr_lambda
}