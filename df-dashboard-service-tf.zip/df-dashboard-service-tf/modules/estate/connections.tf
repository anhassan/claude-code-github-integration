module "vpc_cx" {
  for_each = var.vpc_info["vpc_id"] != "DO_NOT_CREATE" ? { "vpc_connection" : true } : {}
  source   = "./vpc_cx"
  env_name = var.env_name
  vpc_connection_info = {
    vpc_id     = var.vpc_info.vpc_id
    subnet_ids = var.vpc_info.subnet_ids
  }
  connections_config = local.connections_config
}