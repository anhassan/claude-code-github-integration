locals {
}

resource "aws_quicksight_folder" "datasources" {
  folder_id = "datasources-${var.env_name}"
  name      = "datasources-${var.env_name}"

  dynamic "permissions" {
    for_each = toset(var.admin_groups)
    content {
      actions = [
        "quicksight:CreateFolder",
        "quicksight:DescribeFolder",
        "quicksight:CreateFolderMembership",
        "quicksight:DeleteFolderMembership",
        "quicksight:DescribeFolderPermissions"
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }
}

resource "aws_quicksight_folder" "subfolders" {
  for_each  = { for f, cfg in local.folder_config : f => cfg if length(split("/", f)) > 1 }
  folder_id = "${replace(each.key, "/", "-")}-${var.env_name}"
  name      = "${split("/", each.key)[1]}-${var.env_name}"

  parent_folder_arn = aws_quicksight_folder.managed_folders[split("/", each.key)[0]].arn

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "viewers", {})
    content {
      actions = [
        "quicksight:DescribeFolder"
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "owners", {})
    content {
      actions = [
        "quicksight:CreateFolder",
        "quicksight:DescribeFolder",
        "quicksight:UpdateFolder",
        "quicksight:DeleteFolder",
        "quicksight:CreateFolderMembership",
        "quicksight:DeleteFolderMembership",
        "quicksight:DescribeFolderPermissions",
        "quicksight:UpdateFolderPermissions"
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "contributors", {})
    content {
      actions = [
        "quicksight:CreateFolder",
        "quicksight:DescribeFolder",
        "quicksight:CreateFolderMembership",
        "quicksight:DeleteFolderMembership",
        "quicksight:DescribeFolderPermissions"
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }
}

resource "aws_quicksight_folder" "managed_folders" {
  for_each    = { for f, cfg in local.folder_config : f => cfg if length(split("/", f)) == 1 }
  folder_id   = "${each.key}-${var.env_name}"
  name        = "${each.key}-${var.env_name}"
  folder_type = lookup(each.value, "restricted", false) ? "RESTRICTED" : "SHARED"

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "viewers", {})
    content {
      actions = [
        "quicksight:DescribeFolder"
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "owners", {})
    content {
      actions = [
        "quicksight:CreateFolder",
        "quicksight:DescribeFolder",
        "quicksight:UpdateFolder",
        "quicksight:DeleteFolder",
        "quicksight:CreateFolderMembership",
        "quicksight:DeleteFolderMembership",
        "quicksight:DescribeFolderPermissions",
        "quicksight:UpdateFolderPermissions",
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }

  dynamic "permissions" {
    for_each = lookup(each.value.permissions, "contributors", {})
    content {
      actions = [
        "quicksight:CreateFolder",
        "quicksight:DescribeFolder",
        "quicksight:CreateFolderMembership",
        "quicksight:DeleteFolderMembership",
        "quicksight:DescribeFolderPermissions",
      ]
      principal = length(split("@", permissions.value)) > 1 ? "${local.user_arn_base}/${permissions.value}" : "${local.group_arn_base}/${permissions.value}"
    }
  }
}