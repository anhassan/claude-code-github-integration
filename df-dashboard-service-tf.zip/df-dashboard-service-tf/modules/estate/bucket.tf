resource "aws_s3_bucket" "dropbox" {
  bucket        = "${local.shared_conventions.dropbox_bucket_prefix}-${var.account_id}-${var.env_name}"
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "dropbox" {
  bucket = aws_s3_bucket.dropbox.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "dropbox" {
  bucket = aws_s3_bucket.dropbox.id
  versioning_configuration {
    status = "Enabled"
  }
}

data "aws_iam_policy_document" "dropbox_bucket_policy" {
  statement {
    sid    = "AllowQuickSightServiceRoleGet"
    effect = "Allow"
    actions = [
      "s3:ListBucket*",
    ]
    resources = [
      aws_s3_bucket.dropbox.arn
    ]
    principals {
      type        = "AWS"
      identifiers = local.admins_and_service_roles
    }
  }

  statement {
    sid    = "AllowGetQuicksight"
    effect = "Allow"
    actions = [
      "s3:Get*",
      "s3:Put*"
    ]
    resources = ["${aws_s3_bucket.dropbox.arn}/*"]
    principals {
      type        = "AWS"
      identifiers = local.admins_and_service_roles
    }
  }
}


resource "aws_s3_bucket" "main" {
  bucket        = "${local.shared_conventions.foundations_bucket_prefix}-${var.account_id}-${var.env_name}"
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "main" {
  bucket = aws_s3_bucket.main.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "main" {
  bucket = aws_s3_bucket.main.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_object" "rls_dataset" {
  for_each    = local.rls_config
  bucket      = aws_s3_bucket.main.id
  key         = each.value.rls.key
  source      = each.value.rls.path
  source_hash = filemd5(each.value.rls.path)
}

resource "aws_s3_object" "rls_manifest_files" {
  for_each     = local.rls_config
  bucket       = aws_s3_bucket.main.id
  key          = each.value.rls.manifest_key
  content_type = "application/json"
  content = jsonencode({
    "fileLocations" = [{
      "URIs" : ["s3://${aws_s3_bucket.main.id}/${each.value.rls.key}"]
    }]
  })
}

data "aws_iam_policy_document" "qs_bucket_policy" {
  statement {
    sid    = "AllowQuickSightServiceRoleGet"
    effect = "Allow"
    actions = [
      "s3:ListBucket*",
    ]
    resources = [
      aws_s3_bucket.main.arn
    ]
    principals {
      type        = "AWS"
      identifiers = [local.qs_role_arn]
    }
  }

  statement {
    sid    = "AllowGetQuicksight"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:GetObjectVersion"
    ]
    resources = ["${aws_s3_bucket.main.arn}/*"]
    principals {
      type        = "AWS"
      identifiers = [local.qs_role_arn]
    }
  }
}

resource "aws_s3_bucket_policy" "main" {
  bucket = aws_s3_bucket.main.id
  policy = data.aws_iam_policy_document.qs_bucket_policy.json
}

resource "aws_s3_bucket_policy" "dropbox" {
  bucket = aws_s3_bucket.dropbox.id
  policy = data.aws_iam_policy_document.dropbox_bucket_policy.json
}