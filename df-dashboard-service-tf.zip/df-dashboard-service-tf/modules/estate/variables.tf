variable "account_id" {}
variable "acc_name" {}
variable "aws_region" {}
variable "name_suffix" { default = "" }
variable "env_name" {}
variable "artifact_bucket" { default = "" }
variable "artifact_path" { default = "" }
variable "service_name" {
  type = string
}
variable "base_tags" {
  type = map(any)
}

variable "associated_accounts" {
  type        = map(any)
  description = "Account id map (e.g. {dev: 0123456789012 qa: 210987654321}) that can share config and artifacts.  If none are provided, artifacts will need to be manually uploaded across accounts"
  default     = { "accounts" : "MANUALLY_SHARE_ARTIFACTS" }
}

# variable "control_repo" {
#   type        = string
#   description = "The name of the repo you will use to control (make changes/push config/metadata) the infrastructure in this repo."
#   default     = "MANUALLY_PUSH_CONFIG_TO_S3"
# }

variable "vpc_info" {
  type = object({
    vpc_id     = string
    subnet_ids = list(string)
  })
  default = {
    vpc_id     = "DO_NOT_CREATE"
    subnet_ids = []
  }
}

variable "config_path" {
  type        = string
  description = "The path to config files, relative to path.root, default is \"../../../cfg\" for standard df*-deploy repo structure"
  default     = "../../../cfg"
}

variable "admin_groups" {
  type        = list(string)
  description = "The core QS Admin AD groups that will have access to the datasources folder"
}

variable "vpc_id" {
  type = string
  description = "Vpc Id of the DataFabric Vpc being provided by insights terragrunt file"
  
}

variable "private_subnets" {
  type = list(string)
}

variable "smtp_host" {
  description = "This is the host name of the smtp server"
  type = string
}

variable "smtp_port" {
  description = "This is the port used by the smtp server"
  type = string
}