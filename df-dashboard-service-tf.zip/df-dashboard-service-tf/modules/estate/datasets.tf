resource "aws_quicksight_folder_membership" "rls_dataset_folder_membership" {
  for_each    = toset(flatten([for k, v in local.rls_config : [for workspace in v.rls.metadata.workspaces : "${k}[]${workspace}"]]))
  folder_id   = aws_quicksight_folder.managed_folders[split("[]", each.value)[1]].folder_id
  member_type = "DATASET"
  member_id   = aws_quicksight_data_set.rls_datasets[split("[]", each.value)[0]].data_set_id
}

resource "aws_quicksight_data_set" "rls_datasets" {
  for_each    = local.rls_config
  import_mode = "SPICE"
  data_set_id = "${each.key}_rls_${var.env_name}"
  name        = "${each.key}_rls_${var.env_name}"

  physical_table_map {
    physical_table_map_id = replace("${each.key}-${var.env_name}", "_", "-")
    s3_source {
      data_source_arn = aws_quicksight_data_source.rls_datasets[each.key].arn
      dynamic "input_columns" {
        for_each = each.value.rls.content[0]
        content {
          name = input_columns.key
          type = "STRING"
        }
      }
      upload_settings {
        contains_header = true
        format          = "CSV"
        delimiter       = ","
        text_qualifier  = "DOUBLE_QUOTE"
      }
    }
  }
}