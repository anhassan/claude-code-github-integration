resource "aws_iam_role" "vpc_connection_role" {
  name = "bif-qs-vpc-cx-role-${var.env_name}"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = "sts:AssumeRole"
        Principal = {
          Service = "quicksight.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "qs_role_policy" {
  role = aws_iam_role.vpc_connection_role.id
  name = "QuickSightVPCConnectionRolePolicy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:CreateNetworkInterface",
          "ec2:ModifyNetworkInterfaceAttribute",
          "ec2:DeleteNetworkInterface",
          "ec2:DescribeSubnets",
          "ec2:DescribeSecurityGroups"
        ]
        Resource = ["*"]
      }
    ]
  })
}

module "security_groups" {
  for_each    = var.connections_config
  source      = "./securitygroup"
  env_name    = var.env_name
  connections = each.value
  sg_config = {
    name   = each.key
    vpc_id = var.vpc_connection_info.vpc_id
  }
}

resource "aws_quicksight_vpc_connection" "main" {
  vpc_connection_id  = "bif-vpc-cx-${var.env_name}"
  name               = "BI Foundations VPC Connection (${var.env_name})"
  role_arn           = aws_iam_role.vpc_connection_role.arn
  security_group_ids = [for k, v in module.security_groups : v.out.security_group_id]
  subnet_ids         = local.unique_az_subnets
}