variable "env_name" {}
variable "vpc_connection_info" {
  type = object({
    vpc_id     = string
    subnet_ids = list(string)
  })
  default = {
    vpc_id     = "DO_NOT_CREATE"
    subnet_ids = []
  }
}

variable "connections_config" {
  type = map(any)
}