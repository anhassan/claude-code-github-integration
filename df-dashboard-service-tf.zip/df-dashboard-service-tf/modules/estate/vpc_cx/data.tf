data "aws_subnet" "selected_subnets" {
  for_each = toset(var.vpc_connection_info.subnet_ids)
  id       = each.value
}

locals {
  # AWS requires exactly 2 subnets from different Availability Zones when setting up a VPC connection for QS
  unique_az_subnets = slice(distinct([for s in data.aws_subnet.selected_subnets : s.id]), 0, 2)
}