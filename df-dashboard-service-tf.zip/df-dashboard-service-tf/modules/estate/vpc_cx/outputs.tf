output "out" {
  value = {
    security_group_ids = [for k, v in module.security_groups : v.out.security_group_id]
    vpc_connection_arn = aws_quicksight_vpc_connection.main.arn
  }
}