variable "env_name" {}

variable "sg_config" {
  type = object({
    vpc_id = string
    name   = string
  })
}

variable "connections" {
  type = map(any)
}