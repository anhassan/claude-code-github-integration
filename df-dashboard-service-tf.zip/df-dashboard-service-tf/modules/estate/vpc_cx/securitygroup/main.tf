resource "aws_security_group" "quicksight_access" {
  name        = "quicksight_${var.sg_config.name}_${var.env_name}_sg"
  description = "Allows QuickSight service access for ${var.sg_config.name}"
  vpc_id      = var.sg_config.vpc_id

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_egress_rule" "quicksight_db_rules" {
  for_each          = toset(local.db_connections)
  security_group_id = aws_security_group.quicksight_access.id
  from_port         = split("__", each.value)[1]
  ip_protocol       = "tcp"
  to_port           = split("__", each.value)[1]
  cidr_ipv4         = split("__", each.value)[0]
}


resource "aws_vpc_security_group_egress_rule" "quicksight_office_rules" {
  for_each          = toset(local.office_connections)
  security_group_id = aws_security_group.quicksight_access.id
  from_port         = split("__", each.value)[1]
  ip_protocol       = "tcp"
  to_port           = split("__", each.value)[1]
  prefix_list_id    = split("__", each.value)[0]
}

resource "aws_vpc_security_group_egress_rule" "quicksight_aws_rules" {
  for_each          = toset(local.aws_connections)
  security_group_id = aws_security_group.quicksight_access.id
  from_port         = split("__", each.value)[1]
  ip_protocol       = "tcp"
  to_port           = split("__", each.value)[1]
  cidr_ipv4         = split("__", each.value)[0]
}

resource "aws_vpc_security_group_egress_rule" "quicksight_local_rules" {
  for_each                     = toset(local.local_connections)
  security_group_id            = aws_security_group.quicksight_access.id
  from_port                    = split("__", each.value)[1]
  ip_protocol                  = "tcp"
  to_port                      = split("__", each.value)[1]
  referenced_security_group_id = split("__", each.value)[0]
}

resource "aws_vpc_security_group_ingress_rule" "allow_vpn_prefix_quicksight_access" { # Notes: this will add global protect to impacted security group inbound rules
  ip_protocol       = "tcp"                                                           # Notes: such as TCP
  from_port         = 443                                                             # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 443                                                             # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  security_group_id = aws_security_group.quicksight_access.id                         # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_id    = data.aws_ec2_managed_prefix_list.vpn_prefix.id
  description       = "CPPIB Global Protect IP Prefix List"
}

resource "aws_vpc_security_group_ingress_rule" "allow_office_prefix_quicksight_access" { # Notes: this will add global protect to impacted security group inbound rules
  ip_protocol       = "tcp"                                                              # Notes: such as TCP
  from_port         = 443                                                                # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 443                                                                # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  security_group_id = aws_security_group.quicksight_access.id                            # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_id    = data.aws_ec2_managed_prefix_list.office_prefix.id
  description       = "CPPIB Offices IP Prefix List"
}

resource "aws_vpc_security_group_ingress_rule" "allow_vdi_prefix_quicksight_access" { # Notes: this will add global protect to impacted security group inbound rules
  ip_protocol       = "tcp"                                                           # Notes: such as TCP
  from_port         = 443                                                             # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 443                                                             # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  security_group_id = aws_security_group.quicksight_access.id                         # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_id    = data.aws_ec2_managed_prefix_list.vdi_prefix.id
  description       = "CPPIB Azure IP Prefix List"
}

output "out" {
  value = {
    security_group_id = aws_security_group.quicksight_access.id
  }
}