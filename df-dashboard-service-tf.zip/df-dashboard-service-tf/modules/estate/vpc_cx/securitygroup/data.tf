locals {
  # for excalibur/HERBI etc. -- not covered by office IP lists
  db_sources = {
    excalibur = ["10.0.0.0/8"]
    # for gen ai dashaboards (rds databases)
    awb_telemetry_rds = ["10.108.48.0/20","10.99.48.0/20"]
    chatgpt_enterprise_rds = ["10.97.60.0/24","10.97.61.0/24","10.97.62.0/24"]
  }
  # source: https://cppib.atlassian.net/wiki/spaces/CF/pages/55935544/Cloud+Foundation+Platforms+AWS+Accounts+Inventory
  account_lookups = {
    database_dev  = "10.97.84.0/22"
    database_prod = "10.99.88.0/22"
  }
  # pl ref is here https://cppib.atlassian.net/wiki/spaces/CF/pages/285343922/Customer+Managed+Prefixlist
  office_pl_names = [
    "CPPIB TFI IPs",
    "CPPIB Offices IPs",
    "CPPIB UK IPs",
    "CPPIB NYC IPs",
    "CPPIB SaoPaulo IPs",
    "CPPIB Australia IPs",
    "CPPIB Mumbai IPs",
    "CPPIB Toronto IPs",
    "CPPIB Hongkong IPs",
    "CPPIB Sanfransisco IPs",
    "CPPIB Luxemborg IPs",
  ]
  
  db_connections = flatten(flatten([
    for db, ports in lookup(var.connections, "databases", {}) : [
      for port in ports : [
        for cidr in local.db_sources[db]: "${cidr}__${port}"
      ]
    ]
  ]))

  office_connections = flatten([
    for office, ports in lookup(var.connections, "on_prem", {}) : [
      for port in ports : "${data.aws_ec2_managed_prefix_list.main[office].id}__${port}"
    ]
  ])
  aws_connections = flatten([
    for aws_conn, ports in lookup(var.connections, "aws_accounts", {}) : [
      for port in ports : "${local.account_lookups[aws_conn]}__${port}"
    ]
  ])
  local_connections = flatten([
    for sg_id, ports in lookup(var.connections, "local", {}) : [
      for port in ports : "${sg_id}__${port}"
    ]
  ])
}

data "aws_ec2_managed_prefix_list" "main" {
  for_each = lookup(var.connections, "on_prem", {})
  name     = "CPPIB ${each.key} IPs"
}

data "aws_ec2_managed_prefix_list" "vpn_prefix" { # Notes: This data section code is used to retrieve Global Protect prefix named "CPPIB Global Protect IPs"
  name = "CPPIB Global Protect IPs"
}

data "aws_ec2_managed_prefix_list" "office_prefix" {
  name = "CPPIB Offices IPs"
}

data "aws_ec2_managed_prefix_list" "vdi_prefix" {
  name = "CPPIB Azure IPs"
}
