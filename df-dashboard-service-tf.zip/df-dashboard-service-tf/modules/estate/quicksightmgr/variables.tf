variable "account_id" {}
variable "acc_name" {}
variable "aws_region" {}
variable "name_suffix" { default = "" }
variable "env_name" {}
variable "artifact_bucket" { default = "" }
variable "artifact_path" { default = "" }
variable "service_name" {
  type = string
}
variable "base_tags" {
  type = map(any)
}

variable "quicksight_config_bucket" {
  type = string
}

variable "associated_accounts" {
  type        = map(any)
  description = "Account id map (e.g. {dev: 0123456789012 qa: 210987654321}) that can share config and artifacts.  If none are provided, artifacts will need to be manually uploaded across accounts"
  default     = { "accounts" : "MANUALLY_SHARE_ARTIFACTS" }
}

variable "vpc_connection_arn" {
  type        = string
  description = "Arn of the VPC connection"
  default     = "NO_VPC_CONNECTION"
}

variable "tmp_artifacts_bucket" {
  type    = string
  default = "cppib-df-tmp-artifacts-bucket"
}

variable "bif_version" {
  type    = string
  default = "latest"
}

variable "default_admin_group" {
  type = string
}

variable "secret_arns" {
  type    = list(string)
  default = []
}

variable "vpc_id" {
  type = string
  description = "Vpc Id of the DataFabric Vpc being provided by insights terragrunt file"
  
}

variable "private_subnets" {
  type = list(string)
}

variable "smtp_host" {
  description = "This is the host name of the smtp server"
  type = string
}

variable "smtp_port" {
  description = "This is the port used by the smtp server"
  type = string
}
