resource "aws_lambda_function" "qs_mgr" {
  function_name                  = "df-quicksight-mgr-${var.env_name}"
  role                           = aws_iam_role.qs_manager_role.arn
  package_type                   = "Zip"
  handler                        = "quicksight_mgr.handler.handler"
  s3_bucket                      = var.tmp_artifacts_bucket
  s3_key                         = local.mgr_artifact_path
  s3_object_version              = data.aws_s3_object.pkg.version_id
  runtime                        = "python3.12"
  timeout                        = 300
  reserved_concurrent_executions = 1

  vpc_config {
    subnet_ids         = var.private_subnets                                     # List of subnet IDs
    security_group_ids = [aws_security_group.qs_mgr_sg.id]                       # List of security group IDs
  }

  environment {
    variables = {
      CONFIG_BUCKET       = var.quicksight_config_bucket
      ARTIFACT_PREFIX     = local.shared_conventions.quicksight_ops_prefix
      ACCOUNT_ID          = var.account_id
      VPC_CONNECTION_ARN  = var.vpc_connection_arn
      ENV_NAME            = var.env_name
      DEFAULT_ADMIN_GROUP = var.default_admin_group
      ARTIFACTS_BUCKET    = local.shared_conventions.central_dashboard_definition_bucket
      DROPBOX_BUCKET      = "${local.shared_conventions.dropbox_bucket_prefix}-${var.account_id}-${var.env_name}"
      SMTP_HOST           = var.smtp_host
      SMTP_PORT           = var.smtp_port
    }
  }
}

resource "aws_iam_role" "qs_manager_role" {
  name               = "${local.shared_conventions.quicksight_mgr_role_prefix}-${var.env_name}"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume_policy.json
  inline_policy {
    name   = "quicksight-admin"
    policy = data.aws_iam_policy_document.qs_mgr.json
  }
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
  ]
}