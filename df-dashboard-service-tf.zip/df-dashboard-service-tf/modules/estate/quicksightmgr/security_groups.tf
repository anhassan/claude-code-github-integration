resource "aws_security_group" "qs_mgr_sg" {
  name        = "df-quicksight-mgr-${var.env_name}-sg"
  description = "Security group for Quicksight Manager Lambda"
  vpc_id      = var.vpc_id # Make sure to define this variable

  tags = {
    Name = "quicksight-manager-lambda-security-group"
  }

  lifecycle {
    create_before_destroy = true
  }

  # Outbound rule to the data-discovery-elasticsearch-dev security group  
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound traffic"
  }
}