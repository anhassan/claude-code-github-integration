output "out" {
  value = {
    mgr = aws_lambda_function.qs_mgr
  }
}