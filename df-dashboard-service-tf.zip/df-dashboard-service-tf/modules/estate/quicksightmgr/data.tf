locals {
  shared_conventions = jsondecode(file("${path.module}/../../shared/quicksight_shared_naming.json"))
  qs_role_arn        = "arn:aws:iam::${var.account_id}:role/service-role/aws-quicksight-service-role-v0"
  mgr_artifact_path  = "bi-foundations/${var.bif_version}/lambda/quicksight_mgr.zip"
  secret_arns        = var.secret_arns
}

data "aws_s3_object" "pkg" {
  bucket = var.tmp_artifacts_bucket
  key    = local.mgr_artifact_path
}