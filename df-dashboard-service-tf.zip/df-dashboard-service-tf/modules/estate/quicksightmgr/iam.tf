data "aws_iam_policy_document" "lambda_assume_policy" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "qs_mgr" {
  statement {
    actions   = ["quicksight:*"]
    resources = ["*"]
  }
  statement {
    actions = ["s3:Get*", "s3:List*", "s3:Put*"]
    resources = [
      "arn:aws:s3:::${local.shared_conventions.central_dashboard_definition_bucket}",
      "arn:aws:s3:::${local.shared_conventions.central_dashboard_definition_bucket}/*",
      "arn:aws:s3:::cppib-df-ramcdashboard-${var.env_name}",
      "arn:aws:s3:::cppib-df-ramcdashboard-${var.env_name}/*"
    ]
  }
  statement {
    actions = [
      "sso:CreateApplicationAssignment",
      "sso:DeleteApplicationAssignment",
      "user-subscriptions:CreateClaim",
      "user-subscriptions:UpdateClaim"
    ]
    resources = ["*"]
  }

  statement {
      actions = [
          "secretsmanager:GetResourcePolicy",
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret",
          "secretsmanager:ListSecretVersionIds",
          "secretsmanager:ListSecrets"
      ]
      effect = "Allow"
      resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  
  } 

  dynamic "statement" {
    for_each = length(local.secret_arns) != 0 ? { "create" : true } : {}
    content {
      actions = [
        "secretsmanager:GetSecretValue"
      ]
      resources = local.secret_arns
    }
  }
}