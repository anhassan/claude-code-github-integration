resource "aws_iam_role_policy" "qs_update_policy" {
  name   = "df-quicksight-policy-${var.env_name}"
  policy = data.aws_iam_policy_document.qs_service_role_updates.json
  role   = local.qs_role_name
}

resource "aws_iam_role_policy" "qs_sm_update_policy" {
  name   = "df-quicksight-policy-${var.env_name}"
  policy = data.aws_iam_policy_document.qs_service_role_updates.json
  role   = local.qs_secrets_role_name
}

data "aws_iam_policy_document" "qs_service_role_updates" {
  statement {
    effect = "Allow"
    actions = [
      "s3:ListAllMyBuckets"
    ]
    resources = ["arn:aws:s3:::*"]
  }

  statement {
    actions = [
      "s3:ListBucket*",
      "s3:ListBucketMultipartUploads",
      "s3:GetBucketLocation"
    ]
    resources = [
      aws_s3_bucket.main.arn,
      "arn:aws:s3:::${local.athena_bucket}"
    ]
  }

  statement {
    actions = [
      "s3:Get*",
      "s3:GetObjectVersion"
    ]
    resources = [
      "${aws_s3_bucket.main.arn}/*",
      "arn:aws:s3:::${local.athena_bucket}/*"
    ]
  }

  statement {
    actions = [
      "s3:PutObject",
      "s3:AbortMultipartUpload",
      "s3:ListMultipartUploadParts"
    ]
    resources = [
      "arn:aws:s3:::${local.athena_bucket}/*"
    ]
  }

  dynamic "statement" {
    for_each = length(local.secret_arns) != 0 ? { "create" : true } : {}
    content {
      actions = [
        "secretsmanager:GetSecretValue"
      ]
      resources = local.secret_arns
    }
  }
}
