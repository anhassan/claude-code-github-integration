locals {
  # global config
  permission_set_name = "CPPIB-Quicksight-Admin"
  config_path         = "${path.root}/${var.config_path}"
  shared_conventions  = jsondecode(file("${path.module}/../shared/quicksight_shared_naming.json"))

  # group filesets by directory -- directories establish top-level hierarchy
  dataset_fileset = fileset("${local.config_path}/datasets", "**")
  dataset_dirs    = toset([for f in local.dataset_fileset : dirname(f)])
  folder_files    = fileset("${local.config_path}/workspaces", "**")
  folder_dirs     = toset([for f in local.folder_files : dirname(f)])

  # these could be done with nested list comps but keeping it simple for readability
  access             = fileset("${local.config_path}/access", "**")
  access_config      = { for f in local.access : "${split(".", f)[0]}" => yamldecode(file("${local.config_path}/access/${f}")) }
  connections        = fileset("${local.config_path}/connections", "**")
  connections_config = { for f in local.connections : "${split(".", f)[0]}" => yamldecode(file("${local.config_path}/connections/${f}")) }
  datasources        = fileset("${local.config_path}/datasources", "**")
  datasource_config  = { for f in local.datasources : "${split(".", f)[0]}" => yamldecode(file("${local.config_path}/datasources/${f}")) }

  # group config by directories as well
  folder_config = { for f in local.folder_dirs : f => {
    for fi in fileset("${local.config_path}/workspaces/${f}", "*") : split(".", fi)[0] => yamldecode(file("${local.config_path}/workspaces/${f}/${fi}"))
  } }

  dashboard_files  = flatten([for f in local.folder_dirs : [for fi in fileset("${local.config_path}/workspaces/${f}", "*_dashboard.yaml") : "${f}/${fi}"]])
  dashboard_config = { for f in local.dashboard_files : "${split(".", f)[0]}" => yamldecode(file("${local.config_path}/workspaces/${f}")) }

  datasets_config = { for f in local.dataset_dirs : f => {
  "metadata" : yamldecode(file("${local.config_path}/datasets/${f}/metadata.yaml")),
  "query" : fileexists("${local.config_path}/datasets/${f}/query.sql") ? file("${local.config_path}/datasets/${f}/query.sql") : null,
  "rls" : fileexists("${local.config_path}/datasets/${f}/rls.yaml") ? yamldecode(file("${local.config_path}/datasets/${f}/rls.yaml")) : {},
  "cls" : fileexists("${local.config_path}/datasets/${f}/cls.yaml") ? yamldecode(file("${local.config_path}/datasets/${f}/cls.yaml")) : {},
  "s3_manifest" : fileexists("${local.config_path}/datasets/${f}/s3_manifest.yaml") ? yamldecode(file("${local.config_path}/datasets/${f}/s3_manifest.yaml")) : {}

} }
  rls_config = { for f in local.dataset_dirs : f => {
    "rls" : {
      "metadata" : yamldecode(file("${local.config_path}/datasets/${f}/metadata.yaml")),
      "path" : "${local.config_path}/datasets/${f}/rls.csv",
      "key" : "row_level_security/${f}/rls.csv",
      "content" : csvdecode(file("${local.config_path}/datasets/${f}/rls.csv")),
      "manifest_key" : "rls_manifest/${f}/manifest.json"
    }
  } if fileexists("${local.config_path}/datasets/${f}/rls.csv") }

  # role_config = yamldecode(file("${local.config_path}/role_groups/role_groups.yaml"))

  # AWS resource name patterns
  qs_role_name         = "aws-quicksight-service-role-v0"
  qs_secrets_role_name = "aws-quicksight-secretsmanager-role-v0"
  qs_role_arn          = "arn:aws:iam::${var.account_id}:role/service-role/${local.qs_role_name}"
  qs_secrets_role_arn  = "arn:aws:iam::${var.account_id}:role/service-role/${local.qs_secrets_role_name}"
  dataset_arn_base     = "arn:aws:quicksight:${var.aws_region}:${var.account_id}:dataset/"
  group_arn_base       = "arn:aws:quicksight:${var.aws_region}:${var.account_id}:group/default"
  user_arn_base        = "arn:aws:quicksight:${var.aws_region}:${var.account_id}:user/default"
  # prefer to use one() for this sort of thing but only supported in 0.15+
  admin_permission_set_arn = length(tolist(data.aws_iam_roles.roles.arns)) > 0 ? tolist(data.aws_iam_roles.roles.arns)[0] : ""

  admins_and_service_roles = [local.qs_role_arn]
  #removed local.admin_permission_set_arn
  secret_arns = [for source, config in local.datasource_config : config.secret_arn]
}

data "aws_iam_roles" "roles" {
  name_regex  = "AWSReservedSSO_${local.permission_set_name}_.*"
  path_prefix = "/aws-reserved/sso.amazonaws.com/"
}
