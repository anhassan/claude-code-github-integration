module "mgr" {
  source                   = "./quicksightmgr"
  quicksight_config_bucket = aws_s3_bucket.main.id
  env_name                 = var.env_name
  account_id               = var.account_id
  service_name             = var.service_name
  base_tags                = var.base_tags
  aws_region               = var.aws_region
  acc_name                 = var.acc_name
  associated_accounts      = var.associated_accounts
  default_admin_group      = var.admin_groups[0]
  secret_arns              = local.secret_arns
  vpc_connection_arn       = var.vpc_info["vpc_id"] != "DO_NOT_CREATE" ? module.vpc_cx["vpc_connection"].out.vpc_connection_arn : "NO_VPC_CONNECTION"
  vpc_id                   = var.vpc_id
  private_subnets          = var.private_subnets
  smtp_host                = var.smtp_host
  smtp_port                = var.smtp_port  
}

resource "aws_lambda_invocation" "datasets" {
  for_each      = local.datasets_config
  function_name = module.mgr.out.mgr.function_name

  input = jsonencode({
    resource = "dataset"
    payload = {
      force_sync = lookup(each.value.metadata, "force_sync", false) == true ? "${timestamp()}" : "false"
      id         = each.value.metadata.name
      account_id = var.account_id
      rls        = each.value.rls
      cls        = each.value.cls
      s3_manifest = each.value.s3_manifest
      config = {
        name                  = each.value.metadata.name
        import_mode           = each.value.metadata.import_mode
        physical_table_map_id = replace("${each.value.metadata.name}_${var.env_name}", "_", "-")
        # enable using data_source_arn only in dfp-tf-deploy since we're saying that any dataset defined with the arn can use the data
        data_source_arn = lookup(each.value.metadata, "data_source_arn", aws_quicksight_data_source.fabric.arn)
        sql_query = each.value.query != null ? (
        var.env_name == "prod" ?
          replace(each.value.query, "_ENV", "") :
          replace(each.value.query, "ENV", var.env_name)) : "false"
        columns         = each.value.metadata.columns
        folders         = [for f in each.value.metadata.workspaces : "${f}-${var.env_name}"]
        dataset_source = lookup(each.value.metadata, "data_source", null)
      }
    }
  })
}

resource "aws_lambda_invocation" "dashboards" {
  for_each      = local.dashboard_config
  function_name = module.mgr.out.mgr.function_name

  input = jsonencode({
    resource = "dashboard"
    payload = {
      force_sync        = lookup(each.value, "force_sync", false) == true ? "${timestamp()}" : "false"
      dev_account_id    = var.associated_accounts["dev"]
      account_id        = var.account_id
      s3_definition_key = each.value.version != "latest" ? "${each.value.base_dashboard_name}/${each.value.branch}/V${each.value.version}/dashboard_definition.json" : "${each.value.base_dashboard_name}/${each.value.branch}/latest/dashboard_definition.json"
      config = {
        workspace    = []
        owners       = lookup(each.value, "owners", [])
        viewers      = lookup(each.value, "viewers", [])
        display_name = each.value.display_name
        use_fixed    = lookup(each.value, "use_fixed", false)
      }
      id      = "${each.value.id_prefix}-${var.env_name}"
      version = each.value.version
    }
  })
}

# resource "aws_lambda_invocation" "rolegroups" {
#   function_name = module.mgr.out.mgr.function_name

#   input = jsonencode({
#     resource = "rolegroup"
#     payload = {
#       # timestamp      = "${timestamp()}"
#       dev_account_id = var.associated_accounts["dev"]
#       account_id     = var.account_id
#       config         = local.role_config
#     }
#   })
# }

resource "aws_lambda_invocation" "rls_refresh" {
  for_each      = local.rls_config
  function_name = module.mgr.out.mgr.function_name

  triggers = {
    redeploy = sha1(jsonencode(aws_s3_object.rls_dataset))
  }

  input = jsonencode({
    resource = "ingestion"
    payload = {
      id = aws_quicksight_data_set.rls_datasets[each.key].data_set_id
      config = {
        ingestion_type = "FULL_REFRESH"
      }
    }
  })
}

resource "aws_lambda_invocation" "dataset_refresh" {
  for_each      = { for dataset, config in local.datasets_config : dataset => config if lookup(config.metadata, "refresh_schedule", "N/A") != "N/A" }
  function_name = module.mgr.out.mgr.function_name

  input = jsonencode({
    resource = "refresh_schedule"
    payload = {
      id = each.value.metadata.name
      config = {
        schedule_info = each.value.metadata.refresh_schedule
      }
    }
  })
}

# requires update from QuickSight service to enable programmatic
# setup of secrets access

# resource "aws_lambda_invocation" "datasources" {
#   for_each      = local.datasource_config
#   function_name = module.mgr.out.mgr.function_name

#   input = jsonencode({
#     resource = "data_source"
#     payload = {
#       id = "${each.key}-${each.value.name}-${var.env_name}"
#       config = {
#         name       = each.value.name
#         type       = each.value.type
#         secret_arn = each.value.secret_arn
#         parameters = each.value.parameters
#         folder_id  = aws_quicksight_folder.datasources.folder_id
#       }
#     }
#   })
# }