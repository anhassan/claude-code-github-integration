output "out" {
  value = {
    # datasets = { for k, v in local.datasets_config : k => v["metadata"] }
    quicksight_mgr_lambda = module.mgr.out.mgr
    folders               = local.folder_config
    # personas   = local.role_config
    dashboards = local.dashboard_config
  }
}