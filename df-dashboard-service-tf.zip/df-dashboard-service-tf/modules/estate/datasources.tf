locals {
  athena_bucket = "aws-athena-query-results-${var.account_id}-${var.aws_region}"
}

resource "aws_athena_workgroup" "quicksight_group" {
  name = "quicksight_wg_${var.env_name}"

  configuration {
    enforce_workgroup_configuration    = true
    publish_cloudwatch_metrics_enabled = true

    result_configuration {
      output_location = "s3://${local.athena_bucket}"
      encryption_configuration {
        encryption_option = "SSE_S3"
      }
    }
  }

  force_destroy = true
}

resource "aws_quicksight_data_source" "fabric" {
  data_source_id = "fabric_catalog_${var.env_name}"
  name           = "Fabric Catalog Access"

  type = "ATHENA"
  parameters {
    athena {
      work_group = aws_athena_workgroup.quicksight_group.id
    }
  }
  ssl_properties {
    disable_ssl = false
  }
}

resource "aws_quicksight_folder_membership" "datasource_folder_member" {
  folder_id   = aws_quicksight_folder.datasources.folder_id
  member_type = "DATASOURCE"
  member_id   = aws_quicksight_data_source.fabric.data_source_id
}

resource "aws_quicksight_data_source" "rls_datasets" {
  for_each       = local.rls_config
  data_source_id = "${each.key}_rls_${var.env_name}"
  name           = "${each.key}_rls_${var.env_name}"

  type = "S3"
  parameters {
    s3 {
      manifest_file_location {
        bucket = aws_s3_bucket.main.id
        key    = each.value.rls.manifest_key
      }
    }
  }
}