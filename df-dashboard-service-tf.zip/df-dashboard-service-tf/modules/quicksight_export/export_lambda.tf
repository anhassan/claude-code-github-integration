resource "aws_lambda_function" "quicksight_export" {
  function_name     = "df-quicksight-export-${var.env_name}"
  role              = aws_iam_role.quicksight_export_role.arn
  handler           = "${local.export_lambda_name_base}.main.lambda_handler"
  s3_bucket         = data.aws_s3_object.qs_publish_export_lambda.bucket
  s3_key            = data.aws_s3_object.qs_publish_export_lambda.key
  s3_object_version = data.aws_s3_object.qs_publish_export_lambda.version_id

  runtime = "python3.12"
  timeout = 300

  depends_on = [data.aws_s3_object.qs_publish_export_lambda]
  environment {
    variables = {
      BUCKET_NAME = local.published_dashboard_bucket
      ACCOUNT_ID  = var.account_id
    }
  }
}

resource "aws_iam_role" "quicksight_export_role" {
  name               = "df-quicksight-export-role-${var.env_name}"
  assume_role_policy = data.aws_iam_policy_document.dashboard_service_policy_document.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
  ]
}

resource "aws_iam_role_policy" "export_dashboard_bucket_access_policy" {
  name = "published-dashboard-bucket-access-policy-${var.env_name}"
  role = aws_iam_role.quicksight_export_role.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = [
          "s3:Get*",
          "s3:Put*"
        ]
        Effect = "Allow"
        Resource = [
          "${local.published_dashboard_bucket_arn}",
          "${local.published_dashboard_bucket_arn}/*"
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy" "published_dashboard_export_policy" {
  name = "published-dashboard-quicksight-export-policy-${var.env_name}"
  role = aws_iam_role.quicksight_export_role.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = [
          "quicksight:DescribeDashboard",
          "quicksight:DescribeTheme",
          "quicksight:ListThemes",
          "quicksight:Start*",
          "quicksight:Describe*",
          "quicksight:*"
        ]
        Effect   = "Allow"
        Resource = "*"
      }
    ]
  })
}
