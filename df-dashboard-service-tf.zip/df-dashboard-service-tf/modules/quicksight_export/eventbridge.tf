resource "aws_cloudwatch_event_rule" "publish_event" {
  name        = "quicksight_publish_event"
  description = "Quicksight Dashboard or Theme Publish Event"
  role_arn    = aws_iam_role.publish_event_role.arn

  event_pattern = jsonencode({
    source = ["aws.quicksight"],
    detail-type = [
      "QuickSight Dashboard Published Version Updated",
      "QuickSight Dashboard Update Successful",
      "QuickSight Dashboard Creation Successful",
      "QuickSight Theme creation successful",
      "QuickSight Theme update successful",
      "QuickSight Theme Creation Successful",
      "QuickSight Theme Update Successful",
      #   "QuickSight Analysis Creation Successful",
      #   "QuickSight Analysis update successful"
    ]
  })
}

resource "aws_iam_role" "publish_event_role" {
  name               = "df-quicksight-publish-event-role-${var.env_name}"
  assume_role_policy = data.aws_iam_policy_document.dashboard_service_policy_document.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]
}

resource "aws_cloudwatch_event_target" "publish_event" {
  rule = aws_cloudwatch_event_rule.publish_event.name
  arn  = aws_lambda_function.quicksight_export.arn
}

resource "aws_lambda_permission" "eventbridge_execute_permission" {
  statement_id  = "AllowExecutionFromCloudWatch"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.quicksight_export.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.publish_event.arn
}



# =========================================================================
# ================ QS TOPIC CREATION/UPDATE EVENT RULE ====================
# =========================================================================

resource "aws_cloudwatch_event_rule" "qs_topic_event" {
  name = "bi_foundations_qs_topic"
  description = "Quicksight Topic Creation or Update Event"
  event_pattern = jsonencode({
    source = ["aws.quicksight"],
    detail_type = ["AWS API Call via CloudTrail"],
    detail = {
      event_source = ["quicksight.amazonaws.com"],
      eventName = ["CreateTopic","UpdateTopic"]
    }
  })
}


resource "aws_cloudwatch_event_target" "qs_topic_event_target" {
  rule = aws_cloudwatch_event_rule.qs_topic_event.name
  arn = aws_lambda_function.quicksight_export.arn
}


resource "aws_lambda_permission" "qs_topic_event_eventbridge_execute_permission"{
  statement_id = "AllowExecutionFromEventBridgeQSTopicEvent"
  action = "lambda:InvokeFunction"
  function_name = aws_lambda_function.quicksight_export.function_name
  principal = "events.amazonaws.com"
  source_arn = aws_cloudwatch_event_rule.qs_topic_event.arn

}