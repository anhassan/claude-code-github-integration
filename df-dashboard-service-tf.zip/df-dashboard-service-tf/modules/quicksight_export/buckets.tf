# TODO remove after bucket is empty
resource "aws_s3_bucket" "published_dashboard_bucket" {
  count  = local.is_central_bucket_account ? 1 : 0
  bucket = "${local.shared_conventions.dashboard_bucket_prefix}-${var.account_id}-${var.env_name}"
}

resource "aws_s3_bucket" "central_dashboard_definition_bucket" {
  count  = local.is_central_bucket_account ? 1 : 0
  bucket = local.published_dashboard_bucket
}

resource "aws_s3_bucket_public_access_block" "central_dashboard_definition_bucket" {
  count                   = local.is_central_bucket_account ? 1 : 0
  bucket                  = aws_s3_bucket.central_dashboard_definition_bucket[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "central_dashboard_definition_bucket" {
  count  = local.is_central_bucket_account ? 1 : 0
  bucket = aws_s3_bucket.central_dashboard_definition_bucket[0].id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_ownership_controls" "central_dashboard_definition_bucket" {
  count  = local.is_central_bucket_account ? 1 : 0
  bucket = aws_s3_bucket.central_dashboard_definition_bucket[0].id
  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

data "aws_iam_policy_document" "central_dashboard_definition_bucket_policy" {
  count = local.is_central_bucket_account ? 1 : 0
  statement {
    sid    = "AllowAssociatedAccounts"
    effect = "Allow"
    actions = [
      "s3:Get*",
      "s3:Put*",
      "s3:List*",
    ]
    resources = [
      aws_s3_bucket.central_dashboard_definition_bucket[0].arn,
      "${aws_s3_bucket.central_dashboard_definition_bucket[0].arn}/*",
    ]
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }

    condition {
      test     = "StringEquals"
      variable = "aws:PrincipalArn"
      values = concat([
        for env, account in var.associated_accounts : "arn:aws:iam::${account}:role/${local.shared_conventions.quicksight_mgr_role_prefix}-${env}"
        ],
        [for env, account in var.associated_accounts : "arn:aws:iam::${account}:role/${local.shared_conventions.quicksight_processing_role_name}"
      ])
    }
  }
}

resource "aws_s3_bucket_policy" "central_dashboard_definition_bucket" {
  count  = local.is_central_bucket_account ? 1 : 0
  bucket = aws_s3_bucket.central_dashboard_definition_bucket[0].id
  policy = data.aws_iam_policy_document.central_dashboard_definition_bucket_policy[0].json
}