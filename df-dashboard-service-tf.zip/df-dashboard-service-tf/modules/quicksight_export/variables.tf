variable "account_id" {}
variable "acc_name" {}
variable "aws_region" {}
variable "name_suffix" { default = "" }
variable "env_name" {}
variable "artifact_bucket" { default = "" }
variable "artifact_path" { default = "" }
variable "service_name" {
  type = string
}
variable "base_tags" {
  type = map(any)
}
variable "associated_accounts" {
  type        = map(any)
  description = "Account id map (e.g. {dev: 0123456789012 qa: 210987654321}) that can share config and artifacts.  If none are provided, artifacts will need to be manually uploaded across accounts"
  default     = { "accounts" : "MANUALLY_SHARE_ARTIFACTS" }
}

variable "lambda_versions" {
  description = "Map of lambda function name (folder names in bi-foundations) to the version folder in S3"
  type        = map(string)
}