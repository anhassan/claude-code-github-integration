locals {
  non_prod_envs             = ["dev", "qa", "uat"]
  prod_envs                 = ["prod"]
  environment               = var.env_name
  shared_conventions        = jsondecode(file("${path.module}/../shared/quicksight_shared_naming.json"))
  control_plane_conventions = jsondecode(file("${path.module}/../shared/bi_control_plane_shared_naming.json"))
  associated_account_ids    = [for k, v in var.associated_accounts : v]
  export_lambda_name_base   = "qs_publish_export_lambda"

  is_central_bucket_account      = var.env_name == "dev"
  published_dashboard_bucket     = local.shared_conventions.central_dashboard_definition_bucket
  published_dashboard_bucket_arn = "arn:aws:s3:::${local.published_dashboard_bucket}"
}

data "aws_s3_object" "qs_publish_export_lambda" {
  bucket = var.artifact_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.export_lambda_name_base)}/lambda/${local.export_lambda_name_base}.zip"
}