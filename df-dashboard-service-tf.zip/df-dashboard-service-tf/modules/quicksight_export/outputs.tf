output "out" {
  value = {
    dashboard_bucket = local.published_dashboard_bucket
  }
}