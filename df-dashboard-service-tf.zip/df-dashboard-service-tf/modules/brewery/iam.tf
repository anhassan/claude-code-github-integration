locals {
  admin_permission_set_arn = tolist(data.aws_iam_roles.roles.arns)[0]
}

data "aws_iam_roles" "roles" {
  name_regex  = "AWSReservedSSO_CPPIB-Developer-Dev_.*"
  path_prefix = "/aws-reserved/sso.amazonaws.com/"
}

resource "aws_iam_role" "databrew_viewer_role" {
  name               = "df-databrew-role-${var.env_name}"
  assume_role_policy = data.aws_iam_policy_document.temp_demo_assume_policy_doc.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess",
    "arn:aws:iam::aws:policy/service-role/AWSGlueDataBrewServiceRole"
  ]
}

resource "aws_iam_role_policy" "databrew_role_policy" {
  name   = "df-databrew-policy-${var.env_name}"
  policy = data.aws_iam_policy_document.temp_demo_viewer_role_policy.json
  role   = aws_iam_role.databrew_viewer_role.name
}

data "aws_iam_policy_document" "temp_demo_assume_policy_doc" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = [local.admin_permission_set_arn]
    }
  }
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "SERVICE"
      identifiers = ["databrew.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "temp_demo_viewer_role_policy" {
  statement {
    actions = [
      "iam:Get*",
      "iam:List*",
      "iam:CreateServiceLinkedRole",
      "iam:PassRole"
    ]
    resources = ["*"]
  }

  statement {
    actions = [
      "ec2:DescribeVpcEndpoints",
      "ec2:DescribeRouteTables",
      "ec2:DeleteNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeSubnets",
      "ec2:DescribeVpcAttribute",
      "ec2:CreateNetworkInterface"
    ]
    resources = ["*"]
  }

  statement {
    actions = [
      "ec2:CreateTags",
      "ec2:DeleteTags"
    ]
    condition {
      test     = "ForAllValues:StringEquals"
      variable = "aws:TagKeys"
      values   = ["aws-glue-service-resource"]
    }
    resources = [
      "arn:aws:ec2:*:*:network-interface/*",
      "arn:aws:ec2:*:*:security-group/*"
    ]
  }

  statement {
    actions = [
      "ec2:DeleteNetworkInterfae"
    ]
    resources = ["*"]
    condition {
      variable = "aws:ResourceTag/aws-glue-service-resource"
      test     = "StringLike"
      values   = ["*"]
    }
  }

  statement {
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = ["arn:aws:logs:*:*:log-group:/aws-glue-databrew/*"]
  }

  statement {
    actions   = ["lakeformation:GetDataAccess"]
    resources = ["*"]
  }

  statement {
    actions   = ["databrew:*"]
    resources = ["*"]
  }

  statement {
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:PutBucketCORS",
      "s3:ListBucket"
    ]
    resources = ["*"]
  }
}