resource "aws_dynamodb_table" "bi_portal_user_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-user"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_portal_favourite_assets_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-favourite-assets"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"
  range_key    = "asset_id"

  attribute {
    name = "email"
    type = "S"
  }

  attribute {
    name = "asset_id"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_portal_popup_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-popup-table"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "asset_id"

  attribute {
    name = "asset_id"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_portal_edit_permissions_popup_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-edit-permissions-popup-table"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_foundations_entitlement_requests"{
  name = "${local.control_plane_conventions.bi_foundations_prefix}-rls-entitlement-request"
  billing_mode = "PAY_PER_REQUEST"
  hash_key = "request_id"
  range_key = "approver_email" 

  attribute {
    name = "approver_email"
    type = "S"
  }

  attribute {
    name = "request_id"
    type = "S"
  }

  tags = var.tags

}

resource "aws_dynamodb_table" "bi_portal_upload_entitlement_permissions_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-upload-entitlement-permissions-popup-table"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_portal_asset_entitlement_permissions_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-asset-entitlement-permissions"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_portal_hidden_tab_permissions_table" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-hidden-tab-permissions-table"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "email"

  attribute {
    name = "email"
    type = "S"
  }

  tags = var.tags
}

resource "aws_dynamodb_table" "bi_foundations_workspace_entitlements_mapping" {
  name = "${local.control_plane_conventions.bi_foundations_prefix}-workspace-rls-entitlements-mapping"
  billing_mode = "PAY_PER_REQUEST"
  hash_key = "workspace_id"

  attribute {
    name = "workspace_id"
    type = "S"
  }
  
  tags = var.tags
}

resource "aws_dynamodb_table" "bi_foundations_workspace_als_entitlements" {
  name = "${local.control_plane_conventions.bi_foundations_prefix}-workspace-als-entitlements"
  billing_mode = "PAY_PER_REQUEST"
  hash_key = "workspace_id"
  range_key = "unique_key"

  attribute {
    name = "workspace_id"
    type = "S"
  }

  attribute {
    name = "unique_key"
    type = "S"
  }
}

resource "aws_dynamodb_table" "bi_foundations_entitlement_als_requests"{
  name = "${local.control_plane_conventions.bi_foundations_prefix}-als-entitlement-request"
  billing_mode = "PAY_PER_REQUEST"
  hash_key = "request_id"
  range_key = "approver_email" 

  attribute {
    name = "approver_email"
    type = "S"
  }

  attribute {
    name = "request_id"
    type = "S"
  }

  tags = var.tags

}