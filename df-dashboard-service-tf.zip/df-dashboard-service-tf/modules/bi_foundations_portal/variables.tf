variable "aws_org_id" {}
variable "account_id" {}
variable "env_name" {}
variable "aws_region_name" {
  default = "us-east-1"
}
variable "service_name" {
  default = "bi-foundations-portal"
}

variable "tags" {
  type = map(any)
}

variable "api_gateway_stage_version" {
  default = "v1"
}

variable "vpc_id" {}
variable "vpc_endpoint_id" {}
variable "ingress_cidrs" {
  type = list(string)
}

variable "private_subnets" {
  type = list(string)
}

variable "cognito_user_pool_arn" {}
variable "central_cloudfront_arn" { default = "arn:aws:cloudfront::479906572997:distribution/E28JKOUPYEERVG" }

variable "artifact_bucket" {}

variable "application_name" {
  default = "finsights"
}
variable "top_level_domain" {
  default = "datafabric.dev.cppinvestments.io"
}

variable "lambda_versions" {
  description = "Map of lambda function name (folder names in bi-foundations) to the version folder in S3"
  type        = map(string)
}

variable "dependency" {
  description = "This module has a dependency on resources output by another module. We use terragrunt to manage the dependencies between modules and pass the required inputs in a depedency object."
  type        = any
}

variable "smtp_host" {
  description = "This is the host name of the smtp server"
  type = string
}

variable "smtp_port" {
  description = "This is the port used by the smtp server"
  type = string
}