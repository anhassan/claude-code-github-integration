resource "aws_lb" "bi_portal_application_api" {
  name               = local.gateway_resource_name
  internal           = true
  load_balancer_type = "network"

  subnets = var.private_subnets

  tags = var.tags
}

resource "aws_security_group" "execute_api_security_group" {
  name                   = local.gateway_resource_name
  vpc_id                 = var.vpc_id
  revoke_rules_on_delete = "true"

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_security_group_rule" "api_gateway_sg_egress_rule" {
  security_group_id = aws_security_group.execute_api_security_group.id
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks = [
    "0.0.0.0/0"
  ]
}

resource "aws_security_group_rule" "vpc_cidr_block" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = var.ingress_cidrs
  security_group_id = aws_security_group.execute_api_security_group.id
}


# Security Group Rule to add the new prefix list
resource "aws_security_group_rule" "allow_vpn_prefix_api_gateway" {    # Notes: this will add global protect to impacted security group inbound rules
  type              = "ingress"                                        # Notes:  this means the inbound rule
  from_port         = 0                                                # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 0                                                # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  protocol          = "-1"                                             # Notes: such as TCP
  security_group_id = aws_security_group.execute_api_security_group.id # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.vpn_prefix.id]
  description       = "CPPIB Global Protect IP Prefix List"
}

resource "aws_security_group_rule" "allow_office_prefix_api_gateway" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  security_group_id = aws_security_group.execute_api_security_group.id
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.office_prefix.id]
  description       = "CPPIB Office IP Prefix List"
}

resource "aws_security_group_rule" "allow_vdi_prefix_api_gateway" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  security_group_id = aws_security_group.execute_api_security_group.id
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.vdi_prefix.id]
  description       = "CPPIB Azure IP Prefix List"
}

resource "aws_api_gateway_vpc_link" "bi_portal_application_api" {
  name = local.gateway_resource_name
  target_arns = [
    aws_lb.bi_portal_application_api.arn
  ]
}

resource "aws_api_gateway_rest_api" "bi_portal_application_api" {
  name        = local.gateway_resource_name
  description = "BI Portal Application API"
  binary_media_types = ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"]
  endpoint_configuration {
    types = [
      "PRIVATE"
    ]
    vpc_endpoint_ids = [
      data.aws_vpc_endpoint.bi_portal_execute_api_private.id
    ]
  }
}

resource "aws_api_gateway_authorizer" "gateway_authorizer" {
  name          = local.gateway_resource_name
  type          = "COGNITO_USER_POOLS"
  rest_api_id   = aws_api_gateway_rest_api.bi_portal_application_api.id
  provider_arns = [var.cognito_user_pool_arn]
}

data "aws_iam_policy_document" "bi_portal_application_api_invoke_policy" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["apigateway.amazonaws.com"]
    }
  }

  statement {
    effect  = "Allow"
    actions = ["execute-api:Invoke"]
    resources = [
      "${aws_api_gateway_rest_api.bi_portal_application_api.execution_arn}/*"
    ]
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:sourceVpce"
      values = [
        data.aws_vpc_endpoint.bi_portal_execute_api_private.id
      ]
    }
  }
}

resource "aws_api_gateway_rest_api_policy" "bi_portal_application_api" {
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
  policy      = data.aws_iam_policy_document.bi_portal_application_api_invoke_policy.json
}


resource "aws_api_gateway_deployment" "bi_portal_application_api" {
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id

  depends_on = [
    aws_api_gateway_authorizer.gateway_authorizer,
    aws_api_gateway_rest_api_policy.bi_portal_application_api,
    module.endpoint_assets,
    module.endpoint_assets_filters,
    module.endpoint_assets_search,
    module.endpoint_assets_user,
    module.endpoint_assets_search_autocomplete,
    module.endpoint_assets_catalog_recommended,
    module.endpoint_assets_catalog_insights,
    module.endpoint_assets_catalog_non_insights,
    module.endpoint_assets_catalog_department,
    module.endpoint_assets_workspace_entitlement,
    module.endpoint_assets_dashboard_entitlement,
    module.endpoint_assets_departments,
    module.endpoint_dataset_dataset_id,
    module.endpoint_dataset_dataset_id_columns,
    module.endpoint_dataset_dataset_id_workspace_id,
    module.endpoint_dataset_dataset_id_workspace_id_rls_by_claims,
    module.endpoint_dataset_dataset_id_workspace_id_rls_by_email,
    module.endpoint_assets_metadata,
    module.endpoint_asset_id,
    module.endpoint_asset_id_embed_url,
    module.endpoint_asset_id_embed_q_gen_ai_qa_url,
    module.endpoint_asset_id_department,
    module.endpoint_user_login,
    module.endpoint_user_favourites,
    module.endpoint_user_add_favourite,
    module.endpoint_user_remove_favourite,
    module.endpoint_popup_content_get,
    module.endpoint_popup_content_post,
    module.endpoint_popup_content_delete,
    module.endpoint_popup_edit_permissions,
    module.endpoint_popup_all_users,
    module.endpoint_popup_add_user,
    module.endpoint_popup_remove_user,
    module.endpoint_upload_entitlement_permissions,
    module.endpoint_asset_entitlement_permissions,
    module.endpoint_q_topic_security,
    module.endpoint_topic_id,
    module.endpoint_hidden_tab_permissions,
    module.endpoint_entitlements_create_request,
    module.endpoint_entitlements_fulfill_rls,
    module.endpoint_entitlements_fulfill_als,
    module.endpoint_entitlements_request_id,
    module.endpoint_entitlements_request_id_email,
    module.endpoint_entitlements_request_id_email_approve,
    module.endpoint_entitlements_request_id_email_deny,
    module.endpoint_entitlements_update_rls,
    module.endpoint_entitlements_create_als_request,
    module.endpoint_entitlements_request_id_email_approve_als_viewer_request,
    module.endpoint_entitlements_request_id_email_approve_als_whitelist_request,
    module.endpoint_entitlements_request_id_email_deny_als_request
  ]

  variables = {
    vpcLinkId   = aws_api_gateway_vpc_link.bi_portal_application_api.id
    deployed_at = timestamp()
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "bi_portal_application_api" {
  deployment_id        = aws_api_gateway_deployment.bi_portal_application_api.id
  rest_api_id          = aws_api_gateway_rest_api.bi_portal_application_api.id
  stage_name           = var.api_gateway_stage_version
  xray_tracing_enabled = true
}

resource "aws_api_gateway_method_settings" "bi_portal_application_api" {
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
  stage_name  = aws_api_gateway_stage.bi_portal_application_api.stage_name
  method_path = "*/*"
  depends_on = [
    aws_api_gateway_deployment.bi_portal_application_api,
  ]

  settings {
    data_trace_enabled = true
    metrics_enabled    = true
    logging_level      = "INFO"
  }
}