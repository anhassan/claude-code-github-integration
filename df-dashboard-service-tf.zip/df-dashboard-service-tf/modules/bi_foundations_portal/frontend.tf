resource "aws_s3_bucket" "bi_portal_ui" {
  bucket = local.bi_portal_ui_resource_name
}

resource "aws_s3_bucket_ownership_controls" "bi_portal_ui" {
  bucket = aws_s3_bucket.bi_portal_ui.id

  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "bi_portal_ui" {
  bucket = aws_s3_bucket.bi_portal_ui.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_acm_certificate" "bi_portal_ui" {
  domain_name       = local.domain_url
  validation_method = "DNS"
  tags              = var.tags

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_s3_bucket_website_configuration" "bi_portal_ui" {
  bucket = aws_s3_bucket.bi_portal_ui.id

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_public_access_block" "bi_portal_ui" {
  bucket = aws_s3_bucket.bi_portal_ui.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "bi_portal_ui" {
  bucket = aws_s3_bucket.bi_portal_ui.id
  versioning_configuration {
    status = "Enabled"
  }
}


data "aws_iam_policy_document" "bi_portal_ui_resource_name_policy_document" {
  statement {
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
    effect = "Allow"
    actions = [
      "s3:GetObject*",
      "s3:List*"
    ]
    resources = [
      "${aws_s3_bucket.bi_portal_ui.arn}/*",
    ]
    condition {
      test     = "StringEquals"
      variable = "aws:PrincipalOrgID"
      values   = [var.aws_org_id]
    }
  }

  statement {
    principals {
      type        = "AWS"
      identifiers = [var.account_id]
    }
    effect = "Allow"
    actions = [
      "s3:PutObject*",
    ]
    resources = [
      "${aws_s3_bucket.bi_portal_ui.arn}/*",
    ]
  }

  statement {
    principals {
      type        = "Service"
      identifiers = ["cloudfront.amazonaws.com"]
    }
    effect = "Allow"
    actions = [
      "s3:GetObject",
    ]
    resources = [
      "${aws_s3_bucket.bi_portal_ui.arn}/*",
    ]

    condition {
      test     = "StringEquals"
      variable = "aws:SourceArn"
      values   = [var.central_cloudfront_arn]
    }
  }
}

resource "aws_s3_bucket_policy" "bi_portal_ui_resource_name_policy" {
  bucket = local.bi_portal_ui_resource_name
  policy = data.aws_iam_policy_document.bi_portal_ui_resource_name_policy_document.json
}
