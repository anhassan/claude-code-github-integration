resource "aws_api_gateway_resource" "endpoint_resource" {
  rest_api_id = var.rest_api_id
  parent_id   = var.parent_id
  path_part   = var.path_part
}

module "methods" {
  for_each              = var.methods
  source                = "./endpoint_methods"
  endpoint_http_method  = each.key
  method_request_params = lookup(each.value, "method_request_params", null)
  method_request_models = lookup(each.value, "method_request_models", null)
  authorizer_id         = var.authorizer_id
  integration_uri       = lookup(each.value, "integration_uri", var.integration_uri)
  rest_api_id           = var.rest_api_id
  parent_resource_id    = aws_api_gateway_resource.endpoint_resource.id
  role_arn              = var.role_arn
}

module "options" {
  source               = "./endpoint_methods"
  endpoint_http_method = "OPTIONS"
  integration_uri      = var.integration_uri
  rest_api_id          = var.rest_api_id
  integration_response = true
  parent_resource_id   = aws_api_gateway_resource.endpoint_resource.id
  authorizer_id        = null
  role_arn             = var.role_arn
}