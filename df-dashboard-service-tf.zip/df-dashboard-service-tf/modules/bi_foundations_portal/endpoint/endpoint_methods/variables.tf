variable "parent_resource_id" {}
variable "rest_api_id" {}
variable "integration_uri" {}
variable "endpoint_http_method" {}
variable "authorizer_id" {}
variable "method_request_params" {
  default = null
}
variable "method_request_models" {
  default = null
}
variable "integration_request_templates" {
  default = null
}
variable "integration_request_parameters" {
  default = null
}
variable "integration_http_method" {
  default = "POST"
}

variable "integration_response" {
  default = false
}
variable "endpoint_integration_type" {
  default = "AWS_PROXY"
}
variable "role_arn" {
  default = null
}
variable "response_parameters" {
  default = null
}
