
resource "aws_api_gateway_method" "endpoint_method" {
  rest_api_id        = var.rest_api_id
  resource_id        = var.parent_resource_id
  http_method        = var.endpoint_http_method
  authorization      = var.authorizer_id != null ? "COGNITO_USER_POOLS" : "NONE"
  authorizer_id      = var.authorizer_id
  request_parameters = var.method_request_params
  request_models     = var.method_request_models
}


resource "aws_api_gateway_integration" "endpoint_integration" {
  rest_api_id             = var.rest_api_id
  resource_id             = var.parent_resource_id
  credentials             = var.role_arn
  http_method             = aws_api_gateway_method.endpoint_method.http_method
  integration_http_method = var.integration_http_method
  type                    = var.endpoint_integration_type
  request_templates       = var.integration_request_templates
  request_parameters      = var.integration_request_parameters
  uri                     = var.integration_uri
}

resource "aws_api_gateway_method_response" "endpoint_method_response" {
  rest_api_id = var.rest_api_id
  resource_id = var.parent_resource_id
  http_method = aws_api_gateway_method.endpoint_method.http_method
  status_code = 200
  depends_on  = [aws_api_gateway_integration.endpoint_integration]
}

resource "aws_api_gateway_integration_response" "endpoint_integration_response" {
  count       = var.integration_response ? 1 : 0
  rest_api_id = var.rest_api_id
  resource_id = var.parent_resource_id
  http_method = aws_api_gateway_method.endpoint_method.http_method
  status_code = aws_api_gateway_method_response.endpoint_method_response.status_code
  depends_on  = [aws_api_gateway_integration.endpoint_integration]
  response_templates = {
    "application/json" = "Empty"
  }
}