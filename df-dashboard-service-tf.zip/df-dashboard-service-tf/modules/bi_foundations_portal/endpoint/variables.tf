variable "authorizer_id" {}
variable "rest_api_id" {}
variable "integration_uri" {
  default = null
}
variable "parent_id" {}
variable "path_part" {}
variable "methods" {}
variable "role_arn" {}