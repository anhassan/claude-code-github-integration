########################################
# API GATEWAY
########################################
data "aws_iam_policy_document" "bi_portal_gateway_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["apigateway.amazonaws.com", "lambda.amazonaws.com"]
    }
  }

  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::679601897237:root"]
    }
  }
}

resource "aws_iam_role" "bi_portal_gateway_role" {
  name               = "bi_portal_gateway_trust"
  assume_role_policy = data.aws_iam_policy_document.bi_portal_gateway_trust.json
}

data "aws_iam_policy_document" "bi_portal_invocation_policy" {
  statement {
    actions = ["lambda:InvokeFunction"]
    resources = [
      aws_lambda_function.bi_portal_assets_lambda.arn,
      aws_lambda_function.bi_portal_user_lambda.arn,
      aws_lambda_function.bi_portal_entitlements_lambda.arn
    ]
    effect = "Allow"
  }
}


resource "aws_iam_role_policy" "bi_portal_invocation_policy" {
  role   = aws_iam_role.bi_portal_gateway_role.id
  policy = data.aws_iam_policy_document.bi_portal_invocation_policy.json
}

########################################
# Shared BI Portal Lambdas
########################################
data "aws_iam_policy_document" "bi_portal_lambda_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "vpc_permissions" {
  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  }
}

########################################
# bi_portal_assets_lambda
########################################
resource "aws_iam_role" "bi_portal_assets_lambda_exec_role" {
  name               = "${local.bi_portal_assets_lambda_name}_exec_role"
  assume_role_policy = data.aws_iam_policy_document.bi_portal_lambda_assume_role.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_assets_lambda_basic_execution_role" {
  role       = aws_iam_role.bi_portal_assets_lambda_exec_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_policy" "bi_portal_assets_lambda_vpc_permissions" {
  name        = "${local.bi_portal_assets_lambda_name}_vpc_permissions"
  description = "VPC permissions for bi portal assets lambda execution"
  policy      = data.aws_iam_policy_document.vpc_permissions.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_assets_lambda" {
  role       = aws_iam_role.bi_portal_assets_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_assets_lambda_vpc_permissions.arn
}

data "aws_iam_policy_document" "bi_portal_assets_lambda_exec_policy_document" {
  statement {
    effect = "Allow"
    actions = [
      "quicksight:GenerateEmbedUrlForAnonymousUser",
      "quicksight:GenerateEmbedUrlForRegisteredUser",
      "quicksight:DescribeDataSet",
      "quicksight:DescribeTopic",
      "quicksight:ListTopics"
    ]
    resources = [
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:namespace/default",
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:dashboard/*",
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:dataset/*",
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:topic/*",
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:user/*",
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:group/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "es:ESHttpGet",
      "es:ESHttpPost",
    ]
    resources = [
      "arn:aws:es:${var.aws_region_name}:${var.account_id}:domain/${local.opensearch_domain}/${local.opensearch_index_name}*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:BatchGetItem",
      "dynamodb:Scan"
    ]
    resources = [
      aws_dynamodb_table.bi_portal_user_table.arn,
      "${aws_dynamodb_table.bi_portal_user_table.arn}/*",
      var.dependency.bi_foundations_dataset_rls_table.arn,
      "${var.dependency.bi_foundations_dataset_rls_table.arn}/*",
      var.dependency.bi_foundations_asset_level_security_table.arn,
      "${var.dependency.bi_foundations_asset_level_security_table.arn}/*",
      var.dependency.bi_foundations_q_topic_security_table.arn,
      "${var.dependency.bi_foundations_q_topic_security_table.arn}/*",
      "arn:aws:dynamodb:${var.aws_region_name}:${var.account_id}:table/bi-foundations-dataset-cls",
      "arn:aws:dynamodb:${var.aws_region_name}:${var.account_id}:table/bi-foundations-dataset-cls/*"
    ]
  }

    statement {
    effect = "Allow"
    actions = [
      "s3:PutObject"
    ]
    resources = [
      "arn:aws:s3:::dataset-entitlements-bucket/*"
    ]
  }
}

resource "aws_iam_policy" "bi_portal_assets_lambda_exec_policy" {
  name        = local.bi_portal_assets_lambda_name
  description = "Policy for bi portal assets lambda execution"
  policy      = data.aws_iam_policy_document.bi_portal_assets_lambda_exec_policy_document.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_assets_lambda_exec_policy_attachment" {
  role       = aws_iam_role.bi_portal_assets_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_assets_lambda_exec_policy.arn
}

########################################
# bi_portal_user_lambda
########################################
resource "aws_iam_role" "bi_portal_user_lambda_exec_role" {
  name               = "${local.bi_portal_user_lambda_name}_exec_role"
  assume_role_policy = data.aws_iam_policy_document.bi_portal_lambda_assume_role.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_user_lambda_basic_execution_role" {
  role       = aws_iam_role.bi_portal_user_lambda_exec_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_policy" "bi_portal_user_lambda_vpc_permissions" {
  name        = "${local.bi_portal_user_lambda_name}_vpc_permissions"
  description = "VPC permissions for bi portal user lambda execution"
  policy      = data.aws_iam_policy_document.vpc_permissions.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_user_lambda" {
  role       = aws_iam_role.bi_portal_user_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_user_lambda_vpc_permissions.arn
}

data "aws_iam_policy_document" "bi_portal_user_lambda_exec_policy_document" {
  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:UpdateItem",
      "dynamodb:Query",
      "dynamodb:Scan",
      "dynamodb:PutItem",
      "dynamodb:DeleteItem",
      "lambda:InvokeFunction"
    ]
    resources = [
      aws_dynamodb_table.bi_portal_user_table.arn,
      aws_dynamodb_table.bi_portal_favourite_assets_table.arn,
      aws_dynamodb_table.bi_portal_popup_table.arn,
      aws_dynamodb_table.bi_portal_edit_permissions_popup_table.arn,
      aws_dynamodb_table.bi_portal_upload_entitlement_permissions_table.arn,
      aws_dynamodb_table.bi_portal_asset_entitlement_permissions_table.arn,
      aws_dynamodb_table.bi_portal_hidden_tab_permissions_table.arn,
      var.dependency.bi_foundations_q_topic_security_table.arn,
      "${var.dependency.bi_foundations_q_topic_security_table.arn}/*",
      "arn:aws:lambda:us-east-1:200967598245:function:df-data-discovery-service-dev",
      "arn:aws:lambda:us-east-1:885014163466:function:df-data-discovery-service-qa",
      "arn:aws:lambda:us-east-1:207662059077:function:df-data-discovery-service-uat",
      "arn:aws:lambda:us-east-1:679601897237:function:df-data-discovery-service-prod"
    ]
  }
}

resource "aws_iam_policy" "bi_portal_user_lambda_exec_policy" {
  name        = local.bi_portal_user_lambda_name
  description = "Policy for bi portal user lambda execution"
  policy      = data.aws_iam_policy_document.bi_portal_user_lambda_exec_policy_document.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_user_lambda_exec_policy_attachment" {
  role       = aws_iam_role.bi_portal_user_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_user_lambda_exec_policy.arn
}

########################################
# bi_portal_entitlements_lambda
########################################
resource "aws_iam_role" "bi_portal_entitlements_lambda_exec_role" {
  name               = "${local.bi_portal_entitlements_lambda_name}_exec_role"
  assume_role_policy = data.aws_iam_policy_document.bi_portal_lambda_assume_role.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_entitlements_lambda_basic_execution_role" {
  role       = aws_iam_role.bi_portal_entitlements_lambda_exec_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_policy" "bi_portal_entitlements_lambda_vpc_permissions" {
  name        = "${local.bi_portal_entitlements_lambda_name}_vpc_permissions"
  description = "VPC permissions for bi portal entitlements lambda execution"
  policy      = data.aws_iam_policy_document.vpc_permissions.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_entitlements_lambda" {
  role       = aws_iam_role.bi_portal_entitlements_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_entitlements_lambda_vpc_permissions.arn
}

data "aws_iam_policy_document" "bi_portal_entitlements_lambda_exec_policy_document" {

  statement {
    effect = "Allow"
    actions = [
      "es:ESHttpGet",
      "es:ESHttpPost",
    ]
    resources = [
      "arn:aws:es:${var.aws_region_name}:${var.account_id}:domain/${local.opensearch_domain}/${local.opensearch_index_name}*"
    ]
  }
  
  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:UpdateItem",
      "dynamodb:Scan",
      "dynamodb:Query",
      "dynamodb:PutItem",
      "dynamodb:DeleteItem",
      "lambda:InvokeFunction"
    ]
    resources = [
      aws_dynamodb_table.bi_foundations_entitlement_requests.arn,
      aws_dynamodb_table.bi_foundations_workspace_entitlements_mapping.arn,
      "arn:aws:dynamodb:${var.aws_region_name}:${var.account_id}:table/bi-foundations-dataset-rls",
      "arn:aws:dynamodb:us-east-1:200967598245:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:885014163466:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:207662059077:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:679601897237:table/bi-foundations-entitlements-*",
      aws_dynamodb_table.bi_foundations_entitlement_als_requests.arn,
      aws_dynamodb_table.bi_foundations_workspace_als_entitlements.arn,
      "arn:aws:dynamodb:${var.aws_region_name}:${var.account_id}:table/bi-foundations-asset-level-security"
    ]
  }

    statement {
      actions = [
          "secretsmanager:GetResourcePolicy",
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret",
          "secretsmanager:ListSecretVersionIds",
          "secretsmanager:ListSecrets"
      ]
      effect = "Allow"
      resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "quicksight:UpdateDataSet",
      "quicksight:DescribeDataSet",
      "quicksight:CreateIngestion"
    ]
    resources = [
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:dataset/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "quicksight:DescribeDataSource"
    ]
    resources = [
      "arn:aws:quicksight:${var.aws_region_name}:${var.account_id}:datasource/*"
    ]
  }

  
}

resource "aws_iam_policy" "bi_portal_entitlements_lambda_exec_policy" {
  name        = local.bi_portal_entitlements_lambda_name
  description = "Policy for bi portal entitlements lambda execution"
  policy      = data.aws_iam_policy_document.bi_portal_entitlements_lambda_exec_policy_document.json
}

resource "aws_iam_role_policy_attachment" "bi_portal_entitlements_lambda_exec_policy_attachment" {
  role       = aws_iam_role.bi_portal_entitlements_lambda_exec_role.name
  policy_arn = aws_iam_policy.bi_portal_entitlements_lambda_exec_policy.arn
}