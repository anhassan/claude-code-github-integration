//
//  /assets
//
module "endpoint_assets" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      "method.request.querystring.asset_ids" = true
    }
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "assets"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/filters
//
module "endpoint_assets_filters" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "filters"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/search
//
module "endpoint_assets_search" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.querystring.search_text" = true
      }
    }
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "search"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


//
//  /assets/user
//
module "endpoint_assets_user" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.querystring.user_id" = true
      }
    }
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "user"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}



//
//  /assets/search/autocomplete
//
module "endpoint_assets_search_autocomplete" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.querystring.search_text" = true
      }
    }
  }
  parent_id     = module.endpoint_assets_search.resource_id
  path_part     = "autocomplete"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/{asset_id}
//
module "endpoint_asset_id" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "{asset_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/{asset_id}/embed_url
//
module "endpoint_asset_id_embed_url" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_asset_id.resource_id
  path_part     = "embed_url"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


//
//  /assets/{asset_id}/department
//
module "endpoint_asset_id_department" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_asset_id.resource_id
  path_part     = "department"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/{asset_id}/embed_q_gen_ai_qa_url
//
module "endpoint_asset_id_embed_q_gen_ai_qa_url"{
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_asset_id.resource_id
  path_part     = "embed_q_gen_ai_qa_url"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/catalog
//
resource "aws_api_gateway_resource" "assets_catalog" {
  parent_id   = module.endpoint_assets.resource_id
  path_part   = "catalog"
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
}

//
//  /assets/catalog/recommended
//
module "endpoint_assets_catalog_recommended" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_resource.assets_catalog.id
  path_part     = "recommended"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/catalog/insights
//
module "endpoint_assets_catalog_insights" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_resource.assets_catalog.id
  path_part     = "insights"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/catalog/non_insights
//
module "endpoint_assets_catalog_non_insights" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_resource.assets_catalog.id
  path_part     = "non_insights"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/catalog/department
//
module "endpoint_assets_catalog_department" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_resource.assets_catalog.id
  path_part     = "department"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/workspace-entitlement
//
module "endpoint_assets_workspace_entitlement" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "workspace-entitlement"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/dashboard-entitlement
//
module "endpoint_assets_dashboard_entitlement" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "dashboard-entitlement"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/departments
//
module "endpoint_assets_departments" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = module.endpoint_assets.resource_id
  path_part     = "departments"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /assets/{asset_id}/metadata
//
module "endpoint_assets_metadata" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_asset_id.resource_id
  path_part     = "metadata"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /dataset
//
resource "aws_api_gateway_resource" "dataset" {
  parent_id   = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part   = "dataset"
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
}


//
//  /dataset/{dataset_id}
//
module "endpoint_dataset_dataset_id" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dataset_id" = true
      }
    }
  }
  parent_id     = aws_api_gateway_resource.dataset.id
  path_part     = "{dataset_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


//
//  /dataset/{dataset_id}/columns
//
module "endpoint_dataset_dataset_id_columns" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dataset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_dataset_dataset_id.resource_id
  path_part     = "columns"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


//
//  /dataset/{dataset_id}/{workspace_id}
//
module "endpoint_dataset_dataset_id_workspace_id" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dataset_id" = true,
        "method.request.path.workspace_id" = true
      }
    }
  }
  parent_id     = module.endpoint_dataset_dataset_id.resource_id
  path_part     = "{workspace_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /dataset/{dataset_id}/{workspace_id}/rls_by_claims
//
module "endpoint_dataset_dataset_id_workspace_id_rls_by_claims" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dataset_id" = true,
        "method.request.path.workspace_id" = true
      }
    }
  }
  parent_id     = module.endpoint_dataset_dataset_id_workspace_id.resource_id
  path_part     = "rls_by_claims"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /dataset/{dataset_id}/{workspace_id}/rls_by_claims
//
module "endpoint_dataset_dataset_id_workspace_id_rls_by_email" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_assets_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dataset_id" = true,
        "method.request.path.workspace_id" = true
      }
    }
  }
  parent_id     = module.endpoint_dataset_dataset_id_workspace_id.resource_id
  path_part     = "rls_by_email"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


//
//  /user
//
resource "aws_api_gateway_resource" "user" {
  parent_id   = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part   = "user"
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
}

//
//  /user/login
//
module "endpoint_user_login" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.user.id
  path_part     = "login"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /user/favourites
//
module "endpoint_user_favourites" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_resource.user.id
  path_part     = "favourites"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /user/favourite
//
module "endpoint_user_add_favourite" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.user.id
  path_part     = "favourite"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /user/favourite/{asset_id}
//
module "endpoint_user_remove_favourite" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    DELETE : {
      method_request_params : {
        "method.request.path.asset_id" = true
      }
    }
  }
  parent_id     = module.endpoint_user_add_favourite.resource_id
  path_part     = "{asset_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /get-popup-content
//
module "endpoint_popup_content_get" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "get-popup-content"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /update-popup-content
//
module "endpoint_popup_content_post" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "update-popup-content"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /delete-popup-content
//
module "endpoint_popup_content_delete" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    DELETE : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "delete-popup-content"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /popup-edit-permissions
//
module "endpoint_popup_edit_permissions" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "popup-edit-permissions"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /popup-all-users
//
module "endpoint_popup_all_users" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "popup-all-users"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /popup-add-user
//
module "endpoint_popup_add_user" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "popup-add-user"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /popup-remove-user
//
module "endpoint_popup_remove_user" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    DELETE : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "popup-remove-user"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /upload-entitlement-permissions
//
module "endpoint_upload_entitlement_permissions" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "upload-entitlement-permissions"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /asset-entitlement-permissions
//
module "endpoint_asset_entitlement_permissions" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "asset-entitlement-permissions"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /hidden-tab-permissions
//
module "endpoint_hidden_tab_permissions" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {}
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "hidden-tab-permissions"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements
//
resource "aws_api_gateway_resource" "endpoint_entitlements" {
  parent_id   = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part   = "entitlements"
  rest_api_id = aws_api_gateway_rest_api.bi_portal_application_api.id
}


//
//  /entitlements/create_request
//

module "endpoint_entitlements_create_request" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "create_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/create_als_request
//

module "endpoint_entitlements_create_als_request" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "create_als_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/fulfill_rls
//

module "endpoint_entitlements_fulfill_rls" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "fulfill_rls"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/fulfill_als
//

module "endpoint_entitlements_fulfill_als" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "fulfill_als"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/approve_request
//

module "endpoint_entitlements_request_id" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
      }
    }
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "{request_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/approve_request
//

module "endpoint_entitlements_request_id_email" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id.resource_id
  path_part     = "{email}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/approve_request
//

module "endpoint_entitlements_request_id_email_approve" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id_email.resource_id
  path_part     = "approve_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/deny_request
//

module "endpoint_entitlements_request_id_email_deny" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id_email.resource_id
  path_part     = "deny_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/approve_als_viewer_request
//
module "endpoint_entitlements_request_id_email_approve_als_viewer_request" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id_email.resource_id
  path_part     = "approve_als_viewer_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/approve_als_whitelist_request
//
module "endpoint_entitlements_request_id_email_approve_als_whitelist_request" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id_email.resource_id
  path_part     = "approve_als_whitelist_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/{request_id}/{email}/deny_als_request
//
module "endpoint_entitlements_request_id_email_deny_als_request" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.request_id" = true,
        "method.request.path.email" = true
      }
    }
  }
  parent_id     = module.endpoint_entitlements_request_id_email.resource_id
  path_part     = "deny_als_request"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}

//
//  /entitlements/update_rls
//

module "endpoint_entitlements_update_rls" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_entitlements_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    POST : {}
  }
  parent_id     = aws_api_gateway_resource.endpoint_entitlements.id
  path_part     = "update_rls"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}



//
//  /{dashboard_id}
//
module "endpoint_topic_id" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dashboard_id" = true
      }
    }
  }
  parent_id     = aws_api_gateway_rest_api.bi_portal_application_api.root_resource_id
  path_part     = "{dashboard_id}"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}



//
//  /{dashboard_id}/q-topic-permissions
//
module "endpoint_q_topic_security" {
  source          = "./endpoint"
  integration_uri = aws_lambda_function.bi_portal_user_lambda.invoke_arn
  rest_api_id     = aws_api_gateway_rest_api.bi_portal_application_api.id
  methods = {
    GET : {
      method_request_params : {
        "method.request.path.dashboard_id" = true
      }
    }
  }
  parent_id     = module.endpoint_topic_id.resource_id
  path_part     = "q-topic-permissions"
  role_arn      = aws_iam_role.bi_portal_gateway_role.arn
  authorizer_id = aws_api_gateway_authorizer.gateway_authorizer.id
}


