resource "aws_security_group" "bi_portal_lambda_sg" {
  name        = "${local.control_plane_conventions.bi_foundations_prefix}-portal-lambda-sg"
  description = "Allow inbound traffic"
  vpc_id      = var.vpc_id

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_security_group_rule" "bi_portal_lambda_sg_ingress_rule" {
  security_group_id        = aws_security_group.bi_portal_lambda_sg.id
  source_security_group_id = aws_security_group.bi_portal_lambda_sg.id
  type                     = "ingress"
  from_port                = 0
  to_port                  = 0
  protocol                 = "-1"
}

resource "aws_security_group_rule" "bi_portal_lambda_sg_egress_rule" {
  security_group_id = aws_security_group.bi_portal_lambda_sg.id
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks = [
    "0.0.0.0/0"
  ]
}

# Security Group Rule to add the new prefix list
resource "aws_security_group_rule" "allow_vpn_prefix_portal_lambda" { # Notes: this will add global protect to impacted security group inbound rules
  type              = "ingress"                                       # Notes:  this means the inbound rule
  from_port         = 0                                               # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 0                                               # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  protocol          = "-1"                                            # Notes: such as TCP
  security_group_id = aws_security_group.bi_portal_lambda_sg.id       # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.vpn_prefix.id]
  description       = "CPPIB Global Protect and Office IP Prefix List"
}

resource "aws_security_group_rule" "allow_office_prefix_portal_lambda" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  security_group_id = aws_security_group.bi_portal_lambda_sg.id
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.office_prefix.id]
  description       = "CPPIB Office IP Prefix List"
}

resource "aws_security_group_rule" "allow_vdi_prefix_portal_lambda" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  security_group_id = aws_security_group.bi_portal_lambda_sg.id
  prefix_list_ids   = [data.aws_ec2_managed_prefix_list.vdi_prefix.id]
  description       = "CPPIB Azure IP Prefix List"
}

resource "aws_cloudwatch_log_group" "bi_portal_assets_lambda_log_group" {
  name = "/aws/lambda/${local.bi_portal_assets_lambda_name}"
}

resource "aws_lambda_function" "bi_portal_assets_lambda" {
  s3_bucket         = data.aws_s3_object.bi_portal_assets_lambda.bucket
  s3_key            = data.aws_s3_object.bi_portal_assets_lambda.key
  s3_object_version = data.aws_s3_object.bi_portal_assets_lambda.version_id

  function_name = local.bi_portal_assets_lambda_name
  handler       = "${local.asset_lambda_name_base}.${local.common_api_handler}"
  role          = aws_iam_role.bi_portal_assets_lambda_exec_role.arn
  runtime       = "python3.12"
  timeout       = 300
  depends_on = [
    data.aws_s3_object.bi_portal_assets_lambda,
    aws_cloudwatch_log_group.bi_portal_assets_lambda_log_group
  ]

  vpc_config {
    security_group_ids = [
      aws_security_group.bi_portal_lambda_sg.id
    ]
    subnet_ids = var.private_subnets
  }
  environment {
    variables = {
      AWS_REGION_NAME            = var.aws_region_name
      QUICKSIGHT_ACCOUNT_ID      = var.account_id
      OPENSEARCH_ENDPOINT        = var.dependency.bi_foundations_es_domain.endpoint
      OPENSEARCH_INDEX_NAME      = local.opensearch_index_name
      USER_TABLE                 = aws_dynamodb_table.bi_portal_user_table.name
      DATASET_RLS_TABLE          = var.dependency.bi_foundations_dataset_rls_table.name
      DATASET_CLS_TABLE          = "bi-foundations-dataset-cls"
      ASSET_LEVEL_SECURITY_TABLE = var.dependency.bi_foundations_asset_level_security_table.name
      Q_TOPIC_SECURITY_TABLE = var.dependency.bi_foundations_q_topic_security_table.name
      ENV_NAME                   = var.env_name
    }
  }
}

resource "aws_cloudwatch_log_group" "bi_portal_user_lambda_log_group" {
  name = "/aws/lambda/${local.bi_portal_user_lambda_name}"
}

resource "aws_lambda_function" "bi_portal_user_lambda" {
  s3_bucket         = data.aws_s3_object.bi_portal_user_lambda.bucket
  s3_key            = data.aws_s3_object.bi_portal_user_lambda.key
  s3_object_version = data.aws_s3_object.bi_portal_user_lambda.version_id

  function_name = local.bi_portal_user_lambda_name
  handler       = "${local.user_lambda_name_base}.${local.common_api_handler}"
  role          = aws_iam_role.bi_portal_user_lambda_exec_role.arn
  runtime       = "python3.12"
  timeout       = 900
  depends_on = [
    data.aws_s3_object.bi_portal_user_lambda,
    aws_cloudwatch_log_group.bi_portal_user_lambda_log_group
  ]

  vpc_config {
    security_group_ids = [
      aws_security_group.bi_portal_lambda_sg.id
    ]
    subnet_ids = var.private_subnets
  }
  environment {
    variables = {
      AWS_REGION_NAME        = var.aws_region_name
      USER_TABLE             = aws_dynamodb_table.bi_portal_user_table.name
      FAVOURITE_ASSETS_TABLE = aws_dynamodb_table.bi_portal_favourite_assets_table.name
      ENV_NAME               = var.env_name
      POPUP_TABLE            = aws_dynamodb_table.bi_portal_popup_table.name
      POPUP_PERMISSIONS_TABLE = aws_dynamodb_table.bi_portal_edit_permissions_popup_table.name
      UPLOAD_ENTITLEMENT_PERMISSIONS_TABLE = aws_dynamodb_table.bi_portal_upload_entitlement_permissions_table.name
      ASSET_ENTITLEMENT_PERMISSIONS_TABLE = aws_dynamodb_table.bi_portal_asset_entitlement_permissions_table.name
      HIDDEN_TAB_PERMISSIONS_TABLE = aws_dynamodb_table.bi_portal_hidden_tab_permissions_table.name
      Q_TOPIC_SECURITY_TABLE = var.dependency.bi_foundations_q_topic_security_table.name
    }
  }
}

resource "aws_vpc_security_group_ingress_rule" "bi_portal_lambda_es_sg_rule" {
  security_group_id            = var.dependency.bi_foundations_es_security_group.id
  referenced_security_group_id = aws_security_group.bi_portal_lambda_sg.id
  from_port                    = 443
  to_port                      = 443
  ip_protocol                  = "tcp"
}

########################################
# bi_portal_entitlements_lambda
########################################
resource "aws_cloudwatch_log_group" "bi_portal_entitlements_lambda_log_group" {
  name = "/aws/lambda/${local.bi_portal_entitlements_lambda_name}"
}

resource "aws_lambda_function" "bi_portal_entitlements_lambda" {
  s3_bucket         = data.aws_s3_object.bi_portal_entitlements_lambda.bucket
  s3_key            = data.aws_s3_object.bi_portal_entitlements_lambda.key
  s3_object_version = data.aws_s3_object.bi_portal_entitlements_lambda.version_id

  function_name = local.bi_portal_entitlements_lambda_name
  handler       = "${local.entitlements_lambda_name_base}.${local.common_api_handler}"
  #aws_iam_role.bi_portal_user_lambda_exec_role.arn
  role          = aws_iam_role.bi_portal_entitlements_lambda_exec_role.arn
  runtime       = "python3.12"
  timeout       = 900
  depends_on = [
    data.aws_s3_object.bi_portal_entitlements_lambda,
    aws_cloudwatch_log_group.bi_portal_entitlements_lambda_log_group
  ]

  vpc_config {
    security_group_ids = [
      aws_security_group.bi_portal_lambda_sg.id
    ]
    subnet_ids = var.private_subnets
  }
  environment {
    variables = {
      ACCOUNT_ID                            = var.account_id
      AWS_REGION_NAME                       = var.aws_region_name
      ENV_NAME                              = var.env_name
      OPENSEARCH_ENDPOINT                   = var.dependency.bi_foundations_es_domain.endpoint
      OPENSEARCH_INDEX_NAME                 = local.opensearch_index_name
      SMTP_HOST                             = var.smtp_host
      SMTP_PORT                             = var.smtp_port
      ENTITLEMENT_REQUESTS_TABLE            = aws_dynamodb_table.bi_foundations_entitlement_requests.name
      WORKSPACE_ENTITLEMENTS_MAPPING_TABLE  = aws_dynamodb_table.bi_foundations_workspace_entitlements_mapping.name
      DATASET_RLS_TABLE                     = var.dependency.bi_foundations_dataset_rls_table.name
      WORKSPACE_ALS_ENTITLEMENTS_TABLE      = aws_dynamodb_table.bi_foundations_workspace_als_entitlements.name
      ENTITLEMENT_ALS_REQUESTS_TABLE        = aws_dynamodb_table.bi_foundations_entitlement_als_requests.name
      ASSET_LEVEL_SECURITY_TABLE            = "bi-foundations-asset-level-security"
    }
  }
}
