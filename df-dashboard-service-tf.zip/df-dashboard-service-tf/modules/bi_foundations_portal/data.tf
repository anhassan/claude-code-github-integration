locals {
  control_plane_conventions = jsondecode(file("${path.module}/../shared/bi_control_plane_shared_naming.json"))

  gateway_resource_name  = "${var.service_name}-api-${var.env_name}"
  asset_lambda_name_base = "portal_assets_lambda"
  user_lambda_name_base  = "portal_user_lambda"
  entitlements_lambda_name_base = "portal_entitlements_lambda"
  common_api_handler     = "main.handle_api_request"

  bi_portal_assets_lambda_name = "${local.control_plane_conventions.bi_foundations_prefix}-${local.asset_lambda_name_base}-${var.env_name}"
  bi_portal_user_lambda_name   = "${local.control_plane_conventions.bi_foundations_prefix}-${local.user_lambda_name_base}-${var.env_name}"
  bi_portal_ui_resource_name   = "bi-portal-ui-${var.env_name}"
  bi_portal_entitlements_lambda_name = "${local.control_plane_conventions.bi_foundations_prefix}-${local.entitlements_lambda_name_base}-${var.env_name}"

  domain_url = "${var.application_name}.${var.top_level_domain}"


  es_security_group_name = local.control_plane_conventions.es_security_group_name
  opensearch_domain      = local.control_plane_conventions.opensearch_domain
  opensearch_index_name  = local.control_plane_conventions.opensearch_index_name
}

data "aws_vpc_endpoint_service" "execute_api" {
  service = "execute-api"
}

data "aws_vpc_endpoint" "bi_portal_execute_api_private" {
  vpc_id       = var.vpc_id
  service_name = data.aws_vpc_endpoint_service.execute_api.service_name

  filter {
    name   = "vpc-endpoint-id"
    values = toset([var.vpc_endpoint_id])
  }
}

data "aws_s3_object" "bi_portal_assets_lambda" {
  bucket = var.artifact_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.asset_lambda_name_base)}/lambda/${local.asset_lambda_name_base}.zip"
}

data "aws_s3_object" "bi_portal_user_lambda" {
  bucket = var.artifact_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.user_lambda_name_base)}/lambda/${local.user_lambda_name_base}.zip"
}

data "aws_s3_object" "bi_portal_entitlements_lambda" {
  bucket = var.artifact_bucket
  key = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions,local.entitlements_lambda_name_base)}/lambda/${local.entitlements_lambda_name_base}.zip"
}

data "aws_ec2_managed_prefix_list" "vpn_prefix" { # Notes: This data section code is used to retrieve Global Protect prefix named "CPPIB Global Protect IPs"
  name = "CPPIB Global Protect IPs"
}

data "aws_ec2_managed_prefix_list" "office_prefix" { # Notes: This data section code is used to retrieve Global Protect prefix named "CPPIB Global Protect IPs"
  name = "CPPIB Offices IPs"
}

data "aws_ec2_managed_prefix_list" "vdi_prefix" {
  name = "CPPIB Azure IPs"
}