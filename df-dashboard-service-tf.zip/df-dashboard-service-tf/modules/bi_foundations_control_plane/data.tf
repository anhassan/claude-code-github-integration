locals {
  non_prod_envs             = ["dev", "qa", "uat"]
  prod_envs                 = ["prod"]
  environment               = var.env_name
  shared_conventions        = jsondecode(file("${path.module}/../shared/quicksight_shared_naming.json"))
  control_plane_conventions = jsondecode(file("${path.module}/../shared/bi_control_plane_shared_naming.json"))
  version                   = var.bi_foundations_pkg_version
  base_path                 = "bi-foundations/${local.version}/lambda"
  qs_processing_artifact    = "${local.base_path}/qs_asset.zip"
  qs_dataset_artifact       = "${local.base_path}/qs_dataset_lambda.zip"
  qs_mgr_artifact           = "${local.base_path}/quicksight_mgr.zip"
  event_notification_artifact           = "${local.base_path}/event_notification_lambda.zip"
  event_notification_base = "event_notification_lambda"
  dataset_entitlements_artifact           = "${local.base_path}/dataset_entitlements_lambda.zip"
  dataset_notifications_artifact           = "${local.base_path}/dataset_notifications_lambda.zip"
  metadata_email_report_artifact                    = "${local.base_path}/metadata_email_report_lambda.zip"
  dashboard_entitlements_artifact           = "${local.base_path}/dashboard_entitlements_lambda.zip"
  dataset_entitlements_base = "dataset_entitlements_lambda"
  dashboard_entitlements_base = "dashboard_entitlements_lambda"
  pkgs = {
    "qs_processing_mgr" : local.qs_processing_artifact
    "qs_dataset_mgr" : local.qs_dataset_artifact
    "qs_quicksight_mgr" : local.qs_mgr_artifact
    "event_notification" : local.event_notification_artifact
    "dataset_entitlements" : local.dataset_entitlements_artifact
    "dashboard_entitlements" : local.dashboard_entitlements_artifact
    "dataset_notifications" : local.dataset_notifications_artifact
    "metadata_email_report" : local.metadata_email_report_artifact
  }
  tmp_artifacts_bucket                          = "cppib-df-tmp-artifacts-bucket"
  foundations_control_plane_bucket              = "${local.control_plane_conventions.bi_foundations_control_plane_prefix}-${var.account_id}-${var.env_name}"
  dataset_entitlements_bucket                   = "dataset-entitlements-bucket-${var.account_id}-${var.env_name}"
  dashboard_entitlements_bucket                   = "dashboard-entitlements-bucket-${var.account_id}-${var.env_name}"
  bi_foundation_metadata_sns_topic              = "${local.control_plane_conventions.bi_foundations_metadata_processing_prefix}-${var.env_name}"
  bi_foundation_metadata_event_rule_name        = "${local.control_plane_conventions.bi_foundations_metadata_processing_prefix}-${var.env_name}"
  bi_foundation_metadata_csv_to_json_sqs_prefix = local.control_plane_conventions.bi_foundations_metadata_sqs_csv_to_json_prefix
  es_security_group_name                        = local.control_plane_conventions.es_security_group_name
  opensearch_domain                             = local.control_plane_conventions.opensearch_domain
  opensearch_index_name                         = local.control_plane_conventions.opensearch_index_name
  dataset_rls_processing_lambda_prefix          = local.control_plane_conventions.dataset_rls_processing_lambda_prefix
  project_tag                                   = local.control_plane_conventions.project_tag
  route53_topic                                 = local.control_plane_conventions.route53_topic
  route53_health_check_email_dl                 = local.control_plane_conventions.route53_health_check_email_dl
  finsights_domain_name                         = var.env_name == "prod" ? "finsights.cppinvestments.io" : "finsights.${var.env_name}.cppinvestments.io"

  published_dashboard_bucket     = local.shared_conventions.central_dashboard_definition_bucket
  published_dashboard_bucket_arn = "arn:aws:s3:::${local.published_dashboard_bucket}"
}

data "aws_s3_object" "pkgs" {
  for_each = local.pkgs
  bucket   = local.tmp_artifacts_bucket
  key      = each.value
}

data "aws_ec2_managed_prefix_list" "vpn_prefix" { # Notes: This data section code is used to retrieve Global Protect prefix named "CPPIB Global Protect IPs"
  name = "CPPIB Global Protect IPs"
}

data "aws_ec2_managed_prefix_list" "office_prefix" {
  name = "CPPIB Offices IPs"
}

data "aws_ec2_managed_prefix_list" "vdi_prefix" {
  name = "CPPIB Azure IPs"
}

data "aws_s3_object" "bi_foundations-event-notification-lambda" {
  bucket = local.tmp_artifacts_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.event_notification_base)}/lambda/${local.event_notification_base}.zip"
}

data "aws_s3_object" "bi_foundations_dataset_entitlements-lambda" {
  bucket = local.tmp_artifacts_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.dataset_entitlements_base)}/lambda/${local.dataset_entitlements_base}.zip"
}

data "aws_s3_object" "bi_foundations_dashboard_entitlements-lambda" {
  bucket = local.tmp_artifacts_bucket
  key    = "${local.control_plane_conventions.bi_foundations_prefix}/${lookup(var.lambda_versions, local.dashboard_entitlements_base)}/lambda/${local.dashboard_entitlements_base}.zip"
}