resource "aws_lambda_function" "generate_qs_export_processing" {
  function_name     = "df-quicksight-export-processing-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.qs_export_processing_handler.lambda_handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  description       = "function that converts quicksight export into csv files for end users to update"

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }


  environment {
    variables = {
      BUCKET_NAME                 = local.foundations_control_plane_bucket
      ACCOUNT_ID                  = var.account_id
      AWS_REGION_NAME             = var.aws_region
      CONFIG_BUCKET               = local.foundations_control_plane_bucket
      ENV_NAME                    = var.env_name
      DASHBOARD_DEFINITION_BUCKET = local.published_dashboard_bucket
      OPENSEARCH_INDEX_NAME       = local.opensearch_index_name
      AWS_ENVIRONMENT             = var.env_name
      OPENSEARCH_ENDPOINT         = aws_elasticsearch_domain.bi_foundations_es.endpoint
    }
  }
}

resource "aws_lambda_function" "update_os_asset_index" {
  function_name     = "df-bi-foundation-control-plane-update-os-asset-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.upsert_os_metadata_asset_handler.lambda_handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  description       = "function that updates the os index based on json payload from S3"

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }

  environment {
    variables = {
      BUCKET_NAME           = local.foundations_control_plane_bucket
      ACCOUNT_ID            = var.account_id
      AWS_REGION_NAME       = var.aws_region
      OPENSEARCH_ENDPOINT   = aws_elasticsearch_domain.bi_foundations_es.endpoint
      OPENSEARCH_INDEX_NAME = local.opensearch_index_name
      AWS_REGION_NAME       = var.aws_region
      CONFIG_BUCKET         = local.foundations_control_plane_bucket
      ENV_NAME              = var.env_name

    }
  }
}

resource "aws_lambda_function" "metadata_csv_to_json" {
  function_name     = "df-bi-foundation-control-plane-metadata-csv-to-json-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.qs_transform_processing_handler.lambda_handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  description       = "Transforms metadata in csv uploaded by author into metadata json format"


  environment {
    variables = {
      BUCKET_NAME     = local.foundations_control_plane_bucket
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      AWS_ENVIRONMENT = var.env_name
    }
  }
}

resource "aws_lambda_function" "rls_dataset_upload_dynamodb" {
  function_name     = "${local.dataset_rls_processing_lambda_prefix}-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "qs_dataset_lambda.dataset_rls_dynamodb_handler.lambda_handler"
  s3_key            = local.qs_dataset_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_dataset_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  description       = "function that uploads rls for a dataset into dynamodb"


  environment {
    variables = {
      BUCKET_NAME                = local.foundations_control_plane_bucket
      ACCOUNT_ID                 = var.account_id
      DYNAMODB_DATASET_RLS_TABLE = aws_dynamodb_table.bi_foundations_dataset_rls.name
      DYNAMODB_DATASET_CLS_TABLE = aws_dynamodb_table.bi_foundations_dataset_cls.name
    }
  }
  tags = {
    project = local.project_tag
  }
}

resource "aws_lambda_function" "asset_level_security_upload_dynamodb" {
  function_name = "${local.control_plane_conventions.bi_foundations_prefix}-asset_level_security-${var.env_name}"

  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.asset_level_security.main.handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  description       = "function that handles CRUD ops for the embedding_access.yaml for assets into dynamodb"


  environment {
    variables = {
      BUCKET_NAME                = local.foundations_control_plane_bucket
      AWS_REGION_NAME            = var.aws_region
      ENV_NAME                   = var.env_name
      ACCOUNT_ID                 = var.account_id
      ASSET_LEVEL_SECURITY_TABLE = aws_dynamodb_table.bi_foundations_asset_level_security.name
      Q_TOPIC_SECURITY_TABLE     = aws_dynamodb_table.bi_foundations_q_topic_security.name
      DATASET_RLS_TABLE          = aws_dynamodb_table.bi_foundations_dataset_rls.name
      DATASET_CLS_TABLE          = aws_dynamodb_table.bi_foundations_dataset_cls.name
    }
  }
  tags = {
    project = local.project_tag
  }
}

resource "aws_lambda_function" "prepare_qs_dataset_payload" {
  function_name     = "df-bi-foundation-prepare-qs-datasets-payload-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.dataset_publish_payload_handler.handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  memory_size       = 256
  description       = "used in a step function to prepare the QuickSight dataset payload to create datasets in the QuickSight API"


  environment {
    variables = {
      BUCKET_NAME           = local.foundations_control_plane_bucket
      ACCOUNT_ID            = var.account_id
      AWS_REGION_NAME       = var.aws_region
      ENV_NAME              = var.env_name
      FABRIC_DATASOURCE_ARN = "arn:aws:quicksight:${var.aws_region}:${var.account_id}:datasource/fabric_catalog_${var.env_name}"
    }
  }
}

resource "aws_lambda_function" "prepare_qs_dashboard_payload" {
  function_name     = "df-bi-foundation-prepare-qs-asset-payload-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.promote_asset_handler.handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  memory_size       = 256
  description       = "Used in a step function to prepare the QuickSight asset payload to create dashboards using the QuickSight API"


  environment {
    variables = {
      CONFIG_BUCKET    = local.foundations_control_plane_bucket
      DASHBOARD_BUCKET = local.published_dashboard_bucket
      ACCOUNT_ID       = var.account_id
      AWS_REGION_NAME  = var.aws_region
      ENV_NAME         = var.env_name
    }
  }
}

resource "aws_lambda_function" "prepare_qs_dataset_rls_payload" {
  function_name     = "df-bi-foundation-prepare-qs-rls-datasets-payload-${var.env_name}"
  role              = aws_iam_role.qs_processing_lambda.arn
  handler           = "quicksight_mgr.rls_publish_payload_handler.handler"
  s3_key            = local.qs_mgr_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["qs_quicksight_mgr"].version_id
  runtime           = "python3.12"
  timeout           = "300"
  memory_size       = 256
  description       = "used in a step function to prepare the QuickSight dataset payload for rls preparation for writing to dynamodb"
  environment {
    variables = {
      BUCKET_NAME     = local.foundations_control_plane_bucket
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      ENV_NAME        = var.env_name
    }
  }
}

resource "aws_lambda_function" "bi_foundations-event-notification-lambda" {
  function_name = "bi_foundations-event-notification-lambda-${var.env_name}"
  handler       = "event_notification_lambda.main.lambda_handler"
  runtime       = "python3.12"

  role      = aws_iam_role.bi_foundations-event-notification.arn
  s3_key            = local.event_notification_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["event_notification"].version_id

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }

  environment {
    variables = {
      BUCKET_NAME     = local.foundations_control_plane_bucket
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      ENV_NAME        = var.env_name
      HOST            = var.host
      PORT            = var.port
    }
  }

  timeout                        = 900
  memory_size                    = 1024
  reserved_concurrent_executions = 3

  depends_on = [
    data.aws_s3_object.bi_foundations-event-notification-lambda,
    aws_cloudwatch_log_group.bi_event-notification-lambda_log_group
  ]

}

resource "aws_cloudwatch_log_group" "bi_event-notification-lambda_log_group" {
  name = "/aws/lambda/event_notification_base-${var.env_name}"
}

resource "aws_lambda_function" "bi_dataset_entitlements-lambda" {
  function_name = "bi_dataset_entitlements-lambda-${var.env_name}"
  handler       = "dataset_entitlements_lambda.main.lambda_handler"
  runtime       = "python3.12"

  role      = aws_iam_role.bi_dataset_entitlements.arn
  s3_key            = local.dataset_entitlements_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["dataset_entitlements"].version_id

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }

  environment {
    variables = {
      BUCKET_NAME     = local.foundations_control_plane_bucket
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      ENV_NAME        = var.env_name
      HOST            = var.host
      PORT            = var.port
    }
  }

  timeout                        = 900
  memory_size                    = 1024
  reserved_concurrent_executions = 3

  depends_on = [
    data.aws_s3_object.bi_foundations_dataset_entitlements-lambda,
    aws_cloudwatch_log_group.bi_event-notification-lambda_log_group
  ]

}

resource "aws_cloudwatch_log_group" "bi_dataset_entitlements_log_group" {
  name = "/aws/lambda/dataset_entitlements_base-${var.env_name}"
}

##############################################################
################# dashboard_entitlements-lambda ###############
##############################################################

resource "aws_lambda_function" "bi_dashboard_entitlements-lambda" {
  function_name = "bi_dashboard_entitlements-lambda-${var.env_name}"
  handler       = "dashboard_entitlements_lambda.main.lambda_handler"
  runtime       = "python3.12"

  role      = aws_iam_role.bi_dashboard_entitlements.arn
  s3_key            = local.dashboard_entitlements_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["dashboard_entitlements"].version_id

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }

  environment {
    variables = {
      BUCKET_NAME     = local.foundations_control_plane_bucket
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      ENV_NAME        = var.env_name
      HOST            = var.host
      PORT            = var.port
    }
  }

  timeout                        = 900
  memory_size                    = 1024
  reserved_concurrent_executions = 3

  depends_on = [
    data.aws_s3_object.bi_foundations_dashboard_entitlements-lambda,
    aws_cloudwatch_log_group.bi_event-notification-lambda_log_group
  ]

}

resource "aws_cloudwatch_log_group" "bi_dashboard_entitlements_log_group" {
  name = "/aws/lambda/dashbord_entitlements_base-${var.env_name}"
}


##############################################################
################# dataset_notifications-lambda ###############
##############################################################


resource "aws_lambda_function" "bi_dataset_notifications-lambda" {
  function_name = "bi_dataset_notifications-lambda-${var.env_name}"
  handler       = "dataset_notifications_lambda.main.lambda_handler"
  runtime       = "python3.12"

  role              = aws_iam_role.bi_dataset_notifications.arn
  s3_key            = local.dataset_notifications_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["dataset_notifications"].version_id

  # vpc_config {
  #   subnet_ids         = var.subnet_ids                                      # List of subnet IDs
  #   security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  # }

  environment {
    variables = {
      ACCOUNT_ID      = var.account_id
      AWS_REGION_NAME = var.aws_region
      ENV_NAME        = var.env_name
    }
  }

  timeout                        = 900
  memory_size                    = 1024
  reserved_concurrent_executions = 3

}

##############################################################
############## bi_metadata_email_report-lambda ###############
##############################################################

resource "aws_lambda_function" "bi_metadata_email_report-lambda" {
  function_name = "bi_metadata_email_report-lambda-${var.env_name}"
  handler       = "metadata_email_report_lambda.main.lambda_handler"
  runtime       = "python3.12"

  role              = aws_iam_role.bi_metadata_email_report.arn
  s3_key            = local.metadata_email_report_artifact
  s3_bucket         = local.tmp_artifacts_bucket
  s3_object_version = data.aws_s3_object.pkgs["metadata_email_report"].version_id

  vpc_config {
    subnet_ids         = var.subnet_ids                                      # List of subnet IDs
    security_group_ids = [aws_security_group.bi_foundation_control_plane.id] # List of security group IDs
  }

  environment {
    variables = {
      ACCOUNT_ID                  = var.account_id
      AWS_REGION_NAME             = var.aws_region
      ENV_NAME                    = var.env_name
      SMTP_HOST                   = var.host
      SMTP_PORT                   = var.port
      OPENSEARCH_INDEX_NAME       = local.opensearch_index_name
      OPENSEARCH_ENDPOINT         = aws_elasticsearch_domain.bi_foundations_es.endpoint
      S3_BUCKET_NAME              = "cppib-df-ramcdashboard-${var.env_name}"
      GLUE_JOB_NAME               = "qs_metadata_report_job"
    }
  }

  timeout                        = 900
  memory_size                    = 1024
  reserved_concurrent_executions = 3

}