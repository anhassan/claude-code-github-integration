resource "aws_security_group" "bi_foundation_control_plane" {
  name        = "bi-foundation-control-plane-sg"
  description = "Security group for BI Foundation Control Plane"
  vpc_id      = var.opensearch_vpc # Make sure to define this variable

  tags = {
    Name = "bi-foundation-control-plane"
  }

  lifecycle {
    create_before_destroy = true
  }

  # Outbound rule to the data-discovery-elasticsearch-dev security group  
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound traffic"
  }
}

resource "aws_vpc_security_group_ingress_rule" "bi_foundations_lambda_es_sg_rule" {
  ip_protocol                  = "tcp"
  security_group_id            = aws_security_group.bi_foundations_es.id
  referenced_security_group_id = aws_security_group.bi_foundation_control_plane.id
  from_port                    = 443
  to_port                      = 443
}
