resource "aws_s3_bucket" "foundations_control_plane_bucket" {
  bucket        = local.foundations_control_plane_bucket
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "foundations_control_plane_bucket" {
  bucket = aws_s3_bucket.foundations_control_plane_bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "foundations_control_plane_bucket" {
  bucket = aws_s3_bucket.foundations_control_plane_bucket.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_notification" "foundations_control_plane_bucket_notification" {
  bucket      = aws_s3_bucket.foundations_control_plane_bucket.id
  eventbridge = true
}


resource "aws_s3_bucket" "dataset_entitlements_bucket" {
  bucket        = local.dataset_entitlements_bucket
  force_destroy = true
}


resource "aws_s3_bucket_public_access_block" "dataset_entitlements_bucket" {
  bucket = local.dataset_entitlements_bucket

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "dataset_entitlements_bucket" {
  bucket = local.dataset_entitlements_bucket
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_notification" "dataset_entitlements_bucket_notification" {
  bucket      = local.dataset_entitlements_bucket
  eventbridge = true
}

resource "aws_s3_bucket_policy" "allow_lambdas_getobjects"{

  bucket = aws_s3_bucket.dataset_entitlements_bucket.id 

  policy = jsonencode ({
    Version = "2012-10-17",
    Statement = [
      {
        Sid = "AllowLambdaReadObjects",
        Effect = "Allow",
        Action = "s3:GetObject", 
        Principal = {
          AWS = [
            "arn:aws:iam::${var.account_id}:role/bi_dataset_entitlements"
          ]
        },
        Resource = "${aws_s3_bucket.dataset_entitlements_bucket.arn}/*"
      },

      {
        Sid = "AllowLambdaPutObjects",
        Effect = "Allow",
        Action = "s3:PutObject", 
        Principal = {
          AWS = [
             "arn:aws:iam::${var.account_id}:role/bi-foundations-portal_assets_lambda-${var.env_name}_exec_role"
          ]
        },
        Resource = "${aws_s3_bucket.dataset_entitlements_bucket.arn}/*"
      }

    ]
  })
}







resource "aws_s3_bucket" "dashboard_entitlements_bucket" {
  bucket        = local.dashboard_entitlements_bucket
  force_destroy = true
}


resource "aws_s3_bucket_public_access_block" "dashboard_entitlements_bucket" {
  bucket = local.dashboard_entitlements_bucket

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "dashboard_entitlements_bucket" {
  bucket = local.dashboard_entitlements_bucket
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_notification" "dashboard_entitlements_bucket_notification" {
  bucket      = local.dashboard_entitlements_bucket
  eventbridge = true
}

resource "aws_s3_bucket_policy" "allow_dashboard_lambdas_getobjects"{

  bucket = aws_s3_bucket.dashboard_entitlements_bucket.id 

  policy = jsonencode ({
    Version = "2012-10-17",
    Statement = [
      {
        Sid = "AllowLambdaReadObjects",
        Effect = "Allow",
        Action = "s3:GetObject", 
        Principal = {
          AWS = [
            "arn:aws:iam::${var.account_id}:role/bi_dashboard_entitlements"
          ]
        },
        Resource = "${aws_s3_bucket.dashboard_entitlements_bucket.arn}/*"
      },

      {
        Sid = "AllowLambdaPutObjects",
        Effect = "Allow",
        Action = "s3:PutObject", 
        Principal = {
          AWS = [
             "arn:aws:iam::${var.account_id}:role/bi-foundations-portal_assets_lambda-${var.env_name}_exec_role"
          ]
        },
        Resource = "${aws_s3_bucket.dashboard_entitlements_bucket.arn}/*"
      }

    ]
  })
}

