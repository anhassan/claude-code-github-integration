#
## Create the OpenSearch index
#resource "opensearch_index" "asset_metadata" {
#  name               = "asset_metadata"
#  number_of_shards   = 3
#  number_of_replicas = 2
#
#  body = <<EOF
#{
#  "settings": {
#    "index": {
#      "refresh_interval": "30s"
#    }
#  },
#  "mappings": {
#    "properties": {
#      "asset_id": {"type": "text"},
#      "asset_url": {"type": "text"},
#      "asset_display_name": {"type": "keyword"},
#      "artifact_source": {"type": "text"},
#      "associated_dp": {"type": "nested"},
#      "department": {"type": "text"},
#      "owners": {"type": "text"},
#      "status": {"type": "text"},
#      "asset_type": {"type": "text"},
#      "tags": {"type": "text"},
#      "source_account": {"type": "text"},
#      "target_account": {"type": "text"},
#      "created_at": {"type": "text"},
#      "updated_at": {"type": "text"},
#      "description": {"type": "text"},
#      "update_frequency": {"type": "text"},
#      "dataset_last_updated": {"type": "text"},
#      "dashboard_last_updated": {"type": "text"},
#      "row_level_security": {"type": "text"},
#      "sheets": {
#        "type": "nested",
#        "properties": {
#          "visualizations": {
#            "type": "nested",
#            "properties": {
#              "visualization_type": {"type": "text"},
#              "visual_id": {"type": "string"},
#              "visual_name": {"type": "text"},
#              "visual_description": {"type": "string"},
#              "visual_dataset": {
#                "type": "string",
#                "properties": {
#                  "name": {"type": "string"},
#                  "visual_dimension_fields": {"type": "text"},
#                  "visual_numerical_fields": {"type": "string"}
#                }
#              },
#              "calculated_fields": {
#                "type": "nested",
#                "properties": {
#                  "dataset_identifier": {"type": "text"},
#                  "name": {"type": "text"},
#                  "expression": {"type": "text"}
#                }
#              }
#            }
#          }
#        }
#      }
#    }
#  }
#}
#EOF
#  depends_on = [data.opensearch_domain]
#}
