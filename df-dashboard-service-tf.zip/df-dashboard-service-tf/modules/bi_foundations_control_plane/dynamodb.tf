resource "aws_dynamodb_table" "bi_foundations_asset" {
  name         = "bi-foundations-asset"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "asset_id"
  range_key    = "version_id"

  attribute {
    name = "asset_id"
    type = "S"
  }

  attribute {
    name = "version_id"
    type = "S"
  }

}

resource "aws_dynamodb_table" "bi_foundations_dataset_rls" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-dataset-rls"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "workspace_id"
  range_key    = "dataset_id"

  attribute {
    name = "workspace_id"
    type = "S"
  }

  attribute {
    name = "dataset_id"
    type = "S"
  }
}

resource "aws_dynamodb_table" "bi_foundations_dataset_cls" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-dataset-cls"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "workspace_id"
  range_key    = "dataset_id"

  attribute {
    name = "workspace_id"
    type = "S"
  }

  attribute {
    name = "dataset_id"
    type = "S"
  }
}

resource "aws_dynamodb_table" "bi_foundations_asset_level_security" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-asset-level-security"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "asset_id"

  attribute {
    name = "asset_id"
    type = "S"
  }
}

resource "aws_dynamodb_table" "bi_foundations_q_topic_security" {
  name         = "${local.control_plane_conventions.bi_foundations_prefix}-q-topic-security"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "asset_id"

  attribute {
    name = "asset_id"
    type = "S"
  }
}

