resource "aws_sfn_state_machine" "metadata_processing_sfn" {
  name     = "bi-foundations-metadata-processor"
  role_arn = aws_iam_role.bi_foundation_processing_sf.arn

  definition = templatefile(
    "${path.module}/sfn_definitions/bi_foundations_metadata.json",
    {
      csv_to_json_lambda                   = aws_lambda_function.metadata_csv_to_json.function_name
      metadata_to_os_lambda                = aws_lambda_function.update_os_asset_index.function_name
      sqs_failed_dlq                       = aws_sqs_queue.bi_foundation_metadata_csv_to_json_dlq.name
      export_quicksight_definition_lambda  = aws_lambda_function.generate_qs_export_processing.function_name
      asset_level_security_upload_dynamodb = aws_lambda_function.asset_level_security_upload_dynamodb.function_name
    }
  )
}

resource "aws_sfn_state_machine" "qs_datasets_publish_sfn" {
  name     = "bi-foundations-dataset-processor"
  role_arn = aws_iam_role.bi_foundation_processing_sf.arn

  definition = templatefile(
    "${path.module}/sfn_definitions/bi_foundations_datasets.json",
    {
      prepare_dataset_payload_lambda     = aws_lambda_function.prepare_qs_dataset_payload.function_name
      quicksight_mgr_lambda              = var.dependency.quicksight_mgr_lambda.function_name
      prepare_rls_dataset_payload_lambda = aws_lambda_function.prepare_qs_dataset_rls_payload.function_name
      rls_lambda_dynamodb                = aws_lambda_function.rls_dataset_upload_dynamodb.function_name
      dataset_notifications_lambda       = aws_lambda_function.bi_dataset_notifications-lambda.function_name

    }
  )
}

resource "aws_sfn_state_machine" "qs_asset_promotion_sfn" {
  name     = "bi-foundations-asset-processor"
  role_arn = aws_iam_role.bi_foundation_processing_sf.arn

  definition = templatefile(
    "${path.module}/sfn_definitions/bi_foundations_assets.json",
    {
      prepare_asset_payload_lambda = aws_lambda_function.prepare_qs_dashboard_payload.function_name
      quicksight_mgr_lambda        = var.dependency.quicksight_mgr_lambda.function_name
    }
  )
}

resource "aws_sfn_state_machine" "bi_foundations_orchestration_sfn" {
  name     = "bi-foundations-orchestration-pipeline"
  role_arn = aws_iam_role.bi_foundation_processing_sf.arn

  definition = templatefile(
    "${path.module}/sfn_definitions/bi_foundations_orchestration.json",
    {
      qs_datasets_publish_sfn = aws_sfn_state_machine.qs_datasets_publish_sfn.arn
      qs_asset_promotion_sfn  = aws_sfn_state_machine.qs_asset_promotion_sfn.arn
      metadata_processing_sfn = aws_sfn_state_machine.metadata_processing_sfn.arn
    }
  )

  depends_on = [aws_iam_role.bi_foundation_processing_sf]
}