resource "aws_security_group" "bi_foundations_es" {
  name        = local.es_security_group_name
  description = "BI Foundations ES Security Group"
  vpc_id      = var.opensearch_vpc

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "bi_foundations_es_ingress_cidr_rule" {
  for_each          = toset(var.ingress_cidrs)
  security_group_id = aws_security_group.bi_foundations_es.id

  cidr_ipv4   = each.value
  from_port   = 443
  to_port     = 443
  ip_protocol = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "allow_vpn_prefix_es" { # Notes: this will add global protect to impacted security group inbound rules
  ip_protocol       = "tcp"                                            # Notes: such as TCP
  from_port         = 443                                              # Notes: this is the from port number we allow global protect. For example, 443
  to_port           = 443                                              # Notes: this is the to port number we allow global protect. For example, 443.  You can put from and to port as same as 443 to allow this port number
  security_group_id = aws_security_group.bi_foundations_es.id          # Notes: please replace the security group you want to update at YOUR_SECURITY_GROUP
  prefix_list_id    = data.aws_ec2_managed_prefix_list.vpn_prefix.id
  description       = "CPPIB Global Protect IP Prefix List"
}

resource "aws_vpc_security_group_ingress_rule" "allow_office_prefix_es" {
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  security_group_id = aws_security_group.bi_foundations_es.id
  prefix_list_id    = data.aws_ec2_managed_prefix_list.office_prefix.id
  description       = "CPPIB Offices IP Prefix List"
}

resource "aws_vpc_security_group_ingress_rule" "allow_vdi_prefix_es" {
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  security_group_id = aws_security_group.bi_foundations_es.id
  prefix_list_id    = data.aws_ec2_managed_prefix_list.vdi_prefix.id
  description       = "CPPIB Azure IP Prefix List"
}

resource "aws_cloudwatch_log_group" "bi_foundations_es_index_slow_logs" {
  name = "elasticsearch/${local.opensearch_domain}-index"
}

resource "aws_cloudwatch_log_group" "bi_foundations_es_search_slow_logs" {
  name = "elasticsearch/${local.opensearch_domain}-search"
}

resource "aws_cloudwatch_log_group" "bi_foundations_es_application_logs" {
  name = "elasticsearch/${local.opensearch_domain}-application"
}

resource "aws_elasticsearch_domain" "bi_foundations_es" {
  domain_name           = local.opensearch_domain
  elasticsearch_version = "7.10"

  access_policies = <<CONFIG
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": "*",
            "Action": "es:ESHttp*",
            "Resource": "arn:aws:es:${var.aws_region}:${var.account_id}:domain/${local.opensearch_domain}/*"
        }
    ]
}
CONFIG

  cluster_config {
    instance_type  = "m7g.large.elasticsearch"
    instance_count = 2

    dedicated_master_enabled = false
    dedicated_master_type    = "r7g.large.elasticsearch"
    dedicated_master_count   = 1

    zone_awareness_enabled = true
  }

  vpc_options {
    subnet_ids = var.subnet_ids

    security_group_ids = [aws_security_group.bi_foundations_es.id]
  }

  advanced_options = {
    "rest.action.multi.allow_explicit_index" = "true"
  }

  node_to_node_encryption {
    enabled = true
  }

  encrypt_at_rest {
    enabled = true
  }

  snapshot_options {
    automated_snapshot_start_hour = 23
  }

  log_publishing_options {
    cloudwatch_log_group_arn = aws_cloudwatch_log_group.bi_foundations_es_index_slow_logs.arn
    log_type                 = "INDEX_SLOW_LOGS"
  }

  log_publishing_options {
    cloudwatch_log_group_arn = aws_cloudwatch_log_group.bi_foundations_es_search_slow_logs.arn
    log_type                 = "SEARCH_SLOW_LOGS"
  }

  log_publishing_options {
    cloudwatch_log_group_arn = aws_cloudwatch_log_group.bi_foundations_es_application_logs.arn
    log_type                 = "ES_APPLICATION_LOGS"
  }

  ebs_options {
    ebs_enabled = true
    volume_type = "gp3"
    volume_size = 10
  }

  domain_endpoint_options {
    enforce_https       = true
    tls_security_policy = "Policy-Min-TLS-1-2-2019-07"
  }
}