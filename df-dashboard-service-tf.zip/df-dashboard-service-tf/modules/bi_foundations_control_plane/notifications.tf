
data "aws_iam_policy_document" "eventbridge_publish_bi_foundation_metadata" {
  statement {
    effect = "Allow"
    principals {
      identifiers = ["events.amazonaws.com"]
      type        = "Service"
    }
    actions   = ["sqs:SendMessage"]
    resources = [aws_sqs_queue.bi_foundation_metadata_csv_to_json.arn]
  }
}

resource "aws_cloudwatch_event_rule" "dq_processing_eventbridge_rule" {
  name        = local.bi_foundation_metadata_event_rule_name
  description = "Triggers when a metadata file drops in S3"

  event_pattern = <<PATTERN
{
  "source": [
    "aws.s3"
  ],
  "detail-type": [
    "Object Created",
    "Object Updated"
  ],
  "detail": {
    "bucket": {
      "name": ["${aws_s3_bucket.foundations_control_plane_bucket.id}"]
    },
    "object": {
      "key": [{
        "wildcard": "*/manifest.json"
      }]
    }
  }
}
PATTERN
}

resource "aws_cloudwatch_event_target" "sqs_topic_target_metadata" {
  rule      = aws_cloudwatch_event_rule.dq_processing_eventbridge_rule.name
  target_id = "send-to-sqs"
  arn       = aws_sqs_queue.bi_foundation_metadata_csv_to_json.arn
}

# Create an SQS queue for bi foundation metadata notifications
resource "aws_sqs_queue" "bi_foundation_metadata_csv_to_json" {
  name                       = "${local.bi_foundation_metadata_csv_to_json_sqs_prefix}-${var.env_name}"
  delay_seconds              = 3
  max_message_size           = 262144
  message_retention_seconds  = 345600
  receive_wait_time_seconds  = 20
  visibility_timeout_seconds = 120

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.bi_foundation_metadata_csv_to_json_dlq.arn
    maxReceiveCount     = 3 # Maximum number of times a message can be received before being moved to the DLQ
  })
}

resource "aws_sqs_queue_policy" "eventbridge_to_sqs" {
  queue_url = aws_sqs_queue.bi_foundation_metadata_csv_to_json.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowEventBridgeToSendMessages"
        Effect = "Allow"
        Principal = {
          Service = "events.amazonaws.com"
        }
        Action   = "sqs:SendMessage"
        Resource = aws_sqs_queue.bi_foundation_metadata_csv_to_json.arn
        Condition = {
          ArnEquals = {
            "aws:SourceArn" : aws_cloudwatch_event_rule.dq_processing_eventbridge_rule.arn
          }
        }
      }
    ]
  })
}



# Create the bi foundation metadata queue with the DLQ configured
resource "aws_sqs_queue" "bi_foundation_metadata_csv_to_json_dlq" {
  name                      = "${local.bi_foundation_metadata_csv_to_json_sqs_prefix}-dlq-${var.env_name}"
  delay_seconds             = 3
  max_message_size          = 262144
  message_retention_seconds = 345600
  receive_wait_time_seconds = 20

}

#resource "aws_sqs_queue_policy" "stepfunction_to_metadata_dlq_sqs" {
#  queue_url = aws_sqs_queue.bi_foundation_metadata_csv_to_json_dlq.id
#  policy = jsonencode({
#    Version = "2012-10-17"
#    Statement = [
#      {
#        Sid    = "AllowStepFunctionsToSendMessages"
#        Effect = "Allow"
#        Principal = {
#          AWS = aws_iam_role.metadata_processing_sf.arn
#        }
#        Action   = "sqs:SendMessage"
#        Resource = aws_sqs_queue.bi_foundation_metadata_csv_to_json_dlq.arn
#      }
#    ]
#  })
#}


# Create an SQS queue for bi foundation metadata notifications
resource "aws_sqs_queue" "bi_foundation_dataset_rls" {
  name                       = "${local.dataset_rls_processing_lambda_prefix}-${var.env_name}"
  delay_seconds              = 3
  max_message_size           = 262144
  message_retention_seconds  = 345600
  receive_wait_time_seconds  = 20
  visibility_timeout_seconds = 120

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.bi_foundation_dataset_rls_dlq.arn
    maxReceiveCount     = 3 # Maximum number of times a message can be received before being moved to the DLQ
  })
}

resource "aws_sqs_queue_policy" "bi_foundation_dataset_rls" {
  queue_url = aws_sqs_queue.bi_foundation_dataset_rls.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowEventBridgeToSendMessages"
        Effect = "Allow"
        Principal = {
          Service = "events.amazonaws.com"
        }
        Action   = "sqs:SendMessage"
        Resource = aws_sqs_queue.bi_foundation_dataset_rls.arn
        Condition = {
          ArnEquals = {
            "aws:SourceArn" : aws_cloudwatch_event_rule.bi_foundation_dataset_rls_eventbridge_rule.arn
          }
        }
      }
    ]
  })
}



# Create the bi foundation metadata queue with the DLQ configured
resource "aws_sqs_queue" "bi_foundation_dataset_rls_dlq" {
  name                      = "${local.dataset_rls_processing_lambda_prefix}-dlq-${var.env_name}"
  delay_seconds             = 3
  max_message_size          = 262144
  message_retention_seconds = 345600
  receive_wait_time_seconds = 20

}

resource "aws_sqs_queue_policy" "bi_foundation_dataset_rls_dlq_sqs" {
  queue_url = aws_sqs_queue.bi_foundation_dataset_rls_dlq.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowSourceQueueToSendToDLQ"
        Effect = "Allow"
        Principal = {
          AWS = "*"
        }
        Action   = "sqs:SendMessage"
        Resource = aws_sqs_queue.bi_foundation_dataset_rls_dlq.arn
        Condition = {
          ArnEquals = {
            "aws:SourceArn" : aws_sqs_queue.bi_foundation_dataset_rls.arn
          }
        }
      }
    ]
  })
}

resource "aws_cloudwatch_event_rule" "bi_foundation_dataset_rls_eventbridge_rule" {
  name        = "${local.dataset_rls_processing_lambda_prefix}-${var.env_name}"
  description = "Triggers when a rls.yaml file drops in S3"

  event_pattern = <<PATTERN
{
  "source": [
    "aws.s3"
  ],
  "detail-type": [
    "Object Created",
    "Object Updated"
  ],
  "detail": {
    "bucket": {
      "name": ["${aws_s3_bucket.foundations_control_plane_bucket.id}"]
    },
    "object": {
      "key": [{
        "wildcard": "*/rls.yaml"
      }]
    }
  }
}
PATTERN
}

resource "aws_cloudwatch_event_target" "bi_foundation_dataset_rls" {
  rule      = aws_cloudwatch_event_rule.bi_foundation_dataset_rls_eventbridge_rule.name
  target_id = "send-to-sqs"
  arn       = aws_sqs_queue.bi_foundation_dataset_rls.arn
}

resource "aws_cloudwatch_event_rule" "bi_foundations_workspace_s3_event" {
  name        = "bi_foundations_workspace_s3_event"
  description = "Triggers when a manifest.json file drops in a bi foundations workspace S3 folder"

  event_pattern = <<PATTERN
{
  "source": [
    "aws.s3"
  ],
  "detail-type": [
    "Object Created",
    "Object Updated"
  ],
  "detail": {
    "bucket": {
      "name": ["${aws_s3_bucket.foundations_control_plane_bucket.id}"]
    },
    "object": {
      "key": [{
        "wildcard": "*/manifest.json"
      }]
    }
  }
}
PATTERN
}

resource "aws_cloudwatch_event_target" "bi_foundations_workspace_event_target" {
  rule     = aws_cloudwatch_event_rule.bi_foundations_workspace_s3_event.name
  arn      = aws_sfn_state_machine.bi_foundations_orchestration_sfn.arn
  role_arn = aws_iam_role.bi_foundations_workspace_eb_role.arn
}


resource "aws_cloudwatch_event_rule" "bi_foundations_pipeline" {
  name        = "bi_foundations_workspace_event"
  description = "Triggers when a the orchestration pipeline succeds or fails"

  event_pattern = jsonencode({
    "source" = ["aws.states"], 
    "detail-type" = ["Step Functions Execution Status Change"],
    "detail"= {
      "status" =["FAILED", "SUCCEEDED"],
      "stateMachineArn" = [aws_sfn_state_machine.bi_foundations_orchestration_sfn.arn]
    }
  })

}

resource "aws_cloudwatch_event_target" "bi_foundations_pipeline_target" {
  rule     = aws_cloudwatch_event_rule.bi_foundations_pipeline.name
  arn      = aws_lambda_function.bi_foundations-event-notification-lambda.arn
  role_arn = aws_iam_role.bi_foundation_processing_sf.arn
}


resource "aws_cloudwatch_event_rule" "dataset_entitlements_bucket_event" {
  name        = "dataset_entitlements_bucket_event-${var.env_name}"
  description = "Triggers when an excel file drops in the entitlement bucket workspace S3 folder"

  event_pattern = <<PATTERN
{
  "source": [
    "aws.s3"
  ],
  "detail-type": [
    "Object Created",
    "Object Updated"
  ],
  "detail": {
    "bucket": {
      "name": ["${aws_s3_bucket.dataset_entitlements_bucket.id}"]
    },
    "object": {
      "key": [{
        "suffix" : ".xlsx"
      }]
    }
  }
}
PATTERN
}

resource "aws_cloudwatch_event_target" "dataset_entitlements_bucket_lambda_target" {
  rule     = aws_cloudwatch_event_rule.dataset_entitlements_bucket_event.name
  arn      = aws_lambda_function.bi_dataset_entitlements-lambda.arn
  target_id = "entitlementLambda-${var.env_name}"
}

resource "aws_lambda_permission" "eventbridge_execute_permission" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.bi_dataset_entitlements-lambda.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.dataset_entitlements_bucket_event.arn
}


resource "aws_cloudwatch_event_rule" "dashboard_entitlements_bucket_event" {
  name        = "dashboard_entitlements_bucket_event-${var.env_name}"
  description = "Triggers when an excel file drops in the dashboard entitlement bucket workspace S3 folder"

  event_pattern = <<PATTERN
{
  "source": [
    "aws.s3"
  ],
  "detail-type": [
    "Object Created",
    "Object Updated"
  ],
  "detail": {
    "bucket": {
      "name": ["${aws_s3_bucket.dashboard_entitlements_bucket.id}"]
    },
    "object": {
      "key": [{
        "suffix" : ".xlsx"
      }]
    }
  }
}
PATTERN
}

resource "aws_cloudwatch_event_target" "dashboard_entitlements_bucket_lambda_target" {
  rule     = aws_cloudwatch_event_rule.dashboard_entitlements_bucket_event.name
  arn      = aws_lambda_function.bi_dashboard_entitlements-lambda.arn
  target_id = "dashboardEntitlementLambda-${var.env_name}"
}

resource "aws_lambda_permission" "dashboard_eventbridge_execute_permission" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.bi_dashboard_entitlements-lambda.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.dashboard_entitlements_bucket_event.arn
}


############################################################################################
############## bi_metadata_email_report-lambda scheduled daily notifications ###############
############################################################################################
resource "aws_cloudwatch_event_rule" "bi_metadata_email_report_daily_8am_est_rule"{
  name        = "bi-metadata-email-report-daily-8am-est-rule"
  description = "Run Metadata Email Report Daily at 8am EST"
  schedule_expression = "cron(0 13 * * ? *)" # this cron expression is in UTC
}

resource "aws_cloudwatch_event_target" "bi_metadata_email_report_lambda_target" {
  rule      = aws_cloudwatch_event_rule.bi_metadata_email_report_daily_8am_est_rule.name
  target_id = "bi-metadata-email-report-lambda-target"
  arn       = aws_lambda_function.bi_metadata_email_report-lambda.arn
}

resource "aws_lambda_permission" "bi_metadata_email_report_allow_eventbridge" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.bi_metadata_email_report-lambda.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.bi_metadata_email_report_daily_8am_est_rule.arn
}
