resource "aws_sns_topic" "finsight_health_check_topic" {
    name = local.route53_topic
}

resource "aws_sns_topic_subscription" "finsights_health_email_target" {
    topic_arn = aws_sns_topic.finsight_health_check_topic.arn
    protocol = "email"
    endpoint = local.route53_health_check_email_dl
}

resource "aws_route53_health_check" "finsights_route53_health_check" {
    fqdn = local.finsights_domain_name
    port = 443
    type = "HTTPS"
    resource_path = "/"
    failure_threshold = "3"
    request_interval = "30"
    tags = {
        Name = "finsights_route53_health_check"
    }
}


resource "aws_cloudwatch_metric_alarm" "finsights_cloudwatch_alarm" {
    alarm_name =  "finsights_cloudwathc_alarm"
    comparison_operator = "LessThanThreshold"
    evaluation_periods = 2
    metric_name = "HealthCheckStatus"
    namespace = "AWS/Route53"
    period = 60
    statistic = "Minimum"
    threshold = 1
    actions_enabled = "true"
    treat_missing_data = "breaching"
    alarm_actions = [aws_sns_topic.finsight_health_check_topic.arn]
    dimensions = {
        HealthCheckId = aws_route53_health_check.finsights_route53_health_check.id
    }
    depends_on = [ aws_route53_health_check.finsights_route53_health_check ]
}
