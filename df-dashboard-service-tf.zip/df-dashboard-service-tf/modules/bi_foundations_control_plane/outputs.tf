output "bi_foundations_dataset_rls_table" {
  value = aws_dynamodb_table.bi_foundations_dataset_rls
}

output "bi_foundations_asset_level_security_table" {
  value = aws_dynamodb_table.bi_foundations_asset_level_security
}

output "bi_foundations_q_topic_security_table" {
  value = aws_dynamodb_table.bi_foundations_q_topic_security
}

output "bi_foundations_es_security_group" {
  value = aws_security_group.bi_foundations_es
}

output "bi_foundations_es_domain" {
  value = aws_elasticsearch_domain.bi_foundations_es
}
