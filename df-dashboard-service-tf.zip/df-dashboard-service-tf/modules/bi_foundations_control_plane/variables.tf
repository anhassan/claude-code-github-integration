variable "env_name" {}
variable "account_id" {}
variable "acc_name" {}
variable "aws_region" {}
variable "service_name" {}
variable "opensearch_vpc" {}
variable "host" {}
variable "port" {}
variable "subnet_ids" {
  type = list(string)
}

variable "bi_foundations_pkg_version" {
  type        = string
  description = "Version of bi foundations code to fetch"
  default     = "latest"
}

variable "ingress_cidrs" {
  type = list(string)
}

variable "dependency" {
  description = "This module has a dependency on resources output by another module. We use terragrunt to manage the dependencies between modules and pass the required inputs in a depedency object."
  type        = any
}

variable "lambda_versions" {
  description = "Map of lambda function name (folder names in bi-foundations) to the version folder in S3"
  type        = map(string)
}