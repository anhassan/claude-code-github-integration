resource "aws_iam_policy" "bi_foundation_data_plane_processing_policy" {
  name        = "bi-foundations-csv-asset-processing"
  description = "Policy for bi-foundations processing for Lambda"
  policy      = data.aws_iam_policy_document.read_write_bi_foundation_data_plane_processing_policy.json
}

data "aws_iam_policy_document" "lambda_qs_processing_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "qs_processing_lambda" {
  # this role is given access to the central published dashboards bucket
  name               = local.shared_conventions.quicksight_processing_role_name
  assume_role_policy = data.aws_iam_policy_document.lambda_qs_processing_assume_role.json
}

resource "aws_iam_role_policy_attachment" "qs_processing_lambda" {
  role       = aws_iam_role.qs_processing_lambda.name
  policy_arn = aws_iam_policy.bi_foundation_data_plane_processing_policy.arn
}

data "aws_iam_policy_document" "read_write_bi_foundation_data_plane_processing_policy" {
  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:PutObjectAcl",
      "s3:DeleteObject"

    ]
    resources = [
      "${aws_s3_bucket.foundations_control_plane_bucket.arn}/*",
      "arn:aws:s3:::*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"
    ]
    resources = [
      "${local.published_dashboard_bucket_arn}/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      aws_s3_bucket.foundations_control_plane_bucket.arn,
      local.published_dashboard_bucket_arn
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "es:ESHttpGet",
      "es:ESHttpPut",
      "es:ESHttpPost",
      "es:ESHttpDelete",
      "es:ESHttpHead"
    ]
    resources = [
      "arn:aws:es:${var.aws_region}:${var.account_id}:domain/${local.opensearch_domain}/${local.opensearch_index_name}*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetBucketLocation"
    ]
    resources = [
      "arn:aws:s3:::*"
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "lakeformation:GetDataAccess"
    ]
    resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
       "quicksight:UpdateDashboardPermissions",
        "quicksight:DescribeDashboard",
        "quicksight:DescribeDashboardDefinition",
        "quicksight:ListDashboardVersions",
        "quicksight:DescribeDashboardPermissions"
        ]
    resources = ["arn:aws:quicksight:${var.aws_region}:${var.account_id}:dashboard/*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "quicksight:UpdateDataSet",
      "quicksight:DescribeDataSet",
      "quicksight:CreateIngestion",
      "quicksight:DescribeIngestion"
    ]
    resources = [
      "arn:aws:quicksight:${var.aws_region}:${var.account_id}:dataset/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "quicksight:DescribeDataSource"
    ]
    resources = [
      "arn:aws:quicksight:${var.aws_region}:${var.account_id}:datasource/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:BatchWriteItem",
      "dynamodb:DeleteItem",
      "dynamodb:Scan"
    ]
    resources = [
      aws_dynamodb_table.bi_foundations_dataset_rls.arn,
      "${aws_dynamodb_table.bi_foundations_dataset_rls.arn}/index/*",
      aws_dynamodb_table.bi_foundations_dataset_cls.arn,
      "${aws_dynamodb_table.bi_foundations_dataset_cls.arn}/index/*",
      aws_dynamodb_table.bi_foundations_asset_level_security.arn,
      aws_dynamodb_table.bi_foundations_q_topic_security.arn
    ]
  }

}

resource "aws_iam_role_policy_attachment" "lambda_vpc" {
  role       = aws_iam_role.qs_processing_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

resource "aws_iam_role" "bi_foundation_processing_sf" {
  name               = "bi-foundation-sf"
  assume_role_policy = data.aws_iam_policy_document.bi_foundation_processing_sf.json

}

data "aws_iam_policy_document" "bi_foundation_processing_sf" {
  statement {
    actions = ["sts:AssumeRole"]
    effect  = "Allow"
    principals {
      type        = "Service"
      identifiers = ["states.amazonaws.com", "events.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "sf_execution" {


  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:DeleteObject"

    ]
    resources = [
      "${aws_s3_bucket.foundations_control_plane_bucket.arn}/*",

    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "states:StartExecution",
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:stateMachine:*",
    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:stateMachine:*",
    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "states:DescribeExecution",
      "states:StopExecution"
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:execution:*:*",
    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "events:PutTargets",
      "events:PutRule",
      "events:DescribeRule",
    ]
    resources = [
      "arn:aws:events:${var.aws_region}:${var.account_id}:rule/StepFunctionsGetEventsForStepFunctionsExecutionRule"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      aws_s3_bucket.foundations_control_plane_bucket.arn
    ]
  }

  # SQS permissions
  statement {
    effect = "Allow"

    actions = [
      "sqs:SendMessage",
      "sqs:ReceiveMessage",
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes",
      "sqs:GetQueueUrl"
    ]

    resources = [
      aws_sqs_queue.bi_foundation_metadata_csv_to_json_dlq.arn
    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "lambda:InvokeFunction",
      "lambda:InvokeAsync"
    ]

    resources = [
      var.dependency.quicksight_mgr_lambda.arn,
      aws_lambda_function.metadata_csv_to_json.arn,
      aws_lambda_function.update_os_asset_index.arn,
      aws_lambda_function.prepare_qs_dataset_payload.arn,
      aws_lambda_function.prepare_qs_dashboard_payload.arn,
      aws_lambda_function.prepare_qs_dataset_rls_payload.arn,
      aws_lambda_function.rls_dataset_upload_dynamodb.arn,
      aws_lambda_function.generate_qs_export_processing.arn,
      aws_lambda_function.asset_level_security_upload_dynamodb.arn,
      aws_lambda_function.bi_foundations-event-notification-lambda.arn,
      aws_lambda_function.bi_dataset_notifications-lambda.arn
    ]
  }
}

resource "aws_iam_policy" "bi_foundation_sf_policy" {
  name        = "bi-foundations-sf-processing"
  description = "Policy for bi-foundations step function control plane"
  policy      = data.aws_iam_policy_document.sf_execution.json
}

resource "aws_iam_role_policy_attachment" "sf_processing" {
  role       = aws_iam_role.bi_foundation_processing_sf.name
  policy_arn = aws_iam_policy.bi_foundation_sf_policy.arn
}

data "aws_iam_policy_document" "bi_foundations-event-notification" {
 statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "notification_execution" {

  statement {
            actions = [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds",
                "secretsmanager:ListSecrets"
            ]
            effect = "Allow"
            resources = ["*"]
        }

  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  
  } 

  statement {
    effect = "Allow"

    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:stateMachine:*",
    ]
  } 

    statement {
    effect = "Allow"

    actions = [
      "states:GetExecutionHistory", 
      "states:ListExecutions"
    ]
    resources = ["*"]
  }   

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"

    ]
    resources = [
      "${aws_s3_bucket.foundations_control_plane_bucket.arn}/*",
    ]
  }     

}

resource "aws_iam_role" "bi_foundations-event-notification" {
  name               = "bi_foundations-event-notification"
  assume_role_policy = data.aws_iam_policy_document.bi_foundations-event-notification.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]

}

resource "aws_iam_role_policy" "bi_foundations-event-notification-policy" {
  name        = "bi_foundations-event-notification"
  role = aws_iam_role.bi_foundations-event-notification.name
  policy      = data.aws_iam_policy_document.notification_execution.json
}

# IAM role for the pipe
resource "aws_iam_role" "pipe_role" {
  name = "bi-foundation-metadata-processing-pipe-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "pipes.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role" "bi_foundations_workspace_eb_role" {
  name = "bi-foundation-workspace-eb-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "events.amazonaws.com"
        }
      }
    ]
  })
}

data "aws_iam_policy_document" "bi_foundations_workspace_eb_policy_document" {
  statement {
    effect = "Allow"

    actions = [
      "states:StartExecution"
    ]
    resources = [
      aws_sfn_state_machine.bi_foundations_orchestration_sfn.arn,
    ]
  }
}

resource "aws_iam_policy" "bi_foundations_workspace_eb_policy" {
  name        = "bi_foundations_workspace_eb_policy"
  description = "Policy for bi-foundations eventbridge trigger for workspace orchestration pipeline"
  policy      = data.aws_iam_policy_document.bi_foundations_workspace_eb_policy_document.json
}

resource "aws_iam_role_policy_attachment" "bi_foundations_workspace_eb_policy_attachment" {
  role       = aws_iam_role.bi_foundations_workspace_eb_role.name
  policy_arn = aws_iam_policy.bi_foundations_workspace_eb_policy.arn
}

data "aws_iam_policy_document" "metadata_eventbridge_pipe" {


  # SQS permissions
  statement {
    effect = "Allow"

    actions = [
      "sqs:ReceiveMessage",
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes"
    ]

    resources = [
      aws_sqs_queue.bi_foundation_metadata_csv_to_json.arn,
      aws_sqs_queue.bi_foundation_dataset_rls.arn
    ]
  }

  # SFN permissions
  statement {
    effect = "Allow"

    actions = [
      "states:StartExecution"
    ]
    resources = [
      aws_sfn_state_machine.metadata_processing_sfn.arn,
      aws_sfn_state_machine.qs_datasets_publish_sfn.arn
    ]
  }

  statement {
    effect = "Allow"

    actions = [
      "lambda:InvokeFunction"
    ]
    resources = [
      aws_lambda_function.rls_dataset_upload_dynamodb.arn
    ]
  }
}

resource "aws_iam_policy" "bi_foundation_metadata_pipe_policy" {
  name        = "bi-foundations-ebpipes-metadata-processing"
  description = "Policy for bi-foundations eventbridge pipes"
  policy      = data.aws_iam_policy_document.metadata_eventbridge_pipe.json
}

resource "aws_iam_role_policy_attachment" "eb_pipes_metadata_processing" {
  role       = aws_iam_role.pipe_role.name
  policy_arn = aws_iam_policy.bi_foundation_metadata_pipe_policy.arn
}

data "aws_iam_policy_document" "bi_dataset_entitlements" {
 statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "events.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "dataset_entitlements_execution" {

  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  
  } 

  statement {
    effect = "Allow"

    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:stateMachine:*",
    ]
  } 

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"

    ]
    resources = [
      "${aws_s3_bucket.dataset_entitlements_bucket.arn}/*",
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:Scan",
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:BatchWriteItem",
      "dynamodb:DeleteItem", 
      "dynamodb:ListTables", 
      "dynamodb:UpdateTable", 
      "dynamodb:CreateTable", 
      "dynamodb:DeleteTable", 
      "dynamodb:DescribeTable"
    ]
    resources = [
      "arn:aws:dynamodb:us-east-1:200967598245:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:885014163466:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:207662059077:table/bi-foundations-entitlements-*",
      "arn:aws:dynamodb:us-east-1:679601897237:table/bi-foundations-entitlements-*",

      "arn:aws:dynamodb:us-east-1:200967598245:table/bi-foundations-workspace-rls-entitlements-mapping",
      "arn:aws:dynamodb:us-east-1:885014163466:table/bi-foundations-workspace-rls-entitlements-mapping",
      "arn:aws:dynamodb:us-east-1:207662059077:table/bi-foundations-workspace-rls-entitlements-mapping",
      "arn:aws:dynamodb:us-east-1:679601897237:table/bi-foundations-workspace-rls-entitlements-mapping"
    ]
  }     

}

resource "aws_iam_role" "bi_dataset_entitlements" {
  name               = "bi_dataset_entitlements"
  assume_role_policy = data.aws_iam_policy_document.bi_dataset_entitlements.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]

}

resource "aws_iam_role_policy" "bi_dataset_entitlements-policy" {
  name        = "bi_dataset_entitlements"
  role = aws_iam_role.bi_dataset_entitlements.name
  policy      = data.aws_iam_policy_document.dataset_entitlements_execution.json
}

############################################################
################dashboard entitlements######################
############################################################

data "aws_iam_policy_document" "bi_dashboard_entitlements" {
 statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "events.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "dashboard_entitlements_execution" {

  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  
  } 

  statement {
    effect = "Allow"

    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "arn:aws:states:${var.aws_region}:${var.account_id}:stateMachine:*",
    ]
  } 

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"

    ]
    resources = [
      "${aws_s3_bucket.dashboard_entitlements_bucket.arn}/*",
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:Scan",
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:BatchWriteItem",
      "dynamodb:DeleteItem", 
      "dynamodb:ListTables", 
      "dynamodb:UpdateTable", 
      "dynamodb:CreateTable", 
      "dynamodb:DeleteTable", 
      "dynamodb:DescribeTable"
    ]
    resources = [
      "arn:aws:dynamodb:us-east-1:200967598245:table/bi-foundations-workspace-als-entitlements",
      "arn:aws:dynamodb:us-east-1:885014163466:table/bi-foundations-workspace-als-entitlements",
      "arn:aws:dynamodb:us-east-1:207662059077:table/bi-foundations-workspace-als-entitlements",
      "arn:aws:dynamodb:us-east-1:679601897237:table/bi-foundations-workspace-als-entitlements"
    ]
  }     

}

resource "aws_iam_role" "bi_dashboard_entitlements" {
  name               = "bi_dashboard_entitlements"
  assume_role_policy = data.aws_iam_policy_document.bi_dashboard_entitlements.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]

}

resource "aws_iam_role_policy" "bi_dashboard_entitlements-policy" {
  name        = "bi_dashboard_entitlements"
  role = aws_iam_role.bi_dashboard_entitlements.name
  policy      = data.aws_iam_policy_document.dashboard_entitlements_execution.json
}



##############################################################
################ dataset_notifications-iam-role ##############
##############################################################

data "aws_iam_policy_document" "bi_dataset_notifications" {
 statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "events.amazonaws.com"]
    }
  }
}


resource "aws_iam_role" "bi_dataset_notifications" {
  name               = "bi_dataset_notifications"
  assume_role_policy = data.aws_iam_policy_document.bi_dataset_notifications.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]

}

resource "aws_iam_role_policy" "bi_dataset_notifications-policy" {
  name        = "bi_dataset_notifications"
  role = aws_iam_role.bi_dataset_notifications.name
  policy      = data.aws_iam_policy_document.dataset_notifications_execution.json
}

data "aws_iam_policy_document" "dataset_notifications_execution" {

  statement {
    effect = "Allow"
    actions = [
      "quicksight:DescribeDataSetPermissions",
      "quicksight:UpdateDataSetPermissions",
      "quicksight:DescribeDataSetRefreshProperties",
      "quicksight:PutDataSetRefreshProperties",
      "quicksight:DescribeDataSet",
      "quicksight:ListIngestions",
      "quicksight:DescribeIngestion",
      "quicksight:CreateIngestion",
      "quicksight:CancelIngestion",
      "quicksight:UpdateDataSet",
      "quicksight:DeleteDataSet",
      "quicksight:PassDataSet"
    ]
    resources = [
      "*"
    ]
  
  } 

}


##############################################################
################ metadata_email_report-iam-role ##############
##############################################################

data "aws_iam_policy_document" "bi_metadata_email_report" {
 statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com", "events.amazonaws.com"]
    }
  }
}


resource "aws_iam_role" "bi_metadata_email_report" {
  name               = "bi_metadata_email_report"
  assume_role_policy = data.aws_iam_policy_document.bi_metadata_email_report.json
  managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
  ]

}

resource "aws_iam_role_policy" "bi_metadata_email_report-policy" {
  name        = "bi_metadata_email_report"
  role        = aws_iam_role.bi_metadata_email_report.name
  policy      = data.aws_iam_policy_document.metadata_email_report_execution.json
}

data "aws_iam_policy_document" "metadata_email_report_execution" {

  statement {
    effect = "Allow"
    actions = [
      "quicksight:DescribeDataSetPermissions",
      "quicksight:DescribeDataSetRefreshProperties",
      "quicksight:DescribeDataSet",
      "quicksight:ListIngestions",
      "quicksight:DescribeIngestion",
      "quicksight:DescribeDashboardDefinition",
      "quicksight:DescribeDashboard",
      "quicksight:ListDashboards"
    ]
    resources = [
      "*"
    ]
  
  } 

  statement {
    effect = "Allow"
    actions = [
      "es:ESHttpGet",
      "es:ESHttpPut",
      "es:ESHttpPost",
      "es:ESHttpDelete",
      "es:ESHttpHead"
    ]
    resources = [
      "arn:aws:es:${var.aws_region}:${var.account_id}:domain/${local.opensearch_domain}/${local.opensearch_index_name}*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "glue:StartJobRun"
    ]
    resources = [
      "arn:aws:glue:${var.aws_region}:${var.account_id}:job/qs_metadata_report_job"
    ]
  }

  statement {
    actions = ["s3:Get*", "s3:List*", "s3:Put*"]
    resources = [
      "arn:aws:s3:::cppib-df-ramcdashboard-${var.env_name}",
      "arn:aws:s3:::cppib-df-ramcdashboard-${var.env_name}/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "ec2:DescribeInstances",
      "ec2:CreateNetworkInterface",
      "ec2:AttachNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DeleteNetworkInterface"
    ]
    resources = [
      "*"
    ]
  
  } 

  statement {
      actions = [
          "secretsmanager:GetResourcePolicy",
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret",
          "secretsmanager:ListSecretVersionIds",
          "secretsmanager:ListSecrets"
      ]
      effect = "Allow"
      resources = ["*"]
  }

}