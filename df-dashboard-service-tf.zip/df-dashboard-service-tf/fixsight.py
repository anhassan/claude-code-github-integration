"""
Attempts to handle JSON errors by populating missing fields in dashboard
entries from the underlying analysis
"""
import json

import boto3
import botocore

source_account = "274628362356"
account_id = "939137667622"

client = boto3.client("quicksight", region_name="us-east-1")

dashboard_def_file = "test_defs/dashboard_definition.json"
fixed_def_file = "test_defs/fixed_dashboard_definition.json"

class FixSight(object):
    def __init__(self, client, dashboard_file):
        self.client = client
        self.dashboard_file = dashboard_file
        self.fixed_file = fixed_def_file
        self.dashboard = self.load_def_data(dashboard_file)
        self.dashboard_id = self.dashboard["DashboardId"]
        self.error = None
        self.resolved_errors = []

    def load_def_data(self, def_file):
        with open(def_file, "r") as f:
            return json.load(f)

    def reload_fixed_file(self):
        self.dashboard = self.load_def_data(self.fixed_file)

    def get_empty_scoping_configs(self):
        return [
            g["FilterGroupId"] for g in self.dashboard["Definition"]["FilterGroups"]
            if g["ScopeConfiguration"]["SelectedSheets"]["SheetVisualScopingConfigurations"] == []
        ]

    def drop_unscoped_filter_groups(self):
        fixed_filter_groups = [
            g for g in self.dashboard["Definition"]["FilterGroups"]
            if g["ScopeConfiguration"]["SelectedSheets"]["SheetVisualScopingConfigurations"] != []
        ]
        self.dashboard["Definition"]["FilterGroups"] = fixed_filter_groups

    @property
    def get_dashboard_sheets(self):
        return [(s["SheetId"], s["Name"]) for s in self.dashboard["Definition"]["Sheets"]]

    def write_fixed_file(self):
        with open(fixed_def_file, "w") as f:
            json.dump(self.dashboard, f, ensure_ascii=False, indent=4)

    def try_create(self):
        theme_arn = self.dashboard["ThemeArn"]
        name = self.dashboard["Name"]
        try:
            response = client.create_dashboard(
                AwsAccountId=account_id,
                DashboardId="test-fixsight-{}".format(self.dashboard_id),
                Definition=self.dashboard["Definition"],
                ThemeArn=theme_arn,
                Name="test-fixsight-{}".format(name)
            )
            print(response)
        except botocore.exceptions.ParamValidationError as e:
            # print("Error: {}".format(e))
            self.error = e.__dict__["kwargs"]["report"]
            print(self.error)
            print("paths: {}".format([m.strip(",") for m in self.error.split() if "." in m]))
        except client.exceptions.InvalidParameterValueException as e:
            self.error = e.__dict__["response"]["Error"]["Message"]
            print(e)


f = FixSight(client, dashboard_def_file)
