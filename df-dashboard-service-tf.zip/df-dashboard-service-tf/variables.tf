variable "account_id" {}
variable "acc_name" {}
variable "aws_region" {}
variable "name_suffix" { default = "" }
variable "env_name" {}
variable "artifact_bucket" { default = "" }
variable "artifact_path" { default = "" }
variable "service_name" {
  type = string
}
variable "base_tags" {
  type = map(any)
}
variable "config_path" {
  type        = string
  description = "The path to config files, relative to path.root, default is \"../../../cfg\" for standard df*-deploy repo structure"
  default     = "../../../cfg"
}
variable "associated_accounts" {
  type        = map(any)
  description = "Account id map (e.g. {dev: 0123456789012 qa: 210987654321}) that can access the published dashboards bucket"
}
variable "admin_groups" {
  type        = list(string)
  description = "The core QS Admin AD groups that will have access to the datasources folder"
}
variable "vpc_info" {
  type = object({
    vpc_id     = string
    subnet_ids = list(string)
  })
  default = {
    vpc_id     = "DO_NOT_CREATE"
    subnet_ids = []
  }
}

variable "lambda_versions" {
  description = "Map of lambda function name (folder names in bi-foundations) to the version folder in S3"
  type        = map(string)
}

variable "vpc_id" {
  type = string
  description = "Vpc Id of the DataFabric Vpc being provided by insights terragrunt file"
  
}

variable "private_subnets" {
  type = list(string)
}

variable "smtp_host" {
  description = "This is the host name of the smtp server"
  type = string
}

variable "smtp_port" {
  description = "This is the port used by the smtp server"
  type = string
}