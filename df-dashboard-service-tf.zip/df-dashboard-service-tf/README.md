
<!-- TOC -->

- [BI Foundations TF](#bi-foundations-tf)
- [AD Groups and Users](#ad-groups-and-users)
    - [BI Foundations Preflight for Admins](#bi-foundations-preflight-for-admins)
        - [BI SSO Setup](#bi-sso-setup)
        - [S3 Support](#s3-support)
    - [Using the BI Foundations Preview Module](#using-the-bi-foundations-preview-module)
        - [Connections](#connections)
        - [Sync Operations](#sync-operations)
        - [Datasets](#datasets)
            - [Scheduled Refresh](#scheduled-refresh)
            - [Row Level Security](#row-level-security)
        - [Projects](#projects)
        - [Dashboard Config](#dashboard-config)
        - [Role Groups](#role-groups)

<!-- /TOC -->


# BI Foundations (TF)

Provides:

* AD SSO and user management via AD groups
* Automated dataset and RLS setup from config
* Autoamted dataset scheduled refresh setup from config
* Automated export and versioning of assets
* Automated promotion of dashboards, themes, and datasets through BI ops lifecycle
* Workspace management
* Guardrails and best practices out of the box
* Usage tracking for BI asset discovery

Future Releases:

* UI-based BI estate management
* BI Portal integrations

The foundations team is seeking your feedback!  Please reach out to darrenyohan@cppib.com with comments.

# AD Groups and Users

Throughout the module, permissions can be assigned to @cppib.com email addresses for individuals or to AWS_SSO_* AD groups.

**Note that AD group names are CASE_SENSITIVE**, please assign users carefully.

## BI Foundations Preflight (for Admins)

There are some manual, pre-flight steps necessary that cannot be automated at this time due to limitations within the QuickSight API.

### 1. BI SSO Setup
To onboard to SSO for BI users (one-click sharing), follow the steps outlined here: https://cppib.atlassian.net/wiki/spaces/MA/pages/269190552/Onboarding+to+QuickSight+SSO

### 2. S3 Support
Log in to to the AWS SSO portal using your CPPIB-QuickSight-Admin permission set:
![BI Admin Login](./screens/bi_admin_login_sso.PNG)

Once you've logged in, click the user profile and select `Manage QuickSight` from the dropdown:
![BI Admin](./screens/bi_admin_manage.PNG)

From the security & permissions tab, click Manage under QuickSight access to AWS services:
![BI Security & Permissions](./screens/bi_sec_manage.PNG)

Finally, add any S3 bucket by checking the box beside Amazon S3 and selecting any S3 bucket.
![BI S3](./screens/bi_add_s3.PNG)

**Note any bucket can be added here (e.g. athena results bucket) -- the BI Foundations automation will set up permissions for any of its buckets when your pipeline runs.**

## Using the BI Foundations Preview Module

In general, authors are encouraged to create assets freely in DEV accounts.  The BI Foundations automation is designed to port assets from DEV to QA/UAT and PROD accounts based on the state of the assets in the DEV account.
BI Foundations also provides overrides for version control that fill gaps in the QuickSight API.

The BI Foundations (preview) module is comprised of the following folder and file format:

```
cfg/
    datasets/
    role_groups/
    themes/
    projects/
```

### Connections

The connections folder drives configuration for security groups (network layer access) from QuickSight to a variety of different DB targets including RDS, on-prem DBs, etc.

Connections currently supports:

* `[local]` connections to resources in the same AWS account as the QS deployment via security group reference
* `[aws_accounts]` connections to resources in another account via preset CIDR lists
* `[on-prem]` connections to resources to on-prem resources via preset CIDR lists

These 3 connection types are defined in a yaml file inside the `cfg/connections` folder.

See the [example connections file](./tests/cfg/connections/holdings.yaml)

### Sync Operations

When running your pipeline, you will notice that the following resources always require replacement:

```
# module.estate.aws_lambda_invocation.dashboards["ExampleWorkspace/example_dashboard"] must be replaced
# module.estate.aws_lambda_invocation.rolegroups must be replaced
```

These resources are designed to handle syncing operations and will run idempotently to sync on every apply.

### Datasets

Datasets are defined in subfolders under the `datasets` folder shown above.  A dataset subfolder contains **specific files**:

```
datasets/
    cost_insights_report/
        metadata.yaml
        query.sql
        rls.csv (optional)
```

The `metadata.yaml` file defines metadata associated with the dataset and takes the form:

```
name: name_of_the_dataset
import_mode: SPICE | DIRECT_QUERY
workspace: workspace_to_assign_to
columns: mapping of column_name : column_type
refresh_schedule: mapping that complies with the AWS API definitions here: https://docs.aws.amazon.com/quicksight/latest/APIReference/API_RefreshSchedule.html
```

Note that SubTypes are supported using . notation e.g. `DECIMAL.FLOAT`

The `query.sql` file defines the query that will be run to create the dataset and supports the use of ${env} for environment substitution.

e.g.:
```
...
from
    finance_accounting_${env}.cost_insights_report 
where
    processed_datetime = ( select max(processed_datetime) from finance_accounting_${env}.cost_insights_report )
    and fiscal_year >= 2019
group by
      calendar_date 
...
```

#### Scheduled Refresh

BI Foundations supports refresh_schedules for all the parameters permitted by the AWS refresh_schedule API (https://docs.aws.amazon.com/quicksight/latest/APIReference/API_RefreshSchedule.html)

For example the following refresh schedule will fully refresh the dataset every month, on the 3rd day of the month, at midnight EST.
```
...
refresh_schedule:
  ScheduleId: monthly_refresh
  RefreshType: "FULL_REFRESH"
  ScheduleFrequency:
    Interval: MONTHLY
    RefreshOnDay:
      DayOfMonth: "3"
    Timezone: "Canada/Eastern"
    TimeOfTheDay: "00:00"

```

#### Row Level Security

Finally the optional `rls.csv` defines row-level-security for the dataset.  For information on constructing these files see: https://docs.aws.amazon.com/quicksight/latest/user/restrict-access-to-a-data-set-using-row-level-security.html

e.g.:
|GroupName                             |account_lvl_0             |
|---------------------------------------|--------------------------|
|AWS_SSO_Example_Developer_Group         |                          |
|AWS_SSO_Example_RFT_Group |CPPIB_Ending RFT HeadCount|


### Projects

In higher-environments, **all assets must be part of a project**.  A project is equivalent to a Quicksight shared folder (https://docs.aws.amazon.com/quicksight/latest/user/folders.html)

Projects are created by creating folders under the projects folder and subfolders are supported.  For example the following setup will create 2 parent folders (`CostProducts` and `ManagementAnalytics` and one subfolder called `Holdings`):

```
projects/
    CostProducts/
    ManagementAnalytics/
        Holdings/
```

Each workspace folder should contain at least 1 file called `permissions.yaml` that has the form:

```
owners:
  - someperson@cppib.com

contributors:
  - AWS_SSO_SomeOtherADGroup

viewers:
  - AWS_SSO_SomeADGroup
```

This file defines the permissions for the folder.  Assets (such as dashboards) are described in the workspace folder, linking the asset to the workspace.

For example, here is a dashboard that is tied to the CostProducts workspace:

```
projects/
    CostProducts/
        permissions.yaml # required file
        dept_cost_dashboard.yaml # defines an asset that should be imported/created in this workspace
```

### Dashboard Config

For information on naming conventions for dashboards see this confluence page: https://cppib.atlassian.net/wiki/spaces/MA/pages/236486841/QuickSight+-+Folder+Structure+and+Naming+Conventions#2.1-Naming-Conventions

For a high-level view of how Dashboard syncing works see this page: https://cppib.atlassian.net/wiki/spaces/MA/pages/270929329/Dynamic+Dashboard+Sync

BI Foundations supports Many:1 relationships between DEV analyses and dashboards and any given PROD dashboard allowing for versioned-branches of dashboards to support e.g. hotfix, epic, and feature development flows.

When dashboards are created or updated in the DEV account, they are exported and versioned by event-based triggers deployed by the BI Foundations module.  The dashboard config enables teams to promote specific versions of their dashboards (and associated themes) to higher environments.  

A single dashboard config file defines the dashboard to be imported, it's version, and to which owners and viewers permissions should be granted.

Dashboard config files exist in a given workspace (see above) and take the form:

```
base_dashboard_name: CostDashboardCorrected # this is the dashboard base name that we will pull from in the DEV account
display_name: Department Cost Dashboard # this is the display name of the dashboard itself
id_prefix: ma_cost_dashboard # this is the id that will be used in all links to this dashboard (no spaces, changing this changes dashboard links)
branch: PROD # the branch to pull from in the DEV account (CostDashboard/PROD)
version: 1 # the version of the <BaseName>/<Branch> dashboard to use for populating this dashboard
use_fixed: true
owners:
  - AWS_SSO_Example_Owner_Group
viewers:
  - AWS_SSO_Example_Viewer_Group
```

Note that the `use_fixed` parameter will force the dashboard deploy to use a file called `fixed_dashboard_definition` for a given branch version of the dashboard artifact.  This is to handle cases where AWS dashboard exports do not create perfect replicas of the source dashboard for promotion.  If you encounter errors relating to paramtervalidation failures and/or elements dropped from your dashboards on export, open an AWS Support Case and CC foundations team.

Note that row-level security for a dashboard is defined on the **dataset** to which the dashboard is associated.  It is not defined at the dashboard level.  See the datasets section above for info on defining row-level security.

### Role Groups

Role groups define role assignments to QuickSight roles (AUTHOR, ADMIN, READER) and AD groups.  They should be found in the `role_groups` folder in a file called `role_groups.yaml` and take the form:

```
Reader:
  - AWS_SSO_Example_Reader_Group

Author:
  - AWS_SSO_Example_Author_Group

Admin:
  - AWS_SSO_Example_Admin_Group
```

These groups define which AD groups will be able to login via the `applications` tab on the AWS SSO console page and what role they will be assigned when logging into QuickSight.
