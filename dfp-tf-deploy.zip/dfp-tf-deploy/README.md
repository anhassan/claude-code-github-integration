# dfp-tf-deploy

# DEVELOPER TOOLS SETUP

Install the following command line terminal tools in your WSL/Linux environment:

| Required Tools | Installation Guide |
| ---- | ---- |
|   terraform |  https://developer.hashicorp.com/terraform/install | 
|   terragrunt |  https://terragrunt.gruntwork.io/docs/getting-started/install/ | 
|   git |  https://git-scm.com/book/en/v2/Getting-Started-Installing-Git | 
|   gh  |  https://github.com/cli/cli/blob/trunk/docs/install_linux.md| 
|   yq  | https://github.com/mikefarah/yq/#install   | 

To login to GitHub enterpise, run 

    gh auth login

and follow the prompts. 

Make sure to select Github Enterprise Server and provide the host url as (github.com)

**IMPORTANT:** 

The github actions in this repo use the environment variable, 

```
    secrets.SVC_DF_FOUNDATION_GITHUB_TOKEN 
``` 

The token in this variable is generated using the AD service account `svc_df_foundation`

When deploying the stack to a new account you must ensure that the accout is defined in df-foundation vault config git-repo 

https://github.com/cppib-all/devops-vault-tf/blob/master/github-action-config/df-foundation.yaml

