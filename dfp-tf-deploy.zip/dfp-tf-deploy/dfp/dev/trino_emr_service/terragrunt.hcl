# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

# see https://terragrunt.gruntwork.io/docs/reference/config-blocks-and-attributes/#skip
# IMPORTANT: 
# If set true on a repo that is a dependancy, then the mocked output values defined in 
# the dependant service will be passed to the dependant module.
skip            = include.root.locals.params.services.trino_emr_service.skip_deployment
prevent_destroy = include.root.locals.params.services.trino_emr_service.prevent_destroy

locals {

  # Artifact versions to deploy
  repo_name = include.root.locals.params.services.trino_emr_service.repo
  release_version = include.root.locals.params.services.trino_emr_service.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name            = include.root.locals.environment.env_name
  acc_name            = include.root.locals.environment.acc_name
  name_suffix         = include.root.locals.environment.name_suffix
  base_tags           = include.root.locals.environment.base_tags
  artifact_bucket     = include.root.locals.environment.artifact_bucket
  vpc_id              = include.root.locals.environment.vpc.id
  vpc_name              = include.root.locals.environment.vpc.name
  vpc_private_subnets = include.root.locals.environment.vpc.private_subnets
  top_level_domain    = include.root.locals.environment.api_gateway.top_level_domain
  execute_api_private = include.root.locals.environment.api_gateway.execute_api_private

}

terraform {
  source = "git::git@github.com:${local.repo_name}//workspaces/df-pipeline?ref=${local.release_version}"
}

# These are the variables we have to pass in to use the module specified in the terragrunt configuration above
inputs = {

  # IMPORTANT: 
  # Tag values may only contain unicode letters, digits, whitespace, or one of these symbols: '_ . : / = + \ -'
  account_id             = local.account_id
  principals_identifiers = ["arn:aws:iam::836088430007:root"]
  vpc_id                 = local.vpc_id
  vpc_name               = local.vpc_name
  private_subnet_ids     = local.vpc_private_subnets
  emr_subnet_id          = "subnet-006ed9bcaecbf6938"
  env_name               = local.env_name 
  acc_name               = local.acc_name
  bucket_env_name        = local.env_name 

  sg_ingress_cidr_blocks = [
    "10.34.0.0/16",
    "10.35.0.0/16",
    "10.38.0.0/16",
    "10.68.0.0/16",
    "10.78.0.0/16",
    "10.79.20.0/16",
    "10.97.0.0/16"
  ]
  cluster_name        = "trino-emr"
  cluster_name_suffix = "low-latency-graviton"
  service_name                  = "trino"
  #Valid values["regular-cluster","trino-cluster"]
  cluster_type            = "trino-events"
  whitelist_ips           = ["10.0.0.0/8"]
  secrets_prefix          = "emr"
  recovery_window_in_days = 7
  spark_log_level         = "INFO"
  custom_ami_id           = "ami-0f93c02efd1974b8b"
  artifact_s3_location    = "serverlessrepo.cppib.io/df-extras"
  emr_release             = "emr-7.0.0"
  emr_cluster_apps        = ["Trino"]

  termination_protection        = false
  auto_termination_enabled      = false
  auto_termination_idle_timeout = 3600
  step_concurrency_level        = 20

  route53_domain_name = local.top_level_domain
  cert_domain_name    = local.top_level_domain
  sub_domain          = local.top_level_domain

  email_host = "10.78.16.250"
  email_from = "datafabric_info@cppib.com"
  email_to   = "tandd_desubledgerandreporting@cppib.com"

  
  # DMS params
  dms_name                  = "trinodms"
  dms_sg_name               = "trinodms"
  dms_ingress_rules         = [{
    description = "mysql",
    from_port   = 3306,
    to_port     = 3306,
    protocol    = "TCP",
    cidr_blocks = ["10.0.0.0/8"],
  }]

  dms_subnet_a                     = "edl-data-fabric-private-additional-us-east-1a"
  dms_subnet_b                     = "edl-data-fabric-private-additional-us-east-1b"
  dms_instance_name                = "trino-dms-instance"
  dms_preferred_maintenance_window = "sun:10:36-sun:11:06"
  replication_instance = {
    1 = {
    replication_instance_class = "dms.r5.large",
    engine_version             = "3.5.1",
    allocated_storage          = 1000
  }
  }

dms_s3_endpoint = {
  trino-events-cdc = {
    dms_s3_endpoint_name = "s3"
    endpoint_type        = "target"
    engine_name          = "s3"
    bucket_folder        = "trino_events"
    bucket_name          = "df-cloudtrail-api-dev"
//service_access_role_arn = "arn:aws:iam::552166763191:role/CPPIB-dms-s3-rds-full-access
    csv_row_delimiter        = "\\n"
    csv_delimiter            = ","
    compression_type         = "NONE"
    EnableStatistics         = true
    date_partition_enabled   = false
    include_op_for_full_load = true
    add_column_name          = true
    data_format = "parquet"
    parquet_version = "parquet-2-0"
    add_column_name = true
    timestamp_column_name = "migration_timestamp"
  }
}
replication_tasks = {
  trino-events-full-cdc = {
  dms_replication_task_name = "full-cdc"
  instance_key              = "1"
  migration_type            = "full-load-and-cdc"
  source_endpoint_key       = "trino"
  target_endpoint_key       = "trino-events-cdc"
  table_mappings            = "configs/trino_full_cdc_table_mappings.json"
  replication_task_settings = "configs/trino_full_cdc_task_settings.json"
  }
}
# DB params
  db_name                   = "trino_events"
  db_engine                 = "aurora-mysql"
  db_engine_version         = "8.0.mysql_aurora.3.04.1"
  db_username               = "root"
  db_instance_type          = "db.r5.large"
  db_port                   = "3306"
  db_sg_ingress_cidr_blocks = [
  "10.97.16.0/23",
  "10.97.18.0/23",
  "10.34.0.0/16",
  "10.35.0.0/16",
  "10.78.0.0/16",
  "10.79.20.0/22"
  ]
  db_parameter_family_group = "aurora-mysql8.0"
  subnets = ["subnet-006ed9bcaecbf6938", "subnet-0bf0551f3cc852b4e"]
  # emr master instance settings
  master_instance_group_map = {
    group_1 = {
      name                 = "Master - 1",
      instance_type        = "m6g.xlarge",
      instance_count       = 1,
      volume_size          = "128",
      volume_type          = "gp2",
      volumes_per_instance = 1,
    },
  }

  # emr core instance group settings
  core_instance_group_map = {
    group_1 = {
      name                 = "Core - 1",
      instance_type        = "r6g.xlarge",
      instance_count       = 1,
      bid_price            = null,
      volume_size          = "100",
      volume_type          = "gp2",
      volumes_per_instance = 1,
    },
  }

  # emr task instance settings
  task_instance_group_map = {
    group_1 = {
      name                 = "Task - 1 (Ondemand)",
      instance_type        = "r6gd.xlarge",
      instance_count       = 1,
      bid_price            = null,
      volume_size          = "100",
      volume_type          = "gp2",
      volumes_per_instance = 1,
    },
  }

  root_volume_size = 100

  # emr managed scaling policy settings
  minimum_capacity_units          = 2
  maximum_capacity_units          = 10
  maximum_ondemand_capacity_units = 5
  maximum_core_capacity_units     = 3

  #Valid values["regular-cluster","trino-cluster"]
  cluster_type = "trino-cluster"

  route53_domain_name = "data-gateway.dev.cppinvestments.io"
  cert_domain_name    = "data-gateway.dev.cppinvestments.io"
  sub_domain          = "datagateway.dev.cppinvestments.io"

  # emr application settings
  trino_hive_connector_defaults = <<-EOL
    "properties":{
        "hive.cache.location":"/opt/hive-cache",
        "hive.metastore-cache-ttl":"60m",
        "hive.cache.ttl":"1d",
        "hive.parquet.use-column-names":"true",
        "hive.cache.enabled":"true",
        "hive.metastore":"glue",
        "hive.file-status-cache-expire-time":"60m",
        "hive.hdfs.impersonation.enabled":"false",
        "hive.cache.read-mode":"read-through",
        "hive.file-status-cache-tables":"*"
    }
  EOL

  trino_memory_connector_defaults = <<-EOL
    "properties":{
        "connector.name":"memory",
        "memory.max-data-per-node":"350GB"
    }
  EOL

  tags = local.base_tags
}
  

