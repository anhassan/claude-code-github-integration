{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "",
            "Effect": "Allow",
            "Principal": {
                "${principal_type[0]}":  ${jsonencode(
                            [for arn in principal_arns : "${arn}"],
                            )}
            },
            "Action": "sts:AssumeRole"
        }
    ]
}