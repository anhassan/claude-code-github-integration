{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:List*"
            ],
            "Resource": [
                "arn:aws:s3:::apptopia-parquet-data-v2/time_series/app_estimates/timelines/v3/",    
                "arn:aws:s3:::apptopia-parquet-data-v2/time_series/app_ranks/timelines/v0/*",
                "arn:aws:s3:::apptopia-parquet-data-v2/metadata/*",
                "arn:aws:s3:::apptopia-parquet-data",
                "arn:aws:s3:::apptopia-parquet-data/*"
            ]
        }
    ]
}