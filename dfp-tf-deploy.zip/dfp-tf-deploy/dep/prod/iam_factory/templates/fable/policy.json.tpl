{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:List*"
            ],
            "Resource": [
                "arn:aws:s3:::fd-fablesignal-t3/*",    
                "arn:aws:s3:::fd-signalselect/*",
                "arn:aws:s3:::fd-merchant-hierarchy/*",
                "arn:aws:s3:::fd-user-master/*",
                "arn:aws:s3:::fsd-eu-t7/*",
                "arn:aws:s3:::fd-fablesignaldaily-eu-t7-us-east-1/*"
            ]
        }
    ]
}