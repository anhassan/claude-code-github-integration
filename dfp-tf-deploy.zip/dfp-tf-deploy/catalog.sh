#!/bin/bash


get_last_deployed(){
    repo=$1
    curl -H "Accept: application/vnd.github.v3+json" "https://github.com/repos/${repo}/actions/workflows/nonprod-apply.yaml/runs?status=success&event=push" 
}
infra_versions() {

    acc_path=$1
    output_filename=".infra-versions"
    cols_underline="-------------"
    echo ""
    echo "Infra Release versions ($acc_path)"
    echo ""
    versions=$(yq eval '.services[] | (key + ","+  .repo + "," + .release_version)' "${acc_path}"/service_params.yaml)
    
    echo "SERVICE, REPO, DEPLOY_VERSION, LATEST_VERSION, STATUS" >> $output_filename
    echo "$cols_underline, $cols_underline, $cols_underline, $cols_underline, $cols_underline" >> $output_filename
    
    for line in $(echo -e "$versions"); do 
        key=$(echo "$line" | awk -F ',' '{print $1}')
        repo=$(echo "$line" | awk -F ',' '{print $2}')
        release_version=$(echo "$line" | awk -F ',' '{print $3}')
        release_version_latest=$(gh release view -R https://github.com/$repo --json tagName -q .tagName 2> /dev/null)
        
        if [ "$?" = "0" ]; then
            if [ "$release_version" = "$release_version_latest" ]; then
                status="current"
            else
                status="update"    
            fi
        else
            status="no_release" 
            release_version_latest="N/A"   
        fi 
        
        echo "$key, $repo, $release_version, $release_version_latest, $status" >> $output_filename
        

    done
    awk -F',' '{ printf "%-25s %-40s %-40s %-20s %-20s \n", $1, $2,  $3, $4 , $5}' $output_filename
    echo ""
    rm $output_filename
}

deployment_attributes() {
    acc_path=$1
    output_filename=".infra-versions"
    cols_underline="-------------"
    echo ""
    echo "Service deployment attributes ($acc_path)"
    echo ""
    deploy_attributes=$(yq eval '.services[] | (key + ","+  .repo + "," + .skip_deployment + "," + .prevent_destroy )' "${acc_path}"/service_params.yaml)
    
    echo "SERVICE, REPO, SKIP_DEPLOYMENT, PREVENT_DESTROY" >> $output_filename
    echo "$cols_underline, $cols_underline, $cols_underline, $cols_underline" >> $output_filename
    
    for line in $(echo -e "$deploy_attributes"); do 
        key=$(echo "$line" | awk -F ',' '{print $1}')
        repo=$(echo "$line" | awk -F ',' '{print $2}')
        skip_deployment=$(echo "$line" | awk -F ',' '{print $3}')
        prevent_destroy=$(echo "$line" | awk -F ',' '{print $4}')
        echo "$key, $repo, $skip_deployment, $prevent_destroy" >> $output_filename
        

    done
    awk -F',' '{ printf "%-25s %-40s %-20s %-20s \n", $1, $2,  $3, $4 }' $output_filename
    echo ""
    rm $output_filename
}

backend_setup() {
    acc_path=$1
    echo "-------------------------------"
    echo "Terraform backend setup type ($acc_path)"
    echo "-------------------------------"
    echo "TBD"
    echo "-------------------------------"
}

app_versions() {
    acc_path=$1
    echo "-------------------------------"
    echo "Application Release versions ($acc_path)"
    echo "-------------------------------"
    echo "TBD"
    echo "-------------------------------"
}

while [[ $# -gt 0 ]]
do
    key="$1"

    case $key in
        -iv|--infra-versions)
            shift
            infra_versions "$@"
            exit 0
            ;;
         -da|--deploy-attributes)
            shift
            deployment_attributes "$@"
            exit 0
            ;;
        -av|--app-versions)
            shift
            app_versions "$@"
            exit 0
            ;;
        -b|--backends)
            shift
            backend_setup "$@"
            exit 0
            ;;
            
        -ld|--last-deployed)
            shift
            get_last_deployed "$@"
            exit 0
            ;;
            
        *)
            echo "Unknown option: $key"
            exit 1
            ;;
    esac
    shift
done
