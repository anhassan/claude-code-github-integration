#!/usr/bin/env bash
ACC_NAME=df
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)

echo "ACC_NAME: $ACC_NAME"
echo "SCRIPT_DIR: $SCRIPT_DIR"

# $1 target environment dev|qa|uat|prod
is_valid_env() {
    if [[ "$1" =~ (dev|qa|uat|prod)$ ]]; then
        return 0
    else
        return 1
    fi

}
is_valid_account_code() {
    if [[ "$1" =~ (df|dfp|dfe|dep)$ ]]; then
        return 0
    else
        return 1
    fi

}

get_server_id() {
    serverId=$(aws transfer list-servers --profile "$profile" | jq -r '.Servers[0].ServerId')
    if [ -z "${serverId}" ] || [ "${serverId}" = "null" ]; then
      echo "No SFTP servers found" >&2
      echo "Deploy sftp_service to ${env}, then run this script again" >&2
      echo ""
      return 1
    fi
    echo "$serverId"
}

get_vpc_endpoint() {
    local serverId=$1
    vpcendpoint=$(aws transfer describe-server --profile "$profile" --server-id ${serverId} | jq -r '.Server.EndpointDetails.VpcEndpointId')
    echo "$vpcendpoint"
}

get_vpc_endpoint_dnsname() {
    local vpcendpoint=$1
    vpc_dns=$(aws ec2 describe-vpc-endpoints --profile "$profile" --vpc-endpoint-ids $vpcendpoint | jq -r '.VpcEndpoints[0].DnsEntries[0].DnsName')
    echo "$vpc_dns"
}

get_user_count() {
    local userId=$1
    local serverId=$2
    user_count=$(aws transfer list-users --profile "$profile" --server-id $serverId | jq -r '.Users[].UserName' | grep "^${userId}_landing" | wc -l)
    echo "$user_count"
}

generate_user_keys() {
    local env=$1
    local userId=$2
    local vpc_dns=$3

    dir="$SCRIPT_DIR/sftp_keys/${ACC_NAME}/${userId}/${env}"
    echo "Generating keys in $dir"
    mkdir -p "$dir"

    token="${userId}C@anada1${env}!"
    sftp_user_name="${userId}_landing_${env}"

    private_key_file="$dir/${sftp_user_name}"
    public_key_file="${private_key_file}.pub"

    ssh-keygen -t rsa -N $token -f ${private_key_file} -C "$sftp_user_name" <<<y

    mv "${public_key_file}" "${public_key_file}.orig"
    cat "${public_key_file}.orig" | awk '{print $1" "$2}' >"${public_key_file}"

    pubkey=$(cat ${public_key_file})

    instruction_file="$dir/sftp.${env}.instructions.md"
    rm $instruction_file 2>/dev/null

    echo "Next Steps"
    echo "----------"
    echo "1. Open $ACC_NAME/$env/service_params.yaml file."
    echo "2. Go to 'services.sftp_service.inputs.sftp_users'."
    echo "3. Add new entry to list with following values:"
    echo "  "
    echo "   - name: $userId"
    echo "     ssh_key: $pubkey"
    echo "  "
    echo "4. Create New branch/PR and merge changes to master. "
    echo "5. Deploy sftp user id and public key by running GHA workflow. "
    echo "  "
    echo "6. After the deployment test sftp upload using the information in $instruction_file"

    echo "IMPORTANT: "
    echo "---------------------------"
    echo "The PRIVATE_KEY_FILE should be sent/recieved through a confidential email."
    echo "Only the IT owners/developers should be on the recipient list."

    echo "SFTP Credentials" >>$instruction_file
    echo "---------------------------" >>$instruction_file
    echo "HOST                : \`${vpc_dns}\`" >>$instruction_file
    echo "" >>$instruction_file
    echo "USER_ID             : \`${sftp_user_name}\`" >>$instruction_file
    echo "" >>$instruction_file
    echo "PASSPHRASE          : \`${token}\`" >>$instruction_file
    echo "" >>$instruction_file
    echo "PRIVATE_KEY_FILE *  : \`${private_key_file}\`" >>$instruction_file
    echo "" >>$instruction_file
    echo "IMPORTANT: " >>$instruction_file
    echo "---------------------------" >>$instruction_file
    echo "The PRIVATE_KEY_FILE should be sent/received through a confidential email." >>$instruction_file
    echo "Only the IT owners/developers should be on the recipient list." >>$instruction_file

    echo "" >>$instruction_file
    echo "SFTP Command Template" >>$instruction_file
    echo "---------------------------" >>$instruction_file
    echo "\`sftp -i [PRIVATE_KEY_FILE] [USER_ID]@[HOST] <<< $'put [INPUT_FILE]'\`" >>$instruction_file
    echo "" >>$instruction_file
    echo "SFTP TEST [$userId - $env]: " >>$instruction_file
    echo "---------------------------" >>$instruction_file
    echo "\`sftp -i ${private_key_file} ${sftp_user_name}@${vpc_dns} <<< $'put $instruction_file'"\` >>$instruction_file
    echo "" >>$instruction_file

    echo "Key generated successfully"
    echo "Share following instruction file information with client: "
    echo "$instruction_file"
}

help() {
    echo ""
    echo "---command---"
    echo "./generate_keys.sh -u <userId> -e <env>"
    echo ""
    echo "Where "
    echo "  -a    accout code. one of [df|dep|dfe|dfp] "
    echo "  -u     sftp user id. Normally a team name. e.g. 'ci' "
    echo "  -e     Target environment. Must be one of dev|qa|uat|prod"
    echo "  -p     AWS profile. Determines the account this script will run in"
    echo ""
}

# =======================

#=========================
# ACCEPT INPUT PARAMTERS
#=========================

while getopts "a:u:e:p:" opt; do
    case "$opt" in
    a) accountCode="$OPTARG" ;;
    e) env="$OPTARG" ;;
    u) userId="$OPTARG" ;;
    p) profile="$OPTARG" ;;
    \?)
        echo ""
        echo "Invalid option -$OPTARG" >&2
        help
        exit 1
        ;;
    :)
        echo ""
        echo "Option -$OPTARG requires and argument." >&2
        help
        exit 1
        ;;
    esac
done

#=========================
# VALIDATE INPUT PARAMTERS
#=========================
if [ -z " $accountCode" ]; then 
    accountCode="$ACC_NAME"
fi 
if [[ "$(is_valid_account_code $accountCode)" -eq 1 ]]; then

    echo "Invalid Parameter -e. Must be one of df|dfp|dfe|dep"
    help
    exit 1
else
    ACC_NAME="$accountCode"
fi

if [[ "$(is_valid_env $env)" -eq 1 ]]; then
    echo "Invalid Parameter -e. Must be one of dev|qa|uat|prod "
    help
    exit 1
fi

if [[ -z "$userId" ]]; then
    echo ""
    echo "Invalid parameter -u. UserId parameter cannot be blank."
    help
    exit 1
elif [[ "$userId" =~ [^a-zA-Z0-9] ]]; then
    echo ""
    echo "Invalid parameter -u. UserId must contain only alphanumeric characters."
    help
    exit 1
fi
if [[ -z "$profile" ]]; then
    echo ""
    echo "Invalid parameter -p. Profile parameter cannot be blank."
    help
    exit 1
fi

serverId=$(get_server_id)
exit_code=$?
if [ $exit_code -ne 0 ]; then
  echo "Failed to get serverId"
  exit 1
fi

vpcendpoint=$(get_vpc_endpoint "$serverId")
vpc_dns=$(get_vpc_endpoint_dnsname "$vpcendpoint")
user_count=$(get_user_count "$userId" "$serverId")
account_id=$(aws sts get-caller-identity --profile "$profile" --query "Account" --output text)


echo "--- Setup Info ---"
echo "env         : $env"
echo "profile     : $profile"
echo "Account ID  : $account_id"
echo "UserId      : $userId"
echo "user_count  : $user_count"
echo "serverId    : $serverId"
echo "vpcendpoint : $vpcendpoint"
echo "vpc_dns     : $vpc_dns"
echo ""

if [ "$user_count" -gt 0 ]; then
    echo "User already exists"
    echo "Generate keys anyway? (Y/n)"
    read -p "" yn
    yn=${yn:-"y"}
    case $yn in
    [Yy]*)
        echo ""
        echo "Generating keys ... "
        echo ""
        generate_user_keys "$env" "$userId" "$vpc_dns"
        ;;
    [Nn]*)
        echo "Skipping."
        exit
        ;;
    *)
        echo "Skipping. No answer"
        exit
        ;;
    esac
else
  echo "Generating keys for new user"
  generate_user_keys "$env" "$userId" "$vpc_dns"
fi
