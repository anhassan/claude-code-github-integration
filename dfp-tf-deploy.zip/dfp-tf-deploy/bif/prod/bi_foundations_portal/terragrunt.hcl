# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}


skip            = false
prevent_destroy = false

dependency "bi_foundations_control_plane" {
  config_path = "../bi_foundations_control_plane"

  mock_outputs = {
    bi_foundations_dataset_rls_table = { 
      name = "bi_foundations_dataset_rls"
      arn  = "table_arn"
    }
    bi_foundations_asset_level_security_table = {
      name = "bi_foundations_asset_level_security"
      arn  = "table_arn"
    }
    bi_foundations_q_topic_security_table = {
      name = "bi_foundations_q_topic_security"
      arn  = "table_arn"
    }
    bi_foundations_es_security_group = {
      id = "bi_foundations_es_sg"
    }
    bi_foundations_es_domain = {
      endpoint = "bi_foundations_es_domain"
    }
  }

  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  service_key = "bi_foundations_portal"
  repo_name       = include.root.locals.params.services[local.service_key].repo
  release_version = include.root.locals.params.services[local.service_key].release_version

  service_name    = include.root.locals.params.services[local.service_key].service_name
  artifact_bucket = include.root.locals.params.services[local.service_key].inputs.tmp_artifacts_bucket
  lambda_versions = include.root.locals.params.services[local.service_key].inputs.lambda_versions

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region
  aws_org_id = include.root.locals.account.aws_org_id

  # Common envrionment variables
  vpc_id          = include.root.locals.environment.vpc.id
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
  vpc_endpoint_id = include.root.locals.environment.api_gateway.execute_api_private
  private_subnets = include.root.locals.environment.vpc.private_subnets
  ingress_cidrs   = include.root.locals.environment.vpc.ingress_cidrs

  top_level_domain       = include.root.locals.environment.api_gateway.top_level_domain
  cognito_user_pool_arn  = include.root.locals.environment.central_cognito.user_pool_arn
  central_cloudfront_arn = include.root.locals.environment.central_cloudfront.distribution_arn
  smtp_host              = include.root.locals.environment.host
  smtp_port              = include.root.locals.environment.port
}


terraform {
  source = "git::git@github.com:${local.repo_name}.git//modules/${local.service_key}?ref=${local.release_version}"
}

inputs = {
  application_name = "finsights"
  
  #=================
  #Account inputs
  #=================
  aws_region_name = local.aws_region
  account_id      = local.account_id
  aws_org_id      = local.aws_org_id
  #=================
  #Environment inputs
  #=================
  top_level_domain       = local.top_level_domain 
  cognito_user_pool_arn  = local.cognito_user_pool_arn
  central_cloudfront_arn = local.central_cloudfront_arn
  env_name               = local.env_name
  tags                   = local.base_tags
  vpc_id                 = local.vpc_id
  vpc_endpoint_id        = local.vpc_endpoint_id
  private_subnets        = local.private_subnets
  ingress_cidrs          = local.ingress_cidrs

  artifact_bucket        = local.artifact_bucket
  lambda_versions        = local.lambda_versions
  service_name           = local.service_name
  smtp_host              = local.smtp_host
  smtp_port              = local.smtp_port

  #=================
  # Module inputs
  #=================

  dependency = dependency.bi_foundations_control_plane.outputs
}

