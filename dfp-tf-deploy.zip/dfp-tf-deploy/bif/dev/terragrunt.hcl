# ---------------------------------------------------------------------------------------------------------------------
# TERRAGRUNT CONFIGURATION
# Terragrunt is a thin wrapper for Terraform that provides extra tools for working with multiple Terraform modules,
# remote state, and locking: https://github.com/gruntwork-io/terragrunt
# ---------------------------------------------------------------------------------------------------------------------

locals {

  environment = yamldecode(file(("environment.yaml")))
  account     = yamldecode(file(("account.yaml")))
  setup       = yamldecode(file("setup.yaml"))
  params      = yamldecode(file("service_params.yaml"))
}

# Configure Terragrunt to automatically store tfstate files in an S3 bucket
generate "backend" {

  path      = "backend.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
        %{if local.setup.tools.terraform.local_backend}
        terraform {
          backend "local" {
            workspace_dir = "${local.setup.project.name}/${local.environment.acc_name}/${local.environment.env_name}/${path_relative_to_include()}/terraform.tfstate"
          }
        }
        %{else}
        terraform {
          backend "s3" {
            encrypt                   = true
            bucket                    = "terraform-state-prod.cppib.io"
            key                       = "${local.setup.project.name}/${local.environment.acc_name}/${local.environment.env_name}/${path_relative_to_include()}/terraform.tfstate"
            region                    = "${local.account.aws_region}"
            dynamodb_table = "terraform-locks"
          }
        }
        %{endif}
    EOF
}
# terraform {
#   before_hook "check_format" {
#     commands     = ["apply", "plan"]
#     execute      = ["terraform", "fmt", "-recursive", "-check"]
#     run_on_error = true
#   }
# }

generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite"
  contents  = <<EOF
  
  %{if local.setup.tools.terraform.local_backend}
  terraform {
    required_version = "~> ${local.setup.tools.terraform.version}"
    required_providers {
      aws = {
        source  = "hashicorp/aws"
        version = "~> ${local.setup.tools.terraform.providers.aws_version}"
      }
    }
  }
  provider "aws" {
    region     = "${local.account.aws_region}"
    
  }
  provider "vault" {
    address = "${local.account.vault_addr}"
  }
  %{else}
  terraform {
    required_version = "~> ${local.setup.tools.terraform.version}"
    required_providers {
      aws = {
        source  = "hashicorp/aws"
        version = "~> ${local.setup.tools.terraform.providers.aws_version}"
      }
      vault = {
        source  = "hashicorp/vault"
        version = "~> ${local.setup.tools.terraform.providers.vault_version}"
      }
      kubernetes = {
        source  = "hashicorp/kubernetes"
        version = "~> ${local.setup.tools.terraform.providers.kubernetes_version}"
      }
    }
  }

  provider "vault" {
    address = "${local.account.vault_addr}"
  }

  data "vault_generic_secret" "consul" {
    path = "secret/platform/consul"
  }

  provider "consul" {
    address = "consul.devops.cppib.io"
    scheme  = "https"
    token   = data.vault_generic_secret.consul.data["token"]
  }

  data "vault_aws_access_credentials" "sts-session" {
    backend = "${local.account.vault_aws}"
    role    = "${local.account.vault_profile}"
    type    = "sts"
  }


  provider "aws" {
    region     = "${local.account.aws_region}"
    access_key = data.vault_aws_access_credentials.sts-session.access_key
    secret_key = data.vault_aws_access_credentials.sts-session.secret_key
    token      = data.vault_aws_access_credentials.sts-session.security_token
  }


 
%{endif}


EOF
}
