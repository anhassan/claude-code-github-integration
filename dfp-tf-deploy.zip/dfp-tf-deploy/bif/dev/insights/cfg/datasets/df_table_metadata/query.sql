SELECT * FROM dataops.datafabric_table_metadata
WHERE date_parse('run_date', '%Y/%m/%d') > cast(current_date - interval '7' day as DATE)