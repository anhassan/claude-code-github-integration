with asset_class_base as (
	select
		  dataset_id
		, business_date
		, node_name as pbor_node_name
		, "level" as split_level
		, case
			when metric like 'time_weighted_return_%' then 'Return'
			when metric like 'pnl_%' then 'Income'
		  end metric_type
		, case
			when metric like '%_rc' then 'CAD'
			when metric like '%_lc' then 'Local'
		  end currency
		, case
			when metric like '%_qtd_%' then 'QTD'
			when metric like '%_3m_%' then '3M Rolling'
			when metric like '%_fytd_%' then 'FYTD'
			when metric like '%_1y_roll_%' then '1Y Rolling'
			when metric like '%_4yp_%' then '4Y+FYTD'
			when metric like '%_5y_roll_%' then '5Y Rolling'
			else 'MTD'
		  end period
		, value
	from (
		select
			  dataset_id 
			, business_date 
			, node_name 
			, "level"
			, time_weighted_return_rc
			, time_weighted_return_lc
			, time_weighted_return_qtd_rc
			, time_weighted_return_qtd_lc
			, time_weighted_return_3m_roll_rc
			, time_weighted_return_3m_roll_lc
			, time_weighted_return_fytd_rc
			, time_weighted_return_fytd_lc
			, time_weighted_return_1y_roll_rc
			, time_weighted_return_1y_roll_lc
			, time_weighted_return_4yp_rc
			, time_weighted_return_4yp_lc
			, time_weighted_return_5y_roll_rc
			, time_weighted_return_5y_roll_lc
			, last_update 
		from 
			performance.perf_top_down_monthly 
		where
			dataset_id = 'ASSETCL_CMB'
			and periods_per_year = 12
			and "level" = 1
	) pivot
	cross join unnest (
		/* METRIC */
		array[
		  	  'time_weighted_return_rc'
			, 'time_weighted_return_lc'
			, 'time_weighted_return_qtd_rc'
			, 'time_weighted_return_qtd_lc'
			, 'time_weighted_return_3m_roll_rc'
			, 'time_weighted_return_3m_roll_lc'
			, 'time_weighted_return_fytd_rc'
			, 'time_weighted_return_fytd_lc'
			, 'time_weighted_return_1y_roll_rc'
			, 'time_weighted_return_1y_roll_lc'
			, 'time_weighted_return_4yp_rc'
			, 'time_weighted_return_4yp_lc'
			, 'time_weighted_return_5y_roll_rc'
			, 'time_weighted_return_5y_roll_lc'
		  ]
		/* VALUE */
		, array[
			  time_weighted_return_rc
			, time_weighted_return_lc
			, time_weighted_return_qtd_rc
			, time_weighted_return_qtd_lc
			, time_weighted_return_3m_roll_rc
			, time_weighted_return_3m_roll_lc
			, time_weighted_return_fytd_rc
			, time_weighted_return_fytd_lc
			, time_weighted_return_1y_roll_rc
			, time_weighted_return_1y_roll_lc
			, time_weighted_return_4yp_rc
			, time_weighted_return_4yp_lc
			, time_weighted_return_5y_roll_rc
			, time_weighted_return_5y_roll_lc
		  ]
	) unpivot ( metric, value )
), asset_class_clean as (
	select
		  asset_class_base.*
		, cast( business_date as varchar ) as business_date_string
		, cast( format( '%1$tY%1$tm%1$td', business_date ) as int ) as business_date_int
		--, format( '%1$tY-%1$tm', calendar_date ) as year_month
		, case
			when period = 'MTD' then '1. MTD'
			when period = 'QTD' then '2. QTD'
			when period = '3M Rolling' then '3. 3M Rolling'
			when period = 'FYTD' then '4. FYTD'
			when period = '1Y Rolling' then '5. 1Y Rolling'
			when period = '4Y+FYTD' then '6. 4Y+FYTD'
			when period = '5Y Rolling' then '7. 5Y Rolling'
		  end period_sorted
	from
		asset_class_base
)
select * from asset_class_clean