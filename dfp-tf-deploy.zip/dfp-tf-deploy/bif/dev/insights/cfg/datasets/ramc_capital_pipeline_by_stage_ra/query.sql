Select 
    END_DATE,
    TO_DATE(TO_CHAR(END_DATE, '99999999'), 'YYYYMMDD') AS FORMATTED_END_DATE,
    INVESTMENT_GROUP,
    STAGE,
    PERCENTAGE,
    LOAD_TIME,
    CASE
    WHEN STAGE = 'Pre-Screen' then '1. Pre-Screen'
    WHEN STAGE = '2. Preparing for Screening' then '1. Pre-Screen'
    WHEN STAGE = 'Post-Screen DD' then '2. Post-Screen DD'
    WHEN STAGE = '3. Post Screening Due Diligence' then '2. Post-Screen DD'
    WHEN STAGE = 'FIR Approved' then '3. FIR Approved'
    WHEN STAGE = '4. Final Investment Approval Obtained' then '3. FIR Approved'
    WHEN STAGE = 'Signed' then '4. Signed'
    WHEN STAGE = '5. Signed' then '4. Signed'
    ELSE NULL
    END AS "STAGE ORDER FORMAT",
    CASE
    WHEN INVESTMENT_GROUP = 'SEG' then 3
    WHEN INVESTMENT_GROUP = 'Infra' then 2
    WHEN INVESTMENT_GROUP = 'RA' then 1
    WHEN INVESTMENT_GROUP = 'RE' then 4
    ELSE NULL
    END AS "ORDER"
From EXCALIBUR.CAPITAL_PIPELINE_BY_STAGE_RA
Where END_DATE = (SELECT MAX(END_DATE) FROM EXCALIBUR.CAPITAL_PIPELINE_BY_STAGE_RA)

