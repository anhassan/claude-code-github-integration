SELECT
	  TO_DATE(mtc.END_DATE, 'yyyy-mm-dd') AS BUSINESS_DATE 
	, mtc.SERIES_ID 
	, mmt.SYMBOL 
	, mmt.NAME 
	, mmt.SERIES_TYPE 
	, mtc."CLOSE" 
	, TO_DATE(mtc.REF_DATE_1D , 'yyyy-mm-dd') AS REF_DATE_1D
	, TO_DATE(mtc.REF_DATE_5D , 'yyyy-mm-dd') AS REF_DATE_5D
	, TO_DATE(mtc.REF_DATE_1M , 'yyyy-mm-dd') AS REF_DATE_1M 
	, TO_DATE(mtc.REF_DATE_3M , 'yyyy-mm-dd') AS REF_DATE_3M 
        , TO_DATE(mtc.REF_DATE_QTD , 'yyyy-mm-dd') AS REF_DATE_QTD
	, TO_DATE(mtc.REF_DATE_YTD , 'yyyy-mm-dd') AS REF_DATE_YTD
        , TO_DATE(mtc.REF_DATE_FYTD , 'yyyy-mm-dd') AS REF_DATE_FYTD
	, TO_DATE(mtc.REF_DATE_1Y , 'yyyy-mm-dd') AS REF_DATE_1Y
	, TO_DATE(mtc.REF_DATE_5Y , 'yyyy-mm-dd') AS REF_DATE_5Y
	, mtc.DELTA_1D 
	, mtc.DELTA_5D 
	, mtc.DELTA_1M 
	, mtc.DELTA_3M 
	, mtc.DELTA_QTD 
	, mtc.DELTA_YTD 
	, mtc.DELTA_FYTD 
	, mtc.DELTA_1Y 
	, mtc.DELTA_5Y 
	, mtc.DELTA_PERC_1D 
	, mtc.DELTA_PERC_5D 
	, mtc.DELTA_PERC_1M 
	, mtc.DELTA_PERC_3M 
	, mtc.DELTA_PERC_QTD
	, mtc.DELTA_PERC_YTD
	, mtc.DELTA_PERC_FYTD
	, mtc.DELTA_PERC_1Y 
	, mtc.DELTA_PERC_5Y 
	, mtc.DELTA_CAGR_5Y 
	, mtc.LOAD_TIME
	, TO_CHAR( ROUND( mtc."CLOSE"  ), 'FM99G999G999' ) AS FORMATTED_CLOSE 
	, TO_CHAR( TO_DATE( mtc.END_DATE, 'yyyy-mm-dd' ), 'YYYY-MM' ) AS CPI_DATE
	, FIRST_VALUE( mtc."CLOSE"  ) OVER(
		PARTITION BY mtc.SERIES_ID, TO_CHAR( TO_DATE( mtc.END_DATE, 'yyyy-mm-dd' ), 'Mon yyyy' )
		ORDER BY ( TO_DATE( mtc.END_DATE, 'yyyy-mm-dd' ) ) DESC
	  ) AS CURRENT_MON_END_INDEX_VALUE
FROM 
	EXCALIBUR.MARKET_TICKER_CALCULATED mtc 
JOIN
	EXCALIBUR.MAPPING_MARKET_TICKER mmt 
		ON mtc.SERIES_ID = mmt.SERIES_ID 
WHERE 
	END_DATE >=20020101