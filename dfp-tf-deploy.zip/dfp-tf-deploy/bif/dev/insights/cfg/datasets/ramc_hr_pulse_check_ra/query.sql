SELECT 
    END_DATE,
    TRUNC(TO_DATE(END_DATE, 'YYYYMMDD')) AS FORMATTED_DATE,
    QUESTION_TEXT,
    AGGREGATE_LEVEL,
    CASE 
        WHEN AGGREGATE_CATEGORY = 'Sao Paulo' THEN 'Sao Paolo'
        ELSE AGGREGATE_CATEGORY
    END AS AGGREGATE_CATEGORY,
    WEIGHTED_AVERAGE,
    LOAD_TIME,
    CASE 
        WHEN AGGREGATE_CATEGORY = 'RA' THEN 1
        WHEN AGGREGATE_CATEGORY = 'Infra' THEN 2
        WHEN AGGREGATE_CATEGORY = 'SEG' THEN 3
        WHEN AGGREGATE_CATEGORY = 'RE' THEN 4
        WHEN AGGREGATE_CATEGORY = 'LRA' THEN 5
        WHEN AGGREGATE_CATEGORY = 'PVC' THEN 6
        WHEN AGGREGATE_CATEGORY = 'RASG' THEN 7
        WHEN AGGREGATE_CATEGORY = 'RABM' THEN 8
        WHEN AGGREGATE_CATEGORY = 'Prefer not to say' THEN 99
        WHEN AGGREGATE_CATEGORY = 'AA/EA' THEN 2
        WHEN AGGREGATE_CATEGORY = 'Analyst' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Analyst/Associate' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Associate' THEN 4
        WHEN AGGREGATE_CATEGORY = 'Senior Associate' THEN 5
        WHEN AGGREGATE_CATEGORY = 'Principal/Director' THEN 6
        WHEN AGGREGATE_CATEGORY = 'MD/GLT/SMD' THEN 7
        WHEN AGGREGATE_CATEGORY = 'MD' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Hong Kong' THEN 2
        WHEN AGGREGATE_CATEGORY = 'London' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Mumbai' THEN 4
        WHEN AGGREGATE_CATEGORY = 'New York' THEN 5
        WHEN AGGREGATE_CATEGORY = 'San Francisco' THEN 6
        WHEN AGGREGATE_CATEGORY = 'Sao Paulo' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Sao Paolo' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Sydney' THEN 8
        WHEN AGGREGATE_CATEGORY = 'Toronto' THEN 9
        WHEN AGGREGATE_CATEGORY = 'Female' THEN 2
        WHEN AGGREGATE_CATEGORY = 'Male' THEN 3
        ELSE NULL
    END AS VALUE,
    CASE
        WHEN QUESTION_TEXT = 'Q01: I receive training opportunities to develop the skills needed for the future.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q02: I have had a discussion about the skills or achievements needed to realize my short and long-term development goals.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q03: I am recognized for my contributions in a way that is personally motivating.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q04: I have been given clear guidance on how my performance is evaluated.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q05: The performance management process helps me identify strengths and improvement areas.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q06: Flexibility: My team quickly moves capital and people to the best investment opportunities.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q07: Commonality: My team solves for what is best for RA and CPPIB rather than whats best for us.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q08: Proactivity: My team is proactive about figuring out what it wants (e.g. sectors, deals, asset mgmt) and impatiently pursues results.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q09: Full potential: My team doesnt settle until weve hit our full potential.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q10: Engaged leadership: Leaders in my team invest in the future of the business in addition to deal-making.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q11: RA leadership is open and transparent in communication.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q12: I am getting feedback, coaching, and apprenticeship that will help me evolve within my career.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q13: I have the opportunity to provide feedback for others and feel comfortable providing feedback.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q:14 I would recommend my group/RA as a good place to work to a friend or colleague.' THEN 'Sentiment'
        WHEN QUESTION_TEXT = 'Q:15 I intend to stay with CPP Investments over the next 12 months.' THEN 'Sentiment'
    END AS QUESTION_CATEGORY,
    CASE
        WHEN QUESTION_TEXT = 'Q01: I receive training opportunities to develop the skills needed for the future.' THEN 1
        WHEN QUESTION_TEXT = 'Q02: I have had a discussion about the skills or achievements needed to realize my short and long-term development goals.' THEN 1
        WHEN QUESTION_TEXT = 'Q03: I am recognized for my contributions in a way that is personally motivating.' THEN 1
        WHEN QUESTION_TEXT = 'Q04: I have been given clear guidance on how my performance is evaluated.' THEN 1
        WHEN QUESTION_TEXT = 'Q05: The performance management process helps me identify strengths and improvement areas.' THEN 1
        WHEN QUESTION_TEXT = 'Q06: Flexibility: My team quickly moves capital and people to the best investment opportunities.' THEN 2
        WHEN QUESTION_TEXT = 'Q07: Commonality: My team solves for what is best for RA and CPPIB rather than whats best for us.' THEN 2
        WHEN QUESTION_TEXT = 'Q08: Proactivity: My team is proactive about figuring out what it wants (e.g. sectors, deals, asset mgmt) and impatiently pursues results.' THEN 2
        WHEN QUESTION_TEXT = 'Q09: Full potential: My team doesnt settle until weve hit our full potential.' THEN 2
        WHEN QUESTION_TEXT = 'Q10: Engaged leadership: Leaders in my team invest in the future of the business in addition to deal-making.' THEN 2
        WHEN QUESTION_TEXT = 'Q11: RA leadership is open and transparent in communication.' THEN 3
        WHEN QUESTION_TEXT = 'Q12: I am getting feedback, coaching, and apprenticeship that will help me evolve within my career.' THEN 3
        WHEN QUESTION_TEXT = 'Q13: I have the opportunity to provide feedback for others and feel comfortable providing feedback.' THEN 3
        WHEN QUESTION_TEXT = 'Q:14 I would recommend my group/RA as a good place to work to a friend or colleague.' THEN 4
        WHEN QUESTION_TEXT = 'Q:15 I intend to stay with CPP Investments over the next 12 months.' THEN 4
        ELSE NULL
    END AS CATEGORY_VALUE,
    'CHANGE' AS NAME,
    CHANGE AS MEASURE
FROM excalibur.hr_pulse_check_ra
WHERE CHANGE IS NOT NULL
UNION ALL
SELECT 
    END_DATE,
    TRUNC(TO_DATE(END_DATE, 'YYYYMMDD')) AS FORMATTED_DATE,
    QUESTION_TEXT,
    AGGREGATE_LEVEL,
    CASE 
        WHEN AGGREGATE_CATEGORY = 'Sao Paulo' THEN 'Sao Paolo'
        ELSE AGGREGATE_CATEGORY
    END AS AGGREGATE_CATEGORY,
    WEIGHTED_AVERAGE,
    LOAD_TIME,
    CASE 
        WHEN AGGREGATE_CATEGORY = 'RA' THEN 1
        WHEN AGGREGATE_CATEGORY = 'Infra' THEN 2
        WHEN AGGREGATE_CATEGORY = 'SEG' THEN 3
        WHEN AGGREGATE_CATEGORY = 'RE' THEN 4
        WHEN AGGREGATE_CATEGORY = 'LRA' THEN 5
        WHEN AGGREGATE_CATEGORY = 'PVC' THEN 6
        WHEN AGGREGATE_CATEGORY = 'RASG' THEN 7
        WHEN AGGREGATE_CATEGORY = 'RABM' THEN 8
        WHEN AGGREGATE_CATEGORY = 'Prefer not to say' THEN 99
        WHEN AGGREGATE_CATEGORY = 'AA/EA' THEN 2
        WHEN AGGREGATE_CATEGORY = 'Analyst' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Analyst/Associate' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Associate' THEN 4
        WHEN AGGREGATE_CATEGORY = 'Senior Associate' THEN 5
        WHEN AGGREGATE_CATEGORY = 'Principal/Director' THEN 6
        WHEN AGGREGATE_CATEGORY = 'MD/GLT/SMD' THEN 7
        WHEN AGGREGATE_CATEGORY = 'MD' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Hong Kong' THEN 2
        WHEN AGGREGATE_CATEGORY = 'London' THEN 3
        WHEN AGGREGATE_CATEGORY = 'Mumbai' THEN 4
        WHEN AGGREGATE_CATEGORY = 'New York' THEN 5
        WHEN AGGREGATE_CATEGORY = 'San Francisco' THEN 6
        WHEN AGGREGATE_CATEGORY = 'Sao Paulo' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Sao Paolo' THEN 7
        WHEN AGGREGATE_CATEGORY = 'Sydney' THEN 8
        WHEN AGGREGATE_CATEGORY = 'Toronto' THEN 9
        WHEN AGGREGATE_CATEGORY = 'Female' THEN 2
        WHEN AGGREGATE_CATEGORY = 'Male' THEN 3
        ELSE NULL
    END AS VALUE,
    CASE
        WHEN QUESTION_TEXT = 'Q01: I receive training opportunities to develop the skills needed for the future.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q02: I have had a discussion about the skills or achievements needed to realize my short and long-term development goals.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q03: I am recognized for my contributions in a way that is personally motivating.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q04: I have been given clear guidance on how my performance is evaluated.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q05: The performance management process helps me identify strengths and improvement areas.' THEN 'Development and Recognition'
        WHEN QUESTION_TEXT = 'Q06: Flexibility: My team quickly moves capital and people to the best investment opportunities.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q07: Commonality: My team solves for what is best for RA and CPPIB rather than whats best for us.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q08: Proactivity: My team is proactive about figuring out what it wants (e.g. sectors, deals, asset mgmt) and impatiently pursues results.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q09: Full potential: My team doesnt settle until weve hit our full potential.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q10: Engaged leadership: Leaders in my team invest in the future of the business in addition to deal-making.' THEN 'Strategic Priorities'
        WHEN QUESTION_TEXT = 'Q11: RA leadership is open and transparent in communication.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q12: I am getting feedback, coaching, and apprenticeship that will help me evolve within my career.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q13: I have the opportunity to provide feedback for others and feel comfortable providing feedback.' THEN 'Feedback'
        WHEN QUESTION_TEXT = 'Q:14 I would recommend my group/RA as a good place to work to a friend or colleague.' THEN 'Sentiment'
        WHEN QUESTION_TEXT = 'Q:15 I intend to stay with CPP Investments over the next 12 months.' THEN 'Sentiment'
    END AS QUESTION_CATEGORY,
    CASE
        WHEN QUESTION_TEXT = 'Q01: I receive training opportunities to develop the skills needed for the future.' THEN 1
        WHEN QUESTION_TEXT = 'Q02: I have had a discussion about the skills or achievements needed to realize my short and long-term development goals.' THEN 1
        WHEN QUESTION_TEXT = 'Q03: I am recognized for my contributions in a way that is personally motivating.' THEN 1
        WHEN QUESTION_TEXT = 'Q04: I have been given clear guidance on how my performance is evaluated.' THEN 1
        WHEN QUESTION_TEXT = 'Q05: The performance management process helps me identify strengths and improvement areas.' THEN 1
        WHEN QUESTION_TEXT = 'Q06: Flexibility: My team quickly moves capital and people to the best investment opportunities.' THEN 2
        WHEN QUESTION_TEXT = 'Q07: Commonality: My team solves for what is best for RA and CPPIB rather than whats best for us.' THEN 2
        WHEN QUESTION_TEXT = 'Q08: Proactivity: My team is proactive about figuring out what it wants (e.g. sectors, deals, asset mgmt) and impatiently pursues results.' THEN 2
        WHEN QUESTION_TEXT = 'Q09: Full potential: My team doesnt settle until weve hit our full potential.' THEN 2
        WHEN QUESTION_TEXT = 'Q10: Engaged leadership: Leaders in my team invest in the future of the business in addition to deal-making.' THEN 2
        WHEN QUESTION_TEXT = 'Q11: RA leadership is open and transparent in communication.' THEN 3
        WHEN QUESTION_TEXT = 'Q12: I am getting feedback, coaching, and apprenticeship that will help me evolve within my career.' THEN 3
        WHEN QUESTION_TEXT = 'Q13: I have the opportunity to provide feedback for others and feel comfortable providing feedback.' THEN 3
        WHEN QUESTION_TEXT = 'Q:14 I would recommend my group/RA as a good place to work to a friend or colleague.' THEN 4
        WHEN QUESTION_TEXT = 'Q:15 I intend to stay with CPP Investments over the next 12 months.' THEN 4
        ELSE NULL
    END AS CATEGORY_VALUE,
    'WEIGHTED_AVERAGE' AS NAME,
    WEIGHTED_AVERAGE AS MEASURE
FROM excalibur.hr_pulse_check_ra
WHERE WEIGHTED_AVERAGE IS NOT NULL

