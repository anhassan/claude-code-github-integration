with dept_default as (
        select      'management-analytics-cost-admin' as GroupName, 'Real Assets' as department_default
    union
        select      'management-analytics-cost-publisher' as GroupName, 'Real Assets' as department_default
    union
        select      'management-analytics-cost-viewer' as GroupName, 'Real Assets' as department_default
    union
    select      'management-analytics-cost-viewer-ae' as GroupName, 'Active Equities' as department_default
    union
    select      'management-analytics-cost-viewer-ra' as GroupName, 'Real Assets' as department_default
), year_default as (
    select
        GroupName, year_default
    from (
        select
             --format( 'FY%1$ty', max( date_parse( fiscal_date, '%Y-%m-%d' ) ) ) as year_default
             format( 'FY%1$ty', max( fiscal_date ) ) as year_default, 
             array[
                'management-analytics-cost-admin',
                'management-analytics-cost-publisher',
                'management-analytics-cost-viewer',
                'management-analytics-cost-viewer-ae',
                'management-analytics-cost-viewer-ra'
                ] as group_names
        from
                finance_accounting_dev.cost_insights_report
        where
            scenario = 'Actual'
    )
    cross join unnest (
        group_names
    ) as t(GroupName)
), month_default as (
    select
        GroupName, month_default
    from (
        select
                case
          
      when ( extract( month from max( calendar_date ) ) ) > 3
                    then format( '%1$02d. %2$tb', ( extract( month from max( calendar_date ) ) - 3 ), max( calendar_date ) )
                else format( '1%1$01d. %2$tb', ( extract( month from max( calendar_date ) ) - 1 ), max( calendar_date )
 )
            end month_default
            /*case
                when ( extract( month from max( date_parse( calendar_date, '%Y-%m-%d' ) ) ) ) >
 3
                    then format( '%1$02d. %2$tb', ( extract( month from max( date_parse( calendar_date, '%Y-%m-%d' ) ) ) - 3 ), max( date_parse( calen
dar_date, '%Y-%m-%d' ) ) )
                else format( '1%1$01d. %2$tb', ( extract( month from max( date_parse( calendar_date, '%Y-%m-%d' ) ) ) - 1 ), m
ax( date_parse( calendar_date, '%Y-%m-%d' ) ) )
            end month_default*/
            , array[
                                  'management-analytics-cost-admin'
                                        , 'management-analytics-cost-publisher'
                                        , 'management-analytics-cost-viewer'
                            , 'management-analytics-cost-viewer-ae'
                            , 'management-analytics-cost-viewer-ra'
            ] as group_names
        from
                finance_accounting_dev.cost_insights_report
        where
            scenario = 'Actual'
    )
    cross join unnest (
        group_names
    ) as t(GroupName)

), combined_defaults as (
    select      dept.GroupName, dept.department_default, yr.year_default, mth.month_default
    from        dept_default dept
    full join   year_default yr
                on dept.GroupName = yr.GroupName

    full join   month_default mth
                on dept.GroupName = mth.GroupName
)
select * from combined_defaults order by GroupName