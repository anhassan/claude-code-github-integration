SELECT * FROM dataops_${env}.datafabric_usage
WHERE date_parse("timestamp", '%Y/%m/%d') > cast(current_date - interval '6' month as DATE)