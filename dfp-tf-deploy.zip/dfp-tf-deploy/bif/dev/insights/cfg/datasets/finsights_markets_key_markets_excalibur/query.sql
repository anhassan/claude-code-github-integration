WITH CTE1 AS
---Original table fixing the dara types and filtering to show datt after December 31, 2019
(
SELECT
	DISTINCT 
	"Quoted Currency" AS Quoted_Currency,
	TRUNC(TO_DATE(BUSINESSDATE, 'YYYY-MM-DD'), 'MM') AS Monthly_Date,
	---First day OF the month
	TRUNC(TO_DATE(BUSINESSDATE, 'YYYY-MM-DD'), 'Q') AS Quaterly_Date,
	---First day OF the quater
	TRUNC(TO_DATE(BUSINESSDATE, 'YYYY-MM-DD'), 'YYYY') AS Year_Date,
	---First day OF the calendar YEAR
	TO_DATE(BUSINESSDATE, 'YYYY-MM-DD') AS Business_Date,
	CASE
		WHEN EXTRACT(MONTH FROM TO_DATE(BUSINESSDATE, 'YYYY-MM-DD'))>= 4
	THEN TO_DATE(EXTRACT(YEAR FROM TO_DATE(BUSINESSDATE, 'YYYY-MM-DD')) || '-04-01', 'YYYY-MM-DD')
		ELSE TO_DATE((EXTRACT(YEAR FROM TO_DATE(BUSINESSDATE, 'YYYY-MM-DD'))-1) || '-04-01', 'YYYY-MM-DD')
	END AS Fiscal_Year,
	BUSINESSDATE AS Custom_Business_Date,
	CAST(INDEXVALUE AS FLOAT) AS Index_Value,
	"Long Name" AS Long_Name,
	"Short Name" AS Short_Name,
	"Index Group Level 1" AS Index_Group_Level1,
	"Index Group Level 2" AS Index_Group_Level2,
	"Keep Exclude" AS Keep_Exclude
FROM
	CUR_OUTPUTS.MKT_INDICES
WHERE
	TO_DATE(BUSINESSDATE, 'yyyy-mm-dd')>= TO_DATE('2019-12-31', 'yyyy-mm-dd')
),
CTE2 AS
---Identify the index value on the last busines date for each period 
(
SELECT
	Business_Date,
	Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Index_Value,
	Monthly_Date,
	Quaterly_Date,
	Year_Date,
	Fiscal_Year,
	FIRST_VALUE(Index_Value) OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name, Monthly_Date
	ORDER BY Business_Date DESC
	) AS Current_Mon_End_Index_Value,
	FIRST_VALUE(Index_Value) OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name, Quaterly_Date
	ORDER BY Business_Date DESC
	) AS Current_Qtr_End_Index_Value,
	ROW_NUMBER() OVER (
	PARTITION BY Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Monthly_Date
ORDER BY
	Business_Date DESC
	) AS Rn_Month,
	ROW_NUMBER() OVER (
	PARTITION BY Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Quaterly_Date
ORDER BY
	Business_Date DESC
	) AS Rn_Quater,
	ROW_NUMBER() OVER (
	PARTITION BY Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Year_Date
ORDER BY
	Business_Date DESC
	) AS Rn_Year,
	ROW_NUMBER() OVER (
	PARTITION BY Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Fiscal_Year
ORDER BY
	Business_Date DESC
	) AS Rn_Fiscal_Year
FROM
	CTE1),
---1095674 
CTE3 AS
(
---KEEP MONTHLY DATA
SELECT
	Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Index_Value,
	Monthly_Date,
	LAG(Index_Value)OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name
	ORDER BY Monthly_Date
	) AS Prev_Mon_Index_Value
	--Previous month last Day Value (MOM)
FROM
	CTE2
WHERE
	CTE2.Rn_Month = 1
	---Keep ONLY the LAST available INDEX value per period
),
CTE4 AS(
--QUATERLY DATA
SELECT
	Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Index_Value,
	Quaterly_Date,
	LAG(Index_Value)OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name
	ORDER BY Quaterly_Date
	) AS Prev_QTR_Index_Value
	--Previous QTR last Day Value 
FROM
	CTE2
WHERE
	CTE2.Rn_Quater = 1 
),
CTE5 AS(
--CY YEARLY DATA
SELECT
	Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Index_Value,
	Year_Date,
	LAG(Index_Value)OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name
	ORDER BY Year_Date
	) AS Prev_CY_Index_Value
	--Previous CY last Day Value (YOY)
FROM
	CTE2
WHERE
	CTE2.Rn_Year = 1 
),
CTE6 AS(
--FY YEARLY DATA
SELECT
	Business_date,
	Index_Group_Level1,
	Index_Group_Level2,
	Keep_Exclude,
	Quoted_Currency,
	Short_Name,
	Index_Value,
	Fiscal_Year,
	LAG(Index_Value)OVER(
	PARTITION BY Index_Group_Level1, Index_Group_Level2, Keep_Exclude, Quoted_Currency, Short_Name
	ORDER BY Fiscal_Year
	) AS Prev_FY_Index_Value
	--Previous FY last Day Value (FYOY)
FROM
	CTE2
WHERE
	CTE2.Rn_Fiscal_Year = 1 
),
Final_CTE AS(
SELECT
	DISTINCT
CTE1.Business_Date,
	CTE1.Custom_Business_Date,
	CTE1.Short_Name,
	CTE1.Index_Group_Level1,
	CTE1.Index_Group_Level2,
	CTE1.Index_Value,
	CTE1.Keep_Exclude,
	CTE1.Quoted_Currency,
	CTE1.Monthly_Date,
	CTE1.Quaterly_Date,
	CTE1.Fiscal_Year,
	CTE1.Year_Date,
	CTE2.Current_Mon_End_Index_Value,
	CTE2.Current_Qtr_End_Index_Value,
	CTE3.Prev_Mon_Index_Value,
	CTE4.Prev_QTR_Index_Value,
	CTE5.Prev_CY_Index_Value,
	CTE6.Prev_FY_Index_Value
FROM
	CTE1
LEFT JOIN CTE2 ON
	CTE1.Business_Date = CTE2.Business_Date
	AND CTE1.Index_Group_Level1 = CTE2.Index_Group_Level1
	AND CTE1.Index_Group_Level2 = CTE2.Index_Group_Level2
	AND CTE1.Short_Name = CTE2.Short_Name
	AND CTE1.Quoted_Currency = CTE2.Quoted_Currency
	AND CTE1.Keep_Exclude = CTE2.Keep_Exclude
LEFT JOIN CTE3 ON
	CTE1.Monthly_Date = CTE3.Monthly_Date
	AND CTE1.Index_Group_Level1 = CTE3.Index_Group_Level1
	AND CTE1.Index_Group_Level2 = CTE3.Index_Group_Level2
	AND CTE1.Short_Name = CTE3.Short_Name
	AND CTE1.Quoted_Currency = CTE3.Quoted_Currency
	AND CTE1.Keep_Exclude = CTE3.Keep_Exclude
LEFT JOIN CTE4 ON
	CTE1.Quaterly_Date = CTE4.Quaterly_Date
	AND CTE1.Index_Group_Level1 = CTE4.Index_Group_Level1
	AND CTE1.Index_Group_Level2 = CTE4.Index_Group_Level2
	AND CTE1.Short_Name = CTE4.Short_Name
	AND CTE1.Quoted_Currency = CTE4.Quoted_Currency
	AND CTE1.Keep_Exclude = CTE4.Keep_Exclude
LEFT JOIN CTE5 ON
	CTE1.Year_Date = CTE5.Year_Date
	AND CTE1.Index_Group_Level1 = CTE5.Index_Group_Level1
	AND CTE1.Index_Group_Level2 = CTE5.Index_Group_Level2
	AND CTE1.Short_Name = CTE5.Short_Name
	AND CTE1.Quoted_Currency = CTE5.Quoted_Currency
	AND CTE1.Keep_Exclude = CTE5.Keep_Exclude
LEFT JOIN CTE6 ON
	CTE1.Fiscal_Year = CTE6.Fiscal_Year
	AND CTE1.Index_Group_Level1 = CTE6.Index_Group_Level1
	AND CTE1.Index_Group_Level2 = CTE6.Index_Group_Level2
	AND CTE1.Short_Name = CTE6.Short_Name
	AND CTE1.Quoted_Currency = CTE6.Quoted_Currency
	AND CTE1.Keep_Exclude = CTE6.Keep_Exclude
ORDER BY
	CTE1.BUSINESS_DATE ASC)
SELECT
	*
FROM
	Final_CTE