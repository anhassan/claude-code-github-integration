WITH ip_returns AS (
	SELECT 
		  BUSINESS_DATE
		, CASE 
			WHEN DATASET_ID = 'TFMCFB_IPN' AND "LEVEL" = 0 THEN 'Total Fund Management'
		  	ELSE NODE_NAME
		  END NODE_NAME
		, CASE 
			WHEN METRIC LIKE '%_rc' THEN 'CAD'
			WHEN METRIC LIKE '%_lc' THEN 'Local'
		  END CURRENCY
		, CASE 
			WHEN METRIC LIKE '%_qtd_%' THEN 'QTD'
			WHEN METRIC LIKE '%_fytd_%' THEN 'FYTD'
			WHEN METRIC LIKE '%_4yp_%' THEN '4Y+FYTD'
			WHEN METRIC LIKE '%_5y_roll_%' THEN '5Y'
			ELSE 'MTD'
		  END PERIOD
		, VALUE AS INVESTMENT_PORTFOLIO_VALUE
	FROM (
		SELECT
			  "dataset_id" AS DATASET_ID
			, "business_date" AS BUSINESS_DATE
			, "node_name" AS NODE_NAME
			, "level" AS "LEVEL"
			, "twr_rc" 
			, "twr_lc"
			, "twr_qtd_rc"
			, "twr_qtd_lc"
			, "twr_fytd_rc"
			, "twr_fytd_lc"
			, "twr_4yp_rc"
			, "twr_4yp_lc"
			, "twr_5y_roll_rc"
			, "twr_5y_roll_lc"
		FROM
			"performance"."perf_bottom_up"@pgdb
		WHERE 
			"ppy" = 12
			AND "business_date" = LAST_DAY( "business_date" )
			AND "business_date" >= TO_DATE( '2019-06-30', 'yyyy-mm-dd' )
			AND (
					/* DEPARTMENTS ex TFM */
					(
						"dataset_id" in ( 'CMBP_NET' )
						and "level" = 2
						and "parent_node_id" = '2'
						and not "node_name" in ( 'Total Fund Management', 'Active Equities', 'Capital Markets & Factor Investing' ) 
					)
					/* TFM incl. CFB */
					or (
						"dataset_id" in ( 'TFMCFB_IPN' )
					)
			)
	) ip_returns_pivot
	CROSS APPLY (
		SELECT 'twr_rc' AS METRIC, "twr_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_lc' AS METRIC, "twr_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_qtd_rc' AS METRIC, "twr_qtd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_qtd_lc' AS METRIC, "twr_qtd_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_fytd_rc' AS METRIC, "twr_fytd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_fytd_lc' AS METRIC, "twr_fytd_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_4yp_rc' AS METRIC, "twr_4yp_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_4yp_lc' AS METRIC, "twr_4yp_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_5y_roll_rc' AS METRIC, "twr_5y_roll_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_5y_roll_lc' AS METRIC, "twr_5y_roll_lc" AS VALUE FROM DUAL
	) ip_returns_unpivot
), sa AS (
	SELECT
		  "business_date" AS BUSINESS_DATE
		, CASE 
			WHEN "node_name" = 'SAP_TFM' THEN 'Total Fund Management'
			ELSE "node_name"
		  END NODE_NAME
		, CASE 
			WHEN METRIC LIKE '%_rc' THEN 'CAD'
			WHEN METRIC LIKE '%_lc' THEN 'Local'
		  END CURRENCY
		, CASE 
			WHEN METRIC LIKE '%_qtd_%' THEN 'QTD'
			WHEN METRIC LIKE '%_fytd_%' THEN 'FYTD'
			WHEN METRIC LIKE '%_4yp_%' THEN '4Y+FYTD'
			WHEN METRIC LIKE '%_5y_roll_%' THEN '5Y'
			ELSE 'MTD'
		  END PERIOD
		, VALUE AS STRATEGY_ALTERNATIVE_VALUE
	FROM (
		/* DEPARTMENTS ex TFM */
		SELECT
			  "business_date"
			, "dataset_id"
			, "node_name"
			, "level"
			, "twr_rc"
			, "twr_lc"
			, "twr_qtd_rc"
			, "twr_qtd_lc"
			, "twr_fytd_rc"
			, "twr_fytd_lc"
			, "twr_4yp_rc"
			, "twr_4yp_lc"
			, "twr_5y_roll_rc"
			, "twr_5y_roll_lc"
		FROM
			"performance"."perf_bottom_up"@pgdb
		WHERE
			"ppy" = 12
			AND "business_date" = LAST_DAY( "business_date" )
			AND "dataset_id" IN ( 'SAP_C', 'SAP_S' )
			AND "level" IN ( 2 )
			AND "node_name" NOT LIKE '%(S)' -- filter out nodes that are repeats of the parent nodes
			AND "node_name" NOT IN ( 'Total Fund Management', 'Active Equities', 'Capital Markets & Factor Investing' )
		UNION ALL
		SELECT 
			  "business_date"
			, "dataset_id"
			, "node_name"
			, "level"
			, "twr_rc"
			, "twr_lc"
			, "twr_qtd_rc"
			, "twr_qtd_lc"
			, "twr_fytd_rc"
			, "twr_fytd_lc"
			, "twr_4yp_rc"
			, "twr_4yp_lc"
			, "twr_5y_roll_rc"
			, "twr_5y_roll_lc"
		FROM
			"performance"."perf_top_down"@pgdb
		WHERE
			"dataset_id" IN ( 'SAP_TFM_TF' )
			AND "node_name" = 'SAP_TFM'
			AND "business_date" = LAST_DAY("business_date")
	) sa_pivot
	CROSS APPLY (
		SELECT 'twr_rc' AS METRIC, "twr_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_lc' AS METRIC, "twr_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_qtd_rc' AS METRIC, "twr_qtd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_qtd_lc' AS METRIC, "twr_qtd_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_fytd_rc' AS METRIC, "twr_fytd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_fytd_lc' AS METRIC, "twr_fytd_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_4yp_rc' AS METRIC, "twr_4yp_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_4yp_lc' AS METRIC, "twr_4yp_lc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_5y_roll_rc' AS METRIC, "twr_5y_roll_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_5y_roll_lc' AS METRIC, "twr_5y_roll_lc" AS VALUE FROM DUAL
	) sa_unpivot
), sa_spread AS (
	SELECT
		  sa.*
		, CASE 
			WHEN sa.CURRENCY = 'Local' AND sa.PERIOD IN ( '4Y+FYTD', '5Y' ) THEN spread.spread_percentage -- ONLY INCLUDE SPREADS FOR LOCAL 4Y+ AND 5Y
			ELSE 0
		  END SPREAD_PERCENTAGE_VALUE
		, CASE 
			WHEN sa.CURRENCY = 'Local' AND sa.PERIOD IN ( '4Y+FYTD', '5Y' ) THEN sa.STRATEGY_ALTERNATIVE_VALUE + COALESCE( spread.spread_percentage, 0 ) -- ONLY INCLUDE SPREADS FOR LOCAL 4Y+ AND 5Y
			ELSE sa.STRATEGY_ALTERNATIVE_VALUE
		  END STRATEGY_ALTERNATIVE_INCL_SPREAD_VALUE
	FROM 
		sa
	LEFT JOIN 
		( 
			/* PROGRAM-LEVEL SPREADS */
			SELECT	START_DATE
					, END_DATE
					, INVESTMENT_PROGRAM AS NODE_NAME
					, SPREAD_PERCENTAGE
			FROM 	EXCALIBUR.PERF_BENCHMARK_SPREAD
			WHERE 	BENCHMARK_NAME = 'Strategy Alternative'
					AND SPREAD_PERCENTAGE IS NOT NULL 
			/* DEPARTMENT-LEVEL SPREADS */
			UNION ALL
			SELECT 	START_DATE
					, END_DATE
					, INVESTMENT_DEPARTMENT AS NODE_NAME
					, SPREAD_PERCENTAGE / 100 AS SPREAD_PERCENTAGE /* TEMPORARY DIVISION */
			FROM	EXCALIBUR.PERF_BLENDED_BENCHMARK_SPREAD 
			WHERE 	STRATEGY IS NULL
		) spread
			ON
				sa.NODE_NAME = ( CASE
									WHEN spread.NODE_NAME = 'Direct Private Equity ex TPE Legacy' THEN 'Direct Private Equity' -- TEMPORARY RENAME
									WHEN spread.NODE_NAME = 'Active Credit' THEN 'Active Credit ex. Antares' -- TEMPORARY RENAME
									ELSE spread.NODE_NAME
								END )
				AND sa.BUSINESS_DATE BETWEEN TO_DATE( spread.START_DATE, 'yyyymmdd' ) AND TO_DATE( spread.END_DATE, 'yyyymmdd' )
), ip_sa_spread AS (
	SELECT
		  ip.BUSINESS_DATE
		, ip.NODE_NAME
		, ip.CURRENCY
		, ip.PERIOD
		, ip.INVESTMENT_PORTFOLIO_VALUE
		, sa.STRATEGY_ALTERNATIVE_VALUE
		, sa.SPREAD_PERCENTAGE_VALUE
		, sa.STRATEGY_ALTERNATIVE_INCL_SPREAD_VALUE
	FROM
		ip_returns ip
	LEFT JOIN 
		sa_spread sa
			ON ip.BUSINESS_DATE = sa.BUSINESS_DATE
			AND ip.NODE_NAME = sa.NODE_NAME
			AND ip.CURRENCY = sa.CURRENCY
			AND ip.PERIOD = sa.PERIOD
), ip_sa_spread_final AS (
	SELECT
		  ip_sa_spread.*
		, TO_CHAR( BUSINESS_DATE, 'YYYY-MM' ) AS YEAR_MONTH
		, CASE
			WHEN PERIOD = 'MTD' THEN '1. MTD'
			WHEN PERIOD = 'QTD' THEN '2. QTD'
			WHEN PERIOD = 'FYTD' THEN '3. FYTD'
			WHEN PERIOD = '4Y+FYTD' THEN '4. 4Y+FYTD'
			WHEN PERIOD = '5Y' THEN '5. 5Y'
		  END PERIOD_SORTED
		, CASE
				WHEN SYSDATE >= (
									SELECT	TO_DATE( CALENDAR_DATE, 'yyyymmdd' )
									FROM	EXCALIBUR.MAPPING_DATE_TO_BUSINESS_DATE mdtbd 
									WHERE 	YEAR_MONTH = TO_NUMBER( TO_CHAR( SYSDATE, 'yyyymm' ) )
											AND MONTH_BUSINESS_DAY = ( 12 + 1 )
								) THEN 'Final'
				ELSE (
						CASE 
							WHEN BUSINESS_DATE > ADD_MONTHS( TRUNC( SYSDATE, 'MONTH' ), -1 ) THEN 'Prelim'
							ELSE 'Final'
						END
				) 
		  END PRELIM_FINAL
	FROM
		ip_sa_spread
)
SELECT * FROM ip_sa_spread_final