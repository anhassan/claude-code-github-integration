Select 
    END_DATE,
    TO_DATE(TO_CHAR(END_DATE, '99999999'), 'YYYYMMDD') AS FORMATTED_END_DATE,
    STRATEGY,
    ROLE,
    TYPE,
    VALUE,
    LOAD_TIME,
    CASE
    WHEN TYPE = 'Active+ Filled' THEN 'Active + Filled'
    ELSE TYPE
    END AS "TYPE ALIAS",
    CASE
    WHEN ROLE = 'Anayst' THEN 'Analyst'
    ELSE ROLE
    END AS "ROLE ALIAS",
    CASE
    WHEN STRATEGY = 'Infra' THEN 1
    WHEN STRATEGY = 'SEG' THEN 2
    WHEN STRATEGY = 'RE' THEN 3
    WHEN STRATEGY = 'LRA' THEN 4
    WHEN STRATEGY = 'PVC' THEN 5
    WHEN STRATEGY = 'RASG' THEN 6
    WHEN STRATEGY = 'RABM' THEN 7
    ELSE NULL
    END AS "STRATEGY VALUE",
    CASE
    WHEN ROLE = 'MD-H' THEN 1
    WHEN ROLE = 'MD' THEN 2
    WHEN ROLE = 'Principal/PM/Director' THEN 3
    WHEN ROLE = 'Sr. Associate' THEN 4
    WHEN ROLE = 'Associate' THEN 5
    WHEN ROLE = 'Anayst' THEN 6
    WHEN ROLE = 'Non-Investment Roles' THEN 7
    WHEN ROLE = 'Admin' THEN 8
    ELSE NULL
    END AS "ROLE VALUE",
    CASE
    WHEN TYPE = 'Active+ Filled' THEN 'Active = active recruitment; Filled = role filled with future start date'
    ELSE NULL
    END AS "GLOSSARY"
From EXCALIBUR.HR_HEADCOUNT_METRIC_BY_STRATEGY_RA
WHERE END_DATE = (SELECT MAX(END_DATE) FROM EXCALIBUR.HR_HEADCOUNT_METRIC_BY_STRATEGY_RA)
