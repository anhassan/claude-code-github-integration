Select 
    END_DATE,
    TO_DATE(TO_CHAR(END_DATE, '99999999'), 'YYYYMMDD') AS FORMATTED_END_DATE,
    STRATEGY,
    CASE
    WHEN STRATEGY = 'Infra' then 'Infrastructure'
    WHEN STRATEGY = 'SEG' then 'Sustainable Energy Group'
    WHEN STRATEGY = 'RE' then 'Real Estate'
    ELSE NULL
    END AS "STRATEGY_FORMATTED",
    PROJECT_NAME,
    DEAL_STATUS,
    CASE 
    WHEN DEAL_STATUS = 'Funding & Closing' then 'Funding & Closing'
    WHEN DEAL_STATUS = '1. Early Stage Review' then 'Early Stage Review'
    WHEN DEAL_STATUS = '2. Preparing for Screening' then 'Preparing for Screening'
    WHEN DEAL_STATUS = '3. Post Screening Due Diligence' then 'Post Screening Due Diligence'
    WHEN DEAL_STATUS = '4. Final Investment Approval Obtained' then 'Final Investment Approval Obtained'
    WHEN DEAL_STATUS = '5. Signed' then 'Signed'
    ELSE DEAL_STATUS
    END AS "DEAL_STATUS_NAME",
    CASE 
    WHEN DEAL_STATUS = 'Funding & Closing' then 6
    WHEN DEAL_STATUS = '1. Early Stage Review' then 1
    WHEN DEAL_STATUS = '2. Preparing for Screening' then 2
    WHEN DEAL_STATUS = '3. Post Screening Due Diligence' then 3
    WHEN DEAL_STATUS = '4. Final Investment Approval Obtained' then 4
    WHEN DEAL_STATUS = '5. Signed' then 5
    WHEN DEAL_STATUS = 'Early Stage Review' then 1
    WHEN DEAL_STATUS = 'Preparing for Screening' then 2
    WHEN DEAL_STATUS = 'Post Screening Due Diligence' then 3
    WHEN DEAL_STATUS = 'Final Investment Approval Obtained' then 4
    WHEN DEAL_STATUS = 'Signed' then 5
    ELSE NULL
    END AS "DEAL_STATUS_NUMBER",
    LOAD_TIME
From EXCALIBUR.CAPITAL_PIPELINE_STATUS_BY_STRATEGY_RA
Where END_DATE = (SELECT MAX(END_DATE) FROM EXCALIBUR.CAPITAL_PIPELINE_STATUS_BY_STRATEGY_RA)
