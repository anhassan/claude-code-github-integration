Select 
    END_DATE,
    TO_DATE(TO_CHAR(END_DATE, '99999999'), 'YYYYMMDD') AS FORMATTED_END_DATE,
    FISCAL_YEAR,
    MEASURE_NAME,
    ACTUAL_TARGET,
    PERCENT_VALUE,
    LOAD_TIME,
    CASE
    WHEN MEASURE_NAME = 'Prin/Director+ Female Investors (% of headcount)' THEN 'Prin/Director+ Female Investors'
    WHEN MEASURE_NAME = 'Prin/Director+ Minority (% of responses)' THEN 'Prin/Director+ Minority'
    WHEN MEASURE_NAME = 'Female (% of headcount)' THEN 'Female'
    WHEN MEASURE_NAME = 'Minority (% of responses)' THEN 'Minority'
    WHEN MEASURE_NAME = 'LGBTQ+ (% of responses)' THEN 'LGBTQ+'
    WHEN MEASURE_NAME = 'People with Disabilities (% of responses)' THEN 'People with Disabilities'
    WHEN MEASURE_NAME = 'Indigenous (% of responses)' THEN 'Indigenous'
    ELSE NULL
    END AS "Measure Name Formatted",
    CASE
    WHEN MEASURE_NAME = 'Prin/Director+ Female Investors (% of headcount)' THEN 1
    WHEN MEASURE_NAME = 'Prin/Director+ Minority (% of responses)' THEN 2
    WHEN MEASURE_NAME = 'Female (% of headcount)' THEN 3
    WHEN MEASURE_NAME = 'Minority (% of responses)' THEN 4 
    WHEN MEASURE_NAME = 'LGBTQ+ (% of responses)' THEN 5
    WHEN MEASURE_NAME = 'People with Disabilities (% of responses)' THEN 6
    WHEN MEASURE_NAME = 'Indigenous (% of responses)' THEN 7
    ELSE NULL
    END AS "VALUE",
    CASE
    WHEN FISCAL_YEAR = '2024' THEN 'F24'
    WHEN FISCAL_YEAR = '2025' THEN 'F25'
    ELSE NULL
    END AS "Fiscal Year Formatted"
From EXCALIBUR.HR_DIVERSITY_METRIC_RA
WHERE END_DATE = (SELECT MAX(END_DATE) FROM EXCALIBUR.HR_DIVERSITY_METRIC_RA)
