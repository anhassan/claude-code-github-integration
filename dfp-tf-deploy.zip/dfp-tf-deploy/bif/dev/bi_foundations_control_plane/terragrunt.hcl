# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

skip            = include.root.locals.params.services.bi_foundations_control_plane.skip_deployment
prevent_destroy = include.root.locals.params.services.bi_foundations_control_plane.prevent_destroy

dependency "insights" {
  config_path = "../insights"

  mock_outputs = {
    quicksight_mgr_lambda = {
      function_name = "df-quicksight_mgr-dev"
      arn = "function_arn"
    }
  }

  mock_outputs_merge_strategy_with_state = "shallow"
}

locals {
  # Artifact versions to deploy
  repo_name       = include.root.locals.params.services.bi_foundations_control_plane.repo
  release_version = include.root.locals.params.services.bi_foundations_control_plane.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  service_name          = include.root.locals.params.services.bi_foundations_control_plane.service_name
  artifact_bucket       = include.root.locals.params.services.bi_foundations_control_plane.inputs.tmp_artifacts_bucket
  lambda_versions = include.root.locals.params.services.bi_foundations_control_plane.inputs.lambda_versions
  bi_foundations_pkg_version = include.root.locals.params.services.bi_foundations_control_plane.inputs.bi_foundations_pkg_version
  opensearch_vpc = include.root.locals.environment.vpc.id
  subnet_ids = include.root.locals.environment.vpc.private_subnets

  # Common envrionment variables
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
  vpc_endpoint_id = include.root.locals.environment.api_gateway.execute_api_private
  ingress_cidrs   = include.root.locals.environment.vpc.ingress_cidrs
  host        = include.root.locals.environment.host
  port        = include.root.locals.environment.port

}

terraform {
  source = "git::git@github.com:${local.repo_name}.git//modules/${local.service_name}?ref=${local.release_version}"
}

inputs = {

  #=================
  #Account inputs
  #=================
  aws_region = local.aws_region
  account_id = local.account_id

  #=================
  #Environment inputs
  #=================

  acc_name        = local.acc_name
  env_name        = local.env_name
  tags            = local.base_tags
  host        = local.host
  port        = local.port
  artifact_bucket = local.artifact_bucket
  bi_foundations_pkg_version  = local.bi_foundations_pkg_version
  service_name    = local.service_name
  opensearch_vpc  = local.opensearch_vpc
  subnet_ids      = local.subnet_ids
  ingress_cidrs   = local.ingress_cidrs
  lambda_versions = local.lambda_versions

  #=================
  # Module inputs
  #=================

  dependency = dependency.insights.outputs

}

