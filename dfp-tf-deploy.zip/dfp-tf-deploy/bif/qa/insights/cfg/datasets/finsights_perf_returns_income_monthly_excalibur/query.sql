WITH perf AS (
	SELECT
		  "dataset_id" AS DATASET_ID
		, "business_date" AS BUSINESS_DATE
		, CASE
			WHEN "dataset_id" IN ( 'TOTALFUND'/*, 'CMBP_NET'*/ ) AND "level" = 0 THEN 'Total Fund'
			WHEN "dataset_id" = 'ACCOUNTS_BCPP' AND "level" = 0 THEN 'Base CPP'
			WHEN "dataset_id" = 'ACCOUNTS_ACPP' AND "level" = 0 THEN 'Additional CPP'
			WHEN "dataset_id" = 'ATP_TF' AND "level" = 1 THEN 'Total Fund Benchmark Portfolio'
			WHEN "dataset_id" = 'ATP_BCPP' AND "level" = 1 THEN 'Base CPP Benchmark Portfolio'
			WHEN "dataset_id" = 'ATP_ACPP' AND "level" = 1 THEN 'Additional CPP Benchmark Portfolio'
			WHEN "dataset_id" = 'INV_SELECT_TF' AND "level" = 1 THEN 'Total Fund Value-Added'
			ELSE "node_name"
		  END NODE_NAME
		, "level" AS "LEVEL"
		, CASE
			WHEN METRIC LIKE 'twr_%' THEN 'Return'
			WHEN METRIC LIKE 'pnl_%' THEN 'Income'
		  END METRIC_TYPE
		, CASE
			WHEN METRIC LIKE '%_rc' THEN 'CAD'
			WHEN METRIC LIKE '%_lc' THEN 'Local'
		  END CURRENCY
		, CASE
			WHEN METRIC LIKE '%qtd%' THEN 'QTD'
			WHEN METRIC LIKE '%fytd%' THEN 'FYTD'
			WHEN METRIC LIKE '%4yp%' THEN '4Y+FYTD'
			WHEN METRIC LIKE '%5y_roll%' THEN '5Y'
			WHEN METRIC LIKE '%10y_roll%' THEN '10Y'
			ELSE 'MTD'
		  END PERIOD
		, VALUE
	FROM 
		(
		/* DATA PULLED:
		 * - Total Fund: 			MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 * - Total Fund bCPP/aCPP:	MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 * - Department:			MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 */
		SELECT
			  "dataset_id"
			, "business_date"
			, "node_name"
			, "level"
			, "twr_rc"
			, "twr_qtd_rc"
			, "twr_fytd_rc"
			, "twr_4yp_rc"
			, "twr_5y_roll_rc"
			, "twr_10y_roll_rc"
			, "pnl_rc"
			, "pnl_qtd_rc"
			, "pnl_fytd_rc"
			, "pnl_4yp_rc"
			, "pnl_5y_roll_rc"
			, "pnl_10y_roll_rc"
		FROM
			"performance"."perf_bottom_up"@pgdb
		WHERE 
			"ppy" = 12
			AND (
					/* TOTAL FUND */
					(
						"dataset_id" IN ( 'TOTALFUND'/*, 'CMBP_NET'*/ )
						AND "level" = 0
					)
					/* TOTAL FUND ACCOUNTS */
					OR (
						"dataset_id" IN ( 'ACCOUNTS_BCPP', 'ACCOUNTS_ACPP' )
						AND "level" = 0 
					)
					/* DEPARTMENTS */
					OR (
						"dataset_id" IN ( 'CMBP_NET' )
						AND "level" = 2
						AND "parent_node_id" = '2'
					)
			)
		UNION ALL 
		/* DATA PULLED:
		 * - Benchmark Portfolio Total Fund:	MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 * - Benchmark Portfolio bCPP/aCPP:		MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 * - Value-Added IP vs BP Total Fund:	MTD, QTD, FYTD, 4Y+FYTD, 5Y, 10Y
		 */
		SELECT
			  "dataset_id"
			, "business_date"
			, "node_name"
			, "level"
			, "twr_rc"
			, "twr_qtd_rc"
			, "twr_fytd_rc"
			, "twr_4yp_rc"
			, "twr_5y_roll_rc"
			, "twr_10y_roll_rc"
			, "pnl_rc"
			, "pnl_qtd_rc"
			, "pnl_fytd_rc"
			, "pnl_4yp_rc"
			, "pnl_5y_roll_rc"
			, "pnl_10y_roll_rc"
		FROM
			"performance"."perf_top_down"@pgdb
		WHERE 
			"ppy" = 12
			/* BENCHMARK PORTFOLIO TOTAL FUND, BENCHMARK PORTFOLIO ACCOUNTS, VALUE-ADDED TOTAL FUND */
			AND (
				"dataset_id" IN ( 'ATP_TF', 'ATP_BCPP', 'ATP_ACPP', 'INV_SELECT_TF' )
				AND "level" = 1
			)
	) perf_pivot
	CROSS APPLY (
		SELECT 'twr_rc' AS METRIC, "twr_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_qtd_rc' AS METRIC, "twr_qtd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_fytd_rc' AS METRIC, "twr_fytd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_4yp_rc' AS METRIC, "twr_4yp_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_5y_roll_rc' AS METRIC, "twr_5y_roll_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'twr_10y_roll_rc' AS METRIC, "twr_10y_roll_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_rc' AS METRIC, "pnl_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_qtd_rc' AS METRIC, "pnl_qtd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_fytd_rc' AS METRIC, "pnl_fytd_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_4yp_rc' AS METRIC, "pnl_4yp_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_5y_roll_rc' AS METRIC, "pnl_5y_roll_rc" AS VALUE FROM DUAL
		UNION ALL
		SELECT 'pnl_10y_roll_rc' AS METRIC, "pnl_10y_roll_rc" AS VALUE FROM DUAL
	) perf_unpivot
), perf_clean AS (
	SELECT
		  perf.*
		, CASE
				WHEN SYSDATE >= (
									SELECT	TO_DATE( CALENDAR_DATE, 'yyyymmdd' )
									FROM	EXCALIBUR.MAPPING_DATE_TO_BUSINESS_DATE mdtbd 
									WHERE 	YEAR_MONTH = TO_NUMBER( TO_CHAR( SYSDATE, 'yyyymm' ) )
											AND MONTH_BUSINESS_DAY = ( 12 + 1 )
								) THEN 'Final'
				ELSE (
						CASE 
							WHEN BUSINESS_DATE > ADD_MONTHS( TRUNC( SYSDATE, 'MONTH' ), -1 ) THEN 'Prelim'
							ELSE 'Final'
						END
				) 
		  END PRELIM_FINAL
	FROM 
		perf
	WHERE 
		VALUE IS NOT NULL
		AND BUSINESS_DATE >= TO_DATE( '2019-04-01', 'yyyy-mm-dd' )
		AND NOT (
			NODE_NAME IN ( 'Active Equities', 'Capital Markets & Factor Investing' )
			AND METRIC_TYPE = 'Return'
		)
		AND NOT (
			PERIOD = '10Y'
			AND BUSINESS_DATE < TO_DATE( '2024-04-01', 'yyyy-mm-dd' ) -- LOTS OF MISSING 10Y DATA PRIOR TO 2024-04
		)
), perf_final AS (
	SELECT
		  perf_clean.*
		, TO_CHAR( BUSINESS_DATE, 'yyyy-mm-dd' ) AS BUSINESS_DATE_STRING
		, TO_CHAR( BUSINESS_DATE, 'yyyy-mm' ) AS YEAR_MONTH
		, CASE 
			WHEN PERIOD = 'MTD' THEN '1. MTD'
			WHEN PERIOD = 'QTD' THEN '2. QTD'
			WHEN PERIOD = 'FYTD' THEN '3. FYTD'
			WHEN PERIOD = '4Y+FYTD' THEN '4. 4Y+FYTD'
			WHEN PERIOD = '5Y' THEN '5. 5Y'
			WHEN PERIOD = '10Y' THEN '6. 10Y'
		  END PERIOD_SORTED
	FROM 
		perf_clean
	WHERE 
		PRELIM_FINAL = 'Final'
)
SELECT * FROM perf_final