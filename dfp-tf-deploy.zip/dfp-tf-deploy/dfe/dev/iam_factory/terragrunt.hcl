# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

skip            = include.root.locals.params.services.iam_factory.skip_deployment
prevent_destroy = include.root.locals.params.services.iam_factory.prevent_destroy

locals {

  # Artifact versions to deploy
  repo_name = include.root.locals.params.services.iam_factory.repo
  release_version = include.root.locals.params.services.iam_factory.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
}

terraform {
  source = "git::git@github.com:${local.repo_name}.git//modules?ref=${local.release_version}"
}


# These are the variables we have to pass in to use the module specified in the terragrunt configuration above
inputs = {
  #=================
  #Account inputs
  #=================
  aws_region = local.aws_region

  #=================
  #Environment inputs
  #=================
  env_name    = local.env_name
  acc_name    = local.acc_name
  name_suffix = local.name_suffix
  base_tags   = local.base_tags

  # Common Service params

  
  iam_roles      = include.root.locals.params.services.iam_factory.inputs.iam_roles
  trustee_roles  = include.root.locals.params.services.iam_factory.inputs.trustee_roles
  trust_policies = include.root.locals.params.services.iam_factory.inputs.trust_policies
  
  base_tags          = local.base_tags

}