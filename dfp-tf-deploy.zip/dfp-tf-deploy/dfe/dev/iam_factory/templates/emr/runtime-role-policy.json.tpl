{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode([principal_arns])}
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode([principal_arns])}
            },
            "Action": "sts:TagSession",
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode([principal_arns])}
            },
            "Action": "sts:SetSourceIdentity"
        },
        {
            "Effect": "Allow",
            "Principal": {
              "Service": [ "emr-serverless.amazonaws.com",
                "elasticmapreduce.amazonaws.com",
                "emr-containers.amazonaws.com" ]
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
