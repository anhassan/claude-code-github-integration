{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowRuntimeRoleUsage",
            "Effect": "Allow",
            "Action": [
                "sts:AssumeRole",
                "sts:TagSession",
                "sts:SetSourceIdentity"
            ],
            "Resource": ${jsonencode(
                        [for role in role_arns : "${role}"],
                        )}
            ,
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        }
    ]
}