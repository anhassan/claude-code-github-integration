{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "${principal_type[0]}": ${jsonencode(
                            [for arn in principal_arns : "${arn}"],
                        )}
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        },
        {
            "Effect": "Allow",
            "Principal": {
                "${principal_type[0]}": ${jsonencode(
                            [for arn in principal_arns : "${arn}"],
                        )}
            },
            "Action": "sts:SetSourceIdentity"
        }
    ]
}