{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode(
                            [for arn in role_arns : "${arn}"],
                        )}
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode(
                            [for arn in role_arns : "${arn}"],
                        )}
            },
            "Action": "sts:TagSession",
            "Condition": {
                "StringNotLike": {
                    "aws:UserAgent": "aws-cli*"
                }
            }
        },
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": ${jsonencode(
                            [for arn in role_arns : "${arn}"],
                        )}
            },
            "Action": "sts:SetSourceIdentity"
        },
        {
            "Effect": "Allow",
            "Principal": {
              "Service": "emr-serverless.amazonaws.com",
              "Service": "elasticmapreduce.amazonaws.com",
              "Service": "emr-containers.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
