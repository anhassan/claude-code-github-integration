# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

skip            = include.root.locals.params.services.insights.skip_deployment
prevent_destroy = include.root.locals.params.services.insights.prevent_destroy

locals {

  # Artifact versions to deploy
  repo_name       = include.root.locals.params.services.insights.repo
  release_version = include.root.locals.params.services.insights.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
  artifact_bucket = include.root.locals.environment.artifact_bucket
  vpc_endpoint    = include.root.locals.environment.api_gateway.execute_api_private

}

terraform {
  source = "git::git@github.com:${local.repo_name}.git?ref=${local.release_version}"
}

inputs = {
  #=================
  #Account inputs
  #=================
  aws_region = local.aws_region
  account_id = local.account_id

  #=================
  #Environment inputs
  #=================
  env_name        = local.env_name
  acc_name        = local.acc_name
  name_suffix     = local.name_suffix
  base_tags       = local.base_tags
  artifact_bucket = local.artifact_bucket

  # Common Service params
  service_name = include.root.locals.params.services.insights.service_name
  base_tags    = local.base_tags

  # inputs
  associated_accounts     = include.root.locals.params.services.insights.inputs.associated_accounts
  vpc_endpoint            = local.vpc_endpoint
}