# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

# see https://terragrunt.gruntwork.io/docs/reference/config-blocks-and-attributes/#skip
# IMPORTANT: 
# If set true on a repo that is a dependancy, then the mocked output values defined in 
# the dependant service will be passed to the dependant module.
skip            = include.root.locals.params.services.trino_dms_service.skip_deployment
prevent_destroy = include.root.locals.params.services.trino_dms_service.prevent_destroy

dependency "s3_buckets" {
  config_path = "../s3_buckets"
  mock_outputs = {
    buckets = {
      trino_logs = {
        bucket_id = include.root.locals.params.services.s3_buckets.outputs.buckets.trino_logs.bucket_id
        bucket_arn  = include.root.locals.params.services.s3_buckets.outputs.buckets.trino_logs.bucket_arn
      }  
    }
  }
}

dependency "dms_iam" {
  config_path = "../dms_iam"
  mock_outputs = {
    dms_access_endpoint_iam_role_arn = include.root.locals.params.services.dms_iam.outputs.dms_access_endpoint_iam_role_arn
    dms_vpc_role_arn                 = include.root.locals.params.services.dms_iam.outputs.dms_vpc_role_arn
    dms_cloudwatch_logs_role_arn     = include.root.locals.params.services.dms_iam.outputs.dms_cloudwatch_logs_role_arn
  }
}
locals {

  # Artifact versions to deploy
  repo_name       = include.root.locals.params.services.trino_dms_service.repo
  release_version = include.root.locals.params.services.trino_dms_service.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name            = include.root.locals.environment.env_name
  acc_name            = include.root.locals.environment.acc_name
  name_suffix         = include.root.locals.environment.name_suffix
  base_tags           = include.root.locals.environment.base_tags
  artifact_bucket     = include.root.locals.environment.artifact_bucket
  vpc_id              = include.root.locals.environment.vpc.id
  vpc_name            = include.root.locals.environment.vpc.name
  vpc_private_subnets = include.root.locals.environment.vpc.private_subnets
  top_level_domain    = include.root.locals.environment.api_gateway.top_level_domain
  execute_api_private = include.root.locals.environment.api_gateway.execute_api_private
}

terraform {
  source = "git::git@github.com:${local.repo_name}//workspaces/workspace_dms/?ref=${local.release_version}"
}

# =================================
inputs = {
  acc_name     = local.acc_name
  name_suffix  = local.name_suffix
  vpc_id       = local.vpc_id
  vpc_name     = local.vpc_name
  env_name     = local.env_name
  service_name = include.root.locals.params.services.trino_dms_service.service_name

  env = local.env_name


  //Security group
  dms_ingress_rules = include.root.locals.params.services.trino_dms_service.inputs.security_group.ingreess_rules

  //Replication instance
  replication_instances = include.root.locals.params.services.trino_dms_service.inputs.replication_instances
  
  //End points
  dms_s3_endpoints = {
    for key, value in include.root.locals.params.services.trino_dms_service.inputs.end_points.s3 : key => merge(value, { "bucket_name" : dependency.s3_buckets.outputs.buckets.trino_logs.bucket_id })
  }

  dms_db_endpoints = include.root.locals.params.services.trino_dms_service.inputs.end_points.db

  //Replication tasks
  replication_tasks = include.root.locals.params.services.trino_dms_service.inputs.replication_tasks


  tags = local.base_tags

}
# =================================
