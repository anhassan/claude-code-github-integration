# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

skip            = include.root.locals.params.services.s3_buckets.skip_deployment
prevent_destroy = include.root.locals.params.services.s3_buckets.prevent_destroy

locals {

  # Artifact versions to deploy
  repo_name = include.root.locals.params.services.s3_buckets.repo
  release_version = include.root.locals.params.services.s3_buckets.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
  artifact_bucket = include.root.locals.environment.artifact_bucket

}

terraform {
  source = "git::git@github.com:${local.repo_name}.git//workspace/module?ref=${local.release_version}"
}


# These are the variables we have to pass in to use the module specified in the terragrunt configuration above
inputs = {

  #=================
  #Account inputs
  #=================
  aws_region = local.aws_region
  account_id = local.account_id

  #=================
  #Environment inputs
  #=================
  env_name    = local.env_name
  acc_name    = local.acc_name
  name_suffix = local.name_suffix
  base_tags   = local.base_tags

  # Service params
  service_name                = include.root.locals.params.services.s3_buckets.service_name
  common_publisher_principals = include.root.locals.params.services.s3_buckets.inputs.common_configs.publisher_principals
  common_consumer_principals  = include.root.locals.params.services.s3_buckets.inputs.common_configs.consumer_principals
  # common_lifecycle_rules = include.root.locals.params.services.s3_buckets.inputs.common_configs.lifecycle_rules
  noncurrent_version_expiration_days  = include.root.locals.params.services.s3_buckets.inputs.common_configs.noncurrent_version_expiration_days
  intelligent_storage_transition_days = include.root.locals.params.services.s3_buckets.inputs.common_configs.intelligent_storage_transition_days

  buckets = include.root.locals.params.services.s3_buckets.inputs.buckets

}
