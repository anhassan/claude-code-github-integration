# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

# see https://terragrunt.gruntwork.io/docs/reference/config-blocks-and-attributes/#skip
# IMPORTANT: 
# If set true on a repo that is a dependancy, then the mocked output values defined in 
# the dependant service will be passed to the dependant module.
skip            = include.root.locals.params.services.dms_iam.skip_deployment
prevent_destroy = include.root.locals.params.services.dms_iam.prevent_destroy

locals {

  # Artifact versions to deploy
  repo_name       = include.root.locals.params.services.trino_dms_service.repo
  release_version = include.root.locals.params.services.trino_dms_service.release_version

  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common envrionment variables
  env_name            = include.root.locals.environment.env_name
  acc_name            = include.root.locals.environment.acc_name
  name_suffix         = include.root.locals.environment.name_suffix
  base_tags           = include.root.locals.environment.base_tags
  artifact_bucket     = include.root.locals.environment.artifact_bucket
  vpc_id              = include.root.locals.environment.vpc.id
  vpc_name            = include.root.locals.environment.vpc.name
  vpc_private_subnets = include.root.locals.environment.vpc.private_subnets
  top_level_domain    = include.root.locals.environment.api_gateway.top_level_domain
  execute_api_private = include.root.locals.environment.api_gateway.execute_api_private
}

terraform {
  source = "git::git@github.com:${local.repo_name}//workspaces/workspace_iam/?ref=${local.release_version}"
}


# =================================
inputs = {



}
# =================================
