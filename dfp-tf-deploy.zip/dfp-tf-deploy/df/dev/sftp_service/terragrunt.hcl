# Terragrunt will copy the Terraform configurations specified by the source parameter, along with any files in the
# working directory, into a temporary folder, and execute your Terraform commands in that folder.
# Include all settings from the root terragrunt.hcl file
include "root" {
  path   = find_in_parent_folders()
  expose = true
}

skip            = include.root.locals.params.services.sftp_service.skip_deployment
prevent_destroy = include.root.locals.params.services.sftp_service.prevent_destroy


locals {
  # Account variables
  account_id = include.root.locals.account.aws_account_id
  aws_region = include.root.locals.account.aws_region

  # Common environment variables
  env_name        = include.root.locals.environment.env_name
  acc_name        = include.root.locals.environment.acc_name
  name_suffix     = include.root.locals.environment.name_suffix
  base_tags       = include.root.locals.environment.base_tags
  artifact_bucket = include.root.locals.environment.artifact_bucket
  vpc_id              = include.root.locals.environment.vpc.id
  top_level_domain    = include.root.locals.environment.api_gateway.top_level_domain

  # Artifact versions to deploy
  repo_name = include.root.locals.params.services.sftp_service.repo
  release_version = include.root.locals.params.services.sftp_service.release_version
}


terraform {
  source = "git::git@github.com:${local.repo_name}.git//modules?ref=${local.release_version}"
}


# These are the variables we have to pass in to use the module specified in the terragrunt configuration above
inputs = {

  #=================
  #Account inputs
  #=================
  aws_region = local.aws_region
  account_id = local.account_id

  #=================
  #Environment inputs
  #=================
  env_name    = local.env_name
  acc_name    = local.acc_name
  name_suffix = local.name_suffix
  base_tags   = local.base_tags

  # Service params
  vpc_id      = local.vpc_id
  top_level_domain = local.top_level_domain

  service_name = include.root.locals.params.services.sftp_service.service_name
  subnet_ids  = include.root.locals.params.services.sftp_service.inputs.sftp_server.private_subnets
  landing_bucket_name = include.root.locals.params.services.sftp_service.inputs.sftp_server.landing_bucket_name
  sftp_ingress_cidr_blocks = include.root.locals.params.services.sftp_service.inputs.sftp_server.sftp_ingress_cidr_blocks
  sftp_users = include.root.locals.params.services.sftp_service.inputs.sftp_users
}
