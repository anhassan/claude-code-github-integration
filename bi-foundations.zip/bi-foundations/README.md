# bi-foundations
This repo contains the backend code required for the FinSights portal. The following lambdas can be found in here:

* dashboard-entitlements-lambda: Used for handling entitlement files for ALS 
* dataset-entitlements-lambda: Used for handling entitlement files for RLS
* event-notification-lambda: Used to filter error messages from the orchenstration pipeline to send emails regarding successes or failures of pipelien
* metadata-email-report-lambda: 
* portal-assets-lambda: Used as a backend for frontend service, integrated with API gateway, to provide information to the front end regarding assets
* portal-entitlements-lambda: Used to facilitate approval workflows for ALS and RLS reqeusts
* portal-user-lambda: Used as a backend for frontend service, integrated with API gateway, to provide information to the front end regarding users or user driven information. 
* qs_dataset_lambda: Used as part of the overall orchestration pipeline to set up and configure QS datasets
* qs-publish-export-lambda: Used as part of the overall orchestration pipeline to copy and recreate dashboards and other assets
* quicksight_mgr: Overarching lambda used to facilitate portions of the orchestration pipeline or complex tasks for the other qs_* lambdas. 



# Development Set up 
It is recommended to run this library in WSL.

Find instructions here: https://cppib.atlassian.net/wiki/spaces/FS/pages/450495529/Onboarding


## Local Unit Testing
in wsl: pytest -v --cov
Note: there are not many local unit tests currently present, and the ones existing have not been run nor updated for some time. 


## End to End Testing


If you want to test your code changes before merging your code to the develop branch, It is possible to deploy to AWS develop account to do end to end testing.
The following steps outline how to deploy and test end to end.

In this df-data-quality-service repo:

1. Find latest version number cppib-df-tmp-artifacts-bucket in the DataFabric-Dev account
2. Change version number in pr in the version file for example 0.1.2a
3. Update change log
4. Grab the latest aws credentials
5. In wsl: make clean
6. In wsl: make build - makes a version artifact locally (deploy folder is what is ready to deploy)


## Development

### Associated Repos
- Frontend: https://github.cppib.ca/CPPIB/df-data-portal-ui
- IAC: https://github.cppib.ca/CPPIB/df-dashboard-service-tf
- Deployment: https://github.cppib.ca/CPPIB/dfp-tf-deploy

### Deployment
This repo is a collection of microservices for the BI Portal Application deployed as lambdas. Each top-level folder under the `src/` directory is treated as a separate microservice, and is deployed indepedently. A root level `common/` folder is used to share common models and utilities across multiple microservices, and therefore its contents and depedencies are installed on every artifact.

```markdown
├── test_requirements.txt # test dependencies, are not included in artifacts
│
├── common 
│   └── common_requirements.txt # dependencies installed in every artifact
│   └── [README.md](./common/README.md)
│
├── src
│   └── lambda_microservice_1
│       └── requirements.txt # microservice specific dependencies 
│       └── ... 
│
│   └── lambda_microservice_2
│       └── ...
```