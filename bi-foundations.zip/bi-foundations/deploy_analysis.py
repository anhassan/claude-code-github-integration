"""Deploy the analysis definition to QuickSight using boto3."""
import json
import boto3

with open("27221d1f-da9c-429c-8650-65f748c45db0_analysis_definition.json", encoding="utf-8") as f:
    params = json.load(f)

qs = boto3.client("quicksight", region_name="us-east-1")

try:
    qs.describe_analysis(AwsAccountId=params["AwsAccountId"], AnalysisId=params["AnalysisId"])
    print("Analysis exists - updating...")
    response = qs.update_analysis(**params)
    action = "Updated"
except qs.exceptions.ResourceNotFoundException:
    print("Analysis does not exist - creating...")
    response = qs.create_analysis(**params)
    action = "Created"

status = response.get("Status")
arn = response.get("Arn", "")
analysis_id = response.get("AnalysisId", "")
print(f"{action} successfully!")
print(f"  Status:     {status}")
print(f"  AnalysisId: {analysis_id}")
print(f"  Arn:        {arn}")
