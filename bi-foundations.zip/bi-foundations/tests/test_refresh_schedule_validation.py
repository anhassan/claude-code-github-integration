"""PR-time validation for the refresh_schedule metadata block.

Encodes two empirically-confirmed QuickSight limits:
  * a high-frequency interval (HOURLY/MINUTE15/MINUTE30) must be a dataset's
    SOLE refresh schedule, and
  * a dataset may have at most 5 refresh schedules.
"""

from common.utils.validate import validate_dataset_metadata_file


def _meta(schedules, **over):
    m = {
        "name": "rmv_analytics",
        "import_mode": "SPICE",
        "workspaces": ["bif-risk"],
        "columns": {"business_date_dt": "DATETIME", "analytic_value": "DECIMAL"},
        "refresh_schedule": schedules,
    }
    m.update(over)
    return m


def _sched(interval, sid, rtype="FULL_REFRESH"):
    return {
        "ScheduleId": sid,
        "RefreshType": rtype,
        "ScheduleFrequency": {"Interval": interval},
    }


def _sched_errors(meta):
    return [
        e
        for e in validate_dataset_metadata_file(meta, "metadata")
        if "schedule" in str(e).lower()
    ]


def test_two_non_hourly_schedules_ok():
    meta = _meta([_sched("DAILY", "a"), _sched("WEEKLY", "b")])
    assert _sched_errors(meta) == []


def test_hourly_alone_ok():
    meta = _meta([_sched("HOURLY", "a")])
    assert _sched_errors(meta) == []


def test_hourly_with_companion_errors():
    meta = _meta([_sched("HOURLY", "a"), _sched("DAILY", "b")])
    assert any("HOURLY" in e for e in _sched_errors(meta))


def test_minute15_with_companion_errors():
    meta = _meta([_sched("MINUTE15", "a"), _sched("DAILY", "b")])
    errs = _sched_errors(meta)
    assert any("MINUTE15" in e or "sole" in e.lower() for e in errs)


def test_more_than_five_schedules_errors():
    meta = _meta([_sched("DAILY", f"s{i}") for i in range(6)])
    assert any("5" in e for e in _sched_errors(meta))


def test_exactly_five_schedules_ok():
    meta = _meta([_sched("DAILY", f"s{i}") for i in range(5)])
    assert _sched_errors(meta) == []
