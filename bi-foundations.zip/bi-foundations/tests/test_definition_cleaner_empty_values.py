"""remove_invalid_definition_keys must keep meaningful empty-string values.

Regression for the AE Net Country/Sector defect (2026-06-12): the cleaner
stripped "" from filter CategoryValues lists during promote, silently turning
DOES_NOT_CONTAIN [""] into a no-op and dropping the blank-sector bucket from a
CONTAINS list — the dashboards still created successfully, so the semantic
change went unnoticed until business validation.
"""

from src.quicksight_mgr.resources import Dashboard


class FakeLogger:
    def info(self, message):
        pass

    def warning(self, message):
        pass


def make_dashboard():
    event = {
        "resource": "dashboard",
        "payload": {
            "id": "test-dashboard",
            "definition": {"Definition": {}, "DashboardPublishOptions": {}},
            "config": {
                "id_prefix": "dash",
                "workspace": "workspace",
                "display_name": "Test Dashboard",
            },
        },
    }
    return Dashboard(FakeLogger(), object(), event)


def test_category_values_keep_empty_strings():
    definition = {
        "FilterGroups": [
            {
                "Filters": [
                    {
                        "CategoryFilter": {
                            "Configuration": {
                                "FilterListConfiguration": {
                                    "MatchOperator": "DOES_NOT_CONTAIN",
                                    "CategoryValues": [""],
                                    "NullOption": "ALL_VALUES",
                                }
                            }
                        }
                    },
                    {
                        "CategoryFilter": {
                            "Configuration": {
                                "FilterListConfiguration": {
                                    "MatchOperator": "CONTAINS",
                                    "CategoryValues": ["", "Energy", "Utilities"],
                                    "NullOption": "NON_NULLS_ONLY",
                                }
                            }
                        }
                    },
                ]
            }
        ]
    }
    make_dashboard().remove_invalid_definition_keys(definition)
    configs = [
        f["CategoryFilter"]["Configuration"]["FilterListConfiguration"]
        for f in definition["FilterGroups"][0]["Filters"]
    ]
    assert configs[0]["CategoryValues"] == [""]
    assert configs[1]["CategoryValues"] == ["", "Energy", "Utilities"]


def test_static_values_keep_empty_strings():
    definition = {
        "ParameterDeclarations": [
            {
                "StringParameterDeclaration": {
                    "Name": "p",
                    "DefaultValues": {"StaticValues": ["", "ALL"]},
                }
            }
        ]
    }
    make_dashboard().remove_invalid_definition_keys(definition)
    decl = definition["ParameterDeclarations"][0]["StringParameterDeclaration"]
    assert decl["DefaultValues"]["StaticValues"] == ["", "ALL"]


def test_other_empty_values_still_removed():
    definition = {
        "Sheets": [
            {
                "Name": "",  # empty-string key value -> still dropped
                "SheetId": "s1",
                "SomeList": ["", "keep"],  # non-preserved list -> "" stripped
            }
        ]
    }
    make_dashboard().remove_invalid_definition_keys(definition)
    sheet = definition["Sheets"][0]
    assert "Name" not in sheet
    assert sheet["SomeList"] == ["keep"]
    assert sheet["SheetId"] == "s1"
