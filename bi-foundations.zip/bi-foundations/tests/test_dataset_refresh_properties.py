"""Tests for the DatasetRefreshProperties resource — sets the SPICE incremental
refresh LookbackWindow via describe-overlay-put (preserving any existing
FailureConfiguration) with ConflictException retry/backoff."""


class FakeLogger:
    def info(self, *a, **k):
        pass

    def warning(self, *a, **k):
        pass

    def error(self, *a, **k):
        pass


class FakeRefreshPropsClient:
    class exceptions:
        class ResourceNotFoundException(Exception):
            pass

        class ConflictException(Exception):
            pass

    def __init__(self, existing=None, put_conflicts=0):
        self.existing = existing
        self._put_conflicts_remaining = put_conflicts
        self.put_calls = []
        self.describe_calls = 0

    def describe_data_set_refresh_properties(self, **kw):
        self.describe_calls += 1
        if self.existing is None:
            raise self.exceptions.ResourceNotFoundException("not set")
        return {"DataSetRefreshProperties": self.existing}

    def put_data_set_refresh_properties(self, **kw):
        if self._put_conflicts_remaining > 0:
            self._put_conflicts_remaining -= 1
            raise self.exceptions.ConflictException("in-flight refresh")
        self.put_calls.append(kw)
        return {"Status": 200}


def _event(config=None):
    return {
        "resource": "dataset_refresh_properties",
        "payload": {
            "id": "rmv_analytics",
            "account_id": "200967598245",
            "config": config
            or {
                "incremental_refresh": {
                    "column_name": "business_date_dt",
                    "size": 14,
                    "size_unit": "DAY",
                }
            },
        },
    }


def test_overlays_lookback_preserving_existing_failure_config():
    from quicksight_mgr.resources import DatasetRefreshProperties

    qs = FakeRefreshPropsClient(
        existing={"FailureConfiguration": {"EmailAlert": {"AlertStatus": "ENABLED"}}}
    )
    DatasetRefreshProperties(FakeLogger(), qs, _event()).sync()

    assert len(qs.put_calls) == 1
    put = qs.put_calls[0]
    assert put["DataSetId"] == "rmv_analytics"
    props = put["DataSetRefreshProperties"]
    # existing email config preserved (describe-overlay-put, not blind replace)
    assert props["FailureConfiguration"] == {"EmailAlert": {"AlertStatus": "ENABLED"}}
    # lookback window built from config
    assert props["RefreshConfiguration"]["IncrementalRefresh"]["LookbackWindow"] == {
        "ColumnName": "business_date_dt",
        "Size": 14,
        "SizeUnit": "DAY",
    }


def test_sets_lookback_when_no_existing_properties():
    from quicksight_mgr.resources import DatasetRefreshProperties

    qs = FakeRefreshPropsClient(existing=None)  # describe raises ResourceNotFound
    DatasetRefreshProperties(FakeLogger(), qs, _event()).sync()

    assert len(qs.put_calls) == 1
    props = qs.put_calls[0]["DataSetRefreshProperties"]
    assert "FailureConfiguration" not in props
    assert (
        props["RefreshConfiguration"]["IncrementalRefresh"]["LookbackWindow"]["ColumnName"]
        == "business_date_dt"
    )


def test_retries_put_on_conflict_then_succeeds(monkeypatch):
    """UpdateDataSet may leave an in-flight edit refresh; the property put can
    hit ConflictException. It should retry/backoff and eventually land."""
    monkeypatch.setattr("time.sleep", lambda *_: None)
    from quicksight_mgr.resources import DatasetRefreshProperties

    qs = FakeRefreshPropsClient(existing=None, put_conflicts=2)
    DatasetRefreshProperties(FakeLogger(), qs, _event()).sync()

    assert len(qs.put_calls) == 1  # 2 conflicts retried, 3rd attempt landed


def test_handler_dispatch_resolves_resource_name_to_class():
    """The handler resolves a resource string to a class via snake_to_camel.
    `dataset_refresh_properties` must map to the DatasetRefreshProperties class
    and be a registered VALID_RESOURCE, or the publisher can't invoke it."""
    import quicksight_mgr.resources as resources
    from quicksight_mgr.base import snake_to_camel, VALID_RESOURCES

    assert snake_to_camel("dataset_refresh_properties") == "DatasetRefreshProperties"
    assert hasattr(resources, "DatasetRefreshProperties")
    assert "dataset_refresh_properties" in VALID_RESOURCES
