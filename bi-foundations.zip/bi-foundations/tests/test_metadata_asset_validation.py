from src.quicksight_mgr.upload_manifest import (generate_changed_file_list,
                                                get_asset_directories,
                                                get_s3_asset_bucket_name)

github_changed_files_str = "dev/assets/cost_dashboard/config.yaml dev/assets/cost_dashboard/datasets.yaml dev/assets/transaction_dashboard/datasets.csv dev/datasets/transaction_dashboard/datasets.csv"


def test_generate_changed_file_list():
    changed_file_list = generate_changed_file_list(github_changed_files_str)
    assert len(changed_file_list) == 4
    assert changed_file_list[0] == "dev/assets/cost_dashboard/config.yaml"


def test_get_asset_directories(changed_asset_metadata_file_list):
    asset_folder_list = get_asset_directories(changed_asset_metadata_file_list)
    # Retrieve result from storage
    # This will only run if test_first passes
    assert len(asset_folder_list) == 2

def test_get_s3_asset_bucket_name():
    asset_directory="dev/assets/cost_dashboard"
    bucket_name = get_s3_asset_bucket_name(asset_directory)
    assert True