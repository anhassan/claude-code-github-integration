import os

import pytest
import sys

# Get the absolute path to the .github directory
github_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".github")
sys.path.append(github_dir)
from src.quicksight_mgr.qs_asset_manager import detect_metadata_csv_name
from common.utils.validate import (
    check_table_headers,
    check_yaml_required_columns,
    check_yaml_optional_columns,
    check_asset_config_yaml_optional_finsights_detail,
    InvalidColumnError,
    validate_column_data_types,
    __validate_dataset_metadata_file,
    __validate_rls_file,
    __validate_config_file,
    __validate_s3_manifest_file,
)

import csv
import yaml


def test_check_table_headers(env):
    file_to_read = "cost_sheets.csv"
    BASE_DEFINITION_PATH = os.path.join(
        "tests", "resources", "definitions", file_to_read
    )
    with open(BASE_DEFINITION_PATH) as f:
        asset_sheets_csv_reader = csv.DictReader(f, delimiter=",")
        file_type = detect_metadata_csv_name(BASE_DEFINITION_PATH)
        result = check_table_headers(asset_sheets_csv_reader, file_type)
        assert result == []


def test_check_yaml_required_columns():
    config_base_path = os.path.join(
        "tests", "cfg", "assets", "cost_dataset", "config.yaml"
    )
    dataset_metadata_base_path = os.path.join(
        "tests", "cfg", "datasets", "cost_dataset", "metadata.yaml"
    )
    file_validation_list = [config_base_path, dataset_metadata_base_path]
    for file_path in file_validation_list:
        with open(file_path) as f:
            table_name = os.path.basename(file_path).split(".")[0]
            config_reader = yaml.safe_load(f)
            response = check_yaml_required_columns(config_reader, table_name)
            assert response == []


def test_check_yaml_optional_columns():
    rls_base_path = os.path.join("tests", "cfg", "datasets", "cost_dataset", "rls.yaml")
    embedding_base_path = os.path.join(
        "tests", "cfg", "assets", "cost_dataset", "embedding_access.yaml"
    )
    file_validation_list = [rls_base_path, embedding_base_path]
    for file_path in file_validation_list:
        with open(file_path) as f:
            table_name = os.path.basename(file_path).split(".")[0]
            config_reader = yaml.safe_load(f)
            response = check_yaml_optional_columns(config_reader, table_name)
            assert response == True

    invalid_rls_yaml_data = {
        "rls": {
            "department1": {"column_name": "dept"},
            "rls": [
                {
                    "department": {
                        "name": "IT",
                        "authorized_value": ["tech"],
                        "unexpected_field": "value",  # This should trigger an error
                    }
                }
            ],
        }
    }
    with pytest.raises(InvalidColumnError) as exc_info:
        check_yaml_optional_columns(invalid_rls_yaml_data, "rls")
    assert "Unexpected keys ['department1', 'rls'] found in rls" in str(exc_info.value)


def test_check_yaml_optional_columns():
    metadata_path = os.path.join(
        "tests", "cfg", "datasets", "cost_dataset", "metadata.yaml"
    )
    with open(metadata_path) as f:
        config_reader = yaml.safe_load(f)
        response = validate_column_data_types(config_reader)
        assert response == []


def test_validate_full_methods():
    path = os.path.join("tests", "cfg")
    all_errors = []
    # Collect errors from each validation function
    all_errors.extend(__validate_dataset_metadata_file(path))
    all_errors.extend(__validate_rls_file(path))
    all_errors.extend(__validate_config_file(path))
    all_errors.extend(__validate_s3_manifest_file(path))
    all_errors = [error for error in all_errors if error]
    assert all_errors == []


def test_check_asset_config_yaml_optional_finsights_detail_catching_invalid_type_errors():
    asset_config = os.path.join("tests", "cfg", "assets", "cost_dataset", "config.yaml")
    with open(asset_config) as f:
        table_name = os.path.basename(asset_config).split(".")[0]
        config_data = yaml.safe_load(f)

        errors = check_asset_config_yaml_optional_finsights_detail(
            {
                **config_data,
                "finsights_detail": {
                    "asset_type": [],
                    "new_field_whose_type_is_not_validated": {},
                },
            },
            table_name,
        )

        assert len(errors) == 1
        assert "asset_type" in errors[0] and "type" in errors[0]
        assert "new_field_whose_type_is_not_validated" not in errors[0]
