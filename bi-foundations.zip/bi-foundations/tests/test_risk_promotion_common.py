# tests/test_risk_promotion_common.py
from pathlib import Path
import textwrap

from scripts.risk_promotion_common import (
    norm,
    load_dataset_index,
    dataset_id_to_slug,
    extract_dataset_arns,
)


def _make_dataset(tmp_path, slug, name):
    d = tmp_path / "datasets" / slug
    d.mkdir(parents=True)
    (d / "metadata.yaml").write_text(
        textwrap.dedent(f"""\
        name: {name}
        import_mode: DIRECT_QUERY
        workspaces: [bif-risk]
        columns:
          a: STRING
        """)
    )
    return d


def test_norm_lowercases_and_strips_extension():
    assert norm("F30 target.xlsx") == "f30_target"
    assert norm("ae-analytics-dev") == "ae_analytics_dev"


def test_load_dataset_index_maps_id_variants_to_slug(tmp_path):
    _make_dataset(tmp_path, "rmv_position", "rmv_position")
    _make_dataset(tmp_path, "ae_analytics", "ae_analytics")
    index = load_dataset_index(tmp_path / "datasets", env="dev")
    # raw slug id
    assert dataset_id_to_slug("rmv_position", index) == "rmv_position"
    # publisher-derived id form {name}-{env}
    assert dataset_id_to_slug("ae-analytics-dev", index) == "ae_analytics"
    # normalized fallback
    assert dataset_id_to_slug("RMV_Position", index) == "rmv_position"
    # publisher-derived id for an underscore-containing slug resolves
    assert dataset_id_to_slug("rmv_position-dev", index) == "rmv_position"


def test_dataset_id_to_slug_returns_none_when_unresolved(tmp_path):
    _make_dataset(tmp_path, "rmv_position", "rmv_position")
    index = load_dataset_index(tmp_path / "datasets", env="dev")
    assert dataset_id_to_slug("e7df3114-5be6-4b0e-bffa-ce66b6bf5182", index) is None


def test_extract_dataset_arns_reads_declarations():
    definition = {
        "Definition": {
            "DataSetIdentifierDeclarations": [
                {"Identifier": "A", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/rmv_position"},
                {"Identifier": "B", "DataSetArn": "arn:aws:quicksight:us-east-1:840529182937:dataset/e7df3114"},
            ]
        }
    }
    ids = extract_dataset_arns(definition)
    assert ids == [
        ("rmv_position", "200967598245"),
        ("e7df3114", "840529182937"),
    ]
