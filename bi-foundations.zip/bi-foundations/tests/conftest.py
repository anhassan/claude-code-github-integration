from collections import defaultdict
import os
import json
import sys
import pytest
import copy
import io
import botocore.session
from botocore.stub import Stubber
from botocore.response import StreamingBody
import csv
import yaml
from common.models.qs_trigger_config import QSPayload, QSManagerPayload
from datetime import datetime, timezone

os.environ.setdefault("AWS_EC2_METADATA_DISABLED", "true")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "testing")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "testing")
os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-1")

BASE_RESOURCE_PATH = os.path.join("tests", "resources")
CFG_BASE_RESOURCE_PATH = os.path.join("tests", "cfg")

sys.path.insert(0, os.path.abspath("common"))
sys.path.insert(0, os.path.abspath("src"))

ENV = {
    "ACCOUNT_ID": "123456789012",
    "QUICKSIGHT_ACCOUNT_ID": "123456789012",
    "AWS_REGION_NAME": "us-east-1",
    "AWS_REGION": "us-east-1",
    "USERS_TABLE": "users",
    "ASSETS_TABLE": "assets",
    "EXECUTIONS_TABLE": "executions",
    "BUCKET": "bi-foundations-dev",
    "BUCKET_NAME": "bi-foundations-dev",
    "KEY": "quicksights-dashboards/cost",
    "OPENSEARCH_ENDPOINT": "opensearch.com",
    "OPENSEARCH_INDEX_NAME": "assets",
    "USER_TABLE": "bi-foundations-user",
    "FAVOURITE_ASSETS_TABLE": "bi-foundations-favourite-assets",
    "DATASET_RLS_TABLE": "bi-foundations-dataset-rls",
    "DATASET_CLS_TABLE": "bi-foundations-dataset-cls",
    "Q_TOPIC_SECURITY_TABLE": "bi-foundations-q-topic-security",
    "VPC_CONNECTION_ARN": "vpcArn123",
    "DEFAULT_ADMIN_GROUP": "AWS_SSO_QS_Admin",
    "ENV_NAME": "DEV",
    "ARTIFACTS_BUCKET": "artifacts-bucket",
    "FOUNDATION_BUCKET": "foundation-quicksight-123456789012-dev",
    "DROPBOX_BUCKET": "bi-foundations-dropbox-200967598245-dev",
    "DATA_SOURCE_ARN": "fabric_catalog_dev",
    "FABRIC_DATASOURCE_ARN": "arn:aws:quicksight:us-east-1:200967598245:datasource/fabric_catalog_dev",
    "ASSET_LEVEL_SECURITY_TABLE": "bi-foundations-asset-level-security",
    "DISCOVERY_ARN": "arn:aws:lambda:us-east-1:200967598245:function:df-data-discovery-service-dev",
    "POPUP_TABLE": "bi-portal-popup",
    "POPUP_PERMISSIONS_TABLE": "bi-portal-popup-edit-permissions",
    "UPLOAD_ENTITLEMENT_PERMISSIONS_TABLE": "bi-portal-upload-entitlement-permissions",
    "ASSET_ENTITLEMENT_PERMISSIONS_TABLE": "bi-portal-asset-entitlement-permissions",
    "HIDDEN_TAB_PERMISSIONS_TABLE": "bi-portal-hidden-tab-permissions",
    "SMTP_HOST": "smtp.example.com",
    "SMTP_PORT": "25",
    "ENTITLEMENT_REQUESTS_TABLE": "bi-foundations-entitlement-requests",
    "WORKSPACE_ENTITLEMENTS_MAPPING_TABLE": "bi-foundations-workspace-entitlements-mapping",
    "WORKSPACE_ALS_ENTITLEMENTS_TABLE": "bi-foundations-workspace-als-entitlements",
    "ENTITLEMENT_ALS_REQUESTS_TABLE": "bi-foundations-entitlement-als-requests",
}


def set_env():
    for k, v in ENV.items():
        os.environ[k] = v


set_env()


def load_fixtures(root=BASE_RESOURCE_PATH):
    """
    Load all test fixtures
    Output:
    {
        dir: {
            file_name: {
                data
            }
        }
    }
    Accessed via fixtures[directory][filename] = data
    """
    fixtures = defaultdict(dict)
    for root, dirs, files in os.walk(root):
        for dir in dirs:
            fixtures[dir] = {}

        for file in files:
            with open(os.path.join(root, file)) as f:
                path = root.split(os.sep)[-1]
                if file.endswith("json"):
                    print(path, file)
                    fixtures[path][file] = json.load(f)
                elif file.endswith("csv"):
                    print(path, file)
                    reader = csv.DictReader(f)
                    fixtures[path][file] = list(reader)
                elif file.endswith("yaml"):
                    print(path, file)
                    fixtures[path][file] = yaml.safe_load(f)
                elif file.endswith("sql"):
                    fixtures[path][file] = f.read()
                else:
                    raise ValueError(file)
    return fixtures


fixtures = load_fixtures()
CFG_BASE_RESOURCE_PATH = os.path.join("tests", "cfg")
cfg_fixtures = load_fixtures(CFG_BASE_RESOURCE_PATH)


@pytest.fixture
def env():
    return ENV


@pytest.fixture
def resources():
    return fixtures


@pytest.fixture
def sample_errors():
    return {
        "sheet_scoping": """
    "Parameter validation failed:\nInvalid length for parameter Definition.FilterGroups[73].ScopeConfiguration.SelectedSheets.SheetVisualScopingConfigurations, value: 0, valid min length: 1\nInvalid length for parameter Definition.FilterGroups[76].ScopeConfiguration.SelectedSheets.SheetVisualScopingConfigurations, value: 0, valid min length: 1"
    """,
        "default_filter": """
    An error occurred (InvalidParameterValueException) when calling the CreateDashboard operation: Filter(s) with the DefaultFilterControlConfiguration attribute must have at least one associated Filter Control,  \n\t at Filters c556db68-5e5c-4098-9cfc-560d48b6184c.
    """,
    }


@pytest.fixture
def users():
    return {
        "admin": "admin-user@email.com",
        "reader": "reader-user@email.com",
        "author": "author-user@email.com",
    }


@pytest.fixture()
def dynamo_admin_user_stubber(users):
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    with Stubber(dynamo) as stubber:
        stubber.add_response(
            "get_item",
            fixtures["events"]["get_item_admin_user.json"],
            {"Key": {"email": {"S": users["admin"]}}, "TableName": ENV["USERS_TABLE"]},
        )
        yield dynamo


@pytest.fixture()
def dynamo_reader_user_stubber(users):
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    with Stubber(dynamo) as stubber:
        stubber.add_response(
            "get_item",
            fixtures["events"]["get_item_reader_user.json"],
            {"Key": {"email": {"S": users["reader"]}}, "TableName": ENV["USERS_TABLE"]},
        )
        yield dynamo


@pytest.fixture()
def dynamo_execution_stubber():
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    updated_item = copy.deepcopy(fixtures["events"]["get_item_execution.json"]["Item"])
    updated_item["status"]["S"] = "READY"
    with Stubber(dynamo) as stubber:
        stubber.add_response(
            "get_item",
            fixtures["events"]["get_item_execution.json"],
            {
                "Key": {
                    "target_account": {"S": "123456789012"},
                    "execution_id": {"S": "test-execution"},
                },
                "TableName": ENV["EXECUTIONS_TABLE"],
            },
        )
        stubber.add_response(
            "put_item",
            {
                "ConsumedCapacity": {
                    "CapacityUnits": 1,
                    "TableName": ENV["EXECUTIONS_TABLE"],
                }
            },
            {"Item": updated_item, "TableName": ENV["EXECUTIONS_TABLE"]},
        )
        yield dynamo


@pytest.fixture()
def dynamo_create_asset_stubber():
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    with Stubber(dynamo) as stubber:
        item = {
            "asset_id": {"S": "ma-cost-beta-dashboard"},
            "target_account": {"S": "123456789012"},
            "asset_type": {"S": "dashboard"},
            "source_asset_url": {"S": "dashboard-210987654321-x8eikds-latest"},
            "source_account": {"S": "210987654321"},
            "source_region": {"S": "us-east-1"},
            "owners": {"SS": ["admin-user@email.com", "AWS_SSO_CostGroup"]},
            "status": {"S": "unpublished"},
        }
        stubber.add_response(
            "put_item",
            {
                "ConsumedCapacity": {
                    "CapacityUnits": 1,
                    "TableName": ENV["ASSETS_TABLE"],
                }
            },
            {
                "Item": item,
                "TableName": ENV["ASSETS_TABLE"],
                "ConditionExpression": "attribute_not_exists(asset_id)",
            },
        )
        yield dynamo


@pytest.fixture()
def dynamo_asset_stubber():
    """
    generates an S3 stubber for the quicksights asset sample
    """
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    item = fixtures["events"]["get_item_asset.json"]["Item"]
    with Stubber(dynamo) as stubber:
        stubber.add_response(
            "get_item",
            fixtures["events"]["get_item_asset.json"],
            {
                "Key": {"asset_id": {"S": "ma-cost-beta-dashboard"}},
                "TableName": ENV["ASSETS_TABLE"],
            },
        )
        item["status"]["S"] = "published"
        stubber.add_response(
            "put_item",
            {
                "ConsumedCapacity": {
                    "CapacityUnits": 1,
                    "TableName": ENV["ASSETS_TABLE"],
                }
            },
            {"Item": item, "TableName": ENV["ASSETS_TABLE"]},
        )
        yield dynamo


@pytest.fixture()
def dynamo_portal_user_stubber():
    dynamo = botocore.session.get_session().create_client(
        "dynamodb", region_name="us-east-1"
    )
    with Stubber(dynamo) as stubber:
        stubber.add_response(
            "get_item",
            fixtures["events"]["get_item_admin_user.json"],
            {"Key": {"email": {"S": users["admin"]}}, "TableName": ENV["USERS_TABLE"]},
        )
        yield dynamo


def generate_streaming_body_response(body):
    encoded_message = json.dumps(body).encode()
    _stream = StreamingBody(io.BytesIO(encoded_message), len(encoded_message))
    return {"Body": _stream}


def generate_streaming_body_response_json(body):
    encoded_message = json.dumps(body).encode()
    _stream = StreamingBody(io.BytesIO(encoded_message), len(encoded_message))
    return {"Body": _stream}


def generate_streaming_body_response_csv(data, fieldnames=None):
    """
    Generates a streaming body response for CSV data.

    Args:
        data (list): List of dictionaries containing the CSV data
        fieldnames (list, optional): List of column headers. If None, will use keys from first row

    Returns:
        dict: Response containing StreamingBody object with CSV data
    """
    output = io.StringIO()

    # If fieldnames not provided, get them from the first row
    if fieldnames is None and data:
        fieldnames = list(data[0].keys())

    # Create CSV writer and write data
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(data)

    # Get the CSV content and encode it
    csv_content = output.getvalue().encode("utf-8")

    # Create streaming body
    _stream = StreamingBody(io.BytesIO(csv_content), len(csv_content))

    try:
        return {"Body": _stream}
    finally:
        output.close()


@pytest.fixture()
def qs_asset_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    qa_asset_response = generate_streaming_body_response_json(
        fixtures["definitions"]["working_analysis.json"]
    )
    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            qa_asset_response,
            {"Bucket": ENV["BUCKET"], "Key": ENV["KEY"]},
        )
        yield s3


@pytest.fixture()
def qs_asset_dq_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    qa_asset_response = generate_streaming_body_response_json(
        fixtures["definitions"]["data_quality_dashboard_definition.json"]
    )
    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            qa_asset_response,
            {"Bucket": ENV["BUCKET"], "Key": ENV["KEY"]},
        )
        yield s3


@pytest.fixture()
def ceo_qs_asset_highchart_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    qa_asset_response = generate_streaming_body_response_json(
        fixtures["definitions"]["ceo_dashboard_definition.json"]
    )
    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            qa_asset_response,
            {"Bucket": ENV["BUCKET"], "Key": ENV["KEY"]},
        )
        yield s3


@pytest.fixture()
def mock_success_get_embed_url_event():
    return fixtures["events"]["success_get_embed_url_event.json"]


@pytest.fixture()
def mock_success_get_asset_by_id_event():
    return fixtures["events"]["success_get_asset_by_id_event.json"]


@pytest.fixture()
def mock_raw_get_asset_by_id_response():
    return fixtures["definitions"]["raw_get_asset_by_id_response.json"]


@pytest.fixture()
def qs_asset_processed_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    qa_asset_processed_response = generate_streaming_body_response_json(
        fixtures["definitions"]["bi_asset_opensearch.json"]
    )
    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            qa_asset_processed_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_insights_report.json"},
        )
        yield s3


@pytest.fixture()
def csv_metadata_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    csv_sheet_response = fixtures["definitions"]["cost_sheets.csv"]
    csv_sheet_streaming_response = generate_streaming_body_response_csv(
        csv_sheet_response
    )

    with Stubber(s3) as stubber:
        # Add the response to the stubber
        stubber.add_response(
            "get_object",
            csv_sheet_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_sheets.csv"},
        )
        yield s3


@pytest.fixture()
def csv_overview_metadata_stubber():

    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    csv_overview_response = fixtures["definitions"]["cost_overview.csv"]
    csv_overview_streaming_response = generate_streaming_body_response_csv(
        csv_overview_response
    )

    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            csv_overview_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_overview.csv"},
        )
        yield s3


@pytest.fixture()
def csv_datasets_metadata_stubber():

    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    csv_overview_response = fixtures["definitions"]["cost_datasets.csv"]
    csv_overview_streaming_response = generate_streaming_body_response_csv(
        csv_overview_response
    )

    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            csv_overview_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_datasets.csv"},
        )
        yield s3


@pytest.fixture()
def csv_parameters_metadata_stubber():

    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    csv_overview_response = fixtures["definitions"]["cost_parameters.csv"]
    csv_overview_streaming_response = generate_streaming_body_response_csv(
        csv_overview_response
    )

    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            csv_overview_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_parameters.csv"},
        )
        yield s3


@pytest.fixture()
def csv_visualization_metadata_stubber():

    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    csv_overview_response = fixtures["definitions"]["cost_visualizations.csv"]
    csv_overview_streaming_response = generate_streaming_body_response_csv(
        csv_overview_response
    )

    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            csv_overview_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_visualizations.csv"},
        )
        yield s3


@pytest.fixture()
def create_s3_stub_paginator():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")

    # Sample response pages
    page1 = {
        "Contents": [
            {
                "Key": "ma_cost_dashboard/metadata/cost_datasets.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"abc123"',
                "Size": 123,
                "StorageClass": "STANDARD",
            },
            {
                "Key": "ma_cost_dashboard/metadata/cost_overview.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"def456"',
                "Size": 456,
                "StorageClass": "STANDARD",
            },
        ],
        "IsTruncated": True,
        "NextContinuationToken": "token123",
        "Name": "your-bucket-name",
        "Prefix": "ma_cost_dashboard/metadata/",
        "MaxKeys": 1000,
        "EncodingType": "url",
    }

    page2 = {
        "Contents": [
            {
                "Key": "ma_cost_dashboard/metadata/cost_parameters.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"ghi789"',
                "Size": 789,
                "StorageClass": "STANDARD",
            },
            {
                "Key": "ma_cost_dashboard/metadata/cost_sheets.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"ghi789"',
                "Size": 789,
                "StorageClass": "STANDARD",
            },
            {
                "Key": "ma_cost_dashboard/metadata/cost_visualizations.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"ghi789"',
                "Size": 789,
                "StorageClass": "STANDARD",
            },
            {
                "Key": "ma_cost_dashboard/metadata/testfile_1234.csv",
                "LastModified": "2024-01-01T00:00:00+00:00",
                "ETag": '"ghi789"',
                "Size": 789,
                "StorageClass": "STANDARD",
            },
        ],
        "IsTruncated": False,
        "Name": "your-bucket-name",
        "Prefix": "ma_cost_dashboard/metadata/",
        "MaxKeys": 1000,
        "EncodingType": "url",
    }

    # Expected parameters for the API call
    expected_params = {"Bucket": ENV["BUCKET"], "Prefix": "ma_cost_dashboard/metadata/"}
    expected_params_2 = {
        "Bucket": ENV["BUCKET"],
        "Prefix": "ma_cost_dashboard/metadata/",
        "ContinuationToken": "token123",
    }

    with Stubber(s3) as stubber:
        # Add the responses to the stubber
        stubber.add_response("list_objects_v2", page1, expected_params)
        stubber.add_response("list_objects_v2", page2, expected_params_2)

        yield s3


@pytest.fixture()
def create_dashboard_config_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    config_response = fixtures["definitions"]["cost_config.yaml"]
    config_streaming_response = generate_streaming_body_response(config_response)
    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            config_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "cost_config.yaml"},
        )
        yield s3


@pytest.fixture()
def changed_asset_metadata_file_list():
    changed_asset_metadata_file_list = [
        "dev/assets/cost_dashboard/config.yaml",
        "dev/assets/cost_dashboard/datasets.yaml",
        "dev/assets/transaction_dashboard/datasets.csv",
        "dev/datasets/transaction_dashboard/datasets.csv",
    ]
    return changed_asset_metadata_file_list


@pytest.fixture()
def manifest_pipes_payload():
    config_response = fixtures["events"]["manifest_file_sqs_payload.json"]
    return config_response


@pytest.fixture()
def qs_cost_business_metadata_asset():
    qa_asset_response = fixtures["definitions"]["bi_cost_asset_business_metadata.json"]
    return qa_asset_response


@pytest.fixture()
def qs_cost_operational_metadata_asset():
    qa_asset_response = fixtures["definitions"][
        "bi_cost_asset_operational_metadata.json"
    ]
    return qa_asset_response


@pytest.fixture()
def yaml_dataset_rls_cost_dataset_stubber():

    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    yaml_overview_response = cfg_fixtures["cost_dataset"]["rls.yaml"]
    yaml_overview_streaming_response = generate_streaming_body_response_json(
        yaml_overview_response
    )

    with Stubber(s3) as stubber:
        stubber.add_response(
            "get_object",
            yaml_overview_streaming_response,
            {"Bucket": ENV["BUCKET"], "Key": "rls.yaml"},
        )
        yield s3


@pytest.fixture()
def qs_client_create_dataset():
    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    with Stubber(qs_client) as stubber:
        create_dataset_response = {
            "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/test-dataset",
            "DataSetId": "test-dataset",
            "RequestId": "test-request-id",
            "Status": 200,
        }

        create_dataset_params = {
            "AwsAccountId": "123456789012",
            "DataSetId": "test-dataset",
            "Name": "Test Dataset",
            "PhysicalTableMap": {
                "test-table": {
                    "CustomSql": {
                        "DataSourceArn": "arn:aws:quicksight:us-east-1:123456789012:datasource/test-source",
                        "Name": "test-query",
                        "SqlQuery": "SELECT * FROM test_table",
                        "Columns": [
                            {"Name": "department", "Type": "STRING"},
                            {"Name": "cost", "Type": "DECIMAL"},
                        ],
                    }
                }
            },
            "LogicalTableMap": {
                "test-logical-table": {
                    "Alias": "test-alias",
                    "Source": {"PhysicalTableId": "test-table"},
                }
            },
            "ImportMode": "SPICE",
            "Permissions": [
                {
                    "Principal": "arn:aws:quicksight:us-east-1:123456789012:user/default/admin",
                    "Actions": [
                        "quicksight:UpdateDataSetPermissions",
                        "quicksight:DescribeDataSet",
                        "quicksight:DescribeDataSetPermissions",
                        "quicksight:PassDataSet",
                        "quicksight:DescribeIngestion",
                        "quicksight:ListIngestions",
                        "quicksight:UpdateDataSet",
                        "quicksight:DeleteDataSet",
                        "quicksight:CreateIngestion",
                        "quicksight:CancelIngestion",
                    ],
                }
            ],
            "RowLevelPermissionTagConfiguration": {
                "Status": "ENABLED",
                "TagRules": [
                    {
                        "TagKey": "Department",
                        "ColumnName": "department",
                        "TagValues": ["*"],
                    }
                ],
            },
        }

        stubber.add_response(
            "create_data_set", create_dataset_response, create_dataset_params
        )
        yield qs_client

@pytest.fixture()
def qs_client_create_dataset_s3():
    "pytest fixture to create a dataset specifically from S3 as a data source"

    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    with Stubber(qs_client) as stubber:
        create_dataset_response = {
            "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/test-dataset",
            "DataSetId": "test-dataset",
            "RequestId": "test-request-id",
            "Status": 200,
        }

    create_dataset_params = {
        "AwsAccountId": "123456789012",
        "DataSetId": "test-dataset",
        "Name": "Test Dataset",
        "PhysicalTableMap": {
            "test-s3-table": {
                "S3Source": {
                    "DataSourceArn": "arn:aws:quicksight:us-east-1:123456789012:datasource/test-source",
                    "UploadSettings": {
                        "Format": "CSV",
                        "StartFromRow": 1,
                        "ContainsHeader": True,
                        "TextQualifier": "DOUBLE_QUOTE",
                        "Delimiter": ","
                    },
                    "InputColumns": [
                        {"Name": "department", "Type": "STRING"},
                        {"Name": "cost", "Type": "DECIMAL"},
                    ],
                },
            },
        },
        "LogicalTableMap": {
            "test-logical-table": {
                "Alias": "test-alias",
                "Source": {"PhysicalTableId": "test-s3-table"},
            }
        },
        "ImportMode": "SPICE",
        "Permissions": [
            {
                "Principal": "arn:aws:quicksight:us-east-1:123456789012:user/default/admin",
                "Actions": [
                    "quicksight:UpdateDataSetPermissions",
                    "quicksight:DescribeDataSet",
                    "quicksight:DescribeDataSetPermissions",
                    "quicksight:PassDataSet",
                    "quicksight:DescribeIngestion",
                    "quicksight:ListIngestions",
                    "quicksight:UpdateDataSet",
                    "quicksight:DeleteDataSet",
                    "quicksight:CreateIngestion",
                    "quicksight:CancelIngestion",
                ],
            }
        ],
        "RowLevelPermissionTagConfiguration": {
            "Status": "ENABLED",
            "TagRules": [
                {
                    "TagKey": "Department",
                    "ColumnName": "department",
                    "TagValues": ["*"],
                }
            ],
        },
    }

    stubber.add_response(
        "create_data_set", create_dataset_response, create_dataset_params
    )
    yield qs_client

@pytest.fixture()
def create_dataset_payload() -> QSManagerPayload:
    """Fixture that returns a sample QSPayload object"""
    manager_payload = QSManagerPayload(
        resource="data_source",
        payload=QSPayload(
            id="cost_insight_report", account_id="123456", force_sync=True
        ),
    )
    return manager_payload

@pytest.fixture()
def create_dataset_payload_s3_source() -> QSManagerPayload:
    """Fixture that returns a sample QSPayload object"""
    manager_payload = QSManagerPayload(
        resource="data_source",
        payload=QSPayload(
            id="test_s3_csv_datasource", account_id="123456", force_sync=True
        ),
    )
    return manager_payload



@pytest.fixture
def s3_list_objects_stubber():
    """Creates a stubber for list_objects_v2 based on tests/cfg/ directory structure"""
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    with Stubber(s3) as stubber:
        # Walk through the tests/cfg directory to build the S3 response
        cfg_path = "tests/cfg"
        s3_objects = []

        for root, dirs, files in os.walk(cfg_path):
            for file in files:
                # Convert local path to S3 style path
                full_path = os.path.join(root, file)
                s3_key = full_path.replace("tests/", "")  # Remove 'tests/' prefix
                s3_key = s3_key.replace("\\", "/")  # Ensure forward slashes for S3
                s3_objects.append({"Key": s3_key})

        # Create the expected response
        list_objects_response = {"Contents": s3_objects, "IsTruncated": False}

        # Add the expected response to the stubber
        expected_params = {"Bucket": ENV["BUCKET"], "Prefix": "cfg"}

        stubber.add_response(
            "get_object",
            generate_streaming_body_response_json(cfg_fixtures["cfg"]["manifest.json"]),
            {"Bucket": ENV["BUCKET"], "Key": "cfg/manifest.json"},
        )

        stubber.add_response("list_objects_v2", list_objects_response, expected_params)
        dataset_rls_response = generate_streaming_body_response_json(
            cfg_fixtures["cost_dataset"]["rls.yaml"]
        )
        stubber.add_response(
            "get_object",
            dataset_rls_response,
            {"Bucket": ENV["BUCKET"], "Key": "cfg/datasets/cost_dataset/rls.yaml"},
        )
        stubber.add_client_error(
            "get_object",
            service_error_code="NoSuchKey",
            service_message="The specified key does not exist.",
            http_status_code=404,
            expected_params={
                "Bucket": ENV["BUCKET"],
                "Key": "cfg/datasets/test_s3_csv_datasource/rls.yaml",
            },
        )

        dataset_metadata_response = generate_streaming_body_response_json(
            cfg_fixtures["cost_dataset"]["metadata.yaml"]
        )
        stubber.add_response(
            "get_object",
            dataset_metadata_response,
            {"Bucket": ENV["BUCKET"], "Key": "cfg/datasets/cost_dataset/metadata.yaml"},
        )
        dataset_sql_response = generate_streaming_body_response_json(
            cfg_fixtures["cost_dataset"]["query.sql"]
        )
        stubber.add_response(
            "get_object",
            dataset_sql_response,
            {"Bucket": ENV["BUCKET"], "Key": "cfg/datasets/cost_dataset/query.sql"},
        )

        dataset_s3_source_response = generate_streaming_body_response_json(
            cfg_fixtures["test_s3_csv_datasource"]["metadata.yaml"]
        )

        stubber.add_response(
            "get_object",
            dataset_s3_source_response,
            {"Bucket": ENV["BUCKET"], "Key": "cfg/datasets/test_s3_csv_datasource/metadata.yaml"},
        )

        dataset_s3_source_manifest_response = generate_streaming_body_response_json(
            cfg_fixtures["test_s3_csv_datasource"]["s3_manifest.yaml"]
        )

        stubber.add_response(
            "get_object",
            dataset_s3_source_manifest_response,
            {"Bucket": ENV["BUCKET"], "Key": "cfg/datasets/test_s3_csv_datasource/s3_manifest.yaml"},
        )

        # Return stubber for use in tests
        yield s3


@pytest.fixture
def raw_workspace_s3_event():
    return fixtures["events"]["raw_workspace_s3_event.json"]


@pytest.fixture
def return_head_stubber():
    s3 = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    with Stubber(s3) as stubber:
        expected_date = datetime(2024, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        bucket = ENV["BUCKET"]
        file_key = ENV["KEY"]
        # Updated response for JSON file
        response = {
            "LastModified": expected_date,
            "ContentLength": 2048,
            "ETag": '"abc123def456"',
            "ContentType": "application/json",
            "Metadata": {
                "content-type": "application/json",
                "file-type": "configuration",
            },
        }
        stubber.add_response(
            "head_object",
            response,
            {"Bucket": bucket, "Key": file_key},
        )
        yield s3
