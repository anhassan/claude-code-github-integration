select
	calendar_date
	, fiscal_date
	, fiscal_year
	, fiscal_year_string
	, fiscal_quarter
	, fiscal_quarter_string
	, "month"
	, month_string
	, year_month
	, fiscal_year_string || '-' || fiscal_quarter_string as fiscal_year_quarter
	, case 
			when "month" > 3 then fiscal_year_string || '-0' || cast( "month" - 3 as varchar) || ' ' || month_string
			else fiscal_year_string || '-1' || cast( "month" - 1 as varchar) || ' ' || month_string
	  end fiscal_year_month
	, "view"
	, scenario
	, account_lvl_3 
	, account_lvl_2 
	, account_lvl_1 
	, account_lvl_0 
	, entity_lvl_2
	, grouping_1 
	, grouping_2 
	, location_name
	, value
from (
	select
		  calendar_date 
		, fiscal_date 
		, fiscal_year
		, 'FY' || substring( cast( fiscal_year as varchar ), 3, 2 ) as fiscal_year_string
		, fiscal_quarter 
		, format( 'Q%1$d', fiscal_quarter ) as fiscal_quarter_string
		, "month" 
		, format( '%1$tb', calendar_date ) as month_string
		, format( '%1$tY-%1$tm', calendar_date ) as year_month
		, "view" 
		, scenario 
		, account_lvl_3 
		, account_lvl_2 
		, account_lvl_1 
		, account_lvl_0 
		, entity_lvl_2
		, grouping_1 
		, grouping_2 
		, location_name 
		, sum( amount ) as value
	from
		finance_accounting_${env}.vw_cost_insights_report
	where
		processed_datetime = ( select max(processed_datetime) from finance_accounting_${env}.vw_cost_insights_report )
		and fiscal_year >= 2019
		and grouping_1 is not null
	group by
		  calendar_date 
		, fiscal_date 
		, fiscal_year 
		, fiscal_quarter 
		, "month" 
		, "view" 
		, scenario 
		, account_lvl_3 
		, account_lvl_2 
		, account_lvl_1 
		, account_lvl_0 
		, entity_lvl_2 
		, grouping_1
		, grouping_2
		, location_name
)