"""RefreshSchedule reconciliation: schedules removed/renamed in metadata must be
deleted from QuickSight, not left to keep firing.

Regression: converting a dataset from a single daily FULL ('daily_refresh') to
daily-incremental + weekly-full left the old 'daily_refresh' in place, so the
dataset kept doing a daily full re-ingest alongside the incremental.
"""


class FakeLogger:
    def info(self, *a, **k):
        pass

    def warning(self, *a, **k):
        pass

    def error(self, *a, **k):
        pass


class FakeScheduleClient:
    class exceptions:
        class ResourceExistsException(Exception):
            pass

        class ResourceNotFoundException(Exception):
            pass

        class LimitExceededException(Exception):
            pass

    def __init__(self, existing_ids, list_raises=False, create_limit_raises=()):
        self.existing = [{"ScheduleId": sid} for sid in existing_ids]
        self.list_raises = list_raises
        # ScheduleIds whose creation QuickSight rejects with
        # LimitExceededException (e.g. HOURLY while other schedules exist).
        self.create_limit_raises = set(create_limit_raises)
        self.created = []
        self.deleted = []
        self.ops = []

    def create_refresh_schedule(self, **kw):
        sid = kw["Schedule"]["ScheduleId"]
        if sid in self.create_limit_raises:
            raise self.exceptions.LimitExceededException(
                "can create hourly refresh schedule only if no other schedules exist"
            )
        self.created.append(sid)
        self.ops.append(("create", sid))
        return {"Status": 200}

    def update_refresh_schedule(self, **kw):
        return {"Status": 200}

    def list_refresh_schedules(self, **kw):
        if self.list_raises:
            raise self.exceptions.ResourceNotFoundException("no dataset")
        return {"RefreshSchedules": self.existing}

    def delete_refresh_schedule(self, **kw):
        self.deleted.append(kw["ScheduleId"])
        self.ops.append(("delete", kw["ScheduleId"]))
        return {"Status": 200}


def _sched(sid, interval="DAILY", rtype="FULL_REFRESH"):
    return {
        "ScheduleId": sid,
        "RefreshType": rtype,
        "ScheduleFrequency": {"Interval": interval, "Timezone": "Canada/Eastern", "TimeOfTheDay": "07:10"},
    }


def _event(schedules):
    return {
        "resource": "refresh_schedule",
        "payload": {
            "id": "rmv_position",
            "account_id": "200967598245",
            "config": {"schedules": schedules},
        },
    }


def _run(existing_ids, declared, list_raises=False, create_limit_raises=()):
    from quicksight_mgr.resources import RefreshSchedule

    qs = FakeScheduleClient(
        existing_ids, list_raises=list_raises, create_limit_raises=create_limit_raises
    )
    RefreshSchedule(FakeLogger(), qs, _event(declared)).sync()
    return qs


def test_prunes_schedule_not_in_metadata():
    qs = _run(
        existing_ids=["daily_refresh", "rmv_position_daily_incremental", "rmv_position_weekly_full"],
        declared=[_sched("rmv_position_daily_incremental", rtype="INCREMENTAL_REFRESH"), _sched("rmv_position_weekly_full", "WEEKLY")],
    )
    assert qs.deleted == ["daily_refresh"]


def test_keeps_declared_schedules():
    qs = _run(
        existing_ids=["rmv_position_daily_incremental", "rmv_position_weekly_full"],
        declared=[_sched("rmv_position_daily_incremental", rtype="INCREMENTAL_REFRESH"), _sched("rmv_position_weekly_full", "WEEKLY")],
    )
    assert qs.deleted == []


def test_no_existing_schedules_to_prune():
    qs = _run(
        existing_ids=["rmv_position_daily_incremental"],
        declared=[_sched("rmv_position_daily_incremental", rtype="INCREMENTAL_REFRESH")],
    )
    assert qs.deleted == []


def test_list_not_found_is_safe():
    qs = _run(
        existing_ids=[],
        declared=[_sched("rmv_position_daily_incremental", rtype="INCREMENTAL_REFRESH")],
        list_raises=True,
    )
    assert qs.deleted == []


def test_preserves_manual_console_schedules():
    """Schedules added by hand in the QuickSight console get auto-generated
    UUID ScheduleIds (e.g. prod finsights_perf_tf_dept carries a manual
    incremental schedule '078efa2f-...'). Those are operator overrides, not
    publisher state, so pruning must leave them alone — only stale
    publisher-declared (readable, metadata-style) ids may be reconciled away.
    """
    qs = _run(
        existing_ids=[
            "daily_refresh",  # stale publisher schedule (renamed in metadata)
            "078efa2f-5454-4bfc-b50f-808b91008baa",  # manual console schedule
            "rmv_position_weekly_full",
        ],
        declared=[_sched("rmv_position_weekly_full", "WEEKLY")],
    )
    assert qs.deleted == ["daily_refresh"]


def test_preserves_uuid_schedule_when_it_is_the_only_extra():
    qs = _run(
        existing_ids=[
            "rmv_position_daily_incremental",
            "0B6C223E-0B69-4576-B50D-80AC4C22FAD8",  # manual, uppercase UUID
        ],
        declared=[_sched("rmv_position_daily_incremental", rtype="INCREMENTAL_REFRESH")],
    )
    assert qs.deleted == []


def test_prunes_stale_schedules_before_creating_declared():
    """QuickSight enforces schedule limits at CreateRefreshSchedule time (an
    HOURLY schedule must be the dataset's only schedule), so a stale publisher
    schedule must be deleted BEFORE the declared one is created or the create
    is rejected with LimitExceededException mid-sync.
    """
    qs = _run(
        existing_ids=["daily_refresh"],  # stale publisher schedule
        declared=[_sched("hourly_refresh", "HOURLY")],
    )
    assert qs.ops == [("delete", "daily_refresh"), ("create", "hourly_refresh")]


def test_manual_schedule_conflict_skips_declared_creation():
    """Live dev failure (holdings_base): a manually added console schedule
    survives pruning (by design), then CreateRefreshSchedule of the declared
    HOURLY schedule is rejected because HOURLY must be the sole schedule.
    The manual override wins: log and continue instead of failing the
    dataset pipeline.
    """
    qs = _run(
        existing_ids=["815a957c-c3c7-48ba-9978-19a3d4bdf1f0"],  # manual console schedule
        declared=[_sched("hourly_refresh", "HOURLY")],
        create_limit_raises={"hourly_refresh"},
    )
    assert qs.deleted == []
    assert qs.created == []


def test_limit_exceeded_without_manual_schedules_still_raises():
    """If QuickSight rejects a declared schedule and there is no manual
    schedule to blame, that's a real metadata error — surface it."""
    import pytest

    with pytest.raises(FakeScheduleClient.exceptions.LimitExceededException):
        _run(
            existing_ids=[],
            declared=[
                _sched("hourly_refresh", "HOURLY"),
                _sched("rmv_position_weekly_full", "WEEKLY"),
            ],
            create_limit_raises={"hourly_refresh"},
        )
