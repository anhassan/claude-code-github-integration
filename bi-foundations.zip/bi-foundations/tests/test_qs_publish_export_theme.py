import qs_publish_export_lambda.main as export_main


class FakeS3:
    def __init__(self):
        self.put_calls = []
        self.delete_calls = []

    def put_object(self, **kwargs):
        self.put_calls.append(kwargs)

    def delete_object(self, **kwargs):
        self.delete_calls.append(kwargs)


class FakeQS:
    def __init__(self, theme=None, raise_on_describe=False):
        self._theme = theme or {"Theme": {"Name": "T"}}
        self._raise = raise_on_describe
        self.describe_calls = []

    def describe_theme(self, **kwargs):
        self.describe_calls.append(kwargs)
        if self._raise:
            raise Exception("boom")
        return self._theme


def _event():
    return {"account": "200967598245", "detail": {"versionNumber": 7}}


def _patch(monkeypatch, s3, qs):
    monkeypatch.setattr(export_main, "s3_client", s3)
    monkeypatch.setattr(export_main, "qs_client", qs)
    monkeypatch.setattr(export_main, "BUCKET_NAME", "test-bucket")


def test_custom_theme_writes_version_and_latest(monkeypatch):
    s3, qs = FakeS3(), FakeQS(theme={"Theme": {"Name": "Talent_Design_1"}})
    _patch(monkeypatch, s3, qs)
    dashboard_resp = {
        "Name": "MasterTurnoverDashboard/DEVELOP",
        "ThemeArn": "arn:aws:quicksight:us-east-1:200967598245:theme/cf6457fc",
    }

    export_main.export_theme_from_dashboard(_event(), dashboard_resp)

    keys = sorted(c["Key"] for c in s3.put_calls)
    assert keys == [
        "MasterTurnoverDashboard/DEVELOP/V7/theme_definition.json",
        "MasterTurnoverDashboard/DEVELOP/latest/theme_definition.json",
    ]
    assert s3.delete_calls == []
    assert len(qs.describe_calls) == 1


def test_managed_classic_deletes_latest_and_does_not_write(monkeypatch):
    s3, qs = FakeS3(), FakeQS()
    _patch(monkeypatch, s3, qs)
    dashboard_resp = {
        "Name": "MasterTurnoverDashboard/DEVELOP",
        "ThemeArn": "arn:aws:quicksight::aws:theme/CLASSIC",
    }

    export_main.export_theme_from_dashboard(_event(), dashboard_resp)

    assert s3.put_calls == []
    assert qs.describe_calls == []
    assert s3.delete_calls == [
        {
            "Bucket": "test-bucket",
            "Key": "MasterTurnoverDashboard/DEVELOP/latest/theme_definition.json",
        }
    ]


def test_no_theme_arn_deletes_latest(monkeypatch):
    s3, qs = FakeS3(), FakeQS()
    _patch(monkeypatch, s3, qs)
    dashboard_resp = {"Name": "MasterTurnoverDashboard/DEVELOP"}

    export_main.export_theme_from_dashboard(_event(), dashboard_resp)

    assert s3.put_calls == []
    assert s3.delete_calls == [
        {
            "Bucket": "test-bucket",
            "Key": "MasterTurnoverDashboard/DEVELOP/latest/theme_definition.json",
        }
    ]


def test_describe_theme_failure_does_not_write_or_delete(monkeypatch):
    s3, qs = FakeS3(), FakeQS(raise_on_describe=True)
    _patch(monkeypatch, s3, qs)
    dashboard_resp = {
        "Name": "MasterTurnoverDashboard/DEVELOP",
        "ThemeArn": "arn:aws:quicksight:us-east-1:200967598245:theme/cf6457fc",
    }

    export_main.export_theme_from_dashboard(_event(), dashboard_resp)

    assert s3.put_calls == []
    assert s3.delete_calls == []
