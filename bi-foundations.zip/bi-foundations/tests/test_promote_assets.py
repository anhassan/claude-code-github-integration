# tests/test_promote_assets.py
import json
import textwrap
from pathlib import Path

from scripts.promote_assets import compute_promotion


def _seed_repo(tmp_path):
    # source env folder with assets + datasets
    dev = tmp_path / "dev"
    (dev / "assets" / "ae_transactions").mkdir(parents=True)
    (dev / "assets" / "ae_transactions" / "config.yaml").write_text("id_prefix: ae_transactions\n")
    for slug, name in [("ae_pos", "ae_pos"), ("rmv_position", "rmv_position"), ("unused", "unused")]:
        d = dev / "datasets" / slug
        d.mkdir(parents=True)
        (d / "metadata.yaml").write_text(f"name: {name}\nworkspaces: [bif-risk]\ncolumns:\n  a: STRING\n")
    # a dashboard definition referencing two of the three datasets
    definition = {
        "Definition": {
            "DataSetIdentifierDeclarations": [
                {"Identifier": "P", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/ae_pos"},
                {"Identifier": "R", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/rmv_position"},
            ]
        }
    }
    return dev, definition


def test_compute_promotion_resolves_closure_and_excludes_unused(tmp_path):
    dev, definition = _seed_repo(tmp_path)
    result = compute_promotion(
        source_env_dir=dev,
        target_env_dir=tmp_path / "uat",
        dashboard_slug="ae_transactions",
        definition=definition,
        env="dev",
    )
    assert result["dataset_slugs"] == ["ae_pos", "rmv_position"]
    assert result["unresolved"] == []
    # copy plan covers the asset folder + the two dataset folders only
    rel = sorted(p["rel"] for p in result["copies"])
    assert rel == ["assets/ae_transactions", "datasets/ae_pos", "datasets/rmv_position"]


def test_compute_promotion_flags_unresolved(tmp_path):
    dev, _ = _seed_repo(tmp_path)
    definition = {
        "Definition": {
            "DataSetIdentifierDeclarations": [
                {"Identifier": "X", "DataSetArn": "arn:aws:quicksight:us-east-1:840529182937:dataset/ghost-uuid"},
            ]
        }
    }
    result = compute_promotion(
        source_env_dir=dev,
        target_env_dir=tmp_path / "uat",
        dashboard_slug="ae_transactions",
        definition=definition,
        env="dev",
    )
    assert result["unresolved"] == [("ghost-uuid", "840529182937")]


def test_compute_promotion_dedupes_and_sorts(tmp_path):
    dev, _ = _seed_repo(tmp_path)
    definition = {
        "Definition": {
            "DataSetIdentifierDeclarations": [
                {"Identifier": "R", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/rmv_position"},
                {"Identifier": "P", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/ae_pos"},
                {"Identifier": "R2", "DataSetArn": "arn:aws:quicksight:us-east-1:200967598245:dataset/rmv_position"},
            ]
        }
    }
    result = compute_promotion(
        source_env_dir=dev, target_env_dir=tmp_path / "uat",
        dashboard_slug="ae_transactions", definition=definition, env="dev",
    )
    assert result["dataset_slugs"] == ["ae_pos", "rmv_position"]


def test_compute_promotion_follows_join_dependencies(tmp_path):
    dev, definition = _seed_repo(tmp_path)
    # ae_pos joins fx_rate; fx_rate joins calendar (transitive); none in the def
    (dev / "datasets" / "ae_pos" / "metadata.yaml").write_text(
        "name: ae_pos\nworkspaces: [bif-risk]\ncolumns:\n  a: STRING\n"
        "joins:\n  - right_dataset: fx_rate\n    type: LEFT\n"
        "    on_clause:\n      - left: a\n        right: b\n"
    )
    for slug, joins in [("fx_rate", "joins:\n  - right_dataset: calendar\n    type: LEFT\n    on_clause:\n      - left: a\n        right: b\n"), ("calendar", "")]:
        d = dev / "datasets" / slug
        d.mkdir(parents=True, exist_ok=True)
        (d / "metadata.yaml").write_text(
            f"name: {slug}\nworkspaces: [bif-risk]\ncolumns:\n  a: STRING\n{joins}"
        )
    result = compute_promotion(
        source_env_dir=dev,
        target_env_dir=tmp_path / "uat",
        dashboard_slug="ae_transactions",
        definition=definition,
        env="dev",
    )
    assert result["dataset_slugs"] == ["ae_pos", "calendar", "fx_rate", "rmv_position"]
    assert result["unresolved"] == []
    rel = sorted(p["rel"] for p in result["copies"])
    assert "datasets/fx_rate" in rel and "datasets/calendar" in rel


def test_compute_promotion_flags_unresolved_join_target(tmp_path):
    dev, definition = _seed_repo(tmp_path)
    (dev / "datasets" / "ae_pos" / "metadata.yaml").write_text(
        "name: ae_pos\nworkspaces: [bif-risk]\ncolumns:\n  a: STRING\n"
        "joins:\n  - right_dataset: ghost_dataset\n    type: LEFT\n"
        "    on_clause:\n      - left: a\n        right: b\n"
    )
    result = compute_promotion(
        source_env_dir=dev,
        target_env_dir=tmp_path / "uat",
        dashboard_slug="ae_transactions",
        definition=definition,
        env="dev",
    )
    assert ("ghost_dataset", "join") in result["unresolved"]
    assert "ghost_dataset" not in result["dataset_slugs"]
