# tests/test_verify_risk_promotion.py
from scripts.verify_risk_promotion import (
    asset_id,
    ACCOUNT_BY_ENV,
    classify_status,
    classify_error,
)


def test_asset_id_format():
    assert asset_id("ae_transactions", "dev") == "ae_transactions-bif-risk-dev"
    assert asset_id("ae_transactions", "uat") == "ae_transactions-bif-risk-uat"
    assert asset_id("ae_transactions", "qa") == "ae_transactions-bif-risk-qa"
    assert asset_id("ae_transactions", "prod") == "ae_transactions-bif-risk-prod"


def test_account_map_matches_pipeline():
    assert ACCOUNT_BY_ENV == {
        "dev": "200967598245",
        "qa": "885014163466",
        "uat": "207662059077",
        "prod": "679601897237",
    }


def test_classify_status_terminal_ok():
    assert classify_status("CREATION_SUCCESSFUL") == (0, "OK")
    assert classify_status("UPDATE_SUCCESSFUL") == (0, "OK")


def test_classify_status_not_ready():
    assert classify_status("CREATION_IN_PROGRESS")[0] == 2
    assert classify_status("CREATION_FAILED")[0] == 2


def test_classify_error_missing_vs_other():
    assert classify_error("ResourceNotFoundException") == (1, "MISSING")
    assert classify_error("AccessDeniedException")[0] == 2
