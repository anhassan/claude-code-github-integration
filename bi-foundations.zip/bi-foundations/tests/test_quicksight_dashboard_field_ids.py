from src.quicksight_mgr.resources import Dashboard


class FakeLogger:
    def __init__(self):
        self.messages = []

    def info(self, message):
        self.messages.append(("info", message))

    def warning(self, message):
        self.messages.append(("warning", message))


class FakeQuickSightClient:
    def __init__(self, logical_table_map):
        self.logical_table_map = logical_table_map
        self.calls = []

    def describe_data_set(self, **kwargs):
        self.calls.append(kwargs)
        return {
            "DataSet": {
                "LogicalTableMap": self.logical_table_map,
            }
        }


def make_dashboard(qs_client, definition):
    event = {
        "resource": "dashboard",
        "payload": {
            "id": "test-dashboard",
            "definition": {
                "Definition": definition,
                "DashboardPublishOptions": {},
            },
            "config": {
                "id_prefix": "dash",
                "workspace": "workspace",
                "display_name": "Test Dashboard",
            },
        },
    }
    return Dashboard(FakeLogger(), qs_client, event)


def make_definition():
    country_field_id = "sales-dev.country.1.100"
    profit_field_id = "123e4567-e89b-12d3-a456-426614174000.2.200"
    return {
        "DataSetIdentifierDeclarations": [
            {
                "Identifier": "sales",
                "DataSetArn": (
                    "arn:aws:quicksight:us-east-1:200967598245:dataset/sales_ds"
                ),
            }
        ],
        "Sheets": [
            {
                "SheetId": "sheet",
                "Visuals": [
                    {
                        "TableVisual": {
                            "VisualId": "visual",
                            "ChartConfiguration": {
                                "FieldWells": {
                                    "TableAggregatedFieldWells": {
                                        "GroupBy": [
                                            {
                                                "CategoricalDimensionField": {
                                                    "FieldId": country_field_id,
                                                    "Column": {
                                                        "DataSetIdentifier": "sales",
                                                        "ColumnName": "country",
                                                    },
                                                }
                                            }
                                        ],
                                        "Values": [
                                            {
                                                "NumericalMeasureField": {
                                                    "FieldId": profit_field_id,
                                                    "Column": {
                                                        "DataSetIdentifier": "sales",
                                                        "ColumnName": "profit",
                                                    },
                                                    "AggregationFunction": {
                                                        "SimpleNumericalAggregation": "SUM"
                                                    },
                                                }
                                            }
                                        ],
                                    }
                                },
                                "FieldOptions": {
                                    "SelectedFieldOptions": [
                                        {"FieldId": country_field_id},
                                        {"FieldId": profit_field_id},
                                    ],
                                    "Order": [country_field_id, profit_field_id],
                                },
                                "SortConfiguration": {
                                    "RowSort": [
                                        {
                                            "FieldSort": {
                                                "FieldId": country_field_id,
                                                "Direction": "ASC",
                                            }
                                        }
                                    ]
                                },
                            },
                            "ConditionalFormatting": {
                                "ConditionalFormattingOptions": [
                                    {
                                        "Cell": {
                                            "FieldId": country_field_id,
                                            "TextFormat": {},
                                        }
                                    }
                                ]
                            },
                        }
                    }
                ],
            }
        ],
    }


def test_prep_dashboard_inputs_rewrites_field_ids_to_target_logical_table():
    definition = make_definition()
    qs_client = FakeQuickSightClient(
        {"sales-prod": {"Alias": "sales", "Source": {"PhysicalTableId": "sales-prod"}}}
    )

    payload = make_dashboard(qs_client, definition).prep_dashboard_inputs(None)

    rewritten_definition = payload["Definition"]
    table = rewritten_definition["Sheets"][0]["Visuals"][0]["TableVisual"]
    chart_config = table["ChartConfiguration"]
    field_wells = chart_config["FieldWells"]["TableAggregatedFieldWells"]

    assert rewritten_definition["DataSetIdentifierDeclarations"][0]["DataSetArn"] == (
        "arn:aws:quicksight:us-east-1:123456789012:dataset/sales_ds"
    )
    assert field_wells["GroupBy"][0]["CategoricalDimensionField"]["FieldId"] == (
        "sales-prod.country.1.100"
    )
    assert field_wells["Values"][0]["NumericalMeasureField"]["FieldId"] == (
        "sales-prod.profit.2.200"
    )
    assert chart_config["FieldOptions"]["SelectedFieldOptions"] == [
        {"FieldId": "sales-prod.country.1.100"},
        {"FieldId": "sales-prod.profit.2.200"},
    ]
    assert chart_config["FieldOptions"]["Order"] == [
        "sales-prod.country.1.100",
        "sales-prod.profit.2.200",
    ]
    assert chart_config["SortConfiguration"]["RowSort"][0]["FieldSort"]["FieldId"] == (
        "sales-prod.country.1.100"
    )
    assert table["ConditionalFormatting"]["ConditionalFormattingOptions"][0]["Cell"][
        "FieldId"
    ] == "sales-prod.country.1.100"
    assert qs_client.calls == [
        {"DataSetId": "sales_ds", "AwsAccountId": "123456789012"}
    ]


def test_prep_dashboard_inputs_skips_rewrite_for_multi_table_datasets():
    definition = make_definition()
    qs_client = FakeQuickSightClient(
        {
            "sales-prod-a": {"Alias": "sales_a"},
            "sales-prod-b": {"Alias": "sales_b"},
        }
    )

    payload = make_dashboard(qs_client, definition).prep_dashboard_inputs(None)

    field = payload["Definition"]["Sheets"][0]["Visuals"][0]["TableVisual"][
        "ChartConfiguration"
    ]["FieldWells"]["TableAggregatedFieldWells"]["GroupBy"][0][
        "CategoricalDimensionField"
    ]
    assert field["FieldId"] == "sales-dev.country.1.100"


def test_prep_dashboard_inputs_preserves_field_id_for_calc_field_columns():
    # profit is declared as a dashboard-level CalculatedField, so its
    # source-side FieldId (UUID + 2 numeric segments, no embedded column
    # name) must be preserved. Rewriting it to <lt>.<column>.<idx>.<ts>
    # makes QS resolve the field as a dataset column and apply numeric
    # formatting to the calc field's string output.
    definition = make_definition()
    definition["CalculatedFields"] = [
        {
            "DataSetIdentifier": "sales",
            "Name": "profit",
            "Expression": "concat(toString({revenue} - {cost}), ' USD')",
        }
    ]

    qs_client = FakeQuickSightClient(
        {"sales-prod": {"Alias": "sales", "Source": {"PhysicalTableId": "sales-prod"}}}
    )

    payload = make_dashboard(qs_client, definition).prep_dashboard_inputs(None)
    chart_config = payload["Definition"]["Sheets"][0]["Visuals"][0]["TableVisual"][
        "ChartConfiguration"
    ]
    field_wells = chart_config["FieldWells"]["TableAggregatedFieldWells"]

    # country is a dataset column — still gets rewritten
    assert field_wells["GroupBy"][0]["CategoricalDimensionField"]["FieldId"] == (
        "sales-prod.country.1.100"
    )
    # profit is a calc field — source FieldId preserved
    assert field_wells["Values"][0]["NumericalMeasureField"]["FieldId"] == (
        "123e4567-e89b-12d3-a456-426614174000.2.200"
    )
    # FieldOptions, sort, and ConditionalFormatting must agree with the
    # per-field decision (profit kept, country rewritten)
    assert chart_config["FieldOptions"]["Order"] == [
        "sales-prod.country.1.100",
        "123e4567-e89b-12d3-a456-426614174000.2.200",
    ]
