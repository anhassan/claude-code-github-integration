from unittest.mock import MagicMock, patch


def test_user_lambda_clients_are_memoized():
    from portal_user_lambda.config import clients as user_clients

    prior = user_clients._clients
    user_clients._clients = None
    try:
        with patch("portal_user_lambda.config.clients.boto3") as mock_boto3:
            first = user_clients.get_clients()
            second = user_clients.get_clients()

        assert first is second
        assert mock_boto3.client.call_count == 1  # dynamodb, built once
    finally:
        user_clients._clients = prior


def test_assets_lambda_clients_are_memoized():
    from portal_assets_lambda.config import clients as assets_clients

    prior = assets_clients._clients
    assets_clients._clients = None
    try:
        with (
            patch("portal_assets_lambda.config.clients.boto3") as mock_boto3,
            patch(
                "portal_assets_lambda.config.clients._get_opensearch_client",
                return_value=MagicMock(),
            ) as mock_opensearch,
        ):
            first = assets_clients.get_clients()
            second = assets_clients.get_clients()

        assert first is second
        assert mock_boto3.client.call_count == 3  # quicksight, dynamodb, s3
        assert mock_opensearch.call_count == 1
    finally:
        assets_clients._clients = prior


def test_entitlements_lambda_clients_are_memoized():
    from portal_entitlements_lambda.config import clients as ent_clients

    prior = ent_clients._clients
    ent_clients._clients = None
    try:
        with patch("portal_entitlements_lambda.config.clients.boto3") as mock_boto3:
            first = ent_clients.get_clients()
            second = ent_clients.get_clients()

        assert first is second
        assert mock_boto3.client.call_count == 2  # dynamodb, secretsmanager
    finally:
        ent_clients._clients = prior
