import logging
import json
from unittest.mock import MagicMock
import botocore.session
import pytest
from botocore.stub import ANY, Stubber

logger = logging.getLogger()


def _stub_qs_for_join(describes_by_slug):
    """Returns a MagicMock qs_client that responds to describe_data_set with
    the given mapping of {slug: {"Name": ..., "OutputColumns": [{"Name": ...}, ...]}}.
    Used by tests covering create_joined_logical_table_map.
    """
    qs_client = MagicMock()

    def fake_describe(**kwargs):
        slug = kwargs.get("DataSetId")
        if slug not in describes_by_slug:
            raise KeyError(f"No describe stub for {slug}")
        return {"DataSet": describes_by_slug[slug]}

    qs_client.describe_data_set.side_effect = fake_describe
    return qs_client

from src.quicksight_mgr.cfg import BIFoundationsConfigS3
from src.qs_dataset_lambda.common import (
    get_dataset_id,
    read_yaml_from_s3,
    remap_rls_payload_to_dynamodb,
    get_workspace_id,
)
from src.quicksight_mgr.resources import Dataset
from dataclasses import asdict
from common.utils.validate import (
    __validate_dataset_metadata_file,
    validate_dataset_metadata_file,
    validate_s3_manifest_file,
)


def test_full_rls_prep_workflow(yaml_dataset_rls_cost_dataset_stubber, env):
    s3_key = "bif-ma/dev/datasets/cost_insights_report/rls.yaml"
    dataset_id = get_dataset_id(s3_key)
    assert dataset_id == "cost_insights_report"
    workspace_id = get_workspace_id(s3_key)
    assert workspace_id == "bif-ma"
    rls_payload = read_yaml_from_s3(
        s3_bucket=env["BUCKET"],
        s3_key="rls.yaml",
        s3_client=yaml_dataset_rls_cost_dataset_stubber,
    )
    final_payload = remap_rls_payload_to_dynamodb(rls_payload, dataset_id, workspace_id)
    assert final_payload["dataset_id"] == "cost_insights_report"
    assert final_payload["rls_mappings"][0][0]["tag_type"] == "department"
    assert (
        final_payload["rls_mappings"][0][0]["authorized_values"]
        == "technology_cost,software_cost"
    )
    assert final_payload["rls_mappings"][1][0]["tag_type"] == "department"
    assert final_payload["rls_by_email_mappings"] == [
        {
            "emails": [
                "ed@cppib.com",
                "ruby@cppib.com",
            ],
            "rule_groups": [
                {
                    "authorized_values": "Finance,CIO",
                    "column_name": "entity_lvl_2",
                },
                {
                    "authorized_values": "IO,TFM",
                    "column_name": "entity_lvl_3",
                },
            ],
        },
        {
            "emails": [
                "a@cppib.com",
                "ruby@cppib.com",
            ],
            "rule_groups": [
                {
                    "authorized_values": "Finance",
                    "column_name": "entity_lvl_2",
                },
                {
                    "authorized_values": "123",
                    "column_name": "cost_center",
                },
            ],
        },
    ]


def test_prepping_dataset_publish_s3(
    qs_client_create_dataset,
    s3_list_objects_stubber,
    env,
    create_dataset_payload,
    create_dataset_payload_s3_source,
    raw_workspace_s3_event,
):
    cfg = BIFoundationsConfigS3(
        logger=logger,
        s3_client=s3_list_objects_stubber,
        bucket=env["BUCKET"],
        s3_event=raw_workspace_s3_event,
    )
    assert cfg.config["datasets"] == {
        "cost_dataset": {"metadata.yaml": None, "query.sql": None, "rls.yaml": None},
        'test_s3_csv_datasource': {'metadata.yaml': None,"rls.yaml": None, 's3_manifest.yaml': None,}
    }
    rls_results = cfg.parse_dataset_rls_requests()
    metadata_results = cfg.parse_dataset_metadata_requests()
    s3_manifest_results = cfg.parse_dataset_s3_manifest_requests(metadata_results)
    create_dataset_payload.payload.rls = rls_results["cost_dataset"]
    create_dataset_payload.payload.config = metadata_results["cost_dataset"]
    create_dataset_payload = asdict(create_dataset_payload)
    results = Dataset(logger, qs_client_create_dataset, create_dataset_payload)
    tag_rules, tag_configurations = results.prepare_rls_configuration_payload(
        rls_config=rls_results["cost_dataset"]
    )
    create_dataset_payload_s3_source.payload.config = metadata_results["test_s3_csv_datasource"]
    create_dataset_payload_s3_source.payload.s3_manifest = s3_manifest_results[
        "test_s3_csv_datasource"
    ]
    create_dataset_payload_s3_source_payload = asdict(create_dataset_payload_s3_source)
    s3_results = Dataset(logger, qs_client_create_dataset, create_dataset_payload_s3_source_payload)
    print (s3_results)

    s3_inputs = s3_results.prep_inputs()
    s3_source = next(iter(s3_inputs["PhysicalTableMap"].values()))["S3Source"]
    logical_table = next(iter(s3_inputs["LogicalTableMap"].values()))

    assert s3_manifest_results["test_s3_csv_datasource"]["upload_settings"] == {
        "format": "CSV",
        "start_from_row": 1,
        "contains_header": True,
        "text_qualifier": "SINGLE_QUOTE",
        "delimiter": ",",
    }
    assert s3_source["UploadSettings"] == {
        "Format": "CSV",
        "StartFromRow": 1,
        "ContainsHeader": True,
        "TextQualifier": "SINGLE_QUOTE",
        "Delimiter": ",",
    }
    assert all(column["Type"] == "STRING" for column in s3_source["InputColumns"])
    assert {
        transform["CastColumnTypeOperation"]["ColumnName"]: transform["CastColumnTypeOperation"]
        for transform in logical_table["DataTransforms"]
    }["user_count"] == {
        "ColumnName": "user_count",
        "NewColumnType": "DECIMAL",
        "SubType": "FIXED",
    }



    assert tag_rules == [
        {
            "TagKey": "cost_insight_report-department",
            "ColumnName": "asset_type",
            "TagMultiValueDelimiter": ",",
            "MatchAllValue": "*",
        },
        {
            "TagKey": "cost_insight_report-sub_department",
            "ColumnName": "cost_type",
            "TagMultiValueDelimiter": ",",
            "MatchAllValue": "*",
        },
        {
            "TagKey": "cost_insight_report-geo",
            "ColumnName": "region",
            "TagMultiValueDelimiter": ",",
            "MatchAllValue": "*",
        },
    ]
    assert tag_configurations == [
        ["cost_insight_report-department"],  # First rule has only department
        [
            "cost_insight_report-department",
            "cost_insight_report-sub_department",
            "cost_insight_report-geo",
        ],
        # Second rule has all three
        ["cost_insight_report-department", "cost_insight_report-sub_department"],
        # Third rule has department and sub_department
    ]


def test_sync_s3_managed_datasource_creates_manifest_datasource_and_dataset(env):
    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    s3_client = botocore.session.get_session().create_client("s3", region_name="us-east-1")

    event = {
        "resource": "dataset",
        "payload": {
            "id": "pmst",
            "account_id": env["ACCOUNT_ID"],
            "config": {
                "name": "PMST",
                "import_mode": "SPICE",
                "workspaces": ["bif-risk"],
                "data_source_id": "pmst-s3-source",
                "dataset_source": "S3",
                "columns": {
                    "business_date": "DATETIME",
                    "Department": "STRING",
                    "PV": "DECIMAL.FLOAT",
                },
                "physical_table_map_id": "PMST-dev",
                "folders": ["bif-risk-dev"],
            },
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "data_uris": [
                    {
                        "key": "daily_production/CMF/EPM Dashboard/QuickSight/Public_Markets_Stress_Tests.csv",
                        "bucket": "cppib-awb-prod-ir-shared",
                    }
                ],
                "manifest_location": {
                    "key": "bif-risk/s3-manifests/pmst/manifest.json",
                },
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }

    managed_manifest = {
        "fileLocations": [
            {
                "URIs": [
                    "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/Public_Markets_Stress_Tests.csv"
                ]
            }
        ],
        "globalUploadSettings": {
            "containsHeader": "true",
            "delimiter": ",",
            "format": "CSV",
            "startFromRow": 1,
            "textqualifier": "'",
        },
    }

    data_source_parameters = {
        "S3Parameters": {
            "ManifestFileLocation": {
                "Bucket": env["FOUNDATION_BUCKET"],
                "Key": "bif-risk/s3-manifests/pmst/manifest.json",
            }
        }
    }

    expected_dataset_params = {
        "AwsAccountId": env["ACCOUNT_ID"],
        "DataSetId": "pmst",
        "Name": "PMST",
        "PhysicalTableMap": {
            "PMST-dev": {
                "S3Source": {
                    "DataSourceArn": (
                        "arn:aws:quicksight:us-east-1:123456789012:"
                        "datasource/pmst-s3-source"
                    ),
                    "InputColumns": [
                        {"Name": "business_date", "Type": "STRING"},
                        {"Name": "Department", "Type": "STRING"},
                        {"Name": "PV", "Type": "STRING"},
                    ],
                    "UploadSettings": {
                        "Format": "CSV",
                        "StartFromRow": 1,
                        "ContainsHeader": True,
                        "TextQualifier": "SINGLE_QUOTE",
                        "Delimiter": ",",
                    },
                }
            }
        },
        "ImportMode": "SPICE",
        "LogicalTableMap": {
            "logicaltable": {
                "Alias": "PMST-dev",
                "DataTransforms": [
                    {
                        "CastColumnTypeOperation": {
                            "ColumnName": "business_date",
                            "NewColumnType": "DATETIME",
                        }
                    },
                    {
                        "CastColumnTypeOperation": {
                            "ColumnName": "Department",
                            "NewColumnType": "STRING",
                        }
                    },
                    {
                        "CastColumnTypeOperation": {
                            "ColumnName": "PV",
                            "NewColumnType": "DECIMAL",
                            "SubType": "FLOAT",
                        }
                    },
                ],
                "Source": {"PhysicalTableId": "PMST-dev"},
            }
        },
    }

    with Stubber(s3_client) as s3_stubber, Stubber(qs_client) as qs_stubber:
        s3_stubber.add_response(
            "put_object",
            {"ETag": '"manifest-etag"'},
            {
                "Bucket": env["FOUNDATION_BUCKET"],
                "Key": "bif-risk/s3-manifests/pmst/manifest.json",
                "Body": json.dumps(managed_manifest, sort_keys=True),
                "ContentType": "application/json",
            },
        )
        qs_stubber.add_client_error(
            "describe_data_source",
            service_error_code="ResourceNotFoundException",
            service_message="DataSource not found",
            http_status_code=404,
            expected_params={
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
            },
        )
        qs_stubber.add_response(
            "create_data_source",
            {
                "Arn": (
                    "arn:aws:quicksight:us-east-1:123456789012:"
                    "datasource/pmst-s3-source"
                ),
                "DataSourceId": "pmst-s3-source",
                "CreationStatus": "CREATION_SUCCESSFUL",
                "RequestId": "request-id",
                "Status": 200,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
                "Name": "pmst-s3-source",
                "Type": "S3",
                "DataSourceParameters": data_source_parameters,
            },
        )
        qs_stubber.add_response(
            "create_data_set",
            {
                "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/pmst",
                "DataSetId": "pmst",
                "IngestionArn": (
                    "arn:aws:quicksight:us-east-1:123456789012:"
                    "dataset/pmst/ingestion/ingestion-id"
                ),
                "IngestionId": "ingestion-id",
                "RequestId": "request-id",
                "Status": 200,
            },
            expected_dataset_params,
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst",
                "MemberType": "DATASET",
            },
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst-s3-source",
                "MemberType": "DATASOURCE",
            },
        )

        Dataset(logger, qs_client, event, s3_client).sync()


def test_sync_s3_managed_datasource_updates_existing_datasource_and_dataset(env):
    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    s3_client = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    data_source_arn = (
        "arn:aws:quicksight:us-east-1:123456789012:datasource/pmst-s3-source"
    )

    event = {
        "resource": "dataset",
        "payload": {
            "id": "pmst",
            "account_id": env["ACCOUNT_ID"],
            "config": {
                "name": "PMST",
                "import_mode": "SPICE",
                "workspaces": ["bif-risk"],
                "data_source_id": "pmst-s3-source",
                "dataset_source": "S3",
                "columns": {
                    "business_date": "DATETIME",
                    "Department": "STRING",
                    "PV": "DECIMAL.FLOAT",
                },
                "physical_table_map_id": "PMST-dev",
                "folders": ["bif-risk-dev"],
            },
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "data_uris": [
                    {
                        "key": "daily_production/CMF/EPM Dashboard/QuickSight/Public_Markets_Stress_Tests.csv",
                        "bucket": "cppib-awb-prod-ir-shared",
                    }
                ],
                "manifest_location": {
                    "key": "bif-risk/s3-manifests/pmst/manifest.json",
                },
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }
    expected_dataset_params = {
        "AwsAccountId": env["ACCOUNT_ID"],
        "DataSetId": "pmst",
        "Name": "PMST",
        "PhysicalTableMap": ANY,
        "ImportMode": "SPICE",
        "LogicalTableMap": ANY,
    }

    with Stubber(s3_client) as s3_stubber, Stubber(qs_client) as qs_stubber:
        s3_stubber.add_response(
            "put_object",
            {"ETag": '"manifest-etag"'},
            {
                "Bucket": env["FOUNDATION_BUCKET"],
                "Key": "bif-risk/s3-manifests/pmst/manifest.json",
                "Body": ANY,
                "ContentType": "application/json",
            },
        )
        qs_stubber.add_response(
            "describe_data_source",
            {
                "DataSource": {
                    "Arn": data_source_arn,
                    "DataSourceId": "pmst-s3-source",
                    "Name": "pmst-s3-source",
                    "Type": "S3",
                    "Status": "CREATION_SUCCESSFUL",
                },
                "RequestId": "request-id",
                "Status": 200,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
            },
        )
        qs_stubber.add_response(
            "update_data_source",
            {"RequestId": "request-id", "Status": 200},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
                "Name": "pmst-s3-source",
                "DataSourceParameters": {
                    "S3Parameters": {
                        "ManifestFileLocation": {
                            "Bucket": env["FOUNDATION_BUCKET"],
                            "Key": "bif-risk/s3-manifests/pmst/manifest.json",
                        }
                    }
                },
            },
        )
        qs_stubber.add_client_error(
            "create_data_set",
            service_error_code="ResourceExistsException",
            service_message="DataSet already exists",
            http_status_code=409,
            expected_params=expected_dataset_params,
        )
        qs_stubber.add_response(
            "update_data_set",
            {
                "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/pmst",
                "DataSetId": "pmst",
                "IngestionArn": (
                    "arn:aws:quicksight:us-east-1:123456789012:"
                    "dataset/pmst/ingestion/ingestion-id"
                ),
                "IngestionId": "ingestion-id",
                "RequestId": "request-id",
                "Status": 200,
            },
            expected_dataset_params,
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst",
                "MemberType": "DATASET",
            },
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst-s3-source",
                "MemberType": "DATASOURCE",
            },
        )

        Dataset(logger, qs_client, event, s3_client).sync()


def test_sync_s3_new_prep_dataset_skips_legacy_update_when_columns_match(env):
    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    s3_client = botocore.session.get_session().create_client("s3", region_name="us-east-1")
    data_source_arn = (
        "arn:aws:quicksight:us-east-1:123456789012:datasource/pmst-s3-source"
    )

    event = {
        "resource": "dataset",
        "payload": {
            "id": "pmst",
            "account_id": env["ACCOUNT_ID"],
            "config": {
                "name": "PMST",
                "import_mode": "SPICE",
                "workspaces": ["bif-risk"],
                "data_source_id": "pmst-s3-source",
                "dataset_source": "S3",
                "columns": {
                    "business_date": "DATETIME",
                    "Department": "STRING",
                    "PV": "DECIMAL.FLOAT",
                },
                "physical_table_map_id": "PMST-dev",
                "folders": ["bif-risk-dev"],
            },
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "data_uris": [
                    {
                        "key": "daily_production/CMF/EPM Dashboard/QuickSight/Public_Markets_Stress_Tests.csv",
                        "bucket": "cppib-awb-prod-ir-shared",
                    }
                ],
                "manifest_location": {
                    "key": "bif-risk/s3-manifests/pmst/manifest.json",
                },
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }
    expected_dataset_params = {
        "AwsAccountId": env["ACCOUNT_ID"],
        "DataSetId": "pmst",
        "Name": "PMST",
        "PhysicalTableMap": ANY,
        "ImportMode": "SPICE",
        "LogicalTableMap": ANY,
    }

    with Stubber(s3_client) as s3_stubber, Stubber(qs_client) as qs_stubber:
        s3_stubber.add_response(
            "put_object",
            {"ETag": '"manifest-etag"'},
            {
                "Bucket": env["FOUNDATION_BUCKET"],
                "Key": "bif-risk/s3-manifests/pmst/manifest.json",
                "Body": ANY,
                "ContentType": "application/json",
            },
        )
        qs_stubber.add_response(
            "describe_data_source",
            {
                "DataSource": {
                    "Arn": data_source_arn,
                    "DataSourceId": "pmst-s3-source",
                    "Name": "pmst-s3-source",
                    "Type": "S3",
                    "Status": "CREATION_SUCCESSFUL",
                },
                "RequestId": "request-id",
                "Status": 200,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
            },
        )
        qs_stubber.add_response(
            "update_data_source",
            {"RequestId": "request-id", "Status": 200},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSourceId": "pmst-s3-source",
                "Name": "pmst-s3-source",
                "DataSourceParameters": {
                    "S3Parameters": {
                        "ManifestFileLocation": {
                            "Bucket": env["FOUNDATION_BUCKET"],
                            "Key": "bif-risk/s3-manifests/pmst/manifest.json",
                        }
                    }
                },
            },
        )
        qs_stubber.add_client_error(
            "create_data_set",
            service_error_code="ResourceExistsException",
            service_message="DataSet already exists",
            http_status_code=409,
            expected_params=expected_dataset_params,
        )
        qs_stubber.add_client_error(
            "update_data_set",
            service_error_code="InvalidParameterValueException",
            service_message=(
                "Dataset created in new data preparation experience cannot be "
                "updated to legacy data preparation experience"
            ),
            http_status_code=400,
            expected_params=expected_dataset_params,
        )
        qs_stubber.add_response(
            "describe_data_set",
            {
                "DataSet": {
                    "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/pmst",
                    "DataSetId": "pmst",
                    "Name": "PMST",
                    "ImportMode": "SPICE",
                    "PhysicalTableMap": {},
                    "DataPrepConfiguration": {
                        "SourceTableMap": {
                            "source": {"PhysicalTableId": "PMST-dev"}
                        },
                        "TransformStepMap": {},
                        "DestinationTableMap": {},
                    },
                    "OutputColumns": [
                        {"Name": "PV", "Type": "DECIMAL", "SubType": "FLOAT"},
                        {"Name": "Department", "Type": "STRING"},
                        {"Name": "business_date", "Type": "DATETIME"},
                    ],
                },
                "RequestId": "request-id",
                "Status": 200,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSetId": "pmst",
            },
        )
        qs_stubber.add_response(
            "create_ingestion",
            {
                "Arn": (
                    "arn:aws:quicksight:us-east-1:123456789012:"
                    "dataset/pmst/ingestion/ingestion-id"
                ),
                "IngestionId": "ingestion-id",
                "IngestionStatus": "INITIALIZED",
                "RequestId": "request-id",
                "Status": 201,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSetId": "pmst",
                "IngestionId": ANY,
                "IngestionType": "FULL_REFRESH",
            },
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst",
                "MemberType": "DATASET",
            },
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "pmst-s3-source",
                "MemberType": "DATASOURCE",
            },
        )

        Dataset(logger, qs_client, event, s3_client).sync()


def test_s3_manifest_builder_supports_uri_prefixes():
    event = {
        "resource": "dataset",
        "payload": {
            "id": "pmst",
            "account_id": "123456789012",
            "config": {"dataset_source": "S3"},
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "data_uri_prefixes": [{"key": "prefix/", "bucket": "bucket"}],
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 2,
                    "contains_header": True,
                    "text_qualifier": "DOUBLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }

    manifest = Dataset(logger, None, event).build_quicksight_s3_manifest()

    assert manifest["fileLocations"] == [{"URIPrefixes": ["s3://bucket/prefix/"]}]
    assert manifest["globalUploadSettings"]["startFromRow"] == 2


def test_s3_manifest_validation_requires_location_for_managed_datasource():
    errors = validate_s3_manifest_file(
        {
            "data_uris": [{"key": "path/file.csv", "bucket": "bucket"}],
            "upload_settings": {
                "format": "CSV",
                "start_from_row": 1,
                "contains_header": True,
                "text_qualifier": "SINGLE_QUOTE",
                "delimiter": ",",
            },
        },
        "s3_manifest",
    )

    assert any("manifest_location" in error for error in errors)


def test_dataset_metadata_rejects_name_with_disallowed_chars():
    errors = validate_dataset_metadata_file(
        {
            "name": "EPM Dashboard",
            "import_mode": "SPICE",
            "workspaces": ["bif-risk"],
            "columns": {"business_date": "DATETIME"},
        },
        "metadata",
    )

    assert any(
        "EPM Dashboard" in error and "[A-Za-z0-9_-]" in error for error in errors
    )


def test_dataset_metadata_accepts_name_with_underscores_and_hyphens():
    errors = validate_dataset_metadata_file(
        {
            "name": "EPM_Supplementary-data",
            "import_mode": "SPICE",
            "workspaces": ["bif-risk"],
            "columns": {"business_date": "DATETIME"},
        },
        "metadata",
    )

    assert not any("[A-Za-z0-9_-]" in error for error in errors)


def test_dataset_metadata_rejects_bad_joins_block():
    cases = [
        ({"joins": "nope"}, "joins must be a list"),
        ({"joins": [{}]}, "right_dataset is required"),
        ({"joins": [{"right_dataset": "fx_rate"}]}, ".on_clause is required"),
        ({"joins": [{"right_dataset": "fx_rate", "type": "FULL", "on_clause": [{"left": "a", "right": "b"}]}]},
         "type 'FULL' must be one of"),
        ({"joins": [{"right_dataset": "bad slug", "on_clause": [{"left": "a", "right": "b"}]}]},
         "must match"),
        ({"joins": [{"right_dataset": "fx_rate", "on_clause": [{"left": "a"}]}]},
         "right is required"),
        ({"joins": [{"right_dataset": "fx_rate", "on_clause": [{"left": "a", "right": "b", "op": "~="}]}]},
         "op '~=' must be one of"),
    ]
    for extra, expected_fragment in cases:
        base = {
            "name": "vol_greeks",
            "import_mode": "SPICE",
            "workspaces": ["bif-risk"],
            "columns": {"M_Z_RPT_DTE": {"type": "DATETIME", "format": "yyyy-MM-dd"}},
        }
        base.update(extra)
        errors = validate_dataset_metadata_file(base, "metadata")
        assert any(expected_fragment in e for e in errors), (
            f"Expected fragment {expected_fragment!r} in errors for case {extra!r}, got {errors}"
        )


def test_dataset_metadata_accepts_valid_joins_block():
    errors = validate_dataset_metadata_file(
        {
            "name": "vol_greeks",
            "import_mode": "SPICE",
            "workspaces": ["bif-risk"],
            "columns": {"M_Z_RPT_DTE": {"type": "DATETIME", "format": "yyyy-MM-dd"}},
            "joins": [
                {
                    "right_dataset": "fx_rate",
                    "type": "LEFT",
                    "on_clause": [{"left": "M_Z_RPT_DTE", "right": "Date Parsed"}],
                }
            ],
        },
        "metadata",
    )
    assert not any("joins" in e for e in errors)


def test_dataset_join_emits_logical_table_map_with_join_instruction():
    """Joined dataset publisher output: LogicalTableMap has the primary
    PhysicalTable wrapper, a sibling-dataset wrapper (Source.DataSetArn),
    and a root Intermediate Table whose Source is a JoinInstruction."""
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "vol_greeks",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                }
            },
            "config": {
                "name": "vol_greeks",
                "import_mode": "SPICE",
                "physical_table_map_id": "vol-greeks-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/foundations-quicksight-managed-s3",
                "dataset_source": "S3",
                "columns": {
                    "M_Z_RPT_DTE": {"type": "DATETIME", "format": "yyyy-MM-dd"},
                    "QUANTITY": "DECIMAL.FLOAT",
                },
                "joins": [
                    {
                        "right_dataset": "fx_rate",
                        "type": "LEFT",
                        "on_clause": [{"left": "M_Z_RPT_DTE", "right": "Date Parsed"}],
                    }
                ],
            },
        },
    }
    qs_client = _stub_qs_for_join({
        "fx_rate": {
            "Name": "FX_Rate",
            "OutputColumns": [
                {"Name": "Date Parsed", "Type": "DATETIME"},
                {"Name": "mid_val", "Type": "DECIMAL"},
            ],
        }
    })
    ds = Dataset(logger, qs_client, payload)
    inputs = ds.prep_inputs()
    ltm = inputs["LogicalTableMap"]

    primary = ltm["vol-greeks-dev"]
    assert primary["Source"] == {"PhysicalTableId": "vol-greeks-dev"}

    joined = ltm["joined-fx-rate"]
    arn = joined["Source"]["DataSetArn"]
    assert arn.startswith("arn:aws:quicksight:us-east-1:")
    assert arn.endswith(":dataset/fx_rate")

    intermediate = ltm["intermediate"]
    join_instr = intermediate["Source"]["JoinInstruction"]
    assert join_instr["LeftOperand"] == "vol-greeks-dev"
    assert join_instr["RightOperand"] == "joined-fx-rate"
    assert join_instr["Type"] == "LEFT"
    assert join_instr["OnClause"] == "{M_Z_RPT_DTE} = {Date Parsed}"


def test_dataset_join_emits_custom_op_in_on_clause():
    """Non-equality join op (e.g. >=) flows through to the emitted
    JoinInstruction.OnClause."""
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "vol_greeks",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                }
            },
            "config": {
                "name": "vol_greeks",
                "import_mode": "SPICE",
                "physical_table_map_id": "vol-greeks-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/foundations-quicksight-managed-s3",
                "dataset_source": "S3",
                "columns": {"M_Z_RPT_DTE": {"type": "DATETIME", "format": "yyyy-MM-dd"}},
                "joins": [
                    {
                        "right_dataset": "fx_rate",
                        "type": "INNER",
                        "on_clause": [
                            {"left": "M_Z_RPT_DTE", "right": "Date Parsed", "op": ">="},
                            {"left": "currency", "right": "ccy"},
                        ],
                    }
                ],
            },
        },
    }
    qs_client = _stub_qs_for_join({
        "fx_rate": {
            "Name": "FX_Rate",
            "OutputColumns": [
                {"Name": "Date Parsed", "Type": "DATETIME"},
                {"Name": "ccy", "Type": "STRING"},
            ],
        }
    })
    ds = Dataset(logger, qs_client, payload)
    inputs = ds.prep_inputs()
    join_instr = inputs["LogicalTableMap"]["intermediate"]["Source"]["JoinInstruction"]
    assert join_instr["Type"] == "INNER"
    assert join_instr["OnClause"] == (
        "{M_Z_RPT_DTE} >= {Date Parsed} AND {currency} = {ccy}"
    )


def test_dataset_join_renames_right_columns_on_collision():
    """When a right dataset column collides with a primary column name,
    the publisher emits a RenameColumnOperation on the right LT renaming
    `col` -> `col[RightName]`, rewrites the OnClause to use the renamed
    name, and adds a ProjectOperation on the intermediate that lists all
    final column names (primary + non-colliding right + renamed right).

    This matches the canonical QuickSight UI pattern (also documented on
    AWS re:Post) for handling ALIAS_NAME_CONFLICT.
    """
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "beta_ar",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {},
            "config": {
                "name": "Beta_AR",
                "import_mode": "SPICE",
                "physical_table_map_id": "Beta-AR-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/fabric_catalog_dev",
                "sql_query": "SELECT 1",
                "columns": {
                    "hierarchy_node": "STRING",
                    "business_date": "DATETIME",
                    "active_vol_10yr": "DECIMAL.FLOAT",
                },
                "joins": [
                    {
                        "right_dataset": "thresholds",
                        "type": "LEFT",
                        "on_clause": [{"left": "hierarchy_node", "right": "hierarchy_node"}],
                    }
                ],
            },
        },
    }
    qs_client = _stub_qs_for_join({
        "thresholds": {
            "Name": "Thresholds",
            "OutputColumns": [
                {"Name": "hierarchy_node", "Type": "STRING"},
                {"Name": "AR_low", "Type": "DECIMAL"},
                {"Name": "AR-up", "Type": "DECIMAL"},
            ],
        }
    })
    ds = Dataset(logger, qs_client, payload)
    inputs = ds.prep_inputs()
    ltm = inputs["LogicalTableMap"]

    right_lt = ltm["joined-thresholds"]
    assert right_lt["Alias"] == "Thresholds"
    assert right_lt["DataTransforms"] == [
        {"RenameColumnOperation": {
            "ColumnName": "hierarchy_node",
            "NewColumnName": "hierarchy_node[Thresholds]",
        }}
    ]

    intermediate = ltm["intermediate"]
    join_instr = intermediate["Source"]["JoinInstruction"]
    assert join_instr["OnClause"] == "{hierarchy_node} = {hierarchy_node[Thresholds]}"

    project = intermediate["DataTransforms"][0]["ProjectOperation"]
    assert project["ProjectedColumns"] == [
        "hierarchy_node",
        "business_date",
        "active_vol_10yr",
        "hierarchy_node[Thresholds]",
        "AR_low",
        "AR-up",
    ]


def test_dataset_join_no_rename_when_no_collision():
    """When a right dataset has no column-name collisions, the right LT
    has no DataTransforms (no rename needed), but the final intermediate
    still gets a ProjectOperation listing all final columns."""
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "vol_greeks",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                }
            },
            "config": {
                "name": "vol_greeks",
                "import_mode": "SPICE",
                "physical_table_map_id": "vol-greeks-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/foundations-quicksight-managed-s3",
                "dataset_source": "S3",
                "columns": {
                    "M_Z_RPT_DTE": {"type": "DATETIME", "format": "yyyy-MM-dd"},
                    "QUANTITY": "DECIMAL.FLOAT",
                },
                "joins": [
                    {
                        "right_dataset": "fx_rate",
                        "type": "LEFT",
                        "on_clause": [{"left": "M_Z_RPT_DTE", "right": "Date Parsed"}],
                    }
                ],
            },
        },
    }
    qs_client = _stub_qs_for_join({
        "fx_rate": {
            "Name": "FX_Rate",
            "OutputColumns": [
                {"Name": "Date Parsed", "Type": "DATETIME"},
                {"Name": "mid_val", "Type": "DECIMAL"},
            ],
        }
    })
    ds = Dataset(logger, qs_client, payload)
    inputs = ds.prep_inputs()
    ltm = inputs["LogicalTableMap"]

    right_lt = ltm["joined-fx-rate"]
    assert "DataTransforms" not in right_lt

    intermediate = ltm["intermediate"]
    project = intermediate["DataTransforms"][0]["ProjectOperation"]
    assert project["ProjectedColumns"] == [
        "M_Z_RPT_DTE",
        "QUANTITY",
        "Date Parsed",
        "mid_val",
    ]


def test_dataset_join_chains_multiple_joins_with_collisions():
    """Multiple joins chain via intermediate-{idx} LT ids. Each join's
    collision check is against the cumulative column set, so a right_2
    column that collides with right_1's renamed column also gets renamed."""
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "opr_vol_var",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {},
            "config": {
                "name": "OPR_VOL_VAR",
                "import_mode": "SPICE",
                "physical_table_map_id": "OPR-VOL-VAR-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/fabric_catalog_dev",
                "sql_query": "SELECT 1",
                "columns": {
                    "node": "STRING",
                    "raw_node_name": "STRING",
                    "business_date": "DATETIME",
                    "pv": "DECIMAL.FLOAT",
                },
                "joins": [
                    {
                        "right_dataset": "opr_ip_metrics",
                        "type": "LEFT",
                        "on_clause": [
                            {"left": "business_date", "right": "business_date"},
                            {"left": "raw_node_name", "right": "raw_node_name"},
                        ],
                    },
                    {
                        "right_dataset": "beta_ar",
                        "type": "LEFT",
                        "on_clause": [
                            {"left": "business_date", "right": "business_date"},
                            {"left": "node", "right": "hierarchy_node"},
                        ],
                    },
                ],
            },
        },
    }
    qs_client = _stub_qs_for_join({
        "opr_ip_metrics": {
            "Name": "OPR_IP_Metrics",
            "OutputColumns": [
                {"Name": "node", "Type": "STRING"},
                {"Name": "raw_node_name", "Type": "STRING"},
                {"Name": "business_date", "Type": "DATETIME"},
                {"Name": "ip_vol", "Type": "DECIMAL"},
            ],
        },
        "beta_ar": {
            "Name": "Beta_AR",
            "OutputColumns": [
                {"Name": "hierarchy_node", "Type": "STRING"},
                {"Name": "business_date", "Type": "DATETIME"},
                {"Name": "active_vol_10yr", "Type": "DECIMAL"},
            ],
        },
    })
    ds = Dataset(logger, qs_client, payload)
    inputs = ds.prep_inputs()
    ltm = inputs["LogicalTableMap"]

    # First join: opr_ip_metrics — node/raw_node_name/business_date collide.
    right_1 = ltm["joined-opr-ip-metrics"]
    rename_pairs_1 = {
        op["RenameColumnOperation"]["ColumnName"]: op["RenameColumnOperation"]["NewColumnName"]
        for op in right_1["DataTransforms"]
    }
    assert rename_pairs_1 == {
        "node": "node[OPR_IP_Metrics]",
        "raw_node_name": "raw_node_name[OPR_IP_Metrics]",
        "business_date": "business_date[OPR_IP_Metrics]",
    }

    intermediate_0 = ltm["intermediate-0"]
    assert "DataTransforms" not in intermediate_0  # ProjectOperation only on FINAL
    join_instr_0 = intermediate_0["Source"]["JoinInstruction"]
    assert join_instr_0["OnClause"] == (
        "{business_date} = {business_date[OPR_IP_Metrics]} "
        "AND {raw_node_name} = {raw_node_name[OPR_IP_Metrics]}"
    )

    # Second join: beta_ar — hierarchy_node is unique but business_date collides
    # with the LEFT (primary's business_date — opr_ip_metrics's was renamed).
    right_2 = ltm["joined-beta-ar"]
    rename_pairs_2 = {
        op["RenameColumnOperation"]["ColumnName"]: op["RenameColumnOperation"]["NewColumnName"]
        for op in right_2["DataTransforms"]
    }
    assert rename_pairs_2 == {"business_date": "business_date[Beta_AR]"}

    intermediate_1 = ltm["intermediate-1"]
    join_instr_1 = intermediate_1["Source"]["JoinInstruction"]
    assert join_instr_1["LeftOperand"] == "intermediate-0"
    assert join_instr_1["RightOperand"] == "joined-beta-ar"
    assert join_instr_1["OnClause"] == (
        "{business_date} = {business_date[Beta_AR]} AND {node} = {hierarchy_node}"
    )

    # Final intermediate has ProjectOperation listing all columns.
    project = intermediate_1["DataTransforms"][0]["ProjectOperation"]
    assert project["ProjectedColumns"] == [
        "node",
        "raw_node_name",
        "business_date",
        "pv",
        "node[OPR_IP_Metrics]",
        "raw_node_name[OPR_IP_Metrics]",
        "business_date[OPR_IP_Metrics]",
        "ip_vol",
        "hierarchy_node",
        "business_date[Beta_AR]",
        "active_vol_10yr",
    ]


def test_s3_metadata_validation_requires_spice():
    errors = validate_dataset_metadata_file(
        {
            "name": "PMST",
            "import_mode": "DIRECT_QUERY",
            "workspaces": ["bif-risk"],
            "dataset_source": "S3",
            "columns": {"business_date": "DATETIME"},
        },
        "metadata",
    )

    assert any("S3 datasets must use import_mode: SPICE" in error for error in errors)


def test_s3_metadata_validation_requires_sibling_manifest(tmp_path):
    dataset_dir = tmp_path / "bif-risk" / "dev" / "datasets" / "pmst"
    dataset_dir.mkdir(parents=True)
    (dataset_dir / "metadata.yaml").write_text(
        "\n".join(
            [
                "name: PMST",
                "import_mode: SPICE",
                "workspaces:",
                "  - bif-risk",
                "dataset_source: S3",
                "columns:",
                "  business_date: DATETIME",
            ]
        ),
        encoding="utf-8",
    )

    errors = [
        error
        for error_group in __validate_dataset_metadata_file(str(tmp_path / "bif-risk"))
        for error in error_group
    ]

    assert any("requires sibling s3_manifest.yaml" in error for error in errors)


def test_s3_manifest_validation_rejects_literal_bucket_and_bad_key():
    errors = validate_s3_manifest_file(
        {
            "data_uris": [{"key": "path/file.csv", "bucket": "bucket"}],
            "manifest_location": {
                "bucket": "foundation-quicksight-123456789012-dev",
                "key": "wrong/s3-manifests/pmst/manifest.json",
            },
            "upload_settings": {
                "format": "CSV",
                "start_from_row": 1,
                "contains_header": True,
                "text_qualifier": "SINGLE_QUOTE",
                "delimiter": ",",
            },
        },
        "s3_manifest",
        workspace="bif-risk",
        dataset="pmst",
    )

    assert any("manifest_location.bucket is not allowed" in error for error in errors)
    assert any("bif-risk/s3-manifests/pmst/manifest.json" in error for error in errors)


def test_s3_manifest_validation_rejects_raw_uri_string_in_data_uris():
    errors = validate_s3_manifest_file(
        {
            "data_uris": ["s3://bucket/path/file.csv"],
            "manifest_location": {
                "key": "bif-risk/s3-manifests/pmst/manifest.json",
            },
            "upload_settings": {
                "format": "CSV",
                "start_from_row": 1,
                "contains_header": True,
                "text_qualifier": "SINGLE_QUOTE",
                "delimiter": ",",
            },
        },
        "s3_manifest",
        workspace="bif-risk",
        dataset="pmst",
    )

    assert any(
        "must be a mapping with required 'key' and optional 'bucket'" in error
        for error in errors
    )


def test_s3_manifest_builder_defaults_data_uri_bucket_to_dropbox(monkeypatch):
    monkeypatch.setenv("DROPBOX_BUCKET", "bi-foundations-dropbox-200967598245-dev")

    event = {
        "resource": "dataset",
        "payload": {
            "id": "cmf_betas",
            "account_id": "200967598245",
            "config": {"dataset_source": "S3"},
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "data_uris": [
                    {"key": "bif-risk/file-uploads/cmf_betas/data.csv"},
                ],
                "manifest_location": {
                    "key": "bif-risk/s3-manifests/cmf_betas/manifest.json",
                },
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "DOUBLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }

    manifest = Dataset(logger, None, event).build_quicksight_s3_manifest()

    assert manifest["fileLocations"] == [
        {
            "URIs": [
                "s3://bi-foundations-dropbox-200967598245-dev/bif-risk/file-uploads/cmf_betas/data.csv"
            ]
        }
    ]


def test_s3_manifest_validation_rejects_missing_upload_settings_and_locations():
    errors = validate_s3_manifest_file(
        {
            "manifest_location": {
                "key": "bif-risk/s3-manifests/pmst/manifest.json",
            },
        },
        "s3_manifest",
        workspace="bif-risk",
        dataset="pmst",
    )

    assert any("upload_settings.format" in error for error in errors)
    assert any(
        "manifest_location is only valid when data_uris or data_uri_prefixes" in error
        for error in errors
    )


def make_cfg_for_parser(get_s3_path):
    cfg = BIFoundationsConfigS3.__new__(BIFoundationsConfigS3)
    cfg.logger = logger
    cfg.bucket = "bi-foundations-dev"
    cfg.prefix = "bif-risk"
    cfg.changed_folders = set()
    cfg._config = {"datasets": {"pmst": {}, "cost_dataset": {}}}
    cfg.get_s3_path = get_s3_path
    return cfg


def test_managed_s3_metadata_does_not_default_to_fabric_datasource():
    def get_s3_path(key):
        if key == "bif-risk/datasets/pmst/metadata.yaml":
            return {
                "name": "PMST",
                "import_mode": "SPICE",
                "force_sync": True,
                "workspaces": ["bif-risk"],
                "dataset_source": "S3",
                "data_source_id": "pmst-s3-source",
                "columns": {"business_date": "DATETIME"},
            }
        raise AssertionError(f"Unexpected S3 read: {key}")

    cfg = make_cfg_for_parser(get_s3_path)
    cfg._config = {"datasets": {"pmst": {}}}

    metadata_results = cfg.parse_dataset_metadata_requests()

    assert metadata_results["pmst"]["data_source_id"] == "pmst-s3-source"
    assert "data_source_arn" not in metadata_results["pmst"]


def test_legacy_s3_without_data_source_arn_fails_clearly():
    event = {
        "resource": "dataset",
        "payload": {
            "id": "legacy_s3",
            "account_id": "123456789012",
            "config": {
                "name": "legacy_s3",
                "import_mode": "SPICE",
                "dataset_source": "S3",
                "columns": {"business_date": "DATETIME"},
                "physical_table_map_id": "legacy-s3-dev",
                "folders": ["bif-risk-dev"],
            },
            "rls": [],
            "cls": [],
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                },
            },
        },
    }

    with pytest.raises(ValueError, match="requires either managed"):
        Dataset(logger, None, event).sync()


def test_parse_s3_manifest_non_s3_dataset_missing_manifest_is_quiet():
    def get_s3_path(key):
        raise AssertionError(f"Non-S3 dataset should not read manifest: {key}")

    cfg = make_cfg_for_parser(get_s3_path)

    s3_manifest_results = cfg.parse_dataset_s3_manifest_requests(
        {"cost_dataset": {"dataset_source": ""}}
    )

    assert s3_manifest_results == {"cost_dataset": {}}


def test_parse_s3_manifest_s3_dataset_missing_manifest_fails_clearly():
    def get_s3_path(key):
        raise RuntimeError("NoSuchKey")

    cfg = make_cfg_for_parser(get_s3_path)

    with pytest.raises(ValueError, match="required s3_manifest.yaml.*pmst"):
        cfg.parse_dataset_s3_manifest_requests({"pmst": {"dataset_source": "S3"}})


def test_dataset_publish_handler_writes_payload_once_when_datasets_exist(monkeypatch, env):
    from quicksight_mgr import dataset_publish_payload_handler

    put_calls = []

    class FakeS3Client:
        def put_object(self, **kwargs):
            put_calls.append(kwargs)
            return {"ETag": '"payload-etag"'}

    class FakeConfig:
        def __init__(self, **kwargs):
            self.prefix = "bif-risk"

        def parse_dataset_metadata_requests(self):
            return {
                "pmst": {
                    "name": "PMST",
                    "import_mode": "SPICE",
                    "force_sync": True,
                    "workspaces": ["bif-risk"],
                    "dataset_source": "S3",
                    "data_source_id": "pmst-s3-source",
                    "columns": {"business_date": "DATETIME"},
                    "physical_table_map_id": "PMST-dev",
                    "folders": ["bif-risk-dev"],
                }
            }

        def parse_dataset_rls_requests(self):
            return {"pmst": []}

        def parse_dataset_cls_requests(self):
            return {"pmst": []}

        def parse_dataset_s3_manifest_requests(self, metadata_results):
            assert "pmst" in metadata_results
            return {
                "pmst": {
                    "upload_settings": {
                        "format": "CSV",
                        "start_from_row": 1,
                        "contains_header": True,
                        "text_qualifier": "SINGLE_QUOTE",
                        "delimiter": ",",
                    }
                }
            }

    monkeypatch.setattr(dataset_publish_payload_handler, "s3_client", FakeS3Client())
    monkeypatch.setattr(
        dataset_publish_payload_handler,
        "BIFoundationsConfigS3",
        FakeConfig,
    )

    response = dataset_publish_payload_handler.handler({"detail": {"object": {"key": "bif-risk/manifest.json"}}}, None)

    assert response["dataset_count"] == 1
    assert len(put_calls) == 1
    payload = json.loads(put_calls[0]["Body"])
    assert payload[0]["payload"]["id"] == "pmst"
    assert payload[0]["payload"]["config"]["data_source_id"] == "pmst-s3-source"


def test_dataset_publish_handler_emits_refresh_properties_for_incremental(monkeypatch, env):
    """A dataset with an `incremental_refresh` block emits a
    `dataset_refresh_properties` payload carrying that config, so the publisher
    can set the SPICE LookbackWindow via put_data_set_refresh_properties."""
    from quicksight_mgr import dataset_publish_payload_handler

    put_calls = []

    class FakeS3Client:
        def put_object(self, **kwargs):
            put_calls.append(kwargs)
            return {"ETag": '"payload-etag"'}

    class FakeConfig:
        def __init__(self, **kwargs):
            self.prefix = "bif-risk"

        def parse_dataset_metadata_requests(self):
            return {
                "rmv_analytics": {
                    "name": "rmv_analytics",
                    "import_mode": "SPICE",
                    "workspaces": ["bif-risk"],
                    "columns": {"business_date_dt": "DATETIME"},
                    "physical_table_map_id": "rmv-analytics-dev",
                    "folders": ["bif-risk-dev"],
                    "incremental_refresh": {
                        "column_name": "business_date_dt",
                        "size": 14,
                        "size_unit": "DAY",
                    },
                }
            }

        def parse_dataset_rls_requests(self):
            return {"rmv_analytics": []}

        def parse_dataset_cls_requests(self):
            return {"rmv_analytics": []}

        def parse_dataset_s3_manifest_requests(self, metadata_results):
            return {}

    monkeypatch.setattr(dataset_publish_payload_handler, "s3_client", FakeS3Client())
    monkeypatch.setattr(dataset_publish_payload_handler, "BIFoundationsConfigS3", FakeConfig)

    dataset_publish_payload_handler.handler({"detail": {"object": {"key": "bif-risk/manifest.json"}}}, None)

    payloads = json.loads(put_calls[0]["Body"])
    props = [p for p in payloads if p["resource"] == "dataset_refresh_properties"]
    assert len(props) == 1
    assert props[0]["payload"]["id"] == "rmv_analytics"
    assert props[0]["payload"]["config"]["incremental_refresh"] == {
        "column_name": "business_date_dt",
        "size": 14,
        "size_unit": "DAY",
    }


def _make_dataset_payload(slug, joins=None):
    return {
        "resource": "dataset",
        "payload": {
            "id": slug,
            "config": {"name": slug, "joins": joins or []},
        },
    }


def _make_refresh_payload(slug):
    return {
        "resource": "refresh_schedule",
        "payload": {"id": slug, "config": {}},
    }


def _make_refresh_properties_payload(slug):
    return {
        "resource": "dataset_refresh_properties",
        "payload": {"id": slug, "config": {}},
    }


def test_topological_sort_orders_join_targets_before_dependents():
    from quicksight_mgr.dataset_publish_payload_handler import _topological_sort_payloads

    # Alphabetical order puts beta_ar before thresholds — bad.
    payloads = [
        _make_dataset_payload("beta_ar", joins=[{"right_dataset": "thresholds"}]),
        _make_dataset_payload(
            "radar_analytics_v2",
            joins=[
                {"right_dataset": "f30_target_xlsx"},
                {"right_dataset": "beta_ar"},
                {"right_dataset": "opr_sa_metrics"},
            ],
        ),
        _make_dataset_payload("f30_target_xlsx"),
        _make_dataset_payload("opr_sa_metrics"),
        _make_dataset_payload("thresholds"),
    ]
    ordered = _topological_sort_payloads(payloads)
    order = [p["payload"]["id"] for p in ordered]

    # All deps come before their dependents
    assert order.index("thresholds") < order.index("beta_ar")
    assert order.index("f30_target_xlsx") < order.index("radar_analytics_v2")
    assert order.index("beta_ar") < order.index("radar_analytics_v2")
    assert order.index("opr_sa_metrics") < order.index("radar_analytics_v2")


def test_topological_sort_keeps_refresh_schedule_adjacent_to_dataset():
    from quicksight_mgr.dataset_publish_payload_handler import _topological_sort_payloads

    payloads = [
        _make_dataset_payload("beta_ar", joins=[{"right_dataset": "thresholds"}]),
        _make_refresh_payload("beta_ar"),
        _make_dataset_payload("thresholds"),
        _make_refresh_payload("thresholds"),
    ]
    ordered = _topological_sort_payloads(payloads)
    pairs = [(p["resource"], p["payload"]["id"]) for p in ordered]

    # Each dataset is immediately followed by its refresh schedule
    assert pairs == [
        ("dataset", "thresholds"),
        ("refresh_schedule", "thresholds"),
        ("dataset", "beta_ar"),
        ("refresh_schedule", "beta_ar"),
    ]


def test_topological_sort_orders_refresh_properties_between_dataset_and_schedule():
    """Incremental-refresh datasets emit a dataset_refresh_properties payload.
    The LookbackWindow must be set before an INCREMENTAL_REFRESH schedule runs,
    so ordering must be dataset -> refresh_properties -> refresh_schedule."""
    from quicksight_mgr.dataset_publish_payload_handler import _topological_sort_payloads

    # Deliberately out of order in the input.
    payloads = [
        _make_refresh_payload("rmv_analytics"),
        _make_refresh_properties_payload("rmv_analytics"),
        _make_dataset_payload("rmv_analytics"),
    ]
    ordered = _topological_sort_payloads(payloads)
    pairs = [(p["resource"], p["payload"]["id"]) for p in ordered]

    assert pairs == [
        ("dataset", "rmv_analytics"),
        ("dataset_refresh_properties", "rmv_analytics"),
        ("refresh_schedule", "rmv_analytics"),
    ]


def test_topological_sort_ignores_unknown_join_targets():
    """If a join points at a dataset that isn't in this batch (e.g. published
    in a previous sync), don't block the dependent — it'll resolve at runtime."""
    from quicksight_mgr.dataset_publish_payload_handler import _topological_sort_payloads

    payloads = [
        _make_dataset_payload(
            "vol_greeks",
            joins=[{"right_dataset": "fx_rate"}],  # already in central, not in this batch
        ),
    ]
    ordered = _topological_sort_payloads(payloads)
    assert [p["payload"]["id"] for p in ordered] == ["vol_greeks"]


def test_dataset_column_geographic_role_emits_tag_operation():
    """A column with `geographic_role: COUNTRY` in metadata.yaml should emit
    a TagColumnOperation alongside its CastColumnTypeOperation. Without this,
    geospatial visuals fail CreateAnalysis with COLUMN_GEOGRAPHIC_ROLE_INCOMPATIBLE
    (see PA Risk External 2026-05-25)."""
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "atp_bcpp",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                }
            },
            "config": {
                "name": "ATP_BCPP",
                "import_mode": "SPICE",
                "physical_table_map_id": "atp-bcpp-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/foundations-quicksight-managed-s3",
                "dataset_source": "S3",
                "columns": {
                    "business_date": "DATETIME",
                    "Country": {"type": "STRING", "geographic_role": "COUNTRY"},
                },
            },
        },
    }
    ds = Dataset(logger, None, payload)
    inputs = ds.prep_inputs()
    transforms = next(iter(inputs["LogicalTableMap"].values()))["DataTransforms"]

    cast_columns = {
        t["CastColumnTypeOperation"]["ColumnName"]
        for t in transforms if "CastColumnTypeOperation" in t
    }
    assert cast_columns == {"business_date", "Country"}

    tag_ops = [t["TagColumnOperation"] for t in transforms if "TagColumnOperation" in t]
    assert tag_ops == [
        {"ColumnName": "Country", "Tags": [{"ColumnGeographicRole": "COUNTRY"}]}
    ]


def test_dataset_geographic_role_does_not_leak_into_customsql_columns():
    """Regression: setting geographic_role on a column put `GeographicRole` into
    CustomSql.Columns, where only Name/Id/Type/SubType are allowed. Caught when
    private_assets_radar_pos sync failed with
    'Unknown parameter in PhysicalTableMap.CustomSql.Columns[13]: GeographicRole'.
    """
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "ssg_correlation",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "config": {
                "name": "SSG_Correlation",
                "import_mode": "SPICE",
                "physical_table_map_id": "ssg-correlation-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/foundations-quicksight-managed-athena",
                "sql_query": "SELECT business_date, country FROM risk_prod.ssg_correlation",
                "columns": {
                    "business_date": "DATETIME",
                    "country": {"type": "STRING", "geographic_role": "COUNTRY"},
                },
            },
        },
    }
    ds = Dataset(logger, None, payload)
    inputs = ds.prep_inputs()
    custom_sql = next(iter(inputs["PhysicalTableMap"].values()))["CustomSql"]

    allowed_keys = {"Name", "Id", "Type", "SubType"}
    for col in custom_sql["Columns"]:
        assert set(col.keys()).issubset(allowed_keys), (
            f"CustomSql.Columns entry {col} has disallowed keys"
        )

    transforms = next(iter(inputs["LogicalTableMap"].values()))["DataTransforms"]
    tag_ops = [t["TagColumnOperation"] for t in transforms if "TagColumnOperation" in t]
    assert tag_ops == [
        {"ColumnName": "country", "Tags": [{"ColumnGeographicRole": "COUNTRY"}]}
    ]


def test_dataset_calculated_column_emits_create_columns_operation():
    """A `calculated_columns:` entry in metadata.yaml must NOT become an S3
    InputColumn (the CSV has no such physical column) — it must be emitted as a
    CreateColumnsOperation on the LogicalTable, with a trailing ProjectOperation
    keeping every column. Regression: central IODP declared the derived
    `Program Name` column as a raw 8th input column on a 7-column CSV, so it
    ingested as all-NULL and the ARS-QE 'FYTD DVA Trend' visual (filtered on
    Program Name) rendered 'No data' (source defines it via this calc)."""
    expression = (
        "ifelse(\n"
        "    contains({portfolio_name}, 'AIM'), 'Partnership Investing',\n"
        "    contains({portfolio_name}, 'Total Quantitative Equities') AND "
        "contains({source}, 'Murex'), ' Quantitative Equities',\n"
        "    NULL\n"
        ")"
    )
    payload = {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "iodp",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {
                "upload_settings": {
                    "format": "CSV",
                    "start_from_row": 1,
                    "contains_header": True,
                    "text_qualifier": "SINGLE_QUOTE",
                    "delimiter": ",",
                }
            },
            "config": {
                "name": "IODP",
                "import_mode": "SPICE",
                "physical_table_map_id": "iodp-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/awb-iodp-s3-source",
                "dataset_source": "S3",
                "columns": {
                    "business_date": {"type": "DATETIME", "format": "MM/dd/yyyy"},
                    "portfolio_group": "STRING",
                    "portfolio_name": "STRING",
                    "source": "STRING",
                    "time_horizon": "STRING",
                    "type": "STRING",
                    "value": "DECIMAL.FLOAT",
                },
                "calculated_columns": {
                    "Program Name": {"type": "STRING", "expression": expression},
                },
            },
        },
    }
    ds = Dataset(logger, None, payload)
    inputs = ds.prep_inputs()

    # The calculated column must NOT appear as a physical S3 input column.
    input_cols = next(iter(inputs["PhysicalTableMap"].values()))["S3Source"]["InputColumns"]
    input_names = [c["Name"] for c in input_cols]
    assert "Program Name" not in input_names
    assert input_names == [
        "business_date", "portfolio_group", "portfolio_name", "source",
        "time_horizon", "type", "value",
    ]

    transforms = next(iter(inputs["LogicalTableMap"].values()))["DataTransforms"]

    # Exactly one CreateColumnsOperation, carrying the derived Program Name.
    create_ops = [t["CreateColumnsOperation"] for t in transforms if "CreateColumnsOperation" in t]
    assert len(create_ops) == 1
    calc_cols = create_ops[0]["Columns"]
    assert len(calc_cols) == 1
    assert calc_cols[0]["ColumnName"] == "Program Name"
    assert calc_cols[0]["Expression"] == expression
    assert calc_cols[0].get("ColumnId")  # non-empty, QuickSight-required

    # Calc column is created AFTER the casts of the columns it references.
    create_idx = next(i for i, t in enumerate(transforms) if "CreateColumnsOperation" in t)
    cast_idx = [i for i, t in enumerate(transforms) if "CastColumnTypeOperation" in t]
    assert all(i < create_idx for i in cast_idx)

    # A trailing ProjectOperation keeps every column, calc column last.
    project_ops = [t["ProjectOperation"] for t in transforms if "ProjectOperation" in t]
    assert len(project_ops) == 1
    assert project_ops[0]["ProjectedColumns"] == [
        "business_date", "portfolio_group", "portfolio_name", "source",
        "time_horizon", "type", "value", "Program Name",
    ]
    assert transforms.index({"ProjectOperation": project_ops[0]}) > create_idx


def test_topological_sort_raises_on_cycle():
    import pytest as _pytest
    from quicksight_mgr.dataset_publish_payload_handler import _topological_sort_payloads

    payloads = [
        _make_dataset_payload("a", joins=[{"right_dataset": "b"}]),
        _make_dataset_payload("b", joins=[{"right_dataset": "a"}]),
    ]
    with _pytest.raises(ValueError, match="Cyclic"):
        _topological_sort_payloads(payloads)


# def test_qs_dataset_s3_datasource(qs_client_create_dataset_s3):
#     results = Dataset(logger, qs_client_create_dataset_s3, create_dataset_payload)


def test_sync_direct_query_customsql_dataset_no_ingestion(env):
    """A DIRECT_QUERY CustomSql dataset: create_data_set returns no IngestionId.

    The sync must create the dataset and set folder membership without choking
    on the absent IngestionId (regression: SPICE->DIRECT_QUERY risk dashboards).
    """
    qs_client = botocore.session.get_session().create_client(
        "quicksight", region_name="us-east-1"
    )
    s3_client = botocore.session.get_session().create_client("s3", region_name="us-east-1")

    event = {
        "resource": "dataset",
        "payload": {
            "id": "rmv_position",
            "account_id": env["ACCOUNT_ID"],
            "config": {
                "name": "rmv_position",
                "import_mode": "DIRECT_QUERY",
                "workspaces": ["bif-risk"],
                "data_source_arn": env["FABRIC_DATASOURCE_ARN"],
                "sql_query": "SELECT 1 AS business_date",
                "physical_table_map_id": "rmv_position-dev",
                "columns": {"business_date": "DATETIME"},
                "folders": ["bif-risk-dev"],
            },
            "rls": [],
            "cls": [],
            "s3_manifest": {},
        },
    }

    with Stubber(qs_client) as qs_stubber:
        # DIRECT_QUERY create_data_set response has NO IngestionArn/IngestionId.
        qs_stubber.add_response(
            "create_data_set",
            {
                "Arn": "arn:aws:quicksight:us-east-1:123456789012:dataset/rmv_position",
                "DataSetId": "rmv_position",
                "RequestId": "request-id",
                "Status": 200,
            },
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "DataSetId": "rmv_position",
                "Name": "rmv_position",
                "PhysicalTableMap": {
                    "rmv_position-dev": {
                        "CustomSql": {
                            "DataSourceArn": env["FABRIC_DATASOURCE_ARN"],
                            "Name": "rmv_position",
                            "SqlQuery": "SELECT 1 AS business_date",
                            "Columns": [{"Name": "business_date", "Type": "DATETIME"}],
                        }
                    }
                },
                "ImportMode": "DIRECT_QUERY",
            },
        )
        qs_stubber.add_response(
            "create_folder_membership",
            {"Status": 200, "RequestId": "request-id"},
            {
                "AwsAccountId": env["ACCOUNT_ID"],
                "FolderId": "bif-risk-dev",
                "MemberId": "rmv_position",
                "MemberType": "DATASET",
            },
        )

        # Must not raise KeyError on the missing IngestionId.
        Dataset(logger, qs_client, event, s3_client).sync()
        qs_stubber.assert_no_pending_responses()


def _direct_query_customsql_payload(import_mode):
    return {
        "resource": "data_set",
        "payload": {
            "force_sync": True,
            "id": "ae_analytics",
            "account_id": "200967598245",
            "rls": {},
            "cls": {},
            "s3_manifest": {},
            "config": {
                "name": "ae_analytics",
                "import_mode": import_mode,
                "physical_table_map_id": "ae-analytics-dev",
                "data_source_arn": "arn:aws:quicksight:us-east-1:200967598245:datasource/fabric_catalog_dev",
                "sql_query": "SELECT 1",
                "columns": {
                    "node": "STRING",
                    "analytic_value": "DECIMAL.FLOAT",
                },
            },
        },
    }


def _customsql_columns(inputs):
    ptm = inputs["PhysicalTableMap"]["ae-analytics-dev"]
    return {c["Name"]: c for c in ptm["CustomSql"]["Columns"]}


def test_direct_query_omits_column_subtype():
    """DIRECT_QUERY datasets must not emit column SubType - QuickSight rejects
    'Only SPICE dataset can have sub-type'. DECIMAL.FLOAT -> Type DECIMAL only."""
    ds = Dataset(logger, MagicMock(), _direct_query_customsql_payload("DIRECT_QUERY"))
    cols = _customsql_columns(ds.prep_inputs())
    assert cols["analytic_value"]["Type"] == "DECIMAL"
    assert "SubType" not in cols["analytic_value"]


def test_spice_keeps_column_subtype():
    """SPICE datasets still emit SubType (DECIMAL.FLOAT -> DECIMAL/FLOAT)."""
    ds = Dataset(logger, MagicMock(), _direct_query_customsql_payload("SPICE"))
    cols = _customsql_columns(ds.prep_inputs())
    assert cols["analytic_value"]["Type"] == "DECIMAL"
    assert cols["analytic_value"]["SubType"] == "FLOAT"
