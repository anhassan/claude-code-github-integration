from common.utils.quicksight_theme import is_managed_theme


def test_managed_classic_arn_is_managed():
    assert is_managed_theme("arn:aws:quicksight::aws:theme/CLASSIC") is True


def test_managed_midnight_arn_is_managed():
    assert is_managed_theme("arn:aws:quicksight::aws:theme/MIDNIGHT") is True


def test_account_scoped_custom_arn_is_not_managed():
    assert (
        is_managed_theme(
            "arn:aws:quicksight:us-east-1:200967598245:theme/"
            "cf6457fc-78a7-4b45-b358-26626e56cfb7"
        )
        is False
    )


def test_empty_or_none_is_not_managed():
    assert is_managed_theme("") is False
    assert is_managed_theme(None) is False


def test_malformed_arn_is_not_managed():
    # Unparseable value must NOT be treated as managed, so a present-but-odd
    # ThemeArn never causes a custom theme file to be discarded.
    assert is_managed_theme("garbage") is False
