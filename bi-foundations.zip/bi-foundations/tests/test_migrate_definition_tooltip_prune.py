# tests/test_migrate_definition_tooltip_prune.py
import copy

from scripts.migrate_qs_dashboard_definition import prune_dangling_tooltip_fields


def make_definition(tooltip_fields):
    return {
        "Sheets": [
            {
                "SheetId": "sheet-1",
                "Visuals": [
                    {
                        "LineChartVisual": {
                            "VisualId": "visual-1",
                            "ChartConfiguration": {
                                "FieldWells": {
                                    "LineChartAggregatedFieldWells": {
                                        "Category": [
                                            {
                                                "DateDimensionField": {
                                                    "FieldId": "ds.business_date",
                                                    "Column": {
                                                        "DataSetIdentifier": "ds",
                                                        "ColumnName": "business_date",
                                                    },
                                                }
                                            }
                                        ],
                                        "Values": [
                                            {
                                                "NumericalMeasureField": {
                                                    "FieldId": "ds.value.0",
                                                    "Column": {
                                                        "DataSetIdentifier": "ds",
                                                        "ColumnName": "value",
                                                    },
                                                }
                                            }
                                        ],
                                    }
                                },
                                "Tooltip": {
                                    "FieldBasedTooltip": {
                                        "TooltipFields": tooltip_fields,
                                    }
                                },
                            },
                        }
                    }
                ],
            }
        ]
    }


def test_prunes_tooltip_items_with_dangling_field_ids():
    definition = make_definition(
        [
            {"FieldTooltipItem": {"FieldId": "ds.value.0", "Visibility": "VISIBLE"}},
            {"FieldTooltipItem": {"FieldId": "stale.8.1772055016141", "Visibility": "VISIBLE"}},
        ]
    )
    prune_dangling_tooltip_fields(definition)
    remaining = definition["Sheets"][0]["Visuals"][0]["LineChartVisual"][
        "ChartConfiguration"
    ]["Tooltip"]["FieldBasedTooltip"]["TooltipFields"]
    assert remaining == [
        {"FieldTooltipItem": {"FieldId": "ds.value.0", "Visibility": "VISIBLE"}}
    ]


def test_keeps_column_tooltip_items_and_valid_fields():
    tooltip_fields = [
        {"FieldTooltipItem": {"FieldId": "ds.business_date", "Visibility": "VISIBLE"}},
        {
            "ColumnTooltipItem": {
                "Column": {"DataSetIdentifier": "ds", "ColumnName": "other"},
                "Aggregation": {"SimpleNumericalAggregation": "SUM"},
            }
        },
    ]
    definition = make_definition(copy.deepcopy(tooltip_fields))
    prune_dangling_tooltip_fields(definition)
    remaining = definition["Sheets"][0]["Visuals"][0]["LineChartVisual"][
        "ChartConfiguration"
    ]["Tooltip"]["FieldBasedTooltip"]["TooltipFields"]
    assert remaining == tooltip_fields


def test_no_tooltip_is_a_no_op():
    definition = make_definition([])
    del definition["Sheets"][0]["Visuals"][0]["LineChartVisual"]["ChartConfiguration"][
        "Tooltip"
    ]
    prune_dangling_tooltip_fields(definition)
    assert "Tooltip" not in definition["Sheets"][0]["Visuals"][0]["LineChartVisual"][
        "ChartConfiguration"
    ]
