# tests/test_migrate_definition_theme_carry.py
from scripts.migrate_qs_dashboard_definition import (
    create_or_update_analysis,
    create_or_update_dashboard,
    managed_theme_arn,
)

RAINIER = "arn:aws:quicksight::aws:theme/RAINIER"
CUSTOM = "arn:aws:quicksight:us-east-1:840529182937:theme/abc-123"


def test_managed_theme_arn_accepts_aws_managed_only():
    assert managed_theme_arn({"ThemeArn": RAINIER}) == RAINIER
    assert managed_theme_arn({"ThemeArn": CUSTOM}) is None
    assert managed_theme_arn({}) is None


def test_dashboard_dry_run_carries_managed_theme():
    result = create_or_update_dashboard(
        None, "200967598245", "dash-1", "Dash",
        {"Definition": {}, "ThemeArn": RAINIER}, apply_changes=False,
    )
    assert result["params"]["ThemeArn"] == RAINIER


def test_dashboard_dry_run_skips_custom_theme():
    result = create_or_update_dashboard(
        None, "200967598245", "dash-1", "Dash",
        {"Definition": {}, "ThemeArn": CUSTOM}, apply_changes=False,
    )
    assert "ThemeArn" not in result["params"]


def test_analysis_dry_run_carries_managed_theme():
    result = create_or_update_analysis(
        None, "200967598245", "an-1", "An",
        {"Definition": {}, "ThemeArn": RAINIER}, apply_changes=False,
    )
    assert result["params"]["ThemeArn"] == RAINIER
