from pprint import pprint
from src.quicksight_mgr.qs_asset_manager import (
    get_bucket_key_from_sqs_queue,
    read_json_from_s3,
    rename_nested_dict_keys,
    qs_key_mapping,
    base_keys_to_keep,
    qs_keys_to_keep,
    extract_keys,
    process_sheets,
    process_datasets,
    process_calculated_fields,
    CSVProcessingManager,
    check_asset_status_dynamodb,
    detect_metadata_csv_name,
    get_matching_csv_files,
    YamlProcessingManager,
    add_datetime_timestamp_utc,
    extract_visual_dataset_fields,
    add_datetime_from_definition_file,
    set_finsights_detail,
)


def test_quicksight_read_json(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    assert response is not None


def test_qs_mapping(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    renamed_output = rename_nested_dict_keys(response, qs_key_mapping)
    assert qs_key_mapping["Name"] in renamed_output
    # assert qs_key_mapping["Definition.Sheets.*.Visuals.*.PivotTableVisual.Title.RichText" in renamed_output['Definition']"visual_name""]


def test_qs_keys_to_keep():
    keys_to_keep = qs_keys_to_keep(base_keys_to_keep)
    test_list = ["Name"]
    test_set = set(test_list)
    keys_to_keep_set = set(keys_to_keep)
    assert test_set.issubset(keys_to_keep_set)


def test_qs_key_extraction(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    keys_to_keep = qs_keys_to_keep(base_keys_to_keep)
    outjson = extract_keys(response, keys_to_keep)
    assert outjson["Name"] == "Cost Dashboard (DEV)"


def test_qs_key_extraction_with_wildcards(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    keys_to_keep = qs_keys_to_keep(
        [*base_keys_to_keep, "finsights_detail.data_products.*"]
    )
    print(keys_to_keep)
    outjson = extract_keys(
        {
            **response,
            "finsights_detail": {
                "data_products": {"name": "test_value", "value": {"key": "hello"}},
                "should_be_excluded": ["excluded"],
            },
        },
        keys_to_keep,
    )
    pprint(outjson)
    assert outjson["Name"] == "Cost Dashboard (DEV)"
    assert outjson["finsights_detail"]["data_products"]["name"] is not None
    assert outjson["finsights_detail"]["data_products"]["value"]["key"] is not None
    assert outjson["finsights_detail"].get("should_be_excluded") is None


def test_process_sheets(qs_asset_stubber, qs_asset_dq_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    visual_datasets = process_sheets(response)
    assert visual_datasets["sheets"][0]["visualizations"][0]["visual_id"] is not None
    assert visual_datasets["sheets"][3]["parameters"][0]["name"] is not None
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=qs_asset_dq_stubber
    )
    visual_datasets = process_sheets(response)
    assert (
        visual_datasets["sheets"][0]["visualizations"][0]["visualization_type"]
        == "BarChartVisual"
    )


def test_process_datasets(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    processed_datasets = process_datasets(response)
    assert processed_datasets["datasets"][0] is not None


def test_process_calculated_fields(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    processed_calculated_fields = process_calculated_fields(response)
    assert processed_calculated_fields["calculated_fields"][0] is not None


def test_detect_metadata_csv_name():
    s3_object_key_list = [
        "AE Market Data Inventory Dashboard/latest/datasets.csv",
        "AE Market Data Inventory Dashboard/latest/parameter.csv",
        "AE Market Data Inventory Dashboard/latest/sheets_template.csv",
        "AE Market Data Inventory Dashboard/latest/parameters.csv",
    ]
    for object in s3_object_key_list:
        metadata_type = detect_metadata_csv_name(object)
        assert metadata_type in [
            "overview",
            "dataset",
            "sheet",
            "visualization",
            "parameter",
        ]


def test_read_csv(csv_metadata_stubber, env):
    s3_client = csv_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_sheets.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    csv_data = response.data
    assert csv_data[0]["Sheet Name"] == "Budget Objective"


def test_prepare_sheet_payload(csv_metadata_stubber, env):
    s3_client = csv_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_sheets.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    insert_payload = response.prepare_sheet_metadata()
    assert insert_payload[0]["name"] == "Budget Objective"


def test_merge_and_update_sheets_metadata_payload(
    csv_metadata_stubber, qs_asset_processed_stubber, env
):
    s3_client = csv_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_sheets.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    formated_payload = response.prepare_sheet_metadata()
    existing_metadata_asset = read_json_from_s3(
        bucket_name=env["BUCKET"],
        key="cost_insights_report.json",
        s3_client=qs_asset_processed_stubber,
    )
    merge_update_payload = response.merge_and_update_sheets_metadata_payload(
        formated_payload, existing_metadata_asset
    )
    assert merge_update_payload["sheets"][0]["description"] == "Budget Objective"
    empty_payload = {}
    insert_payload = response.insert_sheets_metadata_payload(
        formated_payload, empty_payload
    )
    assert insert_payload["sheets"][0]["description"] == "Budget Objective"


def test_check_asset_status_dynamodb(dynamo_asset_stubber, env):
    response = check_asset_status_dynamodb(
        "ma-cost-beta-dashboard", env["ASSETS_TABLE"], dynamo_asset_stubber
    )
    assert response == False


def test_prepare_overview_payload(
    csv_overview_metadata_stubber, qs_asset_processed_stubber, env
):
    s3_client = csv_overview_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_overview.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    insert_payload = response.prepare_overview_metadata()

    existing_metadata_asset = read_json_from_s3(
        bucket_name=env["BUCKET"],
        key="cost_insights_report.json",
        s3_client=qs_asset_processed_stubber,
    )
    merged_payload = response.merge_and_update_overview_metadata_payload(
        insert_payload, existing_metadata_asset
    )
    assert merged_payload["asset_id"] == "ma-cost-beta-dashboard"
    empty_payload = {}
    insert_payload = response.insert_overview_metadata_payload(
        insert_payload, empty_payload
    )
    assert insert_payload["description"] == "Quicksights Cost Dashboard"


def test_prepare_dataset_payload(
    csv_datasets_metadata_stubber, qs_asset_processed_stubber, env
):
    s3_client = csv_datasets_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_datasets.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    insert_payload = response.prepare_dataset_metadata()
    existing_metadata_asset = read_json_from_s3(
        bucket_name=env["BUCKET"],
        key="cost_insights_report.json",
        s3_client=qs_asset_processed_stubber,
    )
    merged_payload = response.merge_and_update_datasets_metadata_payload(
        insert_payload, existing_metadata_asset
    )
    assert merged_payload["datasets"][0]["dataset_id"] == "cost_insights_report"
    empty_payload = {}
    insert_payload = response.insert_datasets_metadata_payload(
        insert_payload, empty_payload
    )
    assert insert_payload["datasets"][0]["dataset_id"] == "cost_insights_report"
    assert type(insert_payload["datasets"][0]["is_data_product"]) is bool


def test_prepare_parameter_payload(
    csv_parameters_metadata_stubber, qs_asset_processed_stubber, env
):
    s3_client = csv_parameters_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_parameters.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    insert_payload = response.prepare_parameter_metadata()
    # existing_metadata_asset = read_json_from_s3(bucket_name=env['BUCKET'], key="cost_insights_report.json", s3_client=qs_asset_processed_stubber)
    existing_payload = {
        "sheets": [{"name": "Budget Objective", "description": "test1"}]
    }
    processed_payload = response.insert_parameters_metadata_payload(
        insert_payload, existing_payload
    )
    assert processed_payload["sheets"][0]["name"] == "Budget Objective"
    assert processed_payload["sheets"][0]["parameters"][1]["name"] == "Fiscal Month"


def test_prepare_visualization_payload(
    csv_visualization_metadata_stubber, qs_asset_processed_stubber, env
):
    s3_client = csv_visualization_metadata_stubber
    response = CSVProcessingManager(
        s3_bucket=env["BUCKET"],
        s3_key="cost_visualizations.csv",
        delimiter=",",
        s3_client=s3_client,
    )
    insert_payload = response.prepare_visualization_metadata()
    existing_metadata_asset = read_json_from_s3(
        bucket_name=env["BUCKET"],
        key="cost_insights_report.json",
        s3_client=qs_asset_processed_stubber,
    )
    merged_payload = response.merge_and_update_visualizations_metadata_payload(
        insert_payload, existing_metadata_asset
    )
    assert (
        merged_payload["sheets"][0]["visualizations"][0]["visual_name"]
        == "Detailed Transactions"
    )
    existing_payload = {
        "sheets": [{"name": "Budget Objective", "description": "test1"}]
    }
    insert_payload = response.insert_visualizations_metadata_payload(
        insert_payload, existing_payload
    )
    assert (
        insert_payload["sheets"][0]["visualizations"][0]["visual_name"]
        == "Detailed Transactions"
    )


def test_get_matching_csv_files(create_s3_stub_paginator, env):
    s3_client = create_s3_stub_paginator
    results = get_matching_csv_files(
        env["BUCKET"], "ma_cost_dashboard/metadata/", s3_client
    )
    assert len(results) == 5
    assert results["dataset"] == "ma_cost_dashboard/metadata/cost_datasets.csv"


def test_prepare_config_metadata(create_dashboard_config_stubber, env):
    s3_client = create_dashboard_config_stubber
    s3_config_mock_path = "bif-ma/dev/assets/cost_dashboard/"
    response = YamlProcessingManager(
        s3_bucket=env["BUCKET"], s3_key="cost_config.yaml", s3_client=s3_client
    )
    insert_payload = response.prepare_config_metadata(
        s3_key=s3_config_mock_path, aws_environment=env["ENV_NAME"]
    )
    assert insert_payload["asset_id"] == "department_cost_dashboard-bif-ma-dev"
    existing_metadata_payload = {}
    final_payload = response.insert_config_payload(
        insert_payload, existing_metadata_payload
    )
    assert final_payload["asset_id"] == "department_cost_dashboard-bif-ma-dev"
    s3_path = response.get_dashboard_definition_key()
    assert s3_path == "DepartmentCostDashboard/RELEASE/latest/dashboard_definition.json"


def test_get_bucket_key_from_sqs_queue(manifest_pipes_payload):
    for record in manifest_pipes_payload:
        bucket, key = get_bucket_key_from_sqs_queue(record)
        assert bucket == "bi-foundations-control-plane-200967598245-dev"
        assert key == "bif-ma/dev/assets/cost_dashboard/manifest.json"


def test_add_datetime_timestamp_utc():
    payload = {}
    processed_payload = add_datetime_timestamp_utc(payload)
    assert processed_payload["updated_at"] is not None


def test_extract_dataset_fields(qs_asset_stubber, env):
    s3_client = qs_asset_stubber
    response = read_json_from_s3(
        bucket_name=env["BUCKET"], key=env["KEY"], s3_client=s3_client
    )
    visual_1 = response["Definition"]["Sheets"][0]["Visuals"][1]
    results = extract_visual_dataset_fields(visual_1)
    assert results[0]["name"] == "v_cost_combined"
    visual_2 = response["Definition"]["Sheets"][1]["Visuals"][2]
    results2 = extract_visual_dataset_fields(visual_2)
    assert results2[0]["name"] == "v_cost_combined"
    assert results2[0]["visual_numerical_fields"][0].startswith("[Metric Pivot]")


def test_get_datetime_from_s3_object(return_head_stubber, env):
    s3_client = return_head_stubber
    payload = {}
    payload_result = add_datetime_from_definition_file(
        env["BUCKET"], env["KEY"], payload, s3_client
    )
    assert payload_result["updated_at"] is not None
    assert type(payload_result["updated_at"]) == str


def test_process_sheets_with_ceo_os_metadata(ceo_qs_asset_highchart_stubber, env):
    response = read_json_from_s3(
        bucket_name=env["BUCKET"],
        key=env["KEY"],
        s3_client=ceo_qs_asset_highchart_stubber,
    )
    visual_datasets = process_sheets(response)
    assert (
        visual_datasets["sheets"][5]["visualizations"][0]["visualization_type"]
        == "PluginVisual"
    )


def test_set_finsights_detail_on_os_payload(create_dashboard_config_stubber, env):
    s3_client = create_dashboard_config_stubber
    s3_config_mock_path = "bif-ma/dev/assets/cost_dashboard/"
    response = YamlProcessingManager(
        s3_bucket=env["BUCKET"], s3_key="cost_config.yaml", s3_client=s3_client
    )
    insert_payload = response.prepare_config_metadata(
        s3_key=s3_config_mock_path, aws_environment=env["ENV_NAME"]
    )
    assert insert_payload["asset_id"] == "department_cost_dashboard-bif-ma-dev"

    payload = set_finsights_detail({}, insert_payload)
    assert payload["finsights_detail"] is not None

    keys_to_keep = qs_keys_to_keep(base_keys_to_keep)
    outjson = extract_keys(payload, keys_to_keep)

    assert outjson["finsights_detail"] is not None
    assert outjson["finsights_detail"]["department"] is not None
    assert outjson["finsights_detail"]["description"] is not None
    assert len(outjson["finsights_detail"]["product_owners"]) > 0
    assert len(outjson["owners"]) > 0
    assert len(outjson["owner_names"]) > 0
    assert outjson["asset_type"] is not None
    assert outjson["artifact_source"] is not None
