from src.quicksight_mgr.resources import Dashboard


class FakeLogger:
    def __init__(self):
        self.messages = []

    def info(self, message):
        self.messages.append(("info", message))

    def warning(self, message):
        self.messages.append(("warning", message))


class FakeQS:
    """resolve_theme_arn does not call QuickSight; a stub object is enough."""


def make_dashboard(theme_arn=None):
    definition = {"DataSetIdentifierDeclarations": [], "Sheets": []}
    inner = {"Definition": definition, "DashboardPublishOptions": {}}
    if theme_arn is not None:
        inner["ThemeArn"] = theme_arn
    event = {
        "resource": "dashboard",
        "payload": {
            "id": "test-dashboard",
            "definition": inner,
            "config": {
                "id_prefix": "dash",
                "workspace": "workspace",
                "display_name": "Test Dashboard",
            },
        },
    }
    return Dashboard(FakeLogger(), FakeQS(), event)


def test_managed_theme_passthrough_does_not_build_custom_theme():
    dash = make_dashboard("arn:aws:quicksight::aws:theme/CLASSIC")
    called = []
    dash.sync_theme = lambda: called.append(True)

    result = dash.resolve_theme_arn()

    assert result == "arn:aws:quicksight::aws:theme/CLASSIC"
    assert called == []  # custom theme path skipped


def test_custom_theme_builds_asset_theme():
    dash = make_dashboard(
        "arn:aws:quicksight:us-east-1:200967598245:theme/cf6457fc"
    )
    called = []

    def fake_sync_theme():
        called.append(True)
        return "arn:aws:quicksight:us-east-1:123456789012:theme/dash-workspace-theme"

    dash.sync_theme = fake_sync_theme

    result = dash.resolve_theme_arn()

    assert result == (
        "arn:aws:quicksight:us-east-1:123456789012:theme/dash-workspace-theme"
    )
    assert called == [True]


def test_no_theme_arn_returns_none_without_building():
    dash = make_dashboard(None)
    called = []
    dash.sync_theme = lambda: called.append(True)

    assert dash.resolve_theme_arn() is None
    assert called == []


def test_custom_theme_missing_file_warns_and_returns_none():
    dash = make_dashboard(
        "arn:aws:quicksight:us-east-1:200967598245:theme/cf6457fc"
    )
    dash.sync_theme = lambda: None  # s3_theme_key absent -> sync_theme returns None

    assert dash.resolve_theme_arn() is None
    assert any(level == "warning" for level, _ in dash.logger.messages)


def test_prep_dashboard_inputs_sets_managed_theme_arn_in_payload():
    # End-to-end invariant: a resolved (managed) ARN is written into the
    # create/update payload so the promoted dashboard mirrors CLASSIC.
    dash = make_dashboard("arn:aws:quicksight::aws:theme/CLASSIC")

    payload = dash.prep_dashboard_inputs("arn:aws:quicksight::aws:theme/CLASSIC")

    assert payload["ThemeArn"] == "arn:aws:quicksight::aws:theme/CLASSIC"


def test_prep_dashboard_inputs_omits_theme_arn_when_none():
    dash = make_dashboard(None)

    payload = dash.prep_dashboard_inputs(None)

    assert "ThemeArn" not in payload
