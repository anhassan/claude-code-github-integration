import json
import logging

from unittest.mock import ANY, MagicMock, patch

from portal_user_lambda.config.endpoints import PortalUserEndpoints
from tests.conftest import ENV
from portal_user_lambda.main import handle_api_request


@patch("portal_user_lambda.main.get_clients")
def test_handle_request_success_user_login(_):
    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.update_item.return_value = {
        "Attributes": {
            "department": {"S": "Technology & Operations"},
            "geo": {"S": "CAN"},
            "last_seen": {"S": "2024-12-05T23:00:27.193484+00:00"},
            "email": {"S": "test@cppib.com"},
            "display_name": {"S": "Tester, Extreme"},
            "sub_department": {"S": "Technology & Data"},
            "additional_departments": {"SS": ["Technology & Operations"]},
            "additional_sub_departments": {"SS": ["Technology & Data"]},
            "additional_geos": {"SS": ["CAN"]},
        },
    }

    with patch(
        "portal_user_lambda.main.PortalUserEndpoints",
        return_value=PortalUserEndpoints(
            logging.getLogger(), {"dynamodb": mock_dynamodb_client}, ENV
        ),
    ):
        response = handle_api_request(
            {
                "resource": "/user/login",
                "httpMethod": "POST",
                "requestContext": {
                    "authorizer": {
                        "claims": {
                            "custom:subdepartment": "Technology & Data",
                            "custom:country": "CAN",
                            "custom:department": "Technology & Operations",
                            "custom:displayname": "Tester, Extreme",
                            "email": "test@cppib.com",
                        }
                    }
                },
            },
            {},
        )

        assert response["statusCode"] == 200
        assert "body" in response

        mock_dynamodb_client.update_item.assert_called_once_with(
            TableName="bi-foundations-user",
            Key={"email": {"S": "test@cppib.com"}},
            UpdateExpression="SET #display_name = :display_name, #department = :department, #sub_department = :sub_department, #geo = :geo, #user_photo = :user_photo, #last_seen = :last_seen, #additional_departments = if_not_exists(#additional_departments, :additional_departments), #additional_sub_departments = if_not_exists(#additional_sub_departments, :additional_sub_departments), #additional_geos = if_not_exists(#additional_geos, :additional_geos)",
            ExpressionAttributeNames={
                "#display_name": "display_name",
                "#department": "department",
                "#sub_department": "sub_department",
                "#geo": "geo",
                "#user_photo": "user_photo",
                "#additional_departments": "additional_departments",
                "#additional_sub_departments": "additional_sub_departments",
                "#additional_geos": "additional_geos",
                "#last_seen": "last_seen",
            },
            ExpressionAttributeValues={
                ":display_name": {"S": "Tester, Extreme"},
                ":department": {"S": "Technology & Operations"},
                ":sub_department": {"S": "Technology & Data"},
                ":geo": {"S": "CAN"},
                ":user_photo": {'NULL': True},
                ":additional_departments": {"SS": ["Technology & Operations"]},
                ":additional_sub_departments": {"SS": ["Technology & Data"]},
                ":additional_geos": {"SS": ["CAN"]},
                ":last_seen": {
                    "S": ANY,
                },
            },
            ReturnValues="ALL_NEW",
        )

        body = json.loads(response["body"])

        assert body["email"] == "test@cppib.com"
        assert body["display_name"] == "Tester, Extreme"
        assert body["geo"] == "CAN"
        assert body["department"] == "Technology & Operations"
        assert body["sub_department"] == "Technology & Data"
        assert body["last_seen"] is not None
        assert body["additional_geos"] == ["CAN"]
        assert body["additional_departments"] == ["Technology & Operations"]
        assert body["additional_sub_departments"] == ["Technology & Data"]
