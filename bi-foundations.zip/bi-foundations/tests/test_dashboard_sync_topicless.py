"""Regression: a topic-less dashboard whose finsights_detail has neither
bi_admins nor product_owners must sync without raising.

Before the fix, sync() computed the Q-topic notification recipient
(finsights_detail["product_owners"][0]["email"]) unconditionally, so a config
without product_owners raised KeyError AFTER the dashboard was created. That
crashed df-quicksight-mgr, failed the asset-processor distributed map, and
aborted the orchestration pipeline before the downstream metadata/ALS stage
ever ran (leaving promoted dashboards with no embedding/ALS entries).
"""
from src.quicksight_mgr.resources import Dashboard


class FakeLogger:
    def info(self, *a, **k):
        pass

    def warning(self, *a, **k):
        pass


class FakeQS:
    """sync() preamble is stubbed, so no QuickSight calls are made."""


def make_dashboard(topics=None, finsights_detail=None):
    inner = {"Definition": {"DataSetIdentifierDeclarations": [], "Sheets": []},
             "DashboardPublishOptions": {}}
    config = {
        "id_prefix": "dash",
        "workspace": "bif-risk-uat",
        "display_name": "Test Dashboard",
        "finsights_detail": finsights_detail if finsights_detail is not None
        else {"department": "Risk", "description": "Test"},
    }
    if topics is not None:
        config["topics"] = topics
    event = {"resource": "dashboard",
             "payload": {"id": "test-dashboard", "definition": inner, "config": config}}
    dash = Dashboard(FakeLogger(), FakeQS(), event)
    # stub the sync() preamble (real QuickSight calls) up to the topics block
    dash.resolve_theme_arn = lambda: None
    dash.prep_dashboard_inputs = lambda theme_arn: {}
    dash.create_or_update = lambda kwargs: {"VersionArn": "arn:.../dashboard/x/version/1"}
    dash.wait_for_status = lambda *a, **k: None
    dash.update_permissions = lambda *a, **k: None
    dash.update_published_version = lambda *a, **k: None
    dash.add_to_folder = lambda *a, **k: None
    return dash


def test_topicless_dashboard_without_product_owners_syncs():
    # No topics + finsights_detail lacking bi_admins/product_owners: must not raise.
    dash = make_dashboard(topics=[], finsights_detail={"department": "Risk"})
    dash.sync()  # would KeyError('product_owners') before the fix


def test_topicless_dashboard_default_finsights_detail_syncs():
    dash = make_dashboard()  # topics key absent entirely
    dash.sync()
