import json
import logging

from unittest.mock import ANY, MagicMock, patch

from opensearchpy import OpenSearch

from portal_assets_lambda.config.endpoints import PortalAssetEndpoints
from portal_assets_lambda.services.embed_quick_sight import EmbedQuickSight
from tests.conftest import ENV
from common.utils.api_request_handler import BootstrapEndpoints
from portal_assets_lambda.main import handle_api_request


@patch("portal_assets_lambda.main.get_clients")
def test_handle_request_error(_):
    with patch.object(
        BootstrapEndpoints,
        "get_endpoint_from_api_event",
        return_value=None,
    ):
        mock_event = {
            "httpMethod": "GET",
            "path": "/nonsense_route",
        }

        response = handle_api_request(mock_event, {})

        assert response["statusCode"] == 400
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["error"] is not None


@patch("portal_assets_lambda.main.get_clients")
def test_get_asset_by_id(
    _, mock_success_get_asset_by_id_event, mock_raw_get_asset_by_id_response
):
    mock_os_client = MagicMock(OpenSearch)
    mock_os_client.get.return_value = mock_raw_get_asset_by_id_response

    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": {},
                "opensearch": mock_os_client,
                "dynamodb": {},
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_asset_by_id_event, {})

        mock_os_client.get.assert_called_with(
            **{
                "index": ANY,
                "id": mock_success_get_asset_by_id_event["pathParameters"]["asset_id"],
            }
        )

        assert response["statusCode"] == 200

        body = json.loads(response["body"])

        assert body["found"] == True
        assert len(body["_source"]["sheets"]) > 0
        assert len(body["_source"]["owners"]) > 0
        assert body["_source"]["updated_at"] is not None
        assert body["_source"]["asset_display_name"] is not None
        assert body["_source"]["department"] == "Finance"
        assert (
            body["_source"]["asset_id"]
            == mock_success_get_asset_by_id_event["pathParameters"]["asset_id"]
        )


mock_user_dynamo_resp = {
    "email": {"S": "test@cppib.com"},
    "display_name": {"S": "Test, McTest"},
    "department": {"S": "Technology & Operations"},
    "geo": {"S": "CAN"},
    "sub_department": {"S": "COST"},
    "last_seen": {"S": "2025-01-07T15:52:34Z"},
    "additional_departments": {"SS": ["Technology & Operations", "Finance"]},
    "additional_sub_departments": {"SS": ["COST"]},
    "additional_geos": {"SS": ["CAN"]},
}

mock_rls_dynamo_resp = [
    {
        "workspace_id": {"S": "bif-ma"},
        "dataset_id": {"S": "cost_insights_report"},
        "rls_mappings": {
            "L": [
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "department"},
                                "authorized_group": {"S": "Technology & Operations"},
                                "authorized_values": {
                                    "S": "technology_cost,software_cost"
                                },
                            }
                        },
                        {
                            "M": {
                                "tag_type": {"S": "geo"},
                                "authorized_group": {"S": "CAN"},
                                "authorized_values": {"S": "Canada"},
                            }
                        },
                    ]
                },
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "department"},
                                "authorized_group": {"S": "Finance"},
                                "authorized_values": {"S": "*"},
                            }
                        },
                        {
                            "M": {
                                "tag_type": {"S": "geo"},
                                "authorized_group": {"S": "IN"},
                                "authorized_values": {"S": "apac"},
                            }
                        },
                        {
                            "M": {
                                "tag_type": {"S": "sub_department"},
                                "authorized_group": {"S": "COST"},
                                "authorized_values": {
                                    "S": "aws_costs,azure_active_directory"
                                },
                            }
                        },
                    ]
                },
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "department"},
                                "authorized_group": {"S": "Finance"},
                                "authorized_values": {"S": "*"},
                            }
                        },
                        {
                            "M": {
                                "tag_type": {"S": "sub_department"},
                                "authorized_group": {"S": "MA"},
                                "authorized_values": {"S": "capital_exp"},
                            }
                        },
                    ]
                },
            ]
        },
    },
    {
        "workspace_id": {"S": "bif-ma"},
        "dataset_id": {"S": "dataset2"},
        "rls_mappings": {
            "L": [
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "geo"},
                                "authorized_group": {"S": "CAN"},
                                "authorized_values": {"S": "*"},
                            }
                        }
                    ]
                },
            ]
        },
    },
]


mock_rls_dynamo_resp_with_email_rls = [
    {
        "workspace_id": {"S": "bif-ma"},
        "dataset_id": {"S": "cost_insights_report"},
        "rls_mappings": {
            "L": [
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "department"},
                                "authorized_group": {"S": "Finance"},
                                "authorized_values": {"S": "*"},
                            }
                        },
                        {
                            "M": {
                                "tag_type": {"S": "sub_department"},
                                "authorized_group": {"S": "MA"},
                                "authorized_values": {"S": "capital_exp"},
                            }
                        },
                    ]
                },
            ]
        },
        "rls_by_email_mappings": {
            "L": [
                {
                    "M": {
                        "emails": {"L": [{"S": "test@cppib.com"}]},
                        "rule_groups": {
                            "L": [
                                {
                                    "M": {
                                        "authorized_values": {"S": "*"},
                                        "column_name": {"S": "model_portfolio_id"},
                                    }
                                },
                                {
                                    "M": {
                                        "authorized_values": {"S": "123"},
                                        "column_name": {"S": "portfolio_id"},
                                    }
                                },
                            ]
                        },
                    }
                }
            ]
        },
    },
    {
        "workspace_id": {"S": "bif-ma"},
        "dataset_id": {"S": "dataset2"},
        "rls_mappings": {
            "L": [
                {
                    "L": [
                        {
                            "M": {
                                "tag_type": {"S": "geo"},
                                "authorized_group": {"S": "CAN"},
                                "authorized_values": {"S": "*"},
                            }
                        }
                    ]
                },
            ]
        },
    },
]


mock_asset_level_security_dynamo_resp = [
    {
        "asset_id": {"S": "ma_insight_cost_dashboard"},
        "whitelist": {"SS": [""]},
        "viewers": {"SS": ["test@cppib.com"]},
    },
]


def _mock_embed_quick_sight(logger=None):
    return EmbedQuickSight(
        logger or MagicMock(),
        {"quicksight": MagicMock(), "opensearch": MagicMock(), "dynamodb": MagicMock()},
        ENV,
    )


def _make_user(email="ghelmer@cppib.com"):
    from common.models.user import User
    return User(
        email=email,
        display_name="Helmer, Gail",
        department="Talent",
        sub_department="HR Reporting",
        geo="CAN",
    )


def _make_als(whitelist=None, viewers=None, asset_id="master_position_management_dashboard-bif-talent-dev"):
    from common.models.asset_level_security import AssetLevelSecurity
    return AssetLevelSecurity(
        asset_id=asset_id,
        whitelist=set(whitelist or []),
        viewers=set(viewers or []),
    )


def _mock_qs_paginator(group_members_by_name):
    """Build a mock QuickSight client whose list_group_memberships paginator
    returns the supplied per-group member lists. Unknown groups return empty."""
    def paginate(GroupName, AwsAccountId, Namespace):
        members = group_members_by_name.get(GroupName, [])
        return iter([{"GroupMemberList": [{"MemberName": m} for m in members]}])

    paginator = MagicMock()
    paginator.paginate.side_effect = paginate
    qs_client = MagicMock()
    qs_client.get_paginator.return_value = paginator
    return qs_client


def test_validate_user_access_skips_when_no_als():
    service = _mock_embed_quick_sight()
    service._validate_user_access_to_dashboard(_make_user(), [])
    service.qs_client.get_paginator.assert_not_called()


def test_validate_user_access_allows_direct_email_match():
    service = _mock_embed_quick_sight()
    als = _make_als(whitelist=["ghelmer@cppib.com"])
    service._validate_user_access_to_dashboard(_make_user(), [als])
    # Literal match short-circuits before any AD-group lookup.
    service.qs_client.get_paginator.assert_not_called()


def test_validate_user_access_allows_ad_group_member():
    service = _mock_embed_quick_sight()
    service.qs_client = _mock_qs_paginator({
        "AWS_SSO_QS_Viewer_HRReporting_TSS": ["ghelmer@cppib.com"],
    })
    als = _make_als(viewers=["AWS_SSO_QS_Viewer_HRReporting_TSS"])
    service._validate_user_access_to_dashboard(_make_user(), [als])
    service.qs_client.get_paginator.assert_called_with("list_group_memberships")


def test_validate_user_access_denies_when_not_in_whitelist_viewers_or_any_ad_group():
    service = _mock_embed_quick_sight()
    service.qs_client = _mock_qs_paginator({
        "AWS_SSO_QS_Viewer_HRReporting_TSS": ["someone.else@cppib.com"],
    })
    als = _make_als(viewers=["AWS_SSO_QS_Viewer_HRReporting_TSS"])
    import pytest
    with pytest.raises(PermissionError):
        service._validate_user_access_to_dashboard(_make_user(), [als])


def test_validate_user_access_continues_past_failed_group_lookup_and_finds_match():
    service = _mock_embed_quick_sight()
    paginator = MagicMock()
    paginator.paginate.side_effect = [
        Exception("Throttled"),
        iter([{"GroupMemberList": [{"MemberName": "ghelmer@cppib.com"}]}]),
    ]
    service.qs_client.get_paginator.return_value = paginator
    als = _make_als(viewers=[
        "AWS_SSO_QS_Viewer_HRReporting_TSS",
        "AWS_SSO_QS_Viewer_HRReporting_GlobalMobility",
    ])
    service._validate_user_access_to_dashboard(_make_user(), [als])


def test_validate_user_access_denies_when_only_non_ad_group_strings_in_viewers():
    # Defensive: a stray non-AD principal string should not trigger group lookup
    # or grant access by accident.
    service = _mock_embed_quick_sight()
    als = _make_als(viewers=["some-other-principal"])
    import pytest
    with pytest.raises(PermissionError):
        service._validate_user_access_to_dashboard(_make_user(), [als])
    service.qs_client.get_paginator.assert_not_called()


def test_get_user_attributes_params_url_encodes_values_and_preserves_multivalue():
    mock_event = MagicMock()
    mock_event.get_email.return_value = "test.user@cppib.com"
    # Forward-compat: multi-value branch is currently unreachable since Cognito
    # claim getters return strings, but the impl supports it for future use.
    mock_event.get_department.return_value = [
        "Technology & Operations",
        "Technology & Data",
    ]
    mock_event.get_sub_department.return_value = "A/B=C#D"
    mock_event.get_geo_location.return_value = "CAN"

    params = _mock_embed_quick_sight().get_user_attributes_params(mock_event)

    assert "p.cppibEmail=test.user%40cppib.com" in params
    assert "p.cppibDepartment=Technology%20%26%20Operations" in params
    assert "p.cppibDepartment=Technology%20%26%20Data" in params
    assert "p.cppibSubDepartment=A%2FB%3DC%23D" in params
    assert "p.cppibGeo=CAN" in params
    assert "Technology & Operations" not in params
    assert "A/B=C#D" not in params


def test_add_user_attributes_as_dashboard_params_uses_existing_fragment_separator():
    mock_event = MagicMock()
    mock_event.get_email.return_value = "test.user@cppib.com"
    mock_event.get_department.return_value = "Technology & Operations"
    mock_event.get_sub_department.return_value = "A/B=C#D"
    mock_event.get_geo_location.return_value = "CAN"

    response = _mock_embed_quick_sight().add_user_attributes_as_dashboard_params(
        {"EmbedUrl": "https://quicksight.aws.amazon.com/embed?code=SECRET#existing=true"},
        mock_event,
    )

    assert response["EmbedUrl"].count("#") == 1
    assert "#existing=true&p.cppibEmail=test.user%40cppib.com" in response["EmbedUrl"]
    assert "&p.cppibDepartment=Technology%20%26%20Operations" in response["EmbedUrl"]


def test_add_user_attributes_as_dashboard_params_uses_hash_when_no_fragment():
    mock_event = MagicMock()
    mock_event.get_email.return_value = "test.user@cppib.com"
    mock_event.get_department.return_value = "Technology & Operations"
    mock_event.get_sub_department.return_value = "Technology & Data"
    mock_event.get_geo_location.return_value = "CAN"

    response = _mock_embed_quick_sight().add_user_attributes_as_dashboard_params(
        {"EmbedUrl": "https://quicksight.aws.amazon.com/embed?code=xyz&isauthcode=true"},
        mock_event,
    )

    assert response["EmbedUrl"].count("#") == 1
    assert "isauthcode=true#p.cppibEmail=test.user%40cppib.com" in response["EmbedUrl"]
    assert "&p.cppibDepartment=Technology%20%26%20Operations" in response["EmbedUrl"]


def test_add_user_attributes_as_dashboard_params_does_not_log_embed_url_or_auth_code():
    logger = MagicMock()
    mock_event = MagicMock()
    mock_event.get_email.return_value = "test.user@cppib.com"
    mock_event.get_department.return_value = "Technology & Operations"
    mock_event.get_sub_department.return_value = "A/B=C#D"
    mock_event.get_geo_location.return_value = "CAN"

    _mock_embed_quick_sight(logger).add_user_attributes_as_dashboard_params(
        {"EmbedUrl": "https://quicksight.aws.amazon.com/embed?code=SECRET"},
        mock_event,
    )

    logged_messages = " ".join(str(call) for call in logger.info.call_args_list)
    assert "SECRET" not in logged_messages
    assert "code=SECRET" not in logged_messages
    assert "https://quicksight.aws.amazon.com" not in logged_messages


@patch("portal_assets_lambda.main.get_clients")
def test_success_embed_qs_url_session_tags(
    _, mock_raw_get_asset_by_id_response, mock_success_get_embed_url_event
):

    mock_search_client = MagicMock(OpenSearch)
    mock_search_client.get.return_value = mock_raw_get_asset_by_id_response

    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.batch_get_item.return_value = {
        "Responses": {
            ENV["USER_TABLE"]: [mock_user_dynamo_resp],
            ENV["DATASET_RLS_TABLE"]: mock_rls_dynamo_resp,
            ENV["ASSET_LEVEL_SECURITY_TABLE"]: mock_asset_level_security_dynamo_resp,
        },
        "UnprocessedKeys": {},
    }

    mock_qs_client = MagicMock()
    mock_qs_client.generate_embed_url_for_anonymous_user.return_value = {
        "Status": 200,
        "AnonymousUserArn": f"arn:aws:quicksight:{ENV['AWS_REGION_NAME']}:{ENV['QUICKSIGHT_ACCOUNT_ID']}",
        "EmbedUrl": "https://embed_url.com",
        "RequestId": "request-id-1",
    }
    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": mock_qs_client,
                "opensearch": mock_search_client,
                "dynamodb": mock_dynamodb_client,
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_embed_url_event, {})

        assert response["statusCode"] == 200
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["EmbedUrl"] is not None

        mock_qs_client.generate_embed_url_for_anonymous_user.assert_called_with(
            **{
                "AwsAccountId": ANY,
                "Namespace": ANY,
                "AuthorizedResourceArns": ANY,
                "ExperienceConfiguration": ANY,
                "SessionLifetimeInMinutes": ANY,
                "SessionTags": [
                    {
                        "Key": "cost_insights_report-department",
                        "Value": "*",
                    },
                    {"Key": "cost_insights_report-geo", "Value": "Canada"},
                    {
                        "Key": "cost_insights_report-sub_department",
                        "Value": "aws_costs,azure_active_directory",
                    },
                    {"Key": "dataset2-geo", "Value": "*"},
                ],
            }
        )


@patch("portal_assets_lambda.main.get_clients")
def test_success_embed_qs_url_no_rls_session_tags(
    _, mock_raw_get_asset_by_id_response, mock_success_get_embed_url_event
):

    mock_search_client = MagicMock(OpenSearch)
    mock_search_client.get.return_value = mock_raw_get_asset_by_id_response

    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.batch_get_item.return_value = {
        "Responses": {
            ENV["USER_TABLE"]: [mock_user_dynamo_resp],
            ENV["DATASET_RLS_TABLE"]: [],
            ENV["ASSET_LEVEL_SECURITY_TABLE"]: mock_asset_level_security_dynamo_resp,
        },
        "UnprocessedKeys": {},
    }

    mock_qs_client = MagicMock()
    mock_qs_client.generate_embed_url_for_anonymous_user.return_value = {
        "Status": 200,
        "AnonymousUserArn": f"arn:aws:quicksight:{ENV['AWS_REGION_NAME']}:{ENV['QUICKSIGHT_ACCOUNT_ID']}",
        "EmbedUrl": "https://embed_url.com",
        "RequestId": "request-id-1",
    }
    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": mock_qs_client,
                "opensearch": mock_search_client,
                "dynamodb": mock_dynamodb_client,
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_embed_url_event, {})

        assert response["statusCode"] == 200
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["EmbedUrl"] is not None

        mock_qs_client.generate_embed_url_for_anonymous_user.assert_called_with(
            **{
                "AwsAccountId": ANY,
                "Namespace": ANY,
                "AuthorizedResourceArns": ANY,
                "ExperienceConfiguration": ANY,
                "SessionLifetimeInMinutes": ANY,
            }
        )


@patch("portal_assets_lambda.main.get_clients")
def test_success_embed_qs_url_asset_whitelist_session_tags(
    _, mock_raw_get_asset_by_id_response, mock_success_get_embed_url_event
):

    mock_search_client = MagicMock(OpenSearch)
    mock_search_client.get.return_value = mock_raw_get_asset_by_id_response

    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.batch_get_item.return_value = {
        "Responses": {
            ENV["USER_TABLE"]: [mock_user_dynamo_resp],
            ENV["DATASET_RLS_TABLE"]: mock_rls_dynamo_resp,
            ENV["ASSET_LEVEL_SECURITY_TABLE"]: [
                {
                    **mock_asset_level_security_dynamo_resp[0],
                    "whitelist": {"SS": ["test@cppib.com"]},
                }
            ],
        },
        "UnprocessedKeys": {},
    }

    mock_qs_client = MagicMock()
    mock_qs_client.generate_embed_url_for_anonymous_user.return_value = {
        "Status": 200,
        "AnonymousUserArn": f"arn:aws:quicksight:{ENV['AWS_REGION_NAME']}:{ENV['QUICKSIGHT_ACCOUNT_ID']}",
        "EmbedUrl": "https://embed_url.com",
        "RequestId": "request-id-1",
    }
    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": mock_qs_client,
                "opensearch": mock_search_client,
                "dynamodb": mock_dynamodb_client,
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_embed_url_event, {})

        assert response["statusCode"] == 200
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["EmbedUrl"] is not None

        mock_qs_client.generate_embed_url_for_anonymous_user.assert_called_with(
            **{
                "AwsAccountId": ANY,
                "Namespace": ANY,
                "AuthorizedResourceArns": ANY,
                "ExperienceConfiguration": ANY,
                "SessionLifetimeInMinutes": ANY,
                "SessionTags": [
                    {"Key": "cost_insights_report-department", "Value": "*"},
                    {"Key": "cost_insights_report-geo", "Value": "*"},
                    {"Key": "cost_insights_report-sub_department", "Value": "*"},
                    {"Key": "dataset2-geo", "Value": "*"},
                ],
            }
        )


@patch("portal_assets_lambda.main.get_clients")
def test_success_embed_qs_url_session_tags_asset_not_in_es(
    _, mock_success_get_embed_url_event
):

    mock_search_client = MagicMock(OpenSearch)
    mock_search_client.get.return_value = {}

    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.batch_get_item.return_value = {
        "Responses": {
            ENV["USER_TABLE"]: [mock_user_dynamo_resp],
            ENV["DATASET_RLS_TABLE"]: [],
            ENV["ASSET_LEVEL_SECURITY_TABLE"]: mock_asset_level_security_dynamo_resp,
        },
        "UnprocessedKeys": {},
    }

    mock_qs_client = MagicMock()
    mock_qs_client.generate_embed_url_for_anonymous_user.return_value = {
        "Status": 200,
        "AnonymousUserArn": f"arn:aws:quicksight:{ENV['AWS_REGION_NAME']}:{ENV['QUICKSIGHT_ACCOUNT_ID']}",
        "EmbedUrl": "https://embed_url.com",
        "RequestId": "request-id-1",
    }
    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": mock_qs_client,
                "opensearch": mock_search_client,
                "dynamodb": mock_dynamodb_client,
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_embed_url_event, {})

        assert response["statusCode"] == 200
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["EmbedUrl"] is not None

        mock_qs_client.generate_embed_url_for_anonymous_user.assert_called_with(
            **{
                "AwsAccountId": ANY,
                "Namespace": ANY,
                "AuthorizedResourceArns": ANY,
                "ExperienceConfiguration": ANY,
                "SessionLifetimeInMinutes": ANY,
            }
        )


@patch("portal_assets_lambda.main.get_clients")
def test_success_embed_qs_url_session_tags_with_email_rls(
    _, mock_raw_get_asset_by_id_response, mock_success_get_embed_url_event
):

    mock_search_client = MagicMock(OpenSearch)
    mock_search_client.get.return_value = mock_raw_get_asset_by_id_response

    mock_dynamodb_client = MagicMock()
    mock_dynamodb_client.batch_get_item.return_value = {
        "Responses": {
            ENV["USER_TABLE"]: [mock_user_dynamo_resp],
            ENV["DATASET_RLS_TABLE"]: mock_rls_dynamo_resp_with_email_rls,
            ENV["ASSET_LEVEL_SECURITY_TABLE"]: mock_asset_level_security_dynamo_resp,
        },
        "UnprocessedKeys": {},
    }

    mock_qs_client = MagicMock()
    mock_qs_client.generate_embed_url_for_anonymous_user.return_value = {
        "Status": 200,
        "AnonymousUserArn": f"arn:aws:quicksight:{ENV['AWS_REGION_NAME']}:{ENV['QUICKSIGHT_ACCOUNT_ID']}",
        "EmbedUrl": "https://embed_url.com",
        "RequestId": "request-id-1",
    }
    with patch(
        "portal_assets_lambda.main.PortalAssetEndpoints",
        return_value=PortalAssetEndpoints(
            logging.getLogger(),
            {
                "quicksight": mock_qs_client,
                "opensearch": mock_search_client,
                "dynamodb": mock_dynamodb_client,
                "s3": MagicMock(),
            },
            ENV,
        ),
    ):
        response = handle_api_request(mock_success_get_embed_url_event, {})

        assert response["statusCode"] == 200
        assert "body" in response

        response_body = json.loads(response["body"])

        assert response_body["EmbedUrl"] is not None

        mock_qs_client.generate_embed_url_for_anonymous_user.assert_called_with(
            **{
                "AwsAccountId": ANY,
                "Namespace": ANY,
                "AuthorizedResourceArns": ANY,
                "ExperienceConfiguration": ANY,
                "SessionLifetimeInMinutes": ANY,
                "SessionTags": [
                    {
                        "Key": "cost_insights_report-model_portfolio_id-email",
                        "Value": "*",
                    },
                    {
                        "Key": "cost_insights_report-portfolio_id-email",
                        "Value": "123",
                    },
                    {
                        "Key": "dataset2-geo",
                        "Value": "*",
                    },
                ],
            }
        )
