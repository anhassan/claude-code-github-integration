import logging
from unittest.mock import MagicMock

from common.utils.api_request_handler import ApiRequestHandler


def test_options_response_includes_preflight_cache_header():
    handler = ApiRequestHandler(MagicMock(), logging.getLogger())

    response = handler.handle_api_request(
        {"resource": "/user/login", "httpMethod": "OPTIONS"}, {}
    )

    assert response["statusCode"] == 200
    assert response["headers"]["Access-Control-Max-Age"] == "7200"


def test_responses_are_never_browser_cacheable():
    # The headers dict is shared by every response path; embed_url responses
    # carry single-use QuickSight auth codes, so a cached replay (e.g. on a
    # back/forward navigation) redeems a dead code and breaks embedding.
    handler = ApiRequestHandler(MagicMock(), logging.getLogger())

    response = handler.handle_api_request(
        {"resource": "/user/login", "httpMethod": "OPTIONS"}, {}
    )

    assert response["headers"]["Cache-Control"] == "no-store"
