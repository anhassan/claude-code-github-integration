# tests/test_seed_risk_dashboard_definitions.py
from scripts.seed_risk_dashboard_definitions import (
    source_key,
    target_key,
    plan_copy,
)


def test_source_key_is_two_level_latest():
    assert source_key("ARS-FICC Dashboard") == "ARS-FICC Dashboard/latest/dashboard_definition.json"


def test_target_key_is_three_level():
    assert target_key("RiskARSFICC", "DEVELOP") == "RiskARSFICC/DEVELOP/latest/dashboard_definition.json"


def test_plan_copy_builds_copy_source_struct():
    plan = plan_copy(
        bucket="bi-foundations-published-qs-definitions",
        migrated_name="ARS-FICC Dashboard",
        base_dashboard_name="RiskARSFICC",
        branch="DEVELOP",
    )
    assert plan["bucket"] == "bi-foundations-published-qs-definitions"
    assert plan["copy_source"] == {
        "Bucket": "bi-foundations-published-qs-definitions",
        "Key": "ARS-FICC Dashboard/latest/dashboard_definition.json",
    }
    assert plan["dest_key"] == "RiskARSFICC/DEVELOP/latest/dashboard_definition.json"


# ---- sanitize_definition (grandfathered empty-value filters) ----
from scripts.seed_risk_dashboard_definitions import sanitize_definition


def _bad_filter(null_option="NON_NULLS_ONLY"):
    cfc = {"MatchOperator": "DOES_NOT_EQUAL", "CategoryValue": ""}
    if null_option:
        cfc["NullOption"] = null_option
    return {
        "FilterId": "f1",
        "Column": {"DataSetIdentifier": "ds", "ColumnName": "investment_dept"},
        "Configuration": {"CustomFilterConfiguration": cfc},
    }


def test_sanitize_rewrites_empty_value_does_not_equal():
    doc = {"Definition": {"FilterGroups": [{"Filters": [{"CategoryFilter": _bad_filter()}]}]}}
    doc, patched = sanitize_definition(doc)
    assert patched == 1
    cfc = doc["Definition"]["FilterGroups"][0]["Filters"][0]["CategoryFilter"]["Configuration"][
        "CustomFilterConfiguration"
    ]
    assert cfc == {
        "MatchOperator": "DOES_NOT_EQUAL",
        "SelectAllOptions": "FILTER_ALL_VALUES",
        "NullOption": "NON_NULLS_ONLY",
    }
    assert "CategoryValue" not in cfc


def test_sanitize_omits_null_option_when_absent():
    doc = {"Definition": {"FilterGroups": [{"Filters": [{"CategoryFilter": _bad_filter(null_option=None)}]}]}}
    doc, patched = sanitize_definition(doc)
    assert patched == 1
    cfc = doc["Definition"]["FilterGroups"][0]["Filters"][0]["CategoryFilter"]["Configuration"][
        "CustomFilterConfiguration"
    ]
    assert "NullOption" not in cfc


def test_sanitize_leaves_parameter_filters_alone():
    f = _bad_filter()
    f["Configuration"]["CustomFilterConfiguration"]["ParameterName"] = "myParam"
    del f["Configuration"]["CustomFilterConfiguration"]["CategoryValue"]
    doc = {"Definition": {"FilterGroups": [{"Filters": [{"CategoryFilter": f}]}]}}
    before = repr(doc)
    doc, patched = sanitize_definition(doc)
    assert patched == 0
    assert repr(doc) == before


def test_sanitize_leaves_real_category_values_alone():
    f = _bad_filter()
    f["Configuration"]["CustomFilterConfiguration"]["CategoryValue"] = "Equities"
    doc = {"Definition": {"FilterGroups": [{"Filters": [{"CategoryFilter": f}]}]}}
    before = repr(doc)
    doc, patched = sanitize_definition(doc)
    assert patched == 0
    assert repr(doc) == before


def test_sanitize_idempotent_on_already_fixed():
    doc = {"Definition": {"FilterGroups": [{"Filters": [{"CategoryFilter": _bad_filter()}]}]}}
    doc, first = sanitize_definition(doc)
    doc, second = sanitize_definition(doc)
    assert (first, second) == (1, 0)


def test_sanitize_counts_multiple_across_nesting():
    doc = {
        "Definition": {
            "FilterGroups": [
                {"Filters": [{"CategoryFilter": _bad_filter()}, {"CategoryFilter": _bad_filter()}]},
                {"Filters": [{"CategoryFilter": _bad_filter()}]},
            ]
        }
    }
    _, patched = sanitize_definition(doc)
    assert patched == 3
