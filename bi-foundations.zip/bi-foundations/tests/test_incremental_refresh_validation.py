"""PR-time validation for the incremental_refresh metadata block."""

from common.utils.validate import validate_dataset_metadata_file


def _meta(**over):
    m = {
        "name": "rmv_analytics",
        "import_mode": "SPICE",
        "workspaces": ["bif-risk"],
        "columns": {"business_date_dt": "DATETIME", "analytic_value": "DECIMAL"},
    }
    m.update(over)
    return m


def _incr_errors(meta):
    return [e for e in validate_dataset_metadata_file(meta, "metadata") if "incremental" in str(e).lower()]


def test_valid_incremental_refresh_has_no_errors():
    meta = _meta(
        incremental_refresh={"column_name": "business_date_dt", "size": 14, "size_unit": "DAY"}
    )
    assert validate_dataset_metadata_file(meta, "metadata") == []


def test_incremental_refresh_non_datetime_column_errors():
    meta = _meta(
        incremental_refresh={"column_name": "analytic_value", "size": 14, "size_unit": "DAY"}
    )
    errs = _incr_errors(meta)
    assert any("analytic_value" in e and "date" in e.lower() for e in errs)


def test_incremental_refresh_unknown_column_errors():
    meta = _meta(
        incremental_refresh={"column_name": "does_not_exist", "size": 14, "size_unit": "DAY"}
    )
    assert any("does_not_exist" in e for e in _incr_errors(meta))


def test_incremental_refresh_bad_size_unit_errors():
    meta = _meta(
        incremental_refresh={"column_name": "business_date_dt", "size": 14, "size_unit": "MONTH"}
    )
    assert any("size_unit" in e for e in _incr_errors(meta))


def test_incremental_refresh_non_positive_size_errors():
    meta = _meta(
        incremental_refresh={"column_name": "business_date_dt", "size": 0, "size_unit": "DAY"}
    )
    assert any("size" in e for e in _incr_errors(meta))


def test_incremental_refresh_requires_spice():
    meta = _meta(
        import_mode="DIRECT_QUERY",
        incremental_refresh={"column_name": "business_date_dt", "size": 14, "size_unit": "DAY"},
    )
    assert any("SPICE" in e for e in _incr_errors(meta))


def test_incremental_schedule_without_block_errors():
    meta = _meta(
        refresh_schedule=[{"ScheduleId": "x", "RefreshType": "INCREMENTAL_REFRESH"}]
    )
    assert any("INCREMENTAL_REFRESH" in e for e in _incr_errors(meta))
