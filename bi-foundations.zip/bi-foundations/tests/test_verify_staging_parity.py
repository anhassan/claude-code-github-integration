import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.verify_staging_parity import discover_pairs, is_managed_id, normalize


def test_is_managed_id():
    assert is_managed_id("tfm_financing_balance_sheet_mgmt-bif-risk-dev")
    assert is_managed_id("nac-bif-ma-uat")
    assert not is_managed_id("1e27d052-93e4-42ae-9847-cb688b7f08c5")
    assert not is_managed_id("ae_transactions_analysis")


def test_discover_pairs_simple_pair_and_ambiguous():
    summaries = [
        {"Name": "TFM Financing", "DashboardId": "tfm_financing-bif-risk-dev"},
        {"Name": "TFM Financing", "DashboardId": "1e27d052-93e4-42ae-9847-cb688b7f08c5"},
        {"Name": "Solo Managed", "DashboardId": "solo-bif-risk-dev"},
        {"Name": "Test Pipeline", "DashboardId": "a-bif-ma-dev"},
        {"Name": "Test Pipeline", "DashboardId": "b-bif-ma-dev"},
        {"Name": "Test Pipeline", "DashboardId": "0f88fb9f-583f-439e-9c34-d2740f3093da"},
    ]
    pairs, ambiguous = discover_pairs(summaries)
    assert pairs == {
        "TFM Financing": ("tfm_financing-bif-risk-dev", "1e27d052-93e4-42ae-9847-cb688b7f08c5")
    }
    assert ambiguous == ["Test Pipeline"]


def test_normalize_drops_identity_but_keeps_content():
    payload = {
        "DashboardId": "x",
        "Name": "n",
        "RequestId": "r",
        "ResponseMetadata": {"HTTPStatusCode": 200},
        "ThemeArn": "arn:aws:quicksight::aws:theme/RAINIER",
        "Definition": {"Sheets": [{"SheetId": "s1"}]},
    }
    norm = normalize(payload)
    assert "DashboardId" not in norm and "ResponseMetadata" not in norm
    assert norm["ThemeArn"].endswith("RAINIER")
    assert norm["Definition"]["Sheets"] == [{"SheetId": "s1"}]
    # input not mutated
    assert payload["DashboardId"] == "x"


def test_canonicalize_is_list_order_blind():
    from scripts.verify_staging_parity import canonicalize

    a = {"FilterGroups": [{"FilterGroupId": "b"}, {"FilterGroupId": "a"}]}
    b = {"FilterGroups": [{"FilterGroupId": "a"}, {"FilterGroupId": "b"}]}
    assert canonicalize(a) == canonicalize(b)
    # real content drift still differs
    c = {"FilterGroups": [{"FilterGroupId": "a"}, {"FilterGroupId": "X"}]}
    assert canonicalize(a) != canonicalize(c)
