import boto3
import json

qs_client = boto3.client("quicksight", region_name="us-east-1")

def describe_dashboard_definition(AwsAccountId, DashboardId):
    response = qs_client.describe_dashboard_definition(
        AwsAccountId=AwsAccountId,
        DashboardId=DashboardId
    )
    return response

def write_dashboard_definition_to_disk(dashboard_definition,file_name):
    with open(file_name, "w") as f:
        json.dump(dashboard_definition, f, indent=4, default=str)

def get_account_id():
    sts_client = boto3.client("sts")
    return sts_client.get_caller_identity()["Account"]


d1_id = "27221d1f-da9c-429c-8650-65f748c45db0"
file_name_d1 = "{}.json".format(d1_id)

d2_id = "master_talent_turnover_dashboard-bif-talent-dev"
file_name_d2 = "{}.json".format(d2_id)

if __name__ == "__main__":
    ACCOUNT_ID = get_account_id()
    d_definition = describe_dashboard_definition(ACCOUNT_ID, d1_id)
    write_dashboard_definition_to_disk(d_definition, file_name_d1)
