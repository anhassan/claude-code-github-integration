"""
Convert a QuickSight dashboard definition JSON (from describe_dashboard_definition)
into an analysis definition JSON suitable for create_analysis / update_analysis API calls.

The Definition block is identical between dashboards and analyses —
only `DashboardPublishOptions` is dashboard-specific and gets dropped.
"""

import json
import sys
from pathlib import Path


def convert_dashboard_to_analysis(source_path, output_path=None):
    source_path = Path(source_path)
    with source_path.open(encoding="utf-8") as f:
        dashboard = json.load(f)

    # Extract key fields
    dashboard_id = dashboard.get("DashboardId", "")
    name = dashboard.get("Name", "")
    theme_arn = dashboard.get("ThemeArn")
    definition = dashboard.get("Definition")

    if not definition:
        print("ERROR: No 'Definition' block found in the source file.")
        sys.exit(1)

    # Build analysis payload (ready for create_analysis API)
    analysis = {
        "AwsAccountId": "200967598245",
        "AnalysisId": dashboard_id,
        "Name": name,
        "Definition": definition,
        "ValidationStrategy": {"Mode": "LENIENT"},
    }
    if theme_arn:
        analysis["ThemeArn"] = theme_arn

    # Write output
    if not output_path:
        output_path = source_path.with_name(
            source_path.stem + "_analysis_definition.json"
        )
    else:
        output_path = Path(output_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(analysis, f, indent=2, default=str)
        f.write("\n")

    print(f"✓ Analysis definition written to: {output_path}")
    print(f"  AnalysisId: {analysis['AnalysisId']}")
    print(f"  Name:       {analysis['Name']}")
    print(f"  ThemeArn:   {analysis.get('ThemeArn', 'N/A')}")
    print(f"  Sheets:     {len(definition.get('Sheets', []))}")
    print()
    print("To create the analysis via AWS CLI:")
    print(f"  aws quicksight create-analysis --cli-input-json file://{output_path.name}")
    print()
    print("Or via boto3:")
    print("  import json, boto3")
    print(f"  params = json.load(open('{output_path.name}'))")
    print("  qs = boto3.client('quicksight')")
    print("  qs.create_analysis(**params)")


if __name__ == "__main__":
    source = sys.argv[1] if len(sys.argv) > 1 else "27221d1f-da9c-429c-8650-65f748c45db0.json"
    output = sys.argv[2] if len(sys.argv) > 2 else None
    convert_dashboard_to_analysis(source, output)
