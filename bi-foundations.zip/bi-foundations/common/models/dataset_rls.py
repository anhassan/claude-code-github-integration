from dataclasses import dataclass, field
from datetime import datetime, UTC
from typing import List, Literal, Optional, Set


@dataclass
class RlsMapping:
    """
    Represents a single RLS tag mapping:
    'tag_type': is the TagKey suffix;
    'authorized_group': is the group name for members of 'tag_type' who have authorized values;
    'authorized_values' is the filter for which values the group is allowed to see.
    """

    tag_type: Literal["department", "sub_department", "geo"]
    authorized_group: str
    authorized_values: str  # comma separated values
    column_name: Optional[str] = ""


@dataclass
class RlsEmailRule:
    column_name: str  # name of the column in the dataset whose values are are allowed for an email
    authorized_values: str  # comma separated values


@dataclass
class RlsEmailMapping:
    """
    Represents a custom RLS tag mapping determined by email that supersedes RLS by department/sub_department/geo.

    'emails': is the set of emails for which these RLS rules apply
    'rule_groups': is the list of configuration objects treated as AND conditions that apply to the dataset
    """

    emails: Set[str]
    rule_groups: List[RlsEmailRule]


@dataclass
class DatasetRls:
    """
    Represents the lookup table for assets using datasets with RLS.

    'workspace_id: represents the github project associated with the dataset. for e.g bif_ma
    'dataset_id': <dataset name> which corresponds to the unique workspace QS dataset.

    'rls_mappings': a list of lists, where the List[RlsMapping] is expected to contain an RlsMapping for up to one of each type.
    RlsMappings in this list are considered as an 'AND' condition for the purposes of filtering data.
    Each list of RlsMapping in the parent list are considered 'OR' conditions.

    'rls_by_email_mappings': a list of objects, where specific emails are mapped to column:values pairs 
    such that rls is applied based on the pairs if the email is associated with the rule group. 
    This mapping supersedes rls by user claims, which means that if the user has rls_by_email_mappings, other rls_mappings will be ignored when embedding.
    """

    workspace_id: str
    dataset_id: str
    rls_mappings: List[List[RlsMapping]] = field(default_factory=list)
    rls_by_email_mappings: List[RlsEmailMapping] = field(default_factory=list)
    last_updated: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
