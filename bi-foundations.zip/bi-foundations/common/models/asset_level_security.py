from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Set

from common.models.user import User


@dataclass
class AssetLevelSecurity:
    asset_id: str
    last_updated: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    # emails in the whitelist bypass RLS for the dashboard to see everything
    whitelist: Set[str] = field(default_factory=set)
    # emails in the viewers set still have RLS applied
    viewers: Set[str] = field(default_factory=set)

    def __post_init__(self):
        """
        Adds empty string to the string sets to allow initialization in Dynamodb.
        """
        if not self.whitelist:
            self.whitelist.add("")

        if not self.viewers:
            self.viewers.add("")

    def can_user_access(self, user: User) -> bool:
        return any([user.email in self.whitelist, user.email in self.viewers])
