from dataclasses import dataclass, field
from datetime import datetime, UTC
from typing import Set


@dataclass
class User:
    email: str
    display_name: str
    department: str
    sub_department: str
    geo: str
    user_photo: str | None = None
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    # extends the base values to provide additional access for the user
    additional_departments: Set[str] = field(default_factory=set)
    additional_sub_departments: Set[str] = field(default_factory=set)
    additional_geos: Set[str] = field(default_factory=set)

    def __post_init__(self):
        """
        Adds default item of the claims value to the set to allow initialization in Dynamodb.
        """

        if not self.additional_departments:
            self.additional_departments.add(self.department)

        if not self.additional_sub_departments:
            self.additional_sub_departments.add(self.sub_department)

        if not self.additional_geos:
            self.additional_geos.add(self.geo)

    def get_all_departments(self) -> Set[str]:
        all_departments = set([self.department])

        if self.additional_departments:
            all_departments.update(self.additional_departments)

        return all_departments

    def get_all_sub_departments(self) -> Set[str]:
        all_sub_departments = set([self.sub_department])

        if self.additional_sub_departments:
            all_sub_departments.update(self.additional_sub_departments)

        return all_sub_departments

    def get_all_geos(self) -> Set[str]:
        all_geos = set([self.geo])

        if self.additional_geos:
            all_geos.update(self.additional_geos)

        return all_geos
