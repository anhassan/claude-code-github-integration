from dataclasses import dataclass
from typing import Optional


@dataclass
class EntitlementRequest:
    request_id: str
    requestor_email: str
    request_type: str
    workspace_id: str
    dataset_id: str
    validation_token: str
    approver_email: str
    hierarchy: int
    entitlement_col: str
    entitlement_val: str
    rls_request: any
    composite_rule_key: str
    rls_action: str
    status: Optional[str] = "QUEUED"  