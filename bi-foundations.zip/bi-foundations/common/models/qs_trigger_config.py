from typing import Dict, Optional
from dataclasses import dataclass, field


@dataclass
class QSPayload:
    force_sync: bool
    id: str
    account_id: str
    config: Dict[str, any] = field(default_factory=dict)
    rls: Dict[str, any] = field(default_factory=dict)
    cls: Dict[str, any] = field(default_factory=dict)
    s3_manifest: Dict[str, any] = field(default_factory=dict)
    s3_definition_key: Optional[str] = None
    s3_theme_key: Optional[str] = None


@dataclass
class QSManagerPayload:
    resource: str
    payload: QSPayload
