from dataclasses import asdict, dataclass, field
from datetime import datetime, UTC
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer


@dataclass
class FavouriteAsset:
    """
    Composite key where email is the PK and asset_id is the SK.
    """

    email: str
    asset_id: str
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
