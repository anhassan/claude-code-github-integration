#TEMPORARY CLASS FOR Q BAR SECURITY

from dataclasses import dataclass, field
from typing import Set

from common.models.user import User


@dataclass
class QTopicSecurity:
    asset_id: str

    users: Set[str] = field(default_factory=set)

    def __post_init__(self):
        """
        Adds empty string to the string sets to allow initialization in Dynamodb.
        """

        if not self.users:
            self.users.add("")

    def can_user_access(self, user: User) -> bool:
        return any([user.email in self.users])
