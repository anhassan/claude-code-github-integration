import json
from typing import Dict, Literal


class ApiEventConfig:
    def __init__(self, event):
        self.event = event
        self.resource: str = self.event.get("resource")
        self.http_method: Literal[
            "GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"
        ] = self.event.get("httpMethod")

    def get_path_parameters(self) -> str:
        return self.event.get("pathParameters", None)

    def get_query_parameters(self) -> str:
        return self.event.get("queryStringParameters", None)

    def get_event_body(self) -> Dict[str, any]:
        return json.loads(self.event.get("body"))

    def get_auth_claims(self) -> Dict[str, any]:
        return self.event["requestContext"]["authorizer"]["claims"]

    def get_email(self) -> str:
        return self.get_auth_claims()["email"]
    
    def get_department(self) -> str:
        return self.get_auth_claims()["custom:department"]
    
    def get_sub_department(self) -> str:
        return self.get_auth_claims()["custom:subdepartment"]
    
    def get_geo_location(self) -> str:
        return self.get_auth_claims()["custom:country"]
    
    def get_event_headers(self) -> Dict[str, any]:
        return self.event.get("headers", {})
    
    def set_event_body(self,new_event_body):
        self.event["body"] = new_event_body
    
    def __str__(self) -> str:
        return f"{self.__class__}(http_method={self.http_method}, resource={self.resource}, event={self.event})"
