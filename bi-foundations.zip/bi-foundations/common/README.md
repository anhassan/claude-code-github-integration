# Important

This folder is included in the artifact zip for all lambdas under the `src/` directory. This means that dependencies used in the common folder should be kept to a minimum.

The purpose of this repo is to contain shared utilities and models that can be reused across multiple microservices.

For example, there may be multiple BI Portal lambdas supporting different resources, that are called through an API gateway. Thus a common `api_request_handler` utility was created to standardize mapping API gateway calls to their corresponding function triggers by using models provided with the utility.