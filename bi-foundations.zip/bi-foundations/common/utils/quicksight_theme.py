"""Helpers for reasoning about QuickSight theme ARNs."""


def is_managed_theme(theme_arn):
    """Return True if the ARN refers to an AWS-managed (built-in) theme.

    Managed themes (CLASSIC, MIDNIGHT, SEASIDE, RAINIER) have an empty
    account-id segment owned by ``aws``, e.g.
    ``arn:aws:quicksight::aws:theme/CLASSIC``. Custom themes are account
    scoped, e.g.
    ``arn:aws:quicksight:us-east-1:200967598245:theme/<id>``.

    A falsy or unparseable value is treated as NOT managed so a present but
    unexpected ThemeArn never causes a custom theme file to be discarded.
    """
    if not theme_arn:
        return False
    parts = theme_arn.split(":")
    if len(parts) < 6:
        return False
    account = parts[4]
    return account in ("", "aws")
