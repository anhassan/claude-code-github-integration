import abc
import json
from logging import Logger
from typing import Callable, List, Literal

from common.models.api_event_config import ApiEventConfig


class Endpoint:
    """
    Maps the API endpoint to the callable implementation function.

    @param runner is the callable function signature that takes the ApiEventConfig as input.
    @param resource is the mapping between the API Gateway endpoint resource and function trigger for the implementation.
    Supports wildcards after '/' for catch all path segments,
    e.g. /assets/* would match any api event resource that starts with /assets/ followed by a
    value that matches the same number of segments.
    """

    def __init__(
        self,
        http_method: Literal["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        resource: str,
        runner: Callable,
    ):
        self.http_method = http_method
        self.resource = resource
        self.runner = runner

    def run(self, payload: ApiEventConfig):
        return self.runner(payload)

    def __str__(self) -> str:
        return f"{self.__class__}(http_method={self.http_method}, resource={self.resource}, runner={self.runner})"


class BootstrapEndpoints:
    """
    Parent class intended to be extended per lambda.
    Initializes the Endpoint mapping to respective implementation using the Endpoint class defined above.
    """

    def __init__(self, endpoints: List[Endpoint]) -> None:
        self.endpoints = endpoints

    @abc.abstractmethod
    def init_endpoints(self) -> List[Endpoint]:
        raise NotImplementedError(
            "Endpoints must be initialized to get the endpoint from an api event."
        )

    def get_endpoint_from_api_event(self, event: ApiEventConfig) -> Endpoint:
        return next(
            (
                endpoint
                for endpoint in self.endpoints
                if endpoint.http_method == event.http_method
                and len(endpoint.resource.split("/")) == len(event.resource.split("/"))
                and all(
                    resource_part[0] == "*" or resource_part[0] == resource_part[1]
                    for resource_part in zip(
                        endpoint.resource.split("/"), event.resource.split("/")
                    )
                )
            ),
            None,
        )


class JsonResponseEncoder(json.JSONEncoder):
    def default(self, o: object) -> object:
        if isinstance(o, set):
            return list(o)

        return super().default(o)


class ApiRequestHandler:
    """
    Generic lambda API request handler utility.
    Standardizes routing and handling of API requests to resource endpoints.

    Requires initialization with an endpoint helper BootstrapEndpoints,
    which provides the implementation for each of the endpoints mapped to the lambda.
    """

    def __init__(self, endpoint_helper: BootstrapEndpoints, logger: Logger):
        self.endpoint_helper = endpoint_helper
        self.logger = logger

    def _build_fail_response(self, status_code, e, response):
        error = json.dumps({"error": "{}".format(e)})
        response["statusCode"] = status_code
        response["body"] = error
        self.logger.error("BI Portal Service Exception {}".format(e))
        return response

    def handle_api_request(self, event, context):
        self.logger.info("API request event: {}, context: {}".format(event, context))
        api_event = ApiEventConfig(event)
        response = {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Credentials": "true",
                "Content-Type": "application/json",
                "Access-Control-Allow-Headers": "*",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
                "Access-Control-Max-Age": "7200",
                # Responses can carry single-use credentials (QuickSight embed
                # auth codes); a cached replay on back/forward navigation
                # redeems a dead code and breaks embedding.
                "Cache-Control": "no-store",
            },
            "isBase64Encoded": True,
        }

        if api_event.http_method == "OPTIONS":
            return response

        try:
            endpoint = self.endpoint_helper.get_endpoint_from_api_event(api_event)

            if endpoint is None:
                raise ValueError(
                    f"Endpoint was called with incorrect method. Event: {event}"
                )

            self.logger.info("Endpoint: {}, Payload: {}".format(endpoint, api_event))

            result = endpoint.run(api_event)
            response["body"] = json.dumps(result, cls=JsonResponseEncoder)
            self.logger.debug("Response: {}".format(response))
            return response
        except PermissionError as e:
            self.logger.warning(e)
            return self._build_fail_response(403, e, response)
        except Exception as e:
            self.logger.exception(e)
            return self._build_fail_response(400, e, response)
