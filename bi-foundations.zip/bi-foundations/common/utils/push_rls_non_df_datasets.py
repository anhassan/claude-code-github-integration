import boto3
import os
from datetime import datetime, timezone
import sys

ddb_resource = boto3.resource('dynamodb', region_name='us-east-1')
ddb_table = ddb_resource.Table('bi-foundations-dataset-rls')

def add_rls_to_dynamodb_table(table_name, rls_items):
    ddb_table = ddb_resource.Table(table_name)
    for rls_item in rls_items:
        ddb_table.put_item(Item=rls_item)
        print(f"Added RLS item for dataset: {rls_item['dataset_id']} with workspace_id: {rls_item['workspace_id']}")

def convert_yaml_to_json(yaml_file_path):
    import yaml
    with open(yaml_file_path, 'r') as file:
        yaml_content = yaml.safe_load(file)
    return yaml_content

def enrich_rls_item(rls_item, workspace_id):
    rls_item = rls_item.copy()
    rls_item["workspace_id"] = workspace_id
    rls_item["last_updated"] = datetime.now(timezone.utc).isoformat()
    return rls_item

def push_rls_from_yaml(path,env):
    rls_items = []
    workspace_id = path.split("/")[0]
    for root, dirs, files in os.walk(path):
        for file in files:
            if ("rls.yaml" in file or "rls.yml" in file) and "rls/" in root and env in root:
                 yaml_file_path = os.path.join(root, "rls.yaml")
                 rls_item = convert_yaml_to_json(yaml_file_path)

                 rls_item_enriched = enrich_rls_item(rls_item, workspace_id=workspace_id)
                 rls_items.append(rls_item_enriched)

    add_rls_to_dynamodb_table('bi-foundations-dataset-rls', rls_items)
            

if __name__ == "__main__":
    push_rls_from_yaml(sys.argv[1],sys.argv[2])

