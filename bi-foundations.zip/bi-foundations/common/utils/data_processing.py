import json
from typing import Dict
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer


def get_bucket_key_from_sqs_queue(event):
    """
    :param event: event from lambda
    :return: bucket key from sqs message
    """
    try:
        sqs_payload = event["body"]
        body = json.loads(sqs_payload)

        s3_key = body["detail"]["object"]["key"]
        s3_bucket = body["detail"]["bucket"]["name"]
        return s3_bucket, s3_key
    except Exception as e:
        raise ValueError(e)


def serialize_to_dynamodb(payload: Dict[str, any]) -> Dict[str, any]:
    serializer = TypeSerializer()
    return {k: serializer.serialize(v) for k, v in payload.items()}


def deserialize_from_dynamodb(dynamodb_item: Dict[str, any]) -> Dict[str, any]:
    deserializer = TypeDeserializer()
    return {k: deserializer.deserialize(v) for k, v in dynamodb_item.items()}
