"""
This file is meant as a standalone validator for asset configuration files when they are being uploaded to github
"""

import logging
import csv
import os
import re
import sys
from typing import List
from jsonschema import validate
import yaml
logger = logging.getLogger()
logger.setLevel(logging.INFO)


class InvalidColumnError(Exception):
    pass

class TopLevelKeyError(Exception):
    pass

class TableLevelKeyError(Exception):
    pass

class UnknownKeyError(Exception):
    pass

class InvalidDataTypeError(Exception):
    """Raised when an invalid data type is found"""
    pass

REQUIRED_COLUMN_KEYS = {
    "dataset": ["Dataset Identifier", "Dataset Name", "Dataset Description", "Is Data Product","Portal URL"],
    "overview": ["Asset ID", "Description"],
    "parameter": ["Parameter Name", "Dataset Identifier", "Parameter Description", "Sheet Name"],
    "sheet": ["Sheet Name", "Sheet Description"],
    "visualization": ["Visual Name", "Visual Type", "Visual Description", "Sheet Name"],
    "config": ["base_dashboard_name","display_name","id_prefix","branch","version","use_fixed","force_sync","finsights_detail"],
    "metadata": ["name","import_mode","workspaces","columns"],
    "rls": ["rls"],
    "s3_manifest": ["upload_settings"]
}

S3_MANIFEST_UPLOAD_SETTING_KEYS = [
    "format",
    "start_from_row",
    "contains_header",
    "text_qualifier",
    "delimiter",
]
S3_MANIFEST_KEY_PATTERN = re.compile(r"^[^/]+/s3-manifests/[^/]+/manifest\.json$")

ATHENA_VALID_DATATYPES = [
    "STRING",
    "INTEGER",
    "DECIMAL",
    "BOOLEAN",
    "DATE",
    "TIMESTAMP",
    "DATETIME",
    "DECIMAL.FLOAT",
    "DECIMAL.FIXED"
]

OPTIONAL_COLUMN_KEYS = {
    "embedding_access": ["whitelist", "viewers"],
    "rls": {"department": ["column_name"],
            "sub_department": ["column_name"],
            "geo": ["column_name"],
            "rls_by_email": ["emails", {"rules": ["column_name", "authorized_values"]}],
            "rls": {"department": ["name", "authorized_values"],
                    "sub_department": ["name", "authorized_values"],
                    "geo": ["name", "authorized_values"]},
                    "email": ["name", "authorized_values"]},
    "metadata": ["projects"]

}

DATASET_CONFIG_REQUIRED_KEYS = ["tag_key","column_name","tag_target","visible_rows"]

ALLOWED_ASSET_DEPARTMENTS = [
    "Active Equities",
    "Capital Markets & Factor Investing",
    "Credit Investments",
    "Finance",
    "Legal",
    "Office of the Chief Investment Officer",
    "President",
    "Private Equity",
    "Public Affairs & Communications",
    "Real Assets",
    "Risk",
    "Talent",
    "Technology & Operations",
    "Total Fund Management",
    "Total Fund Management Trading",
    "Attribution Analytics",
    "Management Analytics",
    "Data Governance"
]


def __validate_metadata_asset_file(path):
    """
    Runs validation against all CSV files in a given directory
    """
    if not os.path.exists(path):
        print("ERROR: Could not find the path: {}, please check folder path or name".format(path))

    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith('.csv'):  # Only process files ending with .csv
                _path = os.path.join(root, file)
                with open(_path) as f:
                    print("Validating {}".format(_path))
                    asset_file_data = csv.DictReader(f)
                    table_name = os.path.basename(_path).split('.')[0]
                    validate_metadata_asset_file(asset_file_data, table_name)
                    print("{} was valid".format(_path))
    print("All CSV files valid")


def __validate_dataset_metadata_file(path):
    """
    validates the metadata files within a workspace directory
    :param path: root path of the directory to test
    """
    errors = []
    dataset_metadata_file_count = 0
    if not os.path.exists(path):
        print("ERROR: Could not find the path: {}, please check folder path or name".format(path))
    for root, _, files in os.walk(path):
        if "metadata.yaml" in files:
            metadata_path = os.path.join(root, "metadata.yaml")
            logging.info(f"Validating dataset from path {metadata_path}")
            try:
                with open(metadata_path, 'r') as file:
                    dataset_metadata_data = yaml.safe_load(file)
                    table_name = os.path.basename(metadata_path).split('.')[0]
                    errors.append(validate_dataset_metadata_file(dataset_metadata_data, table_name))
                    if (
                        isinstance(dataset_metadata_data, dict)
                        and dataset_metadata_data.get("dataset_source", "").upper() == "S3"
                        and "s3_manifest.yaml" not in files
                    ):
                        errors.append([
                            f"S3 dataset at {root} requires sibling s3_manifest.yaml"
                        ])
                    dataset_metadata_file_count =  dataset_metadata_file_count + 1
            except yaml.YAMLError as e:
                errors.append(f"Error parsing YAML file {metadata_path}: {e}")
    logging.info(f"total dataset metadata files processed = {str(dataset_metadata_file_count)}")
    return errors
def __validate_rls_file(path):
    """
    validates the rls files within a workspace directory
    :param path: root path of the directory to test
    """
    errors = []
    rls_file_count = 0
    if not os.path.exists(path):
        logging.error("ERROR: Could not find the path: {}, please check folder path or name".format(path))
    for root, _, files in os.walk(path):
        if "rls.yaml" in files:
            metadata_path = os.path.join(root, "rls.yaml")
            logging.info(f"Validating {metadata_path}")
            try:
                with open(metadata_path, 'r') as file:
                    rls_data = yaml.safe_load(file)
                    table_name = os.path.basename(metadata_path).split('.')[0]
                    validate_rls_file(rls_data, table_name)
                    rls_file_count =  rls_file_count + 1
            except yaml.YAMLError as e:
                errors.append(f"Error parsing YAML file {metadata_path}: {e}")
    logging.info(f"total rls files processed = {str(rls_file_count)}")
    return errors

def __validate_config_file(path):
    """
    validates the asset config files within a workspace directory
    :param path: root path of the directory to test
    """
    errors = []
    config_file_count = 0
    if not os.path.exists(path):
        print("ERROR: Could not find the path: {}, please check folder path or name".format(path))
    for root, _, files in os.walk(path):
        if "config.yaml" in files:
            config_path = os.path.join(root, "config.yaml")
            logging.info(f"Validating {config_path}")
            try:
                with open(config_path, 'r') as file:
                    config_data = yaml.safe_load(file)
                    table_name = os.path.basename(config_path).split('.')[0]
                    errors.append(validate_config_file(config_data, table_name))
                    config_file_count =  config_file_count + 1
            except yaml.YAMLError as e:
                errors.append(f"Error parsing YAML file {config_path}: {e}")
    logging.info(f"total config files processed = {str(config_file_count)}")
    return errors
def __validate_embedding_access_file(path):
    """
    validates the embedding files within a workspace directory
    :param path: root path of the directory to test
    """
    errors = []
    embedding_access_file_count = 0
    for root, _, files in os.walk(path):
        if "embedding_access.yaml" in files:
            embedding_access_path = os.path.join(root, "embedding_access.yaml")
            logging.info(f"Validating {embedding_access_path}")
            try:
                with open(embedding_access_path, 'r') as file:
                    config_data = yaml.safe_load(file)
                    table_name = os.path.basename(embedding_access_path).split('.')[0]
                    errors.append(validate_embedding_access_file(config_data, table_name))
                    embedding_access_file_count =  embedding_access_file_count + 1
            except yaml.YAMLError as e:
                logging.error(f"Error parsing YAML file {embedding_access_path}: {e}")
    logging.info(f"total embedding files processed = {str(embedding_access_file_count)}")
    return errors

def _workspace_dataset_from_s3_manifest_path(s3_manifest_path):
    parts = os.path.normpath(s3_manifest_path).split(os.sep)
    if "datasets" not in parts:
        return None, None

    dataset_index = parts.index("datasets")
    dataset = parts[dataset_index + 1] if len(parts) > dataset_index + 1 else None
    workspace = None
    if dataset_index >= 2:
        workspace = parts[dataset_index - 2]

    return workspace, dataset


def __validate_s3_manifest_file(path):
    """
    validates the s3 manifest files within a workspace directory
    :param path: root path of the directory to test
    """
    errors = []
    s3_manifest_file_count = 0
    for root, _, files in os.walk(path):
        if "s3_manifest.yaml" in files:
            s3_manifest_path = os.path.join(root, "s3_manifest.yaml")
            logging.info(f"Validating {s3_manifest_path}")
            try:
                with open(s3_manifest_path, 'r') as file:
                    config_data = yaml.safe_load(file)
                    table_name = os.path.basename(s3_manifest_path).split('.')[0]
                    workspace, dataset = _workspace_dataset_from_s3_manifest_path(
                        s3_manifest_path
                    )
                    errors.append(
                        validate_s3_manifest_file(
                            config_data,
                            table_name,
                            workspace=workspace,
                            dataset=dataset,
                        )
                    )
                    s3_manifest_file_count =  s3_manifest_file_count + 1
            except yaml.YAMLError as e:
                logging.error(f"Error parsing YAML file {s3_manifest_path}: {e}")
    logging.info(f"total s3 manifest files processed = {str(s3_manifest_file_count)}")
    return errors
def check_table_headers(asset_csv,table_name):
    """
    Checks if the table headers are valid for the given table name.
    """
    columns = asset_csv.fieldnames
    errors = []

    if table_name not in REQUIRED_COLUMN_KEYS:
        errors.append(TopLevelKeyError(f"Unknown file: {table_name}"))

    required_columns = REQUIRED_COLUMN_KEYS[table_name]
    for column in columns:
        if column not in required_columns:
            errors.append(f"Missing column '{column}' in table '{table_name}'")
    if errors:
        error_message = "\n".join(errors)  # Combine all errors with newlines
        logging.error(InvalidColumnError(f"One or more column name validation errors found:\n{error_message}"))
    logger.info(f"all columns successfully validated in table {table_name}")
    return errors

def check_dataset_config_keys(config_payload):
    columns = config_payload.fieldnames
    errors =  []
    for column in columns:
        if column not in REQUIRED_COLUMN_KEYS:
            errors.append(f"Missing column '{column}' in dataset config file'")
    return errors

def check_yaml_required_columns(yaml_data,table_name):
    """checks if required columns exist in config file
    :param yaml_data: data from the file
    :param table_name: name of the table to check
    :return: True if all required columns exist
    """
    errors = []
    if yaml_data is None:
        errors.append(f"Config file for '{table_name}' is empty or could not be parsed")
        logging.error(errors[0])
        return errors
    for key in REQUIRED_COLUMN_KEYS[table_name]:
        if key not in yaml_data:
            error = f"Missing required key '{key}' in {table_name} file"
            if table_name == "config":
                if "id_prefix" in yaml_data:
                    error = f"{error} for asset id : {yaml_data.get('id_prefix')}"
            errors.append(error)
    if errors:
        error_message = "\n".join(errors)  # Combine all errors with newlines
        logging.error(error_message)
    logger.info(f"all required keys successfully validated in config file for table {table_name}")
    return errors

def check_asset_config_yaml_optional_finsights_detail(yaml_data, table_name) -> List[str]:
    errors = []
    finsights_detail = yaml_data.get("finsights_detail")
    if not finsights_detail:
        return errors

    EXPECTED_FINSIGHTS_DETAIL_SCHEMA = {
        "type": "object",
        "properties": {
            "department": {"type": "string"},
            "description": {"type": "string"},
            "asset_type": {"type": "string"},
            "artifact_source": {"type": "string"},
            "tags": {"type": "array", "items": {"type": "string"}},
            "product_owners": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                    },
                },
            },
        },
    }
    try:
        validate(finsights_detail, EXPECTED_FINSIGHTS_DETAIL_SCHEMA)

        return errors
    except Exception as e:
        error_message = f"Failed validation of finsights_detail for config dashboard name: {yaml_data.get("display_name", "")}, validation error: {e}"
        logging.error(error_message)
        errors.append(error_message)
        return errors

def check_asset_config_yaml_finsights_detail_department(yaml_data, table_name) -> List[str]:
    base_error_message = f"Failed validation of department for config dashboard name: {yaml_data.get("display_name", "")}, validation error:"
    errors = []

    finsights_detail = yaml_data.get("finsights_detail")

    if finsights_detail:
        # validate whether department exists in the finsights_detail
        if "department" not in finsights_detail.keys():
            error = f"{base_error_message} department not provided, a department from the following departments : {ALLOWED_ASSET_DEPARTMENTS} should be provided under finsights_detail tag"
            logging.error(error)
            errors.append(error)
        else:
            # type check for department
            asset_department = finsights_detail.get("department")
            if not isinstance(asset_department,str):
                error = f"{base_error_message} department provided should be of type str and not of type: {type(asset_department)}"
                logging.error(error)
                errors.append(error)
            else:
                # validate whether the department provided is from the list of allowed depeartments
                if asset_department not in ALLOWED_ASSET_DEPARTMENTS:
                    error = f"{base_error_message} department provided : {asset_department} should be in the allowed list of departments : {ALLOWED_ASSET_DEPARTMENTS}"
                    logging.error(error)
                    errors.append(error)
    return errors

def check_yaml_optional_columns(yaml_data: dict, table_name: str) -> bool:
    """
    Validates optional columns in config file:
    - Allows optional keys to be missing
    - Validates spelling of provided optional keys
    - Throws errors for any unexpected keys

    Args:
        yaml_data: Dictionary containing the YAML data
        table_name: Name of the table/section to check

    Returns:
        bool: True if validation passes

    Raises:
        InvalidColumnError: If unexpected keys are found or validation fails
    """
    errors = []

    def validate_nested_structure(data: dict, expected_structure: dict, path: str = "") -> None:
        """
        Recursively validates nested structure against expected schema.

        Args:
            data: Current level of YAML data
            expected_structure: Expected structure at current level
            path: Current path in the structure (for error messages)
        """
        # Handle list type expected structure
        if isinstance(expected_structure, list):
            # Check for unexpected keys
            unexpected_keys = [key for key in data.keys() if key not in expected_structure]
            if unexpected_keys:
                logging.error(f"Unexpected keys {unexpected_keys} found in {path or table_name}")
                errors.append(f"Unexpected keys {unexpected_keys} found in {path or table_name}")
            return errors

        # Handle dictionary type expected structure
        if isinstance(expected_structure, dict):
            # Check for unexpected keys at this level
            unexpected_keys = [key for key in data.keys() if key not in expected_structure]
            if unexpected_keys:
                errors.append(f"Unexpected keys {unexpected_keys} found in {path or table_name}")

            for key, expected_value in expected_structure.items():
                if key in data:
                    current_path = f"{path}.{key}" if path else key

                    # Handle nested list structures
                    if isinstance(data[key], list):
                        if key == "rls":  # Special handling for RLS list
                            for idx, entry in enumerate(data[key]):
                                entry_path = f"{current_path}[{idx}]"

                                # Check for unexpected sections in each entry
                                unexpected_sections = [
                                    section for section in entry.keys()
                                    if section not in expected_value
                                ]
                                if unexpected_sections:
                                    errors.append(
                                        f"Unexpected sections {unexpected_sections} found in {entry_path}"
                                    )

                                # Validate known sections
                                for section, section_data in entry.items():
                                    if section in expected_value:
                                        section_path = f"{entry_path}.{section}"
                                        expected_fields = expected_value[section]

                                        # Check for unexpected fields in section
                                        unexpected_fields = [
                                            field for field in section_data.keys()
                                            if field not in expected_fields
                                        ]
                                        if unexpected_fields:
                                            errors.append(
                                                f"Unexpected fields {unexpected_fields} found in {section_path}"
                                            )

                    # Handle regular nested structures
                    else:
                        validate_nested_structure(data[key], expected_value, current_path)

    try:
        # Get the expected structure for this table
        expected_structure = OPTIONAL_COLUMN_KEYS.get(table_name)
        if not expected_structure:
            errors.append(f"No optional column definition found for table '{table_name}'")

        # Start the recursive validation
        validate_nested_structure(yaml_data, expected_structure)
        logger.info(f"Optional keys validation successful for {table_name}")
        return errors

    except Exception as e:
        if not isinstance(e, InvalidColumnError):
            logger.error(f"Unexpected error during validation: {str(e)}")
            return errors


def validate_column_data_types(yaml_data) -> bool:
    """
    Validates that all column data types in the YAML are valid Athena data types.

    Args:
        yaml_data: The parsed YAML data

    Returns:
        errors: list of errors

    Raises:
        InvalidDataTypeError: If any invalid data types are found
    """
    errors = []

    # Check if columns key exists
    if 'columns' not in yaml_data:
        logging.info(InvalidDataTypeError("Missing 'columns' section in YAML"))
        errors.append(InvalidDataTypeError("Missing 'columns' section in YAML"))

    # Validate each column's data type
    for column_name, spec in yaml_data['columns'].items():
        if isinstance(spec, dict):
            data_type = spec.get('type', '')
        else:
            data_type = spec
        if data_type not in ATHENA_VALID_DATATYPES:
            errors.append(f"Invalid data type '{data_type}' for column '{column_name}'. "
                        f"Must be one of: {', '.join(ATHENA_VALID_DATATYPES)}")

    if errors:
        logger.error(InvalidDataTypeError("\n".join(errors)))
    return errors

def validate_metadata_asset_file(asset_csv, table_name):
    errors = []
    errors.extend(check_table_headers(asset_csv, table_name))
    return errors


def validate_rls_file(rls_data, table_name):
    errors = []
    errors.extend(check_yaml_required_columns(rls_data, table_name))
    errors.extend(check_yaml_optional_columns(rls_data, table_name))
    return errors


def validate_embedding_access_file(config_data, table_name):
    errors = []
    errors.extend(check_yaml_optional_columns(config_data, table_name))
    return errors


def validate_metadata_asset_file(asset_csv, table_name):
    errors = []
    errors.extend(check_table_headers(asset_csv, table_name))
    return errors


def validate_dataset_metadata_file(dataset_metadata_data, table_name):
    errors = []
    errors.extend(validate_column_data_types(dataset_metadata_data))
    errors.extend(check_yaml_required_columns(dataset_metadata_data, table_name))

    if isinstance(dataset_metadata_data, dict):
        dataset_source = dataset_metadata_data.get("dataset_source", "")
        import_mode = dataset_metadata_data.get("import_mode", "")
        if dataset_source.upper() == "S3" and import_mode.upper() != "SPICE":
            errors.append(
                "S3 datasets must use import_mode: SPICE; "
                f"found import_mode: {import_mode}"
            )

        # QuickSight requires physicalTableMap keys and logicalTable physicalTableIds
        # to match [0-9a-zA-Z-]*. The publisher derives this from "<name>_<env>" and
        # only converts underscores to hyphens, so any other disallowed character in
        # `name` causes a ValidationException at CreateDataSet time and aborts the
        # whole sync batch. Reject early so a bad name fails the PR, not the sync.
        name = dataset_metadata_data.get("name")
        if name and not re.match(r"^[A-Za-z0-9_-]+$", name):
            errors.append(
                f"dataset name {name!r} contains characters outside [A-Za-z0-9_-]; "
                "QuickSight rejects the resulting physicalTableMap key. "
                "Use letters, digits, hyphens, or underscores only."
            )

        errors.extend(_validate_joins_block(dataset_metadata_data.get("joins")))
        errors.extend(_validate_incremental_refresh_block(dataset_metadata_data))
        errors.extend(_validate_refresh_schedule_block(dataset_metadata_data))
    return errors


INCREMENTAL_REFRESH_DATE_TYPES = {"DATE", "DATETIME", "TIMESTAMP"}
INCREMENTAL_REFRESH_SIZE_UNITS = {"HOUR", "DAY", "WEEK"}

# QuickSight refresh-schedule limits (empirically confirmed):
#  * a high-frequency interval must be the dataset's SOLE schedule, and
#  * at most 5 refresh schedules per dataset.
REFRESH_SCHEDULE_SOLE_INTERVALS = {"HOURLY", "MINUTE15", "MINUTE30"}
MAX_REFRESH_SCHEDULES = 5


def _validate_refresh_schedule_block(dataset_metadata_data):
    """Validate the optional `refresh_schedule:` list against QuickSight limits.

    QuickSight rejects (at CreateRefreshSchedule time, mid-sync) a dataset that
    has more than 5 refresh schedules, or that pairs a high-frequency interval
    (HOURLY/MINUTE15/MINUTE30) with any other schedule — such an interval must be
    the dataset's only schedule. Catch both at PR time instead.
    """
    errors = []
    schedules = dataset_metadata_data.get("refresh_schedule")
    if schedules is None:
        return errors
    if isinstance(schedules, dict):
        schedules = [schedules]
    if not isinstance(schedules, list):
        return ["refresh_schedule must be a list of schedule entries"]

    if len(schedules) > MAX_REFRESH_SCHEDULES:
        errors.append(
            f"refresh_schedule has {len(schedules)} entries; QuickSight allows at "
            f"most {MAX_REFRESH_SCHEDULES} refresh schedules per dataset"
        )

    sole_intervals = []
    for s in schedules:
        if not isinstance(s, dict):
            continue
        interval = str((s.get("ScheduleFrequency") or {}).get("Interval", "")).upper()
        if interval in REFRESH_SCHEDULE_SOLE_INTERVALS:
            sole_intervals.append(interval)
    if sole_intervals and len(schedules) > 1:
        errors.append(
            f"refresh_schedule has a {sole_intervals[0]} schedule, which QuickSight "
            f"requires to be the dataset's only refresh schedule "
            f"(found {len(schedules)} schedules)"
        )

    return errors


def _validate_incremental_refresh_block(dataset_metadata_data):
    """Validate the optional `incremental_refresh:` block on a dataset.

    Schema:
      incremental_refresh:
        column_name: <a DATETIME/DATE column declared in `columns:`>
        size: <positive int>
        size_unit: HOUR | DAY | WEEK

    QuickSight requires the lookback column to be a date type and the dataset
    to be SPICE + SQL-based. An INCREMENTAL_REFRESH schedule is inert without
    this block, so flag that mismatch too.
    """
    errors = []
    block = dataset_metadata_data.get("incremental_refresh")
    columns = dataset_metadata_data.get("columns", {}) or {}
    schedules = dataset_metadata_data.get("refresh_schedule") or []
    if isinstance(schedules, dict):
        schedules = [schedules]
    has_incremental_schedule = any(
        isinstance(s, dict) and str(s.get("RefreshType", "")).upper() == "INCREMENTAL_REFRESH"
        for s in schedules
    )

    if block is None:
        if has_incremental_schedule:
            errors.append(
                "refresh_schedule has an INCREMENTAL_REFRESH entry but no "
                "incremental_refresh block is defined"
            )
        return errors

    if not isinstance(block, dict):
        return [
            "incremental_refresh must be a mapping with column_name, size, size_unit"
        ]

    if str(dataset_metadata_data.get("import_mode", "")).upper() != "SPICE":
        errors.append("incremental_refresh requires import_mode: SPICE")

    if str(dataset_metadata_data.get("dataset_source", "")).upper() == "S3":
        errors.append(
            "incremental_refresh is not supported on S3/file-source datasets "
            "(SQL-based sources only)"
        )

    column_name = block.get("column_name")
    if not column_name or not isinstance(column_name, str):
        errors.append("incremental_refresh.column_name is required and must be a string")
    elif column_name not in columns:
        errors.append(
            f"incremental_refresh.column_name {column_name!r} is not a declared column"
        )
    else:
        spec = columns[column_name]
        col_type = spec.get("type", "") if isinstance(spec, dict) else spec
        if str(col_type).upper() not in INCREMENTAL_REFRESH_DATE_TYPES:
            errors.append(
                f"incremental_refresh.column_name {column_name!r} must be a date "
                f"column (one of {sorted(INCREMENTAL_REFRESH_DATE_TYPES)}); found {col_type!r}"
            )

    size = block.get("size")
    if isinstance(size, bool) or not isinstance(size, int) or size <= 0:
        errors.append("incremental_refresh.size must be a positive integer")

    size_unit = str(block.get("size_unit", "")).upper()
    if size_unit not in INCREMENTAL_REFRESH_SIZE_UNITS:
        errors.append(
            f"incremental_refresh.size_unit must be one of "
            f"{sorted(INCREMENTAL_REFRESH_SIZE_UNITS)}"
        )

    return errors


VALID_JOIN_TYPES = {"LEFT", "RIGHT", "INNER", "OUTER"}
VALID_JOIN_OPERATORS = {"=", "!=", "<", "<=", ">", ">="}


def _validate_s3_location_entries(entries, field_name):
    """Validate managed-S3 data location entries.

    Each entry must be a mapping with required `key` and optional `bucket`.
    `bucket` is omitted to default to DROPBOX_BUCKET at publish time.
    """
    if not entries:
        return []
    if not isinstance(entries, list):
        return [
            f"s3_manifest.{field_name} must be a list of {{key, bucket?}} entries"
        ]
    errors = []
    for idx, entry in enumerate(entries):
        if not isinstance(entry, dict):
            errors.append(
                f"s3_manifest.{field_name}[{idx}] must be a mapping with "
                "required 'key' and optional 'bucket'; raw 's3://...' strings "
                "are no longer accepted"
            )
            continue
        key = entry.get("key")
        if not isinstance(key, str) or not key:
            errors.append(
                f"s3_manifest.{field_name}[{idx}].key is required and must be "
                "a non-empty string"
            )
        bucket = entry.get("bucket")
        if bucket is not None and (not isinstance(bucket, str) or not bucket):
            errors.append(
                f"s3_manifest.{field_name}[{idx}].bucket, when set, must be a "
                "non-empty string; omit it to default to DROPBOX_BUCKET"
            )
        extra = set(entry.keys()) - {"key", "bucket"}
        if extra:
            errors.append(
                f"s3_manifest.{field_name}[{idx}] has unknown keys {sorted(extra)}; "
                "only 'key' and 'bucket' are supported"
            )
    return errors


def _validate_joins_block(joins):
    """Validate the optional `joins:` block on a dataset metadata.yaml.

    Schema:
      joins:
        - right_dataset: <sibling dataset slug>
          type: LEFT | RIGHT | INNER | OUTER
          on_clause:
            - left: <column name on the primary side>
              right: <column name on the right dataset>
              op: =                  # optional, defaults to `=`
                                     # one of: =, !=, <, <=, >, >=

    Multiple on_clause entries are AND-ed together in the emitted
    JoinInstruction OnClause. The join condition key is `on_clause:`
    (not `on:`) because YAML 1.1 parses bare `on` / `off` as booleans.
    """
    if joins in (None, []):
        return []
    if not isinstance(joins, list):
        return ["joins must be a list of join definitions"]
    errors = []
    for idx, join in enumerate(joins):
        if not isinstance(join, dict):
            errors.append(f"joins[{idx}] must be a mapping, got {type(join).__name__}")
            continue
        right = join.get("right_dataset")
        if not isinstance(right, str) or not right:
            errors.append(f"joins[{idx}].right_dataset is required and must be a non-empty string")
        elif not re.match(r"^[A-Za-z0-9_-]+$", right):
            errors.append(
                f"joins[{idx}].right_dataset {right!r} must match [A-Za-z0-9_-]+"
            )
        join_type = str(join.get("type", "LEFT")).upper()
        if join_type not in VALID_JOIN_TYPES:
            errors.append(
                f"joins[{idx}].type {join_type!r} must be one of {sorted(VALID_JOIN_TYPES)}"
            )
        on_clause = join.get("on_clause")
        if not isinstance(on_clause, list) or not on_clause:
            errors.append(
                f"joins[{idx}].on_clause is required and must be a non-empty list of {{left, right}} pairs"
            )
            continue
        for j, pair in enumerate(on_clause):
            if not isinstance(pair, dict):
                errors.append(
                    f"joins[{idx}].on_clause[{j}] must be a mapping with left/right keys"
                )
                continue
            for side in ("left", "right"):
                col = pair.get(side)
                if not isinstance(col, str) or not col:
                    errors.append(
                        f"joins[{idx}].on_clause[{j}].{side} is required and must be a non-empty string"
                    )
            op = pair.get("op", "=")
            if op not in VALID_JOIN_OPERATORS:
                errors.append(
                    f"joins[{idx}].on_clause[{j}].op {op!r} must be one of {sorted(VALID_JOIN_OPERATORS)}"
                )
    return errors


def validate_rls_file(rls_data, table_name):
    errors = []
    errors.extend(check_yaml_required_columns(rls_data, table_name))
    errors.extend(check_yaml_optional_columns(rls_data, table_name))
    return errors


def validate_config_file(config_data, table_name):
    errors = []
    errors.extend(check_yaml_required_columns(config_data, table_name))
    errors.extend(check_asset_config_yaml_finsights_detail_department(config_data, table_name))
    #errors.extend(check_asset_config_yaml_optional_finsights_detail(config_data, table_name))
    return errors


def validate_embedding_access_file(config_data, table_name):
    errors = check_yaml_optional_columns(config_data, table_name)
    return errors

def validate_s3_manifest_file(config_data, table_name, workspace=None, dataset=None):
    errors = []
    if not isinstance(config_data, dict):
        return [f"{table_name} file must contain a YAML mapping"]

    errors.extend(check_yaml_required_columns(config_data, table_name))

    upload_settings = config_data.get("upload_settings", {})
    if not isinstance(upload_settings, dict):
        errors.append("s3_manifest.upload_settings must be a mapping")
        upload_settings = {}
    for key in S3_MANIFEST_UPLOAD_SETTING_KEYS:
        if key not in upload_settings:
            errors.append(f"Missing required key 'upload_settings.{key}' in {table_name} file")

    data_uris = config_data.get("data_uris") or []
    data_uri_prefixes = config_data.get("data_uri_prefixes") or []
    has_managed_data_locations = bool(data_uris or data_uri_prefixes)
    manifest_location = config_data.get("manifest_location")

    errors.extend(_validate_s3_location_entries(data_uris, "data_uris"))
    errors.extend(
        _validate_s3_location_entries(data_uri_prefixes, "data_uri_prefixes")
    )

    if isinstance(manifest_location, dict) and "bucket" in manifest_location:
        errors.append(
            "s3_manifest.manifest_location.bucket is not allowed; "
            "the bucket is derived from FOUNDATION_BUCKET at runtime"
        )

    if has_managed_data_locations:
        if not isinstance(manifest_location, dict):
            errors.append(
                "Missing required key 'manifest_location' in s3_manifest file "
                "when data_uris or data_uri_prefixes are provided"
            )
        else:
            manifest_key = manifest_location.get("key")
            if not manifest_key:
                errors.append(
                    "Missing required key 'manifest_location.key' in s3_manifest file "
                    "when data_uris or data_uri_prefixes are provided"
                )
            elif workspace and dataset:
                expected_key = f"{workspace}/s3-manifests/{dataset}/manifest.json"
                if manifest_key != expected_key:
                    errors.append(
                        "s3_manifest.manifest_location.key must be "
                        f"'{expected_key}'"
                    )
            elif not S3_MANIFEST_KEY_PATTERN.match(manifest_key):
                errors.append(
                    "s3_manifest.manifest_location.key must match "
                    "'{workspace}/s3-manifests/{dataset}/manifest.json'"
                )
    elif manifest_location:
        errors.append(
            "s3_manifest.manifest_location is only valid when data_uris or "
            "data_uri_prefixes are provided"
        )

    return errors


if __name__ == "__main__":
    logging.info("Validating from path: {}".format(sys.argv[1]))
    all_errors = []
    # Collect errors from each validation function
    all_errors.extend(__validate_dataset_metadata_file(sys.argv[1]))
    all_errors.extend(__validate_rls_file(sys.argv[1]))
    all_errors.extend(__validate_config_file(sys.argv[1]))
    all_errors.extend(__validate_embedding_access_file(sys.argv[1]))
    all_errors.extend(__validate_s3_manifest_file(sys.argv[1]))
    all_errors = [error_item for error in all_errors for error_item in error if error_item]
    # If any errors were collected, raise an exception
    if all_errors:
        error_message = "\n".join(all_errors)
        raise Exception(f"Validation failed with the following errors:\n{error_message}")
        sys.exit(1)
    logging.info("All validations passed successfully")
