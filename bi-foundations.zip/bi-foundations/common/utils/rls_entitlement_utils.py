import copy 
from pprint import pprint
import boto3
import os 
from boto3.dynamodb.conditions import Attr
import json
import copy
from datetime import datetime,UTC
import zlib, base64

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.data_processing import serialize_to_dynamodb


class RlsEntitlementUitls():

    def __init__(self) -> None:
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.qs_client = boto3.client("quicksight", region_name = "us-east-1")
    
    def compress_text(self,input: str) -> str:
        compressed_text = zlib.compress(input.encode("utf-8"))
        return base64.a85encode(compressed_text).decode("utf-8")
    
    def decompress_text(self,input: str) -> str:
        decompressed_text = zlib.decompress(base64.a85decode(input.encode("utf-8")))
        return decompressed_text.decode("utf-8")
    
    def get_next_approvers(self,entitlement_requests_table, request_id):
        next_pending_approver = None
        ddb_entitlement_requests_table = self.dynamodb_resource.Table(
            entitlement_requests_table
        )
        filter_condition = Attr("request_id").eq(request_id) & ~Attr("status").contains("APPROVED")

        entitlement_requests = self.scan_ddb(ddb_entitlement_requests_table,filter_condition)

        if len(entitlement_requests) > 0 :
            lowest_pending_hierarchy = min(
                [int(request["hierarchy"]) for request in entitlement_requests]
            )

            next_pending_approver = [
                request
                for request in entitlement_requests
                if int(request["hierarchy"]) == lowest_pending_hierarchy
            ]

        return next_pending_approver
    

    # ====================================================
    # ================= RLS COMMONS ======================
    # ====================================================

    def contains_rls(self,rls_request):
        if "rls_mappings" in rls_request.keys():
            return True if rls_request["rls_mappings"] else False
        elif "rls_by_email_mappings" in rls_request.keys():
            return True if rls_request["rls_by_email_mappings"] else False
        return False
    
    
    # ====================================================
    # ====== RLS BY AD CLAIMS DELTA AND UPDATES ==========
    # ====================================================

    def is_claim_sub_rule_equal(self,existing_sub_rule,new_sub_rule):
        is_sub_rule_eq = False
        is_sub_rule_partially_eq = False

        column_name_match = existing_sub_rule["column_name"] == new_sub_rule["column_name"]
        auth_group_match = existing_sub_rule["authorized_group"] == new_sub_rule["authorized_group"]
        tag_type_match = existing_sub_rule["tag_type"] == new_sub_rule["tag_type"]

        auth_existing_vals = existing_sub_rule["authorized_values"].lower().split(",")
        auth_new_vals = new_sub_rule["authorized_values"].lower().split(",")   

        auth_values_match = True if len([val for val in auth_new_vals if val in auth_existing_vals]) == len(auth_new_vals) else False

        if column_name_match and auth_group_match and tag_type_match and auth_values_match:
            is_sub_rule_eq = True
        elif column_name_match and auth_group_match and tag_type_match:
            is_sub_rule_partially_eq = True

        return is_sub_rule_eq,is_sub_rule_partially_eq


    def get_rules_tag_combinations(self,rules):
        tag_combos = []
        rules_tag_combinations = {}

        for index,rule in enumerate(rules):
            for sub_rule in rule:
                tag_combos.append(sub_rule["tag_type"])
            
            tag_combos = sorted(tag_combos)
            tag_combination_key = "-".join(tag_combos)

            if tag_combination_key in rules_tag_combinations.keys():
                rules_tag_combinations[tag_combination_key] += [index]
            else:
                rules_tag_combinations[tag_combination_key] = [index]
            
            tag_combos = []
        
        return rules_tag_combinations
    

    def get_tag_combination_per_rule(self,rule):
        tag_combos = []
        for sub_rule in rule:
            tag_combos.append(sub_rule["tag_type"])
        tag_combos = sorted(tag_combos)
        return "-".join(tag_combos)


    def get_matching_rule(self,new_rule,new_rule_tag_combo, 
            existing_rls, existing_tag_combos):
        
        existing_search_inds = existing_tag_combos[new_rule_tag_combo]

        match_sub_rule_cnt = 0
        match_complete_sub_rule_count = 0
        match_complete_rule = False
        match_rule_ind = -1

        for index in existing_search_inds:
            for new_sub_rule in new_rule:
                for existing_sub_rule in existing_rls[index]:
                    is_sub_rule_eq, is_sub_rule_partially_eq =  self.is_claim_sub_rule_equal(existing_sub_rule,new_sub_rule)

                    if is_sub_rule_eq or is_sub_rule_partially_eq:
                        match_sub_rule_cnt +=1

                    if is_sub_rule_eq:
                        match_complete_sub_rule_count +=1
                
            if match_sub_rule_cnt == len(new_rule) or match_complete_sub_rule_count == len(new_rule):
                match_rule_ind = index
                if match_complete_sub_rule_count == len(new_rule):
                    match_complete_rule = True
                break
                
            match_sub_rule_cnt = 0
            match_complete_sub_rule_count = 0

        return match_rule_ind,match_complete_rule

    def update_rls_claim_rule(self,new_rule,existing_rule,new_rule_tag_combination):
        distinct_tags = new_rule_tag_combination.split("-")
        updated_rule  = []

        for distinct_tag in distinct_tags:
            new_sub_rule = [sub_rule for sub_rule in new_rule if sub_rule["tag_type"] == distinct_tag][0]
            existing_sub_rule = [sub_rule for sub_rule in existing_rule if sub_rule["tag_type"] == distinct_tag][0]
            

            new_auth_vals = [auth_val for auth_val in new_sub_rule["authorized_values"].split(",")]
            existing_auth_vals = [auth_val for auth_val in existing_sub_rule["authorized_values"].split(",")]

            to_add_auth_vals = [auth_val for auth_val in new_auth_vals if auth_val not in existing_auth_vals ]

            updated_sub_rule = existing_sub_rule
            updated_sub_rule["authorized_values"] = ",".join(existing_auth_vals + to_add_auth_vals)
            updated_rule.append(updated_sub_rule)
        
        return updated_rule


    def update_rls_by_claims(self,existing_rls,new_rls):
        existing_rls_updt = copy.deepcopy(existing_rls)
        existing_tag_combinations = self.get_rules_tag_combinations(existing_rls_updt)
        to_add_rules = []

        for new_rule in new_rls:
            new_rule_tag_combination = self.get_tag_combination_per_rule(new_rule)

            if new_rule_tag_combination in existing_tag_combinations.keys():
                match_rule_ind,match_complete_rule = self.get_matching_rule(new_rule,new_rule_tag_combination,
                    existing_rls_updt,existing_tag_combinations)
                
                # rule complete match
                if match_complete_rule:
                    print("No update required on the existing rls mapping by claims since the new rule already exists in the existing rls mapping by claims")
                
                # rule no match
                elif match_rule_ind == -1:
                    to_add_rules.append(new_rule)
                
                # rule partial match
                else:
                    updated_rule = self.update_rls_claim_rule(new_rule,existing_rls_updt[match_rule_ind],new_rule_tag_combination)
                    print("===== BEFORE UPDATE RULE =======")
                    print(existing_rls_updt[match_rule_ind])
                    existing_rls_updt[match_rule_ind] = updated_rule
                    print("======= AFTER UPDATE RULE =======")
                    print(existing_rls_updt[match_rule_ind])
            else:
                to_add_rules.append(new_rule)
        
        for to_add_rule in to_add_rules:
            existing_rls_updt.append(to_add_rule)

        return existing_rls_updt




    def get_rls_by_claim_rule_delta(self,new_rule,existing_rule,new_rule_tag_combination):
        distinct_tags = new_rule_tag_combination.split("-")
        updated_rule  = []

        for distinct_tag in distinct_tags:
            new_sub_rule = [sub_rule for sub_rule in new_rule if sub_rule["tag_type"] == distinct_tag][0]
            existing_sub_rule = [sub_rule for sub_rule in existing_rule if sub_rule["tag_type"] == distinct_tag][0]
            

            new_auth_vals = [auth_val for auth_val in new_sub_rule["authorized_values"].split(",")]
            existing_auth_vals = [auth_val for auth_val in existing_sub_rule["authorized_values"].split(",")]

            delta_auth_vals = [auth_val for auth_val in new_auth_vals if auth_val not in existing_auth_vals ]

            updated_sub_rule = copy.deepcopy(existing_sub_rule)
            updated_sub_rule["authorized_values"] = ",".join(delta_auth_vals)
            updated_rule.append(updated_sub_rule)
        
        return updated_rule


    def get_rls_by_claims_delta(self,existing_rls,new_rls):
        existing_tag_combinations = self.get_rules_tag_combinations(existing_rls)
        delta_rls = []

        for new_rule in new_rls:
            new_rule_tag_combination = self.get_tag_combination_per_rule(new_rule)

            if new_rule_tag_combination in existing_tag_combinations.keys():
                match_rule_ind,match_complete_rule = self.get_matching_rule(new_rule,new_rule_tag_combination,
                    existing_rls,existing_tag_combinations)
                
                # rule complete match
                if match_complete_rule:
                    pprint(f"NEW RULE THAT MATCHES: {new_rule}")
                    print("No delta available since the new rule already exists in the existing rls mapping by claims")
                
                # rule no match
                elif match_rule_ind == -1:
                    delta_rls.append(new_rule)
                
                # rule partial match
                else:
                    delta_rule = self.get_rls_by_claim_rule_delta(new_rule,existing_rls[match_rule_ind],new_rule_tag_combination)
                    print("===== BEFORE GETTING DELTA =======")
                    print(existing_rls[match_rule_ind])
                    delta_rls.append(delta_rule)
                    print("======= AFTER GETTING DELTA =======")
                    print(delta_rule)
            else:
                delta_rls.append(new_rule)
        
        return delta_rls


    # ================================================
    # ====== RLS BY EMAIL DELTA AND UPDATES ==========
    # ================================================

    def is_email_rule_group_equal(self,existing_rule_group,new_rule_group):
        is_rule_group_found = False
        is_rule_group_partially_found = False

        column_name_match = existing_rule_group["column_name"] == new_rule_group["column_name"]

        auth_existing_vals = existing_rule_group["authorized_values"].lower().split(",")
        auth_new_vals = new_rule_group["authorized_values"].lower().split(",")
        auth_values_match = True if len([val for val in auth_new_vals if val in auth_existing_vals]) == len(auth_new_vals) else False

        if column_name_match and auth_values_match:
            is_rule_group_found = True
        elif column_name_match:
            is_rule_group_partially_found = True

        return is_rule_group_found,is_rule_group_partially_found

    def get_matching_email_rule(self,existing_rls,new_rule):
        new_email = new_rule["emails"][0]
        for index,existing_rule in enumerate(existing_rls):
            existing_email = existing_rule["emails"][0]
            if new_email == existing_email:
                return existing_rule,index
        return None,None

    def to_update_add_rule_group(self,existing_rule,new_rule):
        to_add_rule_group_list = []
        to_update_rule_group_list = []
        complete_match_group_list = []
        scanned_rule_groups = 0

        for new_rule_group in new_rule["rule_groups"]:
            for index,existing_rule_group in enumerate(existing_rule["rule_groups"]):
                is_rule_group_found,is_rule_group_partially_found = self.is_email_rule_group_equal(existing_rule_group,new_rule_group)

                if is_rule_group_found:
                    scanned_rule_groups = 0
                    complete_match_group_list.append([index,new_rule_group])
                    break
                elif is_rule_group_partially_found:
                    to_update_rule_group_list.append([index,new_rule_group])
                    scanned_rule_groups = 0
                    break
                else:
                    scanned_rule_groups += 1
            
            if scanned_rule_groups == len(existing_rule["rule_groups"]):
                to_add_rule_group_list.append(new_rule_group)
                scanned_rule_groups = 0

        return to_add_rule_group_list,to_update_rule_group_list,complete_match_group_list
            

    def update_email_rule_group(self,to_add_rule_group_list,to_update_rule_group_list,existing_rule):
        updated_rule = existing_rule 

        for index,updt_rule_group in to_update_rule_group_list:
            new_auth_vals = updt_rule_group["authorized_values"].split(",")
            existing_auth_vals = existing_rule["rule_groups"][index]["authorized_values"].split(",")
            to_add_auth_vals = [auth_val for auth_val in new_auth_vals if auth_val not in existing_auth_vals]

            updated_rule["rule_groups"][index]["authorized_values"] = ",".join(existing_auth_vals + to_add_auth_vals)
        
        updated_rule["rule_groups"] += to_add_rule_group_list

        return updated_rule


    def get_rls_email_rule_group_delta(self,to_add_rule_group_list,to_update_rule_group_list,existing_rule):
        delta_rule = {} 
        delta_rule["emails"] = copy.deepcopy(existing_rule["emails"])
        delta_rule["rule_groups"] = []

        for index,updt_rule_group in to_update_rule_group_list:
            new_auth_vals = updt_rule_group["authorized_values"].split(",")
            existing_auth_vals = existing_rule["rule_groups"][index]["authorized_values"].split(",")
            to_add_auth_vals = [auth_val for auth_val in new_auth_vals if auth_val not in existing_auth_vals]

            delta_rule["rule_groups"].append({
                "authorized_values":  ",".join(to_add_auth_vals),
                "column_name" : existing_rule["rule_groups"][index]["column_name"]
            })
        
        delta_rule["rule_groups"] += to_add_rule_group_list

        return delta_rule


    def update_rls_by_email(self,existing_rls,new_rls):
        existing_rls_updt = copy.deepcopy(existing_rls)
        for new_rule in new_rls:
            matched_rule,matched_rule_index = self.get_matching_email_rule(existing_rls,new_rule)
            if matched_rule:
                to_add_rule_group_list,to_update_rule_group_list,_ = self.to_update_add_rule_group(matched_rule,new_rule)
                updated_rule = self.update_email_rule_group(to_add_rule_group_list,to_update_rule_group_list,matched_rule)
                existing_rls_updt[matched_rule_index] = updated_rule
                
            else:
                existing_rls_updt.append(new_rule)
        return existing_rls_updt

    def get_rls_by_email_delta(self,existing_rls,new_rls):
        delta_rules = []
        for new_rule in new_rls:
            matched_rule,matched_rule_index = self.get_matching_email_rule(existing_rls,new_rule)
            if matched_rule:
                to_add_rule_group_list,to_update_rule_group_list,_ = self.to_update_add_rule_group(matched_rule,new_rule)
                delta_rule = self.get_rls_email_rule_group_delta(to_add_rule_group_list,to_update_rule_group_list,matched_rule)
                if to_add_rule_group_list or to_update_rule_group_list:
                    delta_rules.append(delta_rule)        
            else:
                delta_rules.append(new_rule)
        return delta_rules
    
    def get_existing_rls(self,workspace_id,dataset_id,rls_table_name):
        """Gives the current RLS in the rls table given a workspace_id and dataset_id"""

        # TODO: the table name has to come from the environment variables
        ddb_rls_table = self.dynamodb_resource.Table(rls_table_name)
        filter_expression = Attr("workspace_id").eq(workspace_id) & Attr("dataset_id").eq(dataset_id)
        response = ddb_rls_table.scan(FilterExpression=filter_expression).get('Items',[])
        if response:
            return response[0]
        return {}
    

    def get_rls_delta(self,existing_rls,new_rls):
        new_updt_rls = copy.deepcopy(new_rls)
        if "rls_by_email_mappings" in new_rls.keys():
            if "rls_by_email_mappings" in existing_rls.keys():
                rls_delta =  self.get_rls_by_email_delta(existing_rls["rls_by_email_mappings"],new_rls["rls_by_email_mappings"])
                new_updt_rls["rls_by_email_mappings"] = rls_delta
        elif "rls_mappings" in new_rls.keys():
            if "rls_mappings" in existing_rls.keys():
                rls_delta =self.get_rls_by_claims_delta(existing_rls["rls_mappings"],new_rls["rls_mappings"])
                new_updt_rls["rls_mappings"] = rls_delta
        return new_updt_rls
    

    def get_to_update_rls(self,existing_rls,new_rls):
        updated_rls = copy.deepcopy(existing_rls)

        if "rls_by_email_mappings" in new_rls.keys():
            if "rls_by_email_mappings" in existing_rls.keys():
                to_update_rls = self.update_rls_by_email(existing_rls["rls_by_email_mappings"],new_rls["rls_by_email_mappings"])
                updated_rls["rls_by_email_mappings"] = to_update_rls
            else:
                updated_rls["rls_by_email_mappings"] = new_rls["rls_by_email_mappings"]
        elif "rls_mappings" in new_rls.keys():
            if "rls_mappings" in existing_rls.keys():
                to_update_rls = self.update_rls_by_claims(existing_rls["rls_mappings"],new_rls["rls_mappings"])
                updated_rls["rls_mappings"] = to_update_rls
            else:
                updated_rls["rls_mappings"] = new_rls["rls_mappings"]
        
        updated_rls["last_updated"] = datetime.now(UTC).isoformat()

        return updated_rls
    
    # ===========================================================================================
    # =================== AD RLS TO QUICKSIGHT DATASET UTILS ====================================
    # ===========================================================================================

    def scan_ddb(self,ddb_table,filter_condition):
        """Utility function to scan all the pages of the DDB if the table is paginated"""
        response = ddb_table.scan(FilterExpression=filter_condition)
        ddb_result_rows = response.get("Items",[])

        # Continuing the search in case multiple pages exist - introducing pagination logic in DDB search
        while 'LastEvaluatedKey' in response:
            response = ddb_table.scan(
                FilterExpression=filter_condition,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            ddb_result_rows += response.get("Items",[])
        return ddb_result_rows
    
    def get_rls_approved_request(self,entitlement_request_table,request_id):
        ddb_table = self.dynamodb_resource.Table(entitlement_request_table)
        filter_condition = Attr("request_id").eq(request_id)
        response = self.scan_ddb(ddb_table,filter_condition)

        if response:
            return response[0].get("rls_request",{}), response[0].get("requestor_email","")
        
    
    def sanitize_rls(self,rls):
        rls_config = copy.deepcopy(rls)
        rls_cols = ["workspace_id","dataset_id","last_updated","rls_mappings","rls_by_email_mappings"]
        for rls_col in rls_config.keys():
            if rls_col not in rls_cols:
                rls_config.pop(rls_col)
        return rls_config
    

    def write_to_rls_ddb(self,to_update_rls,rls_table_name):
        to_update_sanitized_rls = self.sanitize_rls(to_update_rls)
        to_update_rls_item = serialize_to_dynamodb(to_update_sanitized_rls)
        self.dynamodb_client.put_item(
            TableName = rls_table_name,
            Item = to_update_rls_item
        )
    
    def de_dup_list_of_lists(self,list_of_lists):
        dedup_list_of_lists = []
        for e_list in list_of_lists:
            if e_list not in dedup_list_of_lists:
                dedup_list_of_lists.append(e_list)
        return dedup_list_of_lists
    

    def get_claim_tags_from_rls(self,rls_config):
        if "rls_mappings" not in rls_config.keys():
            return [],[]
        else:
            rls_claims_mappings = rls_config["rls_mappings"]

            all_tag_keys, claims_tag_rules, claims_tag_configurations = [],[],[]

            for rls_claims_mapping in rls_claims_mappings:
                tag_keys = [f"{rls_config['dataset_id']}-{rule['tag_type']}##{rule['column_name']}"
                            for rule in rls_claims_mapping]
                claims_tag_configurations.append(tag_keys)
                all_tag_keys += tag_keys
            
            # Remove duplicates
            tag_keys = list(set(all_tag_keys))
            claims_tag_configurations = self.de_dup_list_of_lists(claims_tag_configurations)

            # Remove column names from tag configurations
            removed_col_tag_configs = []
            for claim_tag_configuration in claims_tag_configurations:
                removed_col_tag_configs.append([tag_key.split("##")[0] for tag_key in claim_tag_configuration])
            
            claims_tag_configurations = removed_col_tag_configs

            claims_tag_rules = [
                {
                "TagKey": tag_key.split("##")[0],
                "ColumnName": tag_key.split("##")[-1],
                "TagMultiValueDelimiter": ",",
                "MatchAllValue": "*",
                }
                for tag_key in tag_keys
            ]

            return claims_tag_rules,claims_tag_configurations
    
    
    def get_email_tags_from_rls(self,rls_config):
        if "rls_by_email_mappings" not in rls_config.keys():
            return [],[]
        else:
            rls_email_mappings = rls_config["rls_by_email_mappings"]
            
            all_tag_keys,email_tag_rules, email_tag_configurations = [],[],[]
            for rls_email_mapping in rls_email_mappings:

                tag_keys = [f"{rls_config['dataset_id']}-{rule['column_name']}-email"
                                    for rule in rls_email_mapping["rule_groups"]]
                email_tag_configurations.append(tag_keys)
                all_tag_keys += tag_keys
            
            # In order to remove duplicates
            email_tag_configurations = self.de_dup_list_of_lists(email_tag_configurations)
            tag_keys = list(set(all_tag_keys))
            
            email_tag_rules = [{
                "TagKey": tag_key,
                "ColumnName": tag_key.split("-")[-2], # get the column name from the tag key
                "TagMultiValueDelimiter": ",",
                "MatchAllValue": "*"
            }
            for tag_key in tag_keys]

            return email_tag_rules,email_tag_configurations
    

    def get_tags_from_rls(self,rls_config):
        if "rls_by_email_mappings" in rls_config.keys():
            tag_rules,tag_configurations = self.get_email_tags_from_rls(rls_config)
        elif "rls_mappings" in rls_config.keys():
            tag_rules,tag_configurations = self.get_claim_tags_from_rls(rls_config)
        
        return tag_rules,tag_configurations
    
    
    def get_all_tags_from_rls(self,rls_config):

        rls_email_config = copy.deepcopy(rls_config)
        if "rls_mappings" in rls_email_config.keys():
            rls_email_config.pop("rls_mappings")

        rls_claims_config = copy.deepcopy(rls_config)
        if "rls_by_email_mappings" in rls_claims_config:
            rls_claims_config.pop("rls_by_email_mappings")

        email_tag_rules, email_tag_configurations = self.get_email_tags_from_rls(rls_email_config)
        claim_tag_rules, claim_tag_configurations = self.get_claim_tags_from_rls(rls_claims_config)

        all_tag_rules = email_tag_rules + claim_tag_rules
        all_tag_configurations = email_tag_configurations + claim_tag_configurations

        return all_tag_rules, all_tag_configurations 
    
    
    def update_rls_qs_ds(self,aws_account_id,dataset_id,new_tag_rules,new_tag_configurations):
        response  = self.qs_client.describe_data_set(
            AwsAccountId = aws_account_id,
            DataSetId = dataset_id
        )

        print(f"============ ADDING/ UPDATING CONFIGS TO QS DS : {dataset_id}  ======")

        ds_update_req = response["DataSet"]

        if "RowLevelPermissionTagConfiguration" not in response["DataSet"]:
            # Creating new RLS
            ds_update_req["RowLevelPermissionTagConfiguration"] = {}

        print("====== NEW CONFIGURATIONS =======")
        pprint(new_tag_rules)
        pprint(new_tag_configurations)

        remove_cols = ["Arn",
                    "ConsumedSpiceCapacityInBytes",
                    "CreatedTime",
                    "LastUpdatedTime",
                    "OutputColumns"
                    ]
        for col in remove_cols:
            ds_update_req.pop(col)

        ds_update_req["RowLevelPermissionTagConfiguration"]["Status"] = "ENABLED"
        ds_update_req["RowLevelPermissionTagConfiguration"]["TagRuleConfigurations"] = new_tag_configurations
        ds_update_req["RowLevelPermissionTagConfiguration"]["TagRules"] = new_tag_rules
        ds_update_req["AwsAccountId"] = aws_account_id

        update_response = self.qs_client.update_data_set(**ds_update_req)

        print("=============== UPDATE RESPONSE ================")
        pprint(update_response)
    
    
    
    # ===========================================================================================
    # =================== SEND FULFILLMENT EMAIL UTILS ==========================================
    # ===========================================================================================

    def sort_fulfillment_keys(self,fulfillment_keys):
        sorted_fulfillment_keys = []

        if len(fulfillment_keys) == 1:
            return fulfillment_keys
        elif len(fulfillment_keys) == 2:
            if "department" in fulfillment_keys and "sub_department" in fulfillment_keys:
                return ["department","sub_department"]
            elif "department" in fulfillment_keys and "geo" in fulfillment_keys:
                return ["department", "geo"]
            elif "sub_department" in fulfillment_keys and "geo" in fulfillment_keys:
                return ["sub_department","geo"]
        elif len(fulfillment_keys) == 3:
            if "department" in fulfillment_keys and "sub_department" in fulfillment_keys and "geo" in fulfillment_keys:
                return ["department","sub_department","geo"]
        else:
            raise Exception(f"Total allowed keys are 3 and not {len(fulfillment_keys)}")


    def get_html_content(self,fulfillments,rule_type):
        theader = "Rule Catgory" if rule_type == "ad_claims" else "Email"
        html_content = f'''<table border="1">
                    <thead>
                        <tr>
                        <th>Rule No</th> 
                        <th>{theader}</th>
                        <th>Exact Rule</th>
                        </tr>
                    </thead>
                    <tbody>
                    '''
        rule_num = 1
        for rule_category,exact_rule in fulfillments:
            exact_rule = exact_rule[0] if isinstance(exact_rule,list) and len(exact_rule) == 1  else exact_rule
            html_content += f'''<tr style="background-color: #d4edda;">
            <td>{rule_num}</td>
            <td>{rule_category}</td>
            <td>{json.dumps(exact_rule)}</td>
            </tr>
            '''
            rule_num+=1
        return html_content
    

    def get_fulfillment_email_content(self,rls_request):
        if "rls_mappings" in rls_request.keys():
            rls_fulfillments = {}

            for rls_mapping in rls_request["rls_mappings"]:
                fulfillment_keys, fulfillment_values = [],{}

                for mapping_rule in rls_mapping:
                    mapping_tag = mapping_rule["tag_type"]

                    fulfillment_keys.append(mapping_tag)
                    fulfillment_values[mapping_tag] = {
                        "column_name" : mapping_rule["column_name"],
                        "column_value" : mapping_rule["authorized_values"],
                        "claim_value" : mapping_rule["authorized_group"]
                    }
                
                rls_category = ".".join(self.sort_fulfillment_keys(fulfillment_keys))

                if rls_category in rls_fulfillments.keys():
                    rls_fulfillments[rls_category] += [[fulfillment_values]]
                else:
                    rls_fulfillments[rls_category] = [[fulfillment_values]]

            fulfillments = []

            for key,val in rls_fulfillments.items():
                for fulfillment in rls_fulfillments[key]:
                    fulfillments.append([key,fulfillment])
            
            return self.get_html_content(fulfillments,"ad_claims")
        
        elif "rls_by_email_mappings" in rls_request.keys():
            fulfillments = []
            for rls_email_mapping in rls_request["rls_by_email_mappings"]:
                email_id = rls_email_mapping["emails"][0]
                for email_rule_group in rls_email_mapping["rule_groups"]:
                    fulfillments.append([email_id,email_rule_group])
            
            return self.get_html_content(fulfillments,"email")
    
    
    def notify_requestor_on_fulfillment(
        self,rls_request,requestor_email,
        fulfillment_type = "Approval"
    ):

        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(self.sm_client,secret_name)
        )

        sender_email = "svc_finsights@cppib.com"
        recepient_email = requestor_email
        cc_email = requestor_email

        # recepient_email = "ahassan@cppib.com"
        # cc_email = "ahassan@cppib.com"

        email_subject = f"Fulfillment Email for {fulfillment_type} for Dataset: {rls_request['dataset_id']}"
        email_body = self.get_fulfillment_email_content(rls_request)

        send_email(
            smtp_user,
            smtp_password,
            smtp_host,
            smtp_port,
            sender_email,
            cc_email,
            recepient_email,
            email_subject,
            email_body,
            True,
        )
        
    
    def notify_requestor_on_als_fulfillment(
        self,als_request,requestor_email,
        asset_access_type,
        fulfillment_type = "Approval"
    ):

        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(self.sm_client,secret_name)
        )

        sender_email = "svc_finsights@cppib.com"
        recepient_email = requestor_email
        cc_email = requestor_email

        # recepient_email = "ahassan@cppib.com"
        # cc_email = "ahassan@cppib.com"

        email_subject = f"Fulfillment Email for {fulfillment_type} for Asset: {als_request['asset_id']}"

        email_body = f"""Your request for access on Asset: {als_request['asset_id']} has been granted.
                         You now have {asset_access_type} access on the asset: {als_request['asset_id']}"""

        send_email(
            smtp_user,
            smtp_password,
            smtp_host,
            smtp_port,
            sender_email,
            cc_email,
            recepient_email,
            email_subject,
            email_body,
            True,
        )

    @staticmethod
    def denial_email_body(request, denied_email):
       requested_user = request['request_id'].split("-")[-1] if "-email-" in request['request_id'] else "Group Permission"
       return f"""
                            <html>
                            <body>
                                <p>
                                The following request was denied:
                                </p>

                                <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; font-family: Arial, sans-serif;">
                                <tr>
                                    <th align="left">Attribute Name</th>
                                    <th align="left">Attribute Value</th>
                                </tr>
                                <tr>
                                    <td><strong>Denied By</strong></td>
                                    <td>{denied_email}</td>
                                </tr>
                                <tr>
                                    <td><strong>Requested For</strong></td>
                                    <td>{requested_user}</td>
                                </tr>
                                <tr>
                                    <td><strong>Workspace</strong></td>
                                    <td>{request['workspace_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Dataset</strong></td>
                                    <td>{request['dataset_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Column</strong></td>
                                    <td>{request['entitlement_col']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Column Value</strong></td>
                                    <td>{request['entitlement_val']}</td>
                                </tr>
                                </table>
                            </body>
                            </html>
                            """
    
    @staticmethod
    def denial_als_email_body(request, denied_email):
       return f"""
                            <html>
                            <body>
                                <p>
                                The following request was denied:
                                </p>

                                <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; font-family: Arial, sans-serif;">
                                <tr>
                                    <th align="left">Attribute Name</th>
                                    <th align="left">Attribute Value</th>
                                </tr>
                                <tr>
                                    <td><strong>Denied By</strong></td>
                                    <td>{denied_email}</td>
                                </tr>
                                <tr>
                                    <td><strong>Requested For</strong></td>
                                    <td>{request['requestor_email']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Workspace</strong></td>
                                    <td>{request['workspace_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Asset</strong></td>
                                    <td>{request['asset_id']}</td>
                                </tr>
                                </table>
                            </body>
                            </html>
                            """
    
    
    def notify_requestor_on_denial(self, request, denied_email, deny_type="rls"):
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(self.sm_client,secret_name)
        )

        requestor_email = request.get('requestor_email')

        sender_email = "svc_finsights@cppib.com"
        recepient_email = requestor_email
        cc_email = denied_email

        # recepient_email = "elowney@cppib.com"
        # cc_email = "elowney@cppib.com"
        
        if deny_type == "rls":
            email_subject = f"Request denied for Dataset: {request['dataset_id']}"
            email_body = self.denial_email_body(request, denied_email)

        elif deny_type == "als":
            email_subject = f"Request denied for Asset: {request['asset_id']}"
            email_body = self.denial_als_email_body(request, denied_email)

        send_email(
            smtp_user,
            smtp_password,
            smtp_host,
            smtp_port,
            sender_email,
            cc_email,
            recepient_email,
            email_subject,
            email_body,
            True,
        )
    
    def get_request_info(self,request_id):
        ddb_table = self.dynamodb_resource.Table("bi-foundations-rls-entitlement-request")
        filter_condition = Attr("request_id").eq(request_id)
        response = self.scan_ddb(ddb_table,filter_condition)
        return response

    def update_remaining_entries_denial(self,request_id, request_info):
        ddb_table = self.dynamodb_resource.Table("bi-foundations-rls-entitlement-request")

        filter_condition = Attr("request_id").eq(request_id) & Attr("status").eq(
            "QUEUED"
        )
        response = self.scan_ddb(ddb_table,filter_condition)

        for entry in response:
            self.update_request_entry(entry['request_id'], "SKIPPED",  entry['approver_email'], response)

        [is_composite_request, composite_rule_key]  = self.is_composite_request(request_info)
        
        if(is_composite_request):
            filter_condition = Attr("composite_rule_key").eq(composite_rule_key) & Attr("status").eq(
                "QUEUED"
            )

            response = self.scan_ddb(ddb_table,filter_condition)

            for entry in response:
                self.update_request_entry(entry['request_id'], "SKIPPED",  entry['approver_email'], response)


    def update_request_entry(self,request_id, action, email, request_info):
        entry_to_update = self.grab_full_approver_email_entry(request_info,email)

        if entry_to_update:
            if(entry_to_update.get('status') == "QUEUED"):
                ddb_table = self.dynamodb_resource.Table("bi-foundations-rls-entitlement-request")
                response = ddb_table.update_item(
                    Key={
                        'request_id': request_id, 
                        'approver_email': entry_to_update['approver_email']
                    }, 
                    UpdateExpression="SET #s = :new_status", 
                    ExpressionAttributeNames={'#s': 'status'}, 
                    ExpressionAttributeValues={':new_status':action}, 
                    ReturnValues="UPDATED_NEW"
                )
                print("update response:", response)
                return [True, entry_to_update.get('status')]
            else: 
                print("Entry already updated")
                return [False, entry_to_update.get('status')]        

    @staticmethod
    def grab_full_approver_email_entry(request_info, email):
        entry_to_update = None
        for item in request_info:
            if email in item.get('approver_email', ''):
                entry_to_update = item
                break
        if entry_to_update == None:
            print("No matching entry found")
        return entry_to_update
            
    @staticmethod
    def is_composite_request(request_info):
        composite_rule_key = request_info[0].get('composite_rule_key')
        return [bool(composite_rule_key), composite_rule_key]
    

    def exist_remaining_composite_requests(self,composite_rule_key,finished_request_id):
        ddb_table = self.dynamodb_resource.Table(
            "bi-foundations-rls-entitlement-request"
        )
        # request_id != finished_request && composite_rule_key == composite_rule_key && status != "APPROVED"
        filter_condition = Attr("request_id").ne(finished_request_id) & Attr("composite_rule_key").eq(composite_rule_key) & Attr("status").ne("APPROVED")
        response = self.scan_ddb(ddb_table,filter_condition)
        return len(response) > 0