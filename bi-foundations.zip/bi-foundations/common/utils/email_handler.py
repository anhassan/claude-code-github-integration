import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import json

def send_email(
        smtp_user,
        smtp_password,
        smtp_host,
        smtp_port,
        sender_email,
        cc_email,
        recepient_email,
        email_subject,
        email_body,
        is_html=False,
    ):

        # creating email content to send via smtp client
        email_msg = MIMEMultipart()
        email_msg["Subject"] = email_subject
        email_msg["From"] = sender_email
        email_msg["Cc"] = cc_email
        email_msg["To"] = recepient_email
        text_type = "html" if is_html else "plain"
        email_msg.attach(MIMEText(email_body, text_type))

        # send required email content using the smtp client
        try:
            smtp_client = smtplib.SMTP(smtp_host, smtp_port)
            smtp_client.starttls()
            smtp_client.login(smtp_user, smtp_password)
            smtp_client.sendmail(
                sender_email, [recepient_email, cc_email], email_msg.as_string()
            )
            print(
                f"Successfully sent email from sender : {sender_email} to recepients: {[recepient_email,cc_email]} "
            )
        except Exception as error:
            print(
                f"Failed sending email from sender : {sender_email} to recepients: {[recepient_email,cc_email]} with error: {error} "
            )
            raise Exception(error)

def get_secret_from_secret_manager(sm_client,secret_name):
    secret_value = sm_client.get_secret_value(SecretId=secret_name)
    return secret_value["SecretString"]

def get_smtp_cred_from_secret(secret_value):
    json_creds = json.loads(secret_value)
    return json_creds["username"], json_creds["password"]