from dataclasses import asdict
from typing import List
from botocore.exceptions import ClientError
import io
import csv
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)
from datetime import datetime, UTC
from common.models.dataset_rls import (
    DatasetRls,
    RlsEmailMapping,
    RlsEmailRule,
    RlsMapping,
)
from collections import defaultdict
import yaml

def write_config_to_ddb(config_items,config_table_name,dynamodb_boto3_resource):
        try:
            ddb_table = dynamodb_boto3_resource.Table(config_table_name)
            with ddb_table.batch_writer() as batch:
                for config_item in config_items:
                     batch.put_item(Item=config_item)
            return True
        except ClientError as e:
            print(f"Error writing to DynamoDB: {e.response['Error']['Message']}")
            return False  

def transform_config_to_ddb_item(config,config_name,dataset_id, workspace_id):
    # Allowed config_names = ["rls_by_adgroup", "cls"]
    from datetime import datetime

    if config_name not in config:
          return []
    return [{
               "workspace_id" : workspace_id,
               "dataset_id" : dataset_id,
               "last_updated" : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
               config_name : config[config_name]
          }]

def get_dataset_id(s3_key: str) -> str:
    """
    Extracts the dataset ID from an S3 key path by returning the second to last element in the path.

    Args:
        s3_key (str): The S3 key path, which can optionally include the 's3://' prefix.
            Example formats:
            - 's3://bfolder/dataset_id/file.csv'

    Returns:
        str: The extracted dataset ID (second to last element) from the S3 path.
    """
    # Remove s3:// prefix if present
    clean_key = s3_key.replace("s3://", "")
    # Split path and get the second to last element
    parts = clean_key.rstrip("/").split("/")
    return parts[-2]


def get_workspace_id(s3_key: str) -> str:
    """
    Extracts the dataset ID from an S3 key path by returning the second to last element in the path.

    Args:
        s3_key (str): The S3 key path, which can optionally include the 's3://' prefix.
            Example formats:
            - 's3://bfolder/dataset_id/file.csv'

    Returns:
        str: The extracted dataset ID (second to last element) from the S3 path.
    """
    # Remove s3:// prefix if present
    clean_key = s3_key.replace("s3://", "")
    # Split path and get the second to last element
    parts = clean_key.rstrip("/").split("/")
    workspace_id = parts[0]
    return workspace_id


def write_to_dynamodb(
    item_dict: dict, table_name: str, dynamodb_boto3_resource
) -> bool:
    """
    Write a dictionary to DynamoDB table
    Args:
        item_dict: Dictionary containing the item data
        table_name: Name of the DynamoDB table
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        table = dynamodb_boto3_resource.Table(table_name)
        response = table.put_item(Item=item_dict)
        return response["ResponseMetadata"]["HTTPStatusCode"] == 200
    except ClientError as e:
        print(f"Error writing to DynamoDB: {e.response['Error']['Message']}")
        return False


def read_yaml_from_s3(s3_bucket: str, s3_key: str, s3_client) -> dict:
    """
    Reads a YAML file from an S3 bucket and returns its contents as a dictionary.

    Args:
    s3_bucket (str): The name of the S3 bucket.
    s3_key (str): The key (path) of the YAML file in the S3 bucket.
    s3_client: boto3 s3 client to read in a file

    Returns:
    dict: A dictionary containing the parsed YAML content.
    """
    try:
        logging.info(f"Reading YAML file from {s3_key}")
        # Get the YAML file from S3
        response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        yaml_content = response["Body"].read().decode("utf-8")

        # Parse the YAML content
        try:
            yaml_data = yaml.safe_load(yaml_content)
            logging.info("Successfully read YAML file into a python dictionary")
            return yaml_data
        except yaml.YAMLError as ye:
            logging.error(f"Error parsing YAML content: {ye}")
            return None

    except ClientError as e:
        logging.error(f"Error reading from S3: {e}")
        return None


def read_csv_from_s3(s3_bucket: str, s3_key: str, delimiter: str, s3_client):
    """
    Reads a CSV file from an S3 bucket and returns its contents as a list of dictionaries.

    Args:
    s3_bucket (str): The name of the S3 bucket.
    s3_key (str): The key (path) of the CSV file in the S3 bucket.
    delimiter (str): The delimiter used in the CSV file.
    s3_client, s3_client to read in a file

    Returns:
    list: A list of dictionaries, where each dictionary represents a row in the CSV file.
    """
    # Initialize the S3 client

    try:
        logging.info(f"reading csv file from {s3_key}")
        # Get the CSV file from S3
        response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        csv_content = response["Body"].read().decode("utf-8")
        # Use StringIO to create a file-like object from the string
        csv_file = io.StringIO(csv_content)
        # Parse the CSV content
        csv_reader = list(csv.DictReader(csv_file, delimiter=delimiter))
        logging.info("successfully read csv file into a python list")
        return csv_reader

    except ClientError as e:
        logger.info(f"Error reading from S3: {e}")
        return None


def join_values(values):
    """Helper function to safely join values"""
    return ",".join(str(v) for v in values if v is not None)


def get_rls_by_email(rls_payload: dict) -> List[RlsEmailMapping]:
    rls_by_email = []

    for group in rls_payload.get("rls_by_email", []):
        rule_groups = []

        for rule in group.get("rules", []):
            authorized_values = ""

            if "*" in rule.get("authorized_values", []):
                authorized_values = "*"
            else:
                authorized_values = join_values(rule.get("authorized_values", []))

            rule_groups.append(
                RlsEmailRule(
                    column_name=rule.get("column_name", ""),
                    authorized_values=authorized_values,
                )
            )

        rls_by_email.append(
            RlsEmailMapping(emails=group.get("emails", set()), rule_groups=rule_groups)
        )

    return rls_by_email


def remap_rls_payload_to_dynamodb(
    rls_payload: dict, dataset_id: str, workspace_id: str
):
    """
    Transforms row-level security (RLS) payload data into a DynamoDB-compatible format by grouping
    and organizing access controls by department, geography, and sub-department categories.

    This function processes a list of RLS records and consolidates them into a structured format
    where visible rows are grouped by their respective tag categories (department, geo, sub_department).
    The visible rows for each category are combined into comma-separated strings and organized into
    a dictionary structure suitable for DynamoDB storage.

    Args:
        rls_payload (list): A list of dictionaries containing RLS records. Each record should have:
            - tag_key (str): Category identifier ('department', 'geo', or 'sub_department')
            - tag_target (str): The specific target within the category
            - authorized_values (str): The rows visible to this target
        dataset_id (str): Unique identifier for the dataset being processed
        workspace_id (str): Unique Identifier for the workspace th data comes from

    Returns:
        dict: A dictionary containing the processed RLS data with the following structure:
            {
                'dataset_id': str,
                'department': dict[str, str],  # {department_name: comma_separated_rows}
                'geo': dict[str, str],         # {location: comma_separated_rows}
                'sub_department': dict[str, str]  # {sub_dept_name: comma_separated_rows}
            }
    """

    if "rls_by_adgroup" in rls_payload.keys():
        return None

    possible_tag_keys = ["department", "geo", "sub_department"]
    rls_mappings = []

    rls_tag_keys_cols = {}

    for tag_key in possible_tag_keys:
        if tag_key in rls_payload.keys():
            if "column_name" in rls_payload.get(tag_key).keys():
                rls_tag_keys_cols[tag_key] = rls_payload.get(tag_key)["column_name"]

    for record in rls_payload.get("rls", []):
        group_mappings = []
        for key in possible_tag_keys:
            if record.get(key):
                tag_dict = record.get(key)
                authorized_values = ",".join(tag_dict.get("authorized_values"))
                rls_mapping = RlsMapping(
                    tag_type=key,
                    authorized_group=tag_dict.get("name"),
                    authorized_values=authorized_values,
                    column_name= rls_tag_keys_cols.get(key)
                )
                group_mappings.append(rls_mapping.__dict__)
        if group_mappings:  # Only append if we have mappings
            rls_mappings.append(group_mappings)

    upsert_dataset_payload = DatasetRls(
        dataset_id=dataset_id,
        workspace_id=workspace_id,
        rls_mappings=rls_mappings,
        rls_by_email_mappings=get_rls_by_email(rls_payload),
    )
    logging.info(f"successfully converted payload for dataset_id={dataset_id}")
    return asdict(upsert_dataset_payload)
