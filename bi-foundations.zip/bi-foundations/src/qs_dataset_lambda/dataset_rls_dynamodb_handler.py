import boto3
import os
import qs_dataset_lambda.common


dataset_rls_table = os.environ.get("DYNAMODB_DATASET_RLS_TABLE")
dataset_cls_table = os.environ.get("DYNAMODB_DATASET_CLS_TABLE")


def lambda_handler(event, context):
    s3_client = boto3.client("s3")
    dynamodb_resource = boto3.resource("dynamodb")
    s3_bucket = event["s3_bucket"]
    s3_key = event["s3_key"]
    dataset_id = qs_dataset_lambda.common.get_dataset_id(s3_key)
    workspace_id = qs_dataset_lambda.common.get_workspace_id(s3_key)

    if s3_key.endswith("rls.yaml"):
        rls_file = qs_dataset_lambda.common.read_yaml_from_s3(s3_bucket, s3_key, s3_client)
        rls_payload = qs_dataset_lambda.common.remap_rls_payload_to_dynamodb(
            rls_file, dataset_id, workspace_id
        )
        if rls_payload:
            qs_dataset_lambda.common.write_to_dynamodb(
                rls_payload, dataset_rls_table, dynamodb_resource
            )
        else:
            rls_by_adgroup_items = qs_dataset_lambda.common.transform_config_to_ddb_item(rls_file,"rls_by_adgroup",dataset_id, workspace_id)
            qs_dataset_lambda.common.write_config_to_ddb(rls_by_adgroup_items,dataset_rls_table,dynamodb_resource)
    
    if s3_key.endswith("cls.yaml"):
        cls_file = qs_dataset_lambda.common.read_yaml_from_s3(s3_bucket, s3_key, s3_client)
        cls_items = qs_dataset_lambda.common.transform_config_to_ddb_item(cls_file,"cls",dataset_id, workspace_id)
        qs_dataset_lambda.common.write_config_to_ddb(cls_items,dataset_cls_table,dynamodb_resource)
