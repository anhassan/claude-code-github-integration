from datetime import datetime
import hashlib
import logging
import boto3
import os
from boto3.dynamodb.conditions import Attr

from openpyxl import load_workbook

logger = logging.getLogger()
logger.setLevel(logging.INFO)
region_name = os.environ['AWS_REGION']
dynamodb = boto3.client('dynamodb', region_name)
ENTITLEMENT_TABLE_NAME = "bi-foundations-workspace-als-entitlements"

def transform_row_to_items(row, header, workspace_id):
    asset_id = row[header.index("dashboard_id")]

    approver_cols = []
    n=1
    while True:
        approver_col = f"approver_{n}"
        approver_backup_col = f"approver_{n}_backup"

        if approver_col in header:
            approver_idx = header.index(approver_col)
            backup_idx = header.index(approver_backup_col)
            approver_cols.append((approver_idx, backup_idx))
            n += 1
        else:
            break

    items = []    
    for hierarchy, (approver_idx, backup_idx) in enumerate(approver_cols, 1):
        approver_email = []
        if row[approver_idx]:
            approver_email.append(row[approver_idx])
        if row[backup_idx]:
          approver_email.append(row[backup_idx])     
        item = {
            "workspace_id" : workspace_id, 
            "asset_id" : asset_id, 
            "hierarchy" : str(hierarchy), 
            "approver_email" : approver_email
        }
        if not approver_email: 
            break
        items.append(item)
    return items      
           

def s3_upload(event):
    bucket = event['detail']['bucket']['name']
    key = event['detail']['object']['key']

    s3 = boto3.client('s3',region_name)
    download_path = f"/tmp/{os.path.basename(key)}"
    s3.download_file(bucket, key, download_path)

    dynamodb_resource = boto3.resource('dynamodb',region_name)
    entitlements_table = dynamodb_resource.Table(ENTITLEMENT_TABLE_NAME)

    wb = load_workbook(download_path)
    sheet = wb.active
    header = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row = 1))]

    workspace_id = os.path.splitext(os.path.basename(key))[0].lower()

    remove_existing_rows(workspace_id)
    
    with entitlements_table.batch_writer() as batch:
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if is_empty_row(row):
                continue
            items = transform_row_to_items(row, header, workspace_id)
            for item in items: 
                item['unique_key'] = make_unique_key(item)
                batch.put_item(Item=item)     


    return {
        'statusCode' : 200, 
        'body' : f"Inserted data for {workspace_id} in {ENTITLEMENT_TABLE_NAME}"
    }


def make_unique_key(row):
    combined = f"{row['workspace_id']}#{row['asset_id']}#{row['hierarchy']}"
    return hashlib.sha256(combined.encode('utf-8')).hexdigest()

def is_empty_row(row):
    return all((cell is None or (isinstance(cell, str) and cell.strip() == "")) for cell in row) 

def scan_ddb(ddb_table, search_key, search_value):
        logger.info(f"Searching for where {search_key} == {search_value}...")   
        filter_condition = Attr(search_key).eq(search_value)
        response = ddb_table.scan(
                        FilterExpression=filter_condition
                    )
        ddb_result_rows = response.get("Items",[])
        while 'LastEvaluatedKey' in response:
            response = ddb_table.scan(
                FilterExpression=filter_condition,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            ddb_result_rows += response.get("Items",[])
        return ddb_result_rows


def remove_existing_rows(workspace_id):
    dynamodb_resource = boto3.resource('dynamodb',region_name)
    entitlements_table = dynamodb_resource.Table(ENTITLEMENT_TABLE_NAME)
    items_to_delete = scan_ddb(entitlements_table, "workspace_id", workspace_id)

    for item in items_to_delete:
        key = {
            'workspace_id' : item['workspace_id'],
            'unique_key' : item['unique_key']
            }
        entitlements_table.delete_item(Key=key)
        logger.info(f"Deleted itme with key {key}")

    logger.info("Deletion complete")

                                 