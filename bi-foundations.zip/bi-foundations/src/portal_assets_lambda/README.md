# Portal Assets Lambda

Defines and implements all of the endpoints that operate on the ASSET resource type. As a portal lambda, the endpoints for this lambda are intended to be accessible by private endpoint through the API gateway.

Assets are the metadata associated with bi products that live on the bi portal. Assets are subjected to the access control systems defined by the bi portal systems, and should only be accessible/modifiable by relevant parties.