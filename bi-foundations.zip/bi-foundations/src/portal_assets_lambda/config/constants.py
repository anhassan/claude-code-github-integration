DEFAULT_SEARCH_RESULTS_SIZE = 10
SEARCH_RESULTS_LIMIT = 50
RECOMMENDED_SEARCH_LIMIT = 100
DEFAULT_AUTOCOMPLETE_RESULTS_SIZE = 5
DEFAULT_AGGREGATION_SIZE = 20
MIN_RESULTS_SIZE = 1
MIN_RESULTS_FROM = 0
INSIGHTS_DEPT = "Management Analytics"

ASSET_CARD_FIELDS = [
    "asset_id",
    "asset_display_name",
    "description",
    "tags",
    "updated_at",
    "department",
    "asset_type",
    "owners",
    "is_restricted",
    "finsights_detail"
]

ASSET_AUTOCOMPLETE_FIELDS = ["asset_id", "asset_display_name", "is_restricted"]
