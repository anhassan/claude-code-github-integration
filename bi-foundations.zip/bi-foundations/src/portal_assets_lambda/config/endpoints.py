from logging import Logger
from typing import Callable, Dict, List

from common.utils.api_request_handler import BootstrapEndpoints, Endpoint
from portal_assets_lambda.services.als_dashboard import AlsDashboard
from portal_assets_lambda.services.asset_catalog import AssetCatalog
from portal_assets_lambda.services.asset_entitlements import AssetEntitlements
from portal_assets_lambda.services.dataset_metadata import DatasetMetadata
from portal_assets_lambda.services.embed_quick_sight import EmbedQuickSight
from portal_assets_lambda.services.search_assets import SearchAssets


class PortalAssetEndpoints(BootstrapEndpoints):
    def __init__(
        self, logger: Logger, clients: Dict[str, Callable], env: Dict[str, str]
    ):
        self.logger = logger
        self.clients = clients
        self.env = env

        super().__init__(self.init_endpoints())

    def init_endpoints(self) -> List[Endpoint]:
        logger, clients, env = self.logger, self.clients, self.env

        return [
            Endpoint(
                "GET",
                "/assets/{asset_id}/embed_url",
                EmbedQuickSight(
                    logger, clients, env
                ).generate_embed_url_for_anonymous_user,
            ),
            Endpoint(
                "GET",
                "/assets/{asset_id}/embed_q_gen_ai_qa_url",
                EmbedQuickSight(
                    logger, clients, env
                ).generate_embed_q_gen_ai_qa_url_for_anonymous_user,
            ),
            Endpoint(
                "GET",
                "/assets",
                SearchAssets(logger, clients, env).get_assets_by_ids,
            ),
            Endpoint(
                "GET",
                "/assets/{asset_id}",
                SearchAssets(logger, clients, env).get_asset_by_id,
            ),
            Endpoint(
                "GET",
                "/assets/filters",
                SearchAssets(logger, clients, env).get_aggregated_filters,
            ),
            Endpoint(
                "GET",
                "/assets/search",
                SearchAssets(logger, clients, env).handle_search,
            ),
            Endpoint(
                "GET",
                "/assets/user",
                SearchAssets(
                    logger,clients,env
                ).get_user_assets
            ),
            Endpoint(
                "GET",
                "/assets/search/autocomplete",
                SearchAssets(logger, clients, env).autocomplete_search,
            ),
            Endpoint(
                "GET",
                "/assets/catalog/recommended",
                AssetCatalog(logger, clients, env).get_recommended_insights,
            ),
            Endpoint(
                "GET",
                "/assets/catalog/department",
                AssetCatalog(
                    logger, clients, env
                ).get_recommended_insights_by_department,
            ),
             Endpoint(
                "POST",
                "/assets/workspace-entitlement",
                AssetEntitlements(logger, clients, env).upload_dataset_file_to_s3,
            ),
            Endpoint(
                "POST",
                "/assets/dashboard-entitlement",
                AssetEntitlements(logger, clients, env).upload_dashboard_file_to_s3,
            ),
            Endpoint(
                "GET",
                "/assets/{asset_id}/metadata",
                EmbedQuickSight(
                    logger, clients, env
                ).get_asset_workspace_datasets,
            ),
            Endpoint(
                "GET",
                "/dataset/{dataset_id}/columns",
                DatasetMetadata(
                    logger, clients, env
                ).get_qs_dataset_cols,
            ),
            Endpoint(
                "GET",
                "/dataset/{dataset_id}/{workspace_id}/rls_by_email",
                DatasetMetadata(
                    logger, clients, env
                ).get_rls_by_email,
            ),
            Endpoint(
                "GET",
                 "/dataset/{dataset_id}/{workspace_id}/rls_by_claims",
                DatasetMetadata(
                    logger, clients, env
                ).get_rls_by_claims,
            ),
            Endpoint(
                "GET",
                "/assets/{asset_id}/department",
                SearchAssets(
                    logger,clients,env
                ).get_asset_department,
            ),
            Endpoint(
                "POST",
                "/assets/departments",
                SearchAssets(
                    logger,clients,env
                ).find_assets_departments
            ),
            Endpoint(
                "GET",
                "/assets/catalog/insights",
                AssetCatalog(logger, clients, env).get_insights_assets,
            ),
            Endpoint(
                "GET",
                "/assets/catalog/non_insights",
                AssetCatalog(logger, clients, env).get_non_insights_assets,
            ),
            Endpoint(
                "GET",
                "/assets/get_als_dashboard_ids",
                AlsDashboard(logger, clients, env).get_als_dashboard_ids
            ),
            Endpoint(
                "GET",
                "/assets/{asset_id}/whitelist_viewers",
                AlsDashboard(logger, clients, env).get_viewers_and_whitelist_by_asset_id
            )
        ]
