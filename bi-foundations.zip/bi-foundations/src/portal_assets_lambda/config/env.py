# all environment variables should be loaded here and
# passed to objects that require them

import os

ENV_VARS = [
    "QUICKSIGHT_ACCOUNT_ID",
    "AWS_REGION_NAME",
    "OPENSEARCH_ENDPOINT",
    "OPENSEARCH_INDEX_NAME",
    "USER_TABLE",
    "DATASET_RLS_TABLE",
    "DATASET_CLS_TABLE",
    "ASSET_LEVEL_SECURITY_TABLE",
    "Q_TOPIC_SECURITY_TABLE",
    "ENV_NAME"
]

ENV = {k: os.environ[k] for k in ENV_VARS}
