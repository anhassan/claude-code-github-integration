import boto3
from typing import Dict, Optional
from opensearchpy import OpenSearch, RequestsHttpConnection
from portal_assets_lambda.config.env import ENV
from requests_aws4auth import AWS4Auth


def _get_opensearch_client() -> OpenSearch:
    credentials = boto3.Session().get_credentials()

    awsauth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        ENV["AWS_REGION_NAME"],
        "es",
        session_token=credentials.token,
    )

    opensearch_client = OpenSearch(
        hosts=[{"host": ENV["OPENSEARCH_ENDPOINT"], "port": 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
    )

    return opensearch_client


# Built once per Lambda container and reused across invocations — client
# construction is CPU-expensive at low memory and was previously paid on
# every request, including CORS preflights.
# NOTE: the memoized OpenSearch client's AWS4Auth snapshots the role
# credentials at construction; watch for OpenSearch 403s (see spec).
_clients: Optional[Dict[str, object]] = None


def get_clients() -> Dict[str, object]:
    global _clients
    if _clients is None:
        _clients = {
            "quicksight": boto3.client("quicksight", region_name=ENV["AWS_REGION_NAME"]),
            "dynamodb": boto3.client("dynamodb", region_name=ENV["AWS_REGION_NAME"]),
            "s3": boto3.client("s3", region_name=ENV["AWS_REGION_NAME"]),
            "opensearch": _get_opensearch_client(),
        }
    return _clients
