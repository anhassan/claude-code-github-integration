from collections import defaultdict
from dataclasses import asdict
from typing import DefaultDict, Dict, List, Set, Tuple
from logging import Logger

from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from opensearchpy import OpenSearch
from common.models.api_event_config import ApiEventConfig
from common.models.asset_level_security import AssetLevelSecurity
from common.models.dataset_rls import DatasetRls, RlsEmailMapping, RlsMapping
from common.models.user import User
from common.utils.data_processing import deserialize_from_dynamodb

class DatasetMetadata:
    PATH_PARAM_DATASET_ID_KEY = "dataset_id"
    PATH_PARAM_WORKSPACE_ID_KEY = "workspace_id"
    

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.qs_client = clients["quicksight"]
        self.dynamodb_client = clients["dynamodb"]
        self.search_client: OpenSearch = clients["opensearch"]
        self.rls_utils = RlsEntitlementUitls()
        self.env = env
    

    def get_qs_dataset_cols(self,event:ApiEventConfig):
        """ Endpoint to give the columns of a dataset given a dataset_id"""
        
        dataset_id = event.get_path_parameters()[self.PATH_PARAM_DATASET_ID_KEY]
        ds_cols = []

        self.logger.info(f"Getting the columns for dataset : {dataset_id}")

        ds_response = self.qs_client.describe_data_set(
            AwsAccountId = self.env["QUICKSIGHT_ACCOUNT_ID"],
            DataSetId = dataset_id
        )

        if "DataSet" in ds_response.keys():
            if "OutputColumns" in ds_response["DataSet"].keys():
                ds_cols += [ds_col_meta["Name"] for ds_col_meta in ds_response["DataSet"]["OutputColumns"]]
        
        return ds_cols
    

    def _is_rule_group_eq(self,rule_group1,rule_group2):

        is_rule_eq,eq_num_rule  = False,0

        if len(rule_group1) ==  len(rule_group2):
            for rule1 in rule_group1:
                for rule2 in rule_group2:
                    if rule1["column_name"] == rule2["column_name"]:
                        if set(rule1["authorized_values"].split(",")) == set(rule2["authorized_values"].split(",")):
                            eq_num_rule +=1
            if len(rule_group1) == eq_num_rule:
                is_rule_eq = True
            return is_rule_eq
        else:
            return is_rule_eq


    def _is_already_grouped(self,rls_groupings,new_rule_num):
        for rule_group in rls_groupings:
            if new_rule_num in rule_group:
                return True
        return False


    def _get_rls_by_emails_grouped(self,rls_by_email):
        rls_groupings = []

        for index,rls_email_rule in enumerate(rls_by_email):
            rule_group = []
            for index_inner, rls_email_rule_inner in enumerate(rls_by_email):
                if index_inner > index:
                    if self._is_rule_group_eq(rls_email_rule["rule_groups"],rls_email_rule_inner["rule_groups"]):
                        if not self._is_already_grouped(rls_groupings,index_inner):
                            rule_group.append(index_inner)
            if rule_group:
                rls_groupings.append([index]+rule_group)


        new_rls_by_email = []
        for index,rls_by_email_rule in enumerate(rls_by_email):
            if not self._is_already_grouped(rls_groupings,index):
                new_rls_by_email.append(rls_by_email_rule)

        for rls_group in rls_groupings:
            email_groups = []
            for rule_num in rls_group:
                email_groups.append(rls_by_email[rule_num]["emails"][0])
            new_rls_by_email.append(
                {
                    "emails" : email_groups,
                    "rule_groups" : rls_by_email[rls_group[0]]["rule_groups"]
                }
            )
                
        return new_rls_by_email



    def get_rls_by_email(self,event:ApiEventConfig):

        """Endpoints that aggragates emails in case they have same rule groups
           and returns result to the front end"""
        
        dataset_id = event.get_path_parameters()[self.PATH_PARAM_DATASET_ID_KEY]
        workspace_id = event.get_path_parameters()[self.PATH_PARAM_WORKSPACE_ID_KEY]
        rls_table_name = self.env["DATASET_RLS_TABLE"]

        rls_response  = self.rls_utils.get_existing_rls(workspace_id,dataset_id,rls_table_name)
        if rls_response:
            if "rls_by_email_mappings" in rls_response.keys():
                return self._get_rls_by_emails_grouped(rls_response["rls_by_email_mappings"])
        return []
    
    
    def get_rls_by_claims(self,event:ApiEventConfig):

        """Endpoints that returns rls by claims result to the front end"""
        
        dataset_id = event.get_path_parameters()[self.PATH_PARAM_DATASET_ID_KEY]
        workspace_id = event.get_path_parameters()[self.PATH_PARAM_WORKSPACE_ID_KEY]
        rls_table_name = self.env["DATASET_RLS_TABLE"]

        rls_response  = self.rls_utils.get_existing_rls(workspace_id,dataset_id,rls_table_name)
        if rls_response:
            if "rls_mappings" in rls_response.keys():
                return rls_response["rls_mappings"]
        return []