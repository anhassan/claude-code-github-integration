from collections import defaultdict
from dataclasses import asdict
from typing import DefaultDict, Dict, List, Set, Tuple
from logging import Logger
from urllib.parse import quote

from opensearchpy import OpenSearch
from common.models.api_event_config import ApiEventConfig
from common.models.asset_level_security import AssetLevelSecurity
from common.models.dataset_rls import DatasetRls, RlsEmailMapping, RlsMapping
from common.models.user import User
from common.utils.data_processing import deserialize_from_dynamodb


class EmbedQuickSight:
    PATH_PARAM_ASSET_ID_KEY = "asset_id"
    PATH_PARAM_DATASET_ID_KEY = "dataset_id"
    SESSION_LIFETIME_IN_MINUTES = 600
    DASHBOARD_NAMESPACE = "default"
    

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.qs_client = clients["quicksight"]
        self.dynamodb_client = clients["dynamodb"]
        self.search_client: OpenSearch = clients["opensearch"]
        self.env = env

    def _get_rls_mapping_keys(self, asset_id: str) -> List[str]:
        response = self.search_client.get(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            id=asset_id,
            _source_includes=["row_level_security"],
        )

        self.logger.info(
            f"Retrieved the following for asset with id: {asset_id}, row_level_security: {response}"
        )

        return response.get("_source", {}).get("row_level_security", [])
    
    
    def _get_q_gen_ai_qa_rls_mapping_keys(self,asset_id:str,topic_id:str)-> List[str]:
        """ A utility method to get rls mapping keys for q gen ai q&a experience search bar """
    
        workspace_id = self._get_rls_mapping_keys(asset_id)[0].get("workspace_id")

        response = self.qs_client.describe_topic(
            AwsAccountId = self.env["QUICKSIGHT_ACCOUNT_ID"] ,
            TopicId = topic_id
        )

        rls_mapping_keys = [{
            "workspace_id" : workspace_id,
            "dataset_id" : ds["DatasetArn"].split("/")[-1]
            }
            for ds in response["Topic"]["DataSets"]]
        

        self.logger.info(
            f"Retrieved the following for asset with id: {asset_id} and topic with id : {topic_id}, rls mapping keys: {rls_mapping_keys}"
        )

        return rls_mapping_keys
    
    
    def is_dataset_rls(self,dataset_id):
        response = self.qs_client.describe_data_set(
        AwsAccountId = self.env["QUICKSIGHT_ACCOUNT_ID"],
        DataSetId = dataset_id
        )
        response_ds = response["DataSet"]

        if "RowLevelPermissionTagConfiguration" in response_ds:
            response_ds_rls = response_ds["RowLevelPermissionTagConfiguration"]
            if "TagRuleConfigurations" in response_ds_rls and "TagRules" in response_ds_rls:
                if response_ds_rls["TagRuleConfigurations"] and response_ds_rls["TagRules"]:
                    return True
        
        return False
    
    def _get_workspace_from_asset_id(self,asset_id:str) -> str:
        """ A utility method that returns workspace id given asset id"""
        asset_id_splits = asset_id.split("-")[0:-1]
        asset_search_key = "bif"
        asset_search_key_ind = [index for index,split in enumerate(asset_id_splits) if asset_search_key in split][-1]
        workspace_id = "-".join(asset_id_splits[asset_search_key_ind:])
        return workspace_id

    
    def _get_rls_mapping_keys_data(self, asset_id: str) -> List[str]:
        response = self.search_client.get(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            id=asset_id,
            _source_includes=["datasets"],
        )

        asset_id_splits = asset_id.split("-")[0:-1]
        asset_search_key = "bif"
        asset_search_key_ind = [index for index,split in enumerate(asset_id_splits) if asset_search_key in split][-1]
        workspace_id = "-".join(asset_id_splits[asset_search_key_ind:])

        all_ds_metadata = response.get("_source",{}).get("datasets",[])
        all_ds_ids = [ds_obj["dataset_id"].split("/")[-1] for ds_obj in all_ds_metadata]

        rls_mapping_keys = [ {
            "workspace_id" : workspace_id,
            "dataset_id" : ds_id
        } for ds_id in all_ds_ids if self.is_dataset_rls(ds_id) ]

        self.logger.info(
            f"Retrieved the following for asset with id: {asset_id}, row_level_security: {rls_mapping_keys}"
        )

        return rls_mapping_keys

    def _get_user_and_asset_rls(
        self, event: ApiEventConfig, rls_mapping_keys: List[str], asset_id: str
    ) -> Tuple[User, List[DatasetRls], List[AssetLevelSecurity]]:
        request_items = {
            self.env["USER_TABLE"]: {"Keys": [{"email": {"S": event.get_email()}}]},
            self.env["ASSET_LEVEL_SECURITY_TABLE"]: {
                "Keys": [{"asset_id": {"S": asset_id}}]
            },
        }

        if rls_mapping_keys:
            request_items[self.env["DATASET_RLS_TABLE"]] = {
                "Keys": [
                    {
                        "workspace_id": {"S": mapping.get("workspace_id")},
                        "dataset_id": {"S": mapping.get("dataset_id")},
                    }
                    for mapping in rls_mapping_keys
                ]
            }

        responses = self.dynamodb_client.batch_get_item(RequestItems=request_items).get(
            "Responses", {}
        )

        self.logger.info(
            f"Dynamodb batch_get_item for {request_items} returned: {responses}"
        )

        user = [
            User(**deserialize_from_dynamodb(item))
            for item in responses.get(self.env["USER_TABLE"], [])
        ].pop(0)

        asset_rls = [
            DatasetRls(**deserialize_from_dynamodb(item))
            for item in responses.get(self.env["DATASET_RLS_TABLE"], [])
        ]

        asset_access = [
            AssetLevelSecurity(**deserialize_from_dynamodb(item))
            for item in responses.get(self.env["ASSET_LEVEL_SECURITY_TABLE"], [])
        ]

        return user, asset_rls, asset_access

    def _get_rls_by_email_for_user(
        self,
        workspace_dataset_rls: DatasetRls,
        user: User,
    ) -> List[RlsEmailMapping]:
        return [
            mapping
            for mapping in workspace_dataset_rls.rls_by_email_mappings
            if user.email.lower() in map(str.lower, mapping.get("emails", []))
        ]

    def _get_dataset_tags_from_rls_per_tag_key(
        self, rls_per_tag_key: DefaultDict[str, Set[str]], override_rls: bool
    ) -> List[dict]:
        dataset_tags = []
        for tag_key, authorized_values in rls_per_tag_key.items():
            dataset_tags.append(
                {
                    "Key": tag_key,
                    "Value": (
                        "*"
                        if override_rls or "*" in authorized_values
                        else ",".join(authorized_values)
                    ),
                }
            )

        return dataset_tags

    def _get_dataset_rls_tags_for_user_email(
        self,
        workspace_dataset_rls: DatasetRls,
        rls_by_email_mappings: List[RlsEmailMapping],
        override_rls: bool,
    ) -> List[dict]:
        rls_per_tag_key = defaultdict(set)

        for mapping in rls_by_email_mappings:
            for rule in mapping.get("rule_groups", []):
                tag_key = f"{workspace_dataset_rls.dataset_id}-{rule.get("column_name", "")}-email"

                if override_rls:
                    rls_per_tag_key[tag_key].add("*")

                rls_per_tag_key[tag_key].add(rule.get("authorized_values", ""))

        return self._get_dataset_tags_from_rls_per_tag_key(
            rls_per_tag_key, override_rls
        )

    def _get_dataset_rls_tags_by_user_claims(
        self,
        workspace_dataset_rls: DatasetRls,
        user: User,
        override_rls: bool,
    ) -> List[dict]:
        rls_per_tag_key = defaultdict(set)

        user_entitlements = {
            "department": user.get_all_departments(),
            "sub_department": user.get_all_sub_departments(),
            "geo": user.get_all_geos(),
        }
        distinct_tag_keys = []
        for mapping in workspace_dataset_rls.rls_mappings:
            for rule in mapping:
                rls = RlsMapping(**rule)
                tag_key = f"{workspace_dataset_rls.dataset_id}-{rls.tag_type}"
                
                if tag_key not in distinct_tag_keys:
                    distinct_tag_keys.append(tag_key)

                if override_rls:
                    rls_per_tag_key[tag_key].add("*")
                    
                elif rls.authorized_group in user_entitlements[rls.tag_type]:
                    rls_per_tag_key[tag_key].add(rls.authorized_values)
        
        for distinct_tag_key in distinct_tag_keys:
            if distinct_tag_key not in rls_per_tag_key.keys():
                rls_per_tag_key[distinct_tag_key].add("*")


        return self._get_dataset_tags_from_rls_per_tag_key(
            rls_per_tag_key, override_rls
        )

    def _get_dataset_session_tags(
        self,
        workspace_dataset_rls: DatasetRls,
        user: User,
        override_rls: bool,
    ) -> List[dict]:
        if rls_by_email_mappings := self._get_rls_by_email_for_user(
            workspace_dataset_rls, user
        ):
            return self._get_dataset_rls_tags_for_user_email(
                workspace_dataset_rls, rls_by_email_mappings, override_rls
            )

        return self._get_dataset_rls_tags_by_user_claims(
            workspace_dataset_rls, user, override_rls
        )

    def _validate_user_access_to_dashboard(
        self, user: User, asset_level_security: List[AssetLevelSecurity]
    ):
        """
        If a dashboard is restricted, only users with access can view the embedding in the portal.
        An error is raised if the requesting user doesn't have access and tries to view the embedding.

        Access principals in the stored whitelist/viewers may be either user emails
        (matched literally) or QuickSight group names (typically AD-synced, e.g.
        AWS_SSO_*). For group principals we resolve membership at request time via
        ListGroupMemberships and short-circuit on the first group that contains the
        requesting user. This mirrors the resolution path already used by the
        dashboard-list endpoint (search_assets.get_user_assets) so the list view
        and the embed view stay in sync.
        """
        if not asset_level_security:
            return

        als = asset_level_security[0]

        self.logger.info(
            f"User: {user.email} is trying to embed: {als.asset_id}, which has the following access controls: {asdict(als)}"
        )

        if als.can_user_access(user):
            return

        if self._user_in_any_ad_group(user.email, als.whitelist | als.viewers):
            self.logger.info(
                f"User: {user.email} access to {als.asset_id} resolved via AD group membership"
            )
            return

        self.logger.warning(
            f"User: {user.email} unauthorized to view embedding for asset: {als.asset_id}"
        )
        raise PermissionError(
            f"User: {user.email} unauthorized to view embedding for asset: {als.asset_id}"
        )

    def _user_in_any_ad_group(self, user_email: str, principals: Set[str]) -> bool:
        """Return True if user_email is a member of any AD-synced QuickSight group
        listed in principals. AD groups are detected by the AWS_SSO_ prefix.
        Short-circuits on first match. Per-group lookup failures are logged and
        treated as not-a-match so a transient API error does not silently grant
        access.
        """
        ad_groups = [p for p in principals if isinstance(p, str) and p.startswith("AWS_SSO_")]
        if not ad_groups:
            return False

        account_id = self.env["QUICKSIGHT_ACCOUNT_ID"]
        for group_name in ad_groups:
            try:
                paginator = self.qs_client.get_paginator("list_group_memberships")
                pages = paginator.paginate(
                    GroupName=group_name,
                    AwsAccountId=account_id,
                    Namespace=self.DASHBOARD_NAMESPACE,
                )
                for page in pages:
                    for member in page.get("GroupMemberList", []) or []:
                        if member.get("MemberName") == user_email:
                            return True
            except Exception as error:
                self.logger.warning(
                    f"Failed to resolve membership for AD group: {group_name}, error: {error}"
                )
        return False
        
    def _batch_ddb_request(self,rls_mapping_keys,ddb_table):
        if rls_mapping_keys:
            request_items = {}

            request_items[ddb_table] = {
                    "Keys": [
                        {
                            "workspace_id": {"S": mapping.get("workspace_id")},
                            "dataset_id": {"S": mapping.get("dataset_id")},
                        }
                        for mapping in rls_mapping_keys
                    ]
                }

            responses = self.dynamodb_client.batch_get_item(RequestItems=request_items).get(
                "Responses", {}
            )

            self.logger.info(
                f"Dynamodb batch_get_item for {request_items} returned: {responses}"
            )

            asset_config = [ item for item in responses.get(ddb_table, [])]
            return asset_config
        return []
     

    def _check_if_asset_requires_registered_user(self, rls_mapping_keys: List[str]):
        rls_ddb_table = self.env["DATASET_RLS_TABLE"]
        cls_ddb_table = self.env["DATASET_CLS_TABLE"]

        cls_configs = self._batch_ddb_request(rls_mapping_keys,cls_ddb_table)

        if cls_configs:
            return True
        else:
            rls_configs = self._batch_ddb_request(rls_mapping_keys,rls_ddb_table)
            for rls_config in rls_configs:
                if "rls_by_adgroup" in rls_config.keys():
                    return True
            return False

    def _get_rls_session_tags(self, event: ApiEventConfig, asset_id: str, topic_id: str=""):
        """
        The RLS session tags determine if a user is able to view data in a dashboard protected by RLS.
        We check if the asset has RLS, and if it does, add any tags applicable for the user.
        """
        if topic_id:
            rls_mapping_keys = self._get_q_gen_ai_qa_rls_mapping_keys(asset_id,topic_id)
        else:
            rls_mapping_keys = self._get_rls_mapping_keys(asset_id)

        user, asset_rls, asset_access = self._get_user_and_asset_rls(
            event, rls_mapping_keys, asset_id
        )

        self._validate_user_access_to_dashboard(user, asset_access)

        session_tags = []

        if not asset_rls or not rls_mapping_keys:
            return session_tags

        override_rls = asset_access and user.email.lower() in map(str.lower, asset_access[0].whitelist)

        self.logger.info(
            f"User: {user.email}, asset_access: {asset_access}, override RLS set to: {override_rls} for {asset_id}"
        )

        for workspace_dataset_rls in asset_rls:
            session_tags.extend(
                self._get_dataset_session_tags(
                    workspace_dataset_rls,
                    user,
                    override_rls,
                )
            )

        return session_tags
    

    def get_user_attributes_params(self,event: ApiEventConfig):
        """ A utility method to add user attributes as dashboard parameters"""

        user_attributes_params = self.get_user_attributes_param_map(event)

        self.logger.info(
            f"Adding user attribute params to embed url for user: {event.get_email()}, params: {list(user_attributes_params.keys())}"
        )

        # Build parameter string correctly for multi-value support
        user_attributes_params_string = "&".join([
            f"p.{k}={quote(str(value), safe='')}"
            for k, v in user_attributes_params.items()
            for value in (v if isinstance(v, list) else [v])
        ])

        return user_attributes_params_string


    def get_user_attributes_param_map(self,event: ApiEventConfig):
        """ A utility method to get user attributes mapped to dashboard parameters"""

        return {
            "cppibEmail": event.get_email(),
            "cppibDepartment": event.get_department(),
            "cppibSubDepartment": event.get_sub_department(),
            "cppibGeo": event.get_geo_location()
        }
    
    
    def add_user_attributes_as_dashboard_params(self,embed_url_response:str,event: ApiEventConfig):
        """ A utility method to add user attributes as dashboard parameters to the embed url"""

        user_attributes_params_string = self.get_user_attributes_params(event)

        if user_attributes_params_string:
            user_attributes_params = self.get_user_attributes_param_map(event)
            separator = "&" if "#" in embed_url_response["EmbedUrl"] else "#"
            embed_url_response["EmbedUrl"] = f"{embed_url_response['EmbedUrl']}{separator}{user_attributes_params_string}"
            self.logger.info(
                f"Added user attribute params to embed url for user: {event.get_email()}, params: {list(user_attributes_params.keys())}"
            )
            return embed_url_response
        else:
            self.logger.info(
                f"No user attribute params to add to embed url for user: {event.get_email()}"
            )
            return embed_url_response

    
    def generate_embed_url_for_registered_user(self, event: ApiEventConfig):
        asset_id = event.get_path_parameters()[self.PATH_PARAM_ASSET_ID_KEY]

        self.logger.info(
            f"Generating embedding url for registered user for dashboard with id: {asset_id}, in namespace: {self.DASHBOARD_NAMESPACE}, for user: {event.get_email()}"
        )

        request_args = {
            "AwsAccountId": self.env["QUICKSIGHT_ACCOUNT_ID"],
            "UserArn" : f'arn:aws:quicksight:{self.env['AWS_REGION_NAME']}:{self.env['QUICKSIGHT_ACCOUNT_ID']}:user/default/{event.get_email()}',
            "ExperienceConfiguration": {"Dashboard": {"InitialDashboardId": asset_id,
                                                        "FeatureConfigurations" : {"StatePersistence" : {"Enabled" : True}}}},
            "SessionLifetimeInMinutes": self.SESSION_LIFETIME_IN_MINUTES,
        }

        embed_url_response = self.qs_client.generate_embed_url_for_registered_user(**request_args)
        return self.add_user_attributes_as_dashboard_params(embed_url_response, event)

    def generate_embed_url_for_anonymous_user(self, event: ApiEventConfig):
        asset_id = event.get_path_parameters()[self.PATH_PARAM_ASSET_ID_KEY]

        # Check if the embed url should be created with registered or anonymous user
        rls_mapping_keys = self._get_rls_mapping_keys(asset_id)
        if self._check_if_asset_requires_registered_user(rls_mapping_keys):
            return self.generate_embed_url_for_registered_user(event)

        self.logger.info(
            f"Generating anonymous embedding url for dashboard with id: {asset_id}, in namespace: {self.DASHBOARD_NAMESPACE}, for user: {event.get_email()}"
        )

        request_args = {
            "AwsAccountId": self.env["QUICKSIGHT_ACCOUNT_ID"],
            "Namespace": self.DASHBOARD_NAMESPACE,
            "AuthorizedResourceArns": [
                f"arn:aws:quicksight:{self.env['AWS_REGION_NAME']}:{self.env['QUICKSIGHT_ACCOUNT_ID']}:dashboard/{asset_id}"
            ],
            "ExperienceConfiguration": {"Dashboard": {"InitialDashboardId": asset_id}},
            "SessionLifetimeInMinutes": self.SESSION_LIFETIME_IN_MINUTES,
        }

        session_tags = self._get_rls_session_tags(event, asset_id)
        self.logger.info(
            f"The following SessionTags for asset_id: {asset_id}, to be used during RLS: {session_tags}, for user: {event.get_email()}"
        )
        if session_tags:
            request_args["SessionTags"] = session_tags

        return self.qs_client.generate_embed_url_for_anonymous_user(**request_args)
    
    
    def get_asset_topics(self,asset_id):
        """ Utility function to get the topic id from asset id"""
        try:
            print(f"Getting topic id for topic name: {asset_id}")
            all_topics = []
            asset_topics = []

            response = self.qs_client.list_topics(AwsAccountId = self.env["QUICKSIGHT_ACCOUNT_ID"])
            if "TopicsSummaries" in response.keys():
                all_topics += response["TopicsSummaries"]

            # Paginating over all the topics
            while "NextToken" in response.keys():
                next_token = response.get("NextToken")
                response = self.qs_client.list_topics(AwsAccountId = self.env["QUICKSIGHT_ACCOUNT_ID"],NextToken=next_token)
                if "TopicsSummaries" in response.keys():
                    all_topics += response["TopicsSummaries"]

            # Finding the topic id for the required topic name
            for topic_info in all_topics:
                if asset_id in topic_info["TopicId"]:
                    asset_topics.append(topic_info["TopicId"])
            print(f"Topic(s) found for asset id: {asset_id} are: {asset_topics}")
            return asset_topics

        except Exception as error:
            print(f"Listing topics for finding topic id for topic name : {asset_id} failed with error : {error}")
    
    
    def generate_embed_q_gen_ai_qa_url_for_anonymous_user(self, event: ApiEventConfig):
        """ An endpoint method to create an embedded url for providing q q&a experience based user and dashboard permissions"""

        asset_id = event.get_path_parameters()[self.PATH_PARAM_ASSET_ID_KEY]
        topic_ids = self.get_asset_topics(asset_id)

        self.logger.info(
            f"Generating anonymous embedding q q&a url for topics with ids: {topic_ids}, in namespace: {self.DASHBOARD_NAMESPACE}, for user: {event.get_email()}"
        )

        authorized_topic_arns = [f"arn:aws:quicksight:{self.env['AWS_REGION_NAME']}:{self.env['QUICKSIGHT_ACCOUNT_ID']}:topic/{topic_id}"
                                 for topic_id in topic_ids]

        if topic_ids:
            request_args = {
                "AwsAccountId": self.env["QUICKSIGHT_ACCOUNT_ID"],
                "Namespace": self.DASHBOARD_NAMESPACE,
                "AuthorizedResourceArns": authorized_topic_arns ,
                "ExperienceConfiguration": {"GenerativeQnA": {"InitialTopicId": topic_ids[0]}},
                "SessionLifetimeInMinutes": self.SESSION_LIFETIME_IN_MINUTES,
            }

            print(f"Authorized Topic Arns : {authorized_topic_arns}")

            # session_tags = self._get_rls_session_tags(event, asset_id,topic_ids[0])
            # self.logger.info(
            #     f"The following SessionTags for topic_id: {topic_ids[0]}, to be used during RLS: {session_tags}, for user: {event.get_email()}"
            # )
            # if session_tags:
            #     request_args["SessionTags"] = session_tags

            return self.qs_client.generate_embed_url_for_anonymous_user(**request_args)
        
        return {}
        
    

    def get_asset_workspace_datasets(self, event: ApiEventConfig):
        """ Endpoint to return workspace_id and dataset_ids for given dashboard given it's asset_id"""

        asset_id = event.get_path_parameters()[self.PATH_PARAM_ASSET_ID_KEY]

        asset_metadata = self._get_rls_mapping_keys(asset_id)

        if asset_metadata:
            workspace_id = list(set([item["workspace_id"] for item in asset_metadata]))[0]
            dataset_ids = [item["dataset_id"] for item in asset_metadata]
            return {
                "workspace_id" : workspace_id,
                "dataset_ids" : dataset_ids
            }
        else:
            return {}

