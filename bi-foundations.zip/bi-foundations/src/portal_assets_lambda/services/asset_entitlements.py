import base64
from logging import Logger
import os
from typing import Dict

from opensearchpy import OpenSearch
from boto3.dynamodb.types import TypeDeserializer

from common.models.api_event_config import ApiEventConfig
from common.models.user import User
from portal_assets_lambda.config.constants import (
    ASSET_CARD_FIELDS,
    DEFAULT_SEARCH_RESULTS_SIZE,
)


class AssetEntitlements:
    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.env = env
        self.s3_client = clients["s3"]

    def upload_dataset_file_to_s3(self, event: ApiEventConfig):
        file_data = event.get_event_body()

        file_bytes = base64.b64decode(file_data["data"])

        filename = file_data["fileName"]
        key = f"uploads/{filename}"
        account_number = self.env["QUICKSIGHT_ACCOUNT_ID"]
        env_name = self.env["ENV_NAME"]
        bucket_name = "dataset-entitlements-bucket-" + account_number + "-"  + env_name

        self.s3_client.put_object(
            Bucket = bucket_name,
            Key = key,
            Body = file_bytes,
            ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        self.logger.info(
            f"Uploaded {filename} to dashboard-entitlements-bucket"
        )

        return {"statusCode" :200}
    
    def upload_dashboard_file_to_s3(self, event: ApiEventConfig):
        file_data = event.get_event_body()

        file_bytes = base64.b64decode(file_data["data"])

        filename = file_data["fileName"]
        key = f"uploads/{filename}"
        account_number = self.env["QUICKSIGHT_ACCOUNT_ID"]
        env_name = self.env["ENV_NAME"]
        bucket_name = "dashboard-entitlements-bucket-" + account_number + "-"  + env_name

        self.s3_client.put_object(
            Bucket = bucket_name,
            Key = key,
            Body = file_bytes,
            ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

        self.logger.info(
            f"Uploaded {filename} to dashboard-entitlements-bucket"
        )

        return {"statusCode" :200}

    