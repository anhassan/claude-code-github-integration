from dataclasses import asdict
from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from common.utils.data_processing import (
    deserialize_from_dynamodb,
    serialize_to_dynamodb
)
import boto3

class AlsDashboard:
    PRIMARY_KEY = "asset_id"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
    
    def get_als_dashboard_ids(self, event: ApiEventConfig):
        asset_ids = []
        try:
            scan_kwargs = {
                "TableName": self.env["ASSET_LEVEL_SECURITY_TABLE"],
                "ProjectionExpression": "asset_id"
            }

            while True:
                response = self.dynamodb_client.scan(**scan_kwargs)
                items = response.get("Items", [])
                for item in items:
                    deserialized = deserialize_from_dynamodb(item)
                    asset_id = deserialized.get("asset_id")
                    if asset_id is not None:
                        asset_ids.append(asset_id)
                if "LastEvaluatedKey" not in response:
                    break
                scan_kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
        except Exception as e:
            self.logger.exception(e)
        return asset_ids
    
    def get_viewers_and_whitelist_by_asset_id(self, event: ApiEventConfig):
        viewers = []
        whitelist = []
        try:
            asset_id_param = None
            if event.get_query_parameters():
                asset_id_param = event.get_query_parameters().get("asset_id")
            if not asset_id_param and event.get_path_parameters():
                asset_id_param = event.get_path_parameters().get("asset_id")
            if not asset_id_param:
                return {"viewers": viewers, "whitelist": whitelist}

            response = self.dynamodb_client.get_item(
                TableName=self.env["ASSET_LEVEL_SECURITY_TABLE"],
                Key={"asset_id": {"S": asset_id_param}},
                ProjectionExpression="#v, #w",
                ExpressionAttributeNames={"#v": "viewers", "#w": " "}
            )

            item = response.get("Item")
            if item:
                deserialized = deserialize_from_dynamodb(item)
                viewers = deserialized.get("viewers", [])
                whitelist = deserialized.get("whitelist", [])
        except Exception as e:
            self.logger.exception(e)
        
        return {"viewers": viewers, "whitelist": whitelist}