import json
from logging import Logger
from typing import Dict, List
from opensearchpy import OpenSearch
from urllib.parse import unquote_plus
import boto3

from common.models.api_event_config import ApiEventConfig
from portal_assets_lambda.config.constants import (
    ASSET_AUTOCOMPLETE_FIELDS,
    ASSET_CARD_FIELDS,
    DEFAULT_AGGREGATION_SIZE,
    DEFAULT_AUTOCOMPLETE_RESULTS_SIZE,
    DEFAULT_SEARCH_RESULTS_SIZE,
    MIN_RESULTS_FROM,
    MIN_RESULTS_SIZE,
    SEARCH_RESULTS_LIMIT,
)


class SearchAssets:
    PATH_PARAM_ASSET_ID_KEY = "asset_id"
    SEARCHABLE_FIELDS = [
        "asset_id",
        "asset_display_name",
        "associated_dp",
        "tags",
    ]
    FINSIGHTS_DEPT_TAG = "finsights_detail.department"
    FINSIGHTS_HOME_PAGE_DEPT = "Management Analytics" # have been updated depending upon Ruby's input

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.search_client: OpenSearch = clients["opensearch"]
        self.env = env
        self.ddb_resource = boto3.resource('dynamodb',region_name="us-east-1")
        self.qs_client = boto3.client("quicksight",region_name="us-east-1")

    def get_asset_by_id(self, event: ApiEventConfig):
        asset_id = event.get_path_parameters()[self.PATH_PARAM_ASSET_ID_KEY]

        self.logger.info(
            f"Getting asset from index: {self.env['OPENSEARCH_INDEX_NAME']} by id: {asset_id}"
        )

        return self.search_client.get(
            index=self.env["OPENSEARCH_INDEX_NAME"], id=asset_id
        )

    def get_assets_by_ids(self, event: ApiEventConfig):
        asset_ids = unquote_plus(event.get_query_parameters()["asset_ids"]).split(",")[
            :SEARCH_RESULTS_LIMIT
        ]

        self.logger.info(
            f"Getting assets from index: {self.env['OPENSEARCH_INDEX_NAME']} by multiple ids: {asset_ids}"
        )

        return self.search_client.mget(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            body={"ids": asset_ids},
            _source_includes=ASSET_CARD_FIELDS,
        )

    def handle_search(self, event: ApiEventConfig):
        search_text = event.get_query_parameters().get("search_text", "")
        filters = event.get_query_parameters().get("filters")
        size = int(
            event.get_query_parameters().get("size", DEFAULT_SEARCH_RESULTS_SIZE)
        )
        fromValue = int(event.get_query_parameters().get("from", MIN_RESULTS_FROM))

        assert MIN_RESULTS_SIZE <= size <= SEARCH_RESULTS_LIMIT, f"size query parameter should be between {MIN_RESULTS_SIZE} and {SEARCH_RESULTS_LIMIT}"

        assert MIN_RESULTS_FROM <= fromValue, f"from query parameter should be greater than {MIN_RESULTS_FROM}"

        if filters:
            parsed_filters = json.loads(unquote_plus(filters))
            return self._search_with_filters(search_text, parsed_filters, size, fromValue)

        return self._search_assets_by_query(search_text, size, fromValue)

    def _search_with_filters(self, search_text: str, filters: List[dict], size: int, fromValue: int):
        text_query = None

        if search_text:
            text_query = [
                {
                    "multi_match": {
                        "query": unquote_plus(search_text),
                        "fields": self.SEARCHABLE_FIELDS,
                        "fuzziness": "AUTO",
                        "lenient": True,
                    }
                }
            ]
        else:
            text_query = [{"match_all": {}}]

        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=min(size, SEARCH_RESULTS_LIMIT),
            body={
                "query": {
                    "bool": {
                        "must": text_query,
                        "filter": filters,
                    },
                },
                "from": fromValue,
                "size": size
            },
            _source_includes=ASSET_CARD_FIELDS,
        )

        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} with query: {search_text} + filters: {filters} and recieved: {response}"
        )

        return response.get("hits")

    def _search_assets_by_query(self, search_text: str, size: int, fromValue: int):
        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=min(size, SEARCH_RESULTS_LIMIT),
            body={
                "query": {
                    "multi_match": {
                        "query": unquote_plus(search_text),
                        "fields": self.SEARCHABLE_FIELDS,
                        "fuzziness": "AUTO",
                        "lenient": True,
                    },
                },
                "from": fromValue,
                "size": size
            },
            _source_includes=ASSET_CARD_FIELDS,
        )

        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} with query: {search_text} and recieved: {response}"
        )

        return response.get("hits")

    def autocomplete_search(self, event: ApiEventConfig):
        search_text = event.get_query_parameters()["search_text"]

        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=DEFAULT_AUTOCOMPLETE_RESULTS_SIZE,
            body={
                "query": {
                    "match_phrase": {
                        "asset_display_name": unquote_plus(search_text),
                    }
                }
            },
            _source_includes=ASSET_AUTOCOMPLETE_FIELDS,
        )

        return response.get("hits")

    # get possible filter values by aggregating unique filterable fields in ES
    def get_aggregated_filters(self, _):
        department_filter = "department.keyword"
        tag_filter = "tags.keyword"

        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=0,
            body={
                "aggs": {
                    # the group name should align with the field name on the doc since they'll be used as filters
                    department_filter: {
                        "terms": {
                            "field": department_filter,
                            "size": DEFAULT_AGGREGATION_SIZE,
                        }
                    },
                    tag_filter: {
                        "terms": {
                            "field": "tags.keyword",
                            "size": DEFAULT_AGGREGATION_SIZE,
                        }
                    },
                },
            },
        )

        self.logger.info(
            f"Aggregated unique {department_filter} and {tag_filter} values from index: {self.env['OPENSEARCH_INDEX_NAME']} and recieved: {response}"
        )

        return response
    
    # get the department for the given asset id
    def get_asset_department(self,event: ApiEventConfig):
        asset_id = event.get_path_parameters()["asset_id"] 
        asset_dept = None
        is_highlighted = False

        results = self.search_client.search(
            index = self.env['OPENSEARCH_INDEX_NAME'],
            allow_partial_search_results = True,
            body = {
                    "query": {
                        "term": {
                        "_id": asset_id
                        }
                    }
                },
                _source_includes = [self.FINSIGHTS_DEPT_TAG]
        )

        self.logger.info(
                f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for department of asset : {asset_id} and recieved: {results}"
            )
        
        # Searching the elastic search results for asset's department
        if "hits" in results.get("hits").keys():
            search_results = results.get("hits")
            if search_results["hits"]:
                if "_source" in search_results["hits"][0].keys():
                    search_hits = search_results["hits"][0]["_source"]
                    if "finsights_detail" in search_hits.keys():
                            if "department" in search_hits["finsights_detail"].keys():
                                asset_dept = search_hits["finsights_detail"]["department"]

        if asset_dept and asset_dept == self.FINSIGHTS_HOME_PAGE_DEPT:
            is_highlighted = True

        return {
            "dept" : asset_dept,
            "isHighlighted" : is_highlighted
        }


    #  find the department for the given list of asset ids
    def find_assets_departments(self,event: ApiEventConfig):
        asset_ids = event.get_event_body()["asset_ids"]
        assets_departments = []
        from_val,size_val = 0,100

        results = self.search_client.search(
            index = self.env['OPENSEARCH_INDEX_NAME'],
            allow_partial_search_results = True,
            body = {
                     "query": {
                        "ids": {
                        "values": asset_ids
                        }
                    },
                    "from": 0,
                    "size": 100
                },
                _source_includes = [self.FINSIGHTS_DEPT_TAG]
        )

        self.logger.info(
                f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for department of assets : {asset_ids} and recieved: {results}"
            )
        
        # Searching the elastic search results for asset's department
        if "hits" in results.get("hits").keys():
            search_results = results.get("hits")
            if search_results["hits"]:
                search_hits = search_results["hits"]
                for search_hit in search_hits:
                    asset_id = search_hit.get("_id")
                    if "_source" in search_hit.keys():
                        search_hit_src = search_hit.get("_source")
                        is_highlighted = False
                        if "finsights_detail" in search_hit_src.keys():
                            if "department" in search_hit_src.get("finsights_detail").keys():
                                asset_dept = search_hit_src["finsights_detail"]["department"]
                                if asset_dept == self.FINSIGHTS_HOME_PAGE_DEPT:
                                    is_highlighted = True
                                assets_departments.append({
                                    "asset_id" : asset_id,
                                    "dept" : asset_dept,
                                    "isHiglighted" : is_highlighted
                                })

        return assets_departments
    
    
    def _get_all_ddb_rows(self,ddb_table_name):
        ddb_table = self.ddb_resource.Table(ddb_table_name)
        ddb_rows = []
        try:
            response = ddb_table.scan()
            ddb_rows += response.get('Items',[])

            while 'LastEvaluatedKey' in response:
                response = ddb_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                ddb_rows += response.get('Items',[])
            
            return ddb_rows

        except Exception as error:
            print(f"Reading all rows from ddb table: {ddb_table_name} failed with Error: {error}")
            return []
    
    def get_ad_group_members(self,ad_group_name):
        try:
            ad_group_members = []

            response = self.qs_client.list_group_memberships(
                GroupName=ad_group_name,
                AwsAccountId=self.env["QUICKSIGHT_ACCOUNT_ID"],
                Namespace='default'
            )
            if "GroupMemberList" in response.keys():
                ad_group_members = [member["MemberName"] for member in response["GroupMemberList"]]
            print(f"Finding members : {ad_group_members} in ad group : {ad_group_name}")
            return ad_group_members

        except Exception as error:
            print(f"Finding members in ad group : {ad_group_name} failed with Error : {error}")
    
    def get_ad_groups_from_embedding(self,embedding_object):
        all_member = list(embedding_object['viewers']) + list(embedding_object['whitelist'])
        return [member for member in all_member if member.startswith("AWS_SSO")]


    def get_user_assets(self,event: ApiEventConfig):
        user_id = event.get_query_parameters()["user_id"] 
        assets_metadata = self._get_all_ddb_rows(self.env["ASSET_LEVEL_SECURITY_TABLE"])
        user_assets = []

        for asset_metadata in assets_metadata:
            if user_id in asset_metadata['viewers'] or user_id in asset_metadata['whitelist']:
                user_assets.append(asset_metadata['asset_id'])
            else:
                asset_ad_groups = self.get_ad_groups_from_embedding(asset_metadata)
                asset_ad_groups_users = []
                for ad_group in asset_ad_groups:
                    asset_ad_groups_users+= self.get_ad_group_members(ad_group)
                if user_id in asset_ad_groups_users:
                    user_assets.append(asset_metadata['asset_id'])
        return user_assets