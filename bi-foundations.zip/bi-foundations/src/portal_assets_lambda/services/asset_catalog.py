from logging import Logger
from typing import Dict

from opensearchpy import OpenSearch
from boto3.dynamodb.types import TypeDeserializer

from common.models.api_event_config import ApiEventConfig
from common.models.user import User
from portal_assets_lambda.config.constants import (
    ASSET_CARD_FIELDS,
    DEFAULT_SEARCH_RESULTS_SIZE,
    MIN_RESULTS_FROM,
    RECOMMENDED_SEARCH_LIMIT,
    INSIGHTS_DEPT
)


class AssetCatalog:
    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client: OpenSearch = clients["dynamodb"]
        self.search_client: OpenSearch = clients["opensearch"]
        self.env = env

    # currently naive until a recommendation system is setup
    def get_recommended_insights(self, event: ApiEventConfig):
        size = int(
            event.get_query_parameters().get("size", RECOMMENDED_SEARCH_LIMIT)
        )
        fromValue = int(event.get_query_parameters().get("from", MIN_RESULTS_FROM))

        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=min(size, RECOMMENDED_SEARCH_LIMIT),
            body={
                "query": {
                    "bool": {
                        "must": [{"match_all": {}}],
                        "must_not": [
                            {"match": {"asset_display_name": "FinSights"}}
                        ],  # exclude FinSights and io dashboards from being in reccomendations
                    }
                },
                "sort": [{"updated_at": {"order": "desc"}}],
                "from": fromValue,
                "size": size
            },
            _source_includes=ASSET_CARD_FIELDS,
        )

        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for recommended insights and recieved: {response}"
        )

        reordered = sorted(response.get("hits").get("hits"), key=lambda x: x['_source']['asset_display_name'] != "CEO Dashboard")

        response["hits"]["hits"] = reordered
        
        return response.get("hits")
    

    def get_insights_assets(self, event: ApiEventConfig):
        size = int(
            event.get_query_parameters().get("size", RECOMMENDED_SEARCH_LIMIT)
        )
        fromValue = int(event.get_query_parameters().get("from", MIN_RESULTS_FROM))

        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=min(size, RECOMMENDED_SEARCH_LIMIT),
            body = {
                    "query": {
                        "bool": {
                        "must": [
                            {
                            "match": {
                                "finsights_detail.department": {
                                "query": INSIGHTS_DEPT,
                                "operator": "and"
                                }
                            }
                            }
                        ],
                        "must_not": [
                            {
                            "match": {
                                "asset_display_name": "FinSights"
                            }
                            }
                        ] # exclude FinSights and io dashboards from being in reccomendations
                        }
                    },
                    "sort": [{"updated_at": {"order": "desc"}}],
                    "from": fromValue,
                    "size": size
                    },
            _source_includes=ASSET_CARD_FIELDS,
        )

        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for insights assets and recieved: {response}"
        )

        reordered = sorted(response.get("hits").get("hits"), key=lambda x: x['_source']['asset_display_name'] != "CEO Dashboard")

        response["hits"]["hits"] = reordered
        
        return response.get("hits")
    
    
    def get_non_insights_assets(self, event: ApiEventConfig):
        size = int(
            event.get_query_parameters().get("size", RECOMMENDED_SEARCH_LIMIT)
        )
        fromValue = int(event.get_query_parameters().get("from", MIN_RESULTS_FROM))
 
        response = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=min(size, RECOMMENDED_SEARCH_LIMIT),
            body = {
                "query": {
                    "bool": {
                    "must_not": [
                        {
                        "term": {
                            "finsights_detail.department.keyword": {
                            "value": INSIGHTS_DEPT,
                            "case_insensitive": True
                            }
                        }
                        },
                        {
                        "match": {
                            "asset_display_name": "FinSights"
                        }
                        }# exclude FinSights and io dashboards from being in reccomendations
                    ],
                    "filter": [
                        {
                        "exists": {
                            "field": "finsights_detail.department"
                        }
                        }
                    ]
                    }
                },
                "sort": [{"updated_at": {"order": "desc"}}],
                "from": fromValue,
                "size": size
            },
            _source_includes=ASSET_CARD_FIELDS,
        )
 
        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for non insights assets and recieved: {response}"
        )
       
        return response.get("hits")
    

    def get_recommended_insights_by_department(self, event: ApiEventConfig):
        user_resp = self.dynamodb_client.get_item(
            TableName=self.env["USER_TABLE"], Key={"email": {"S": event.get_email()}}
        )

        deserializer = TypeDeserializer()

        user = User(
            **{k: deserializer.deserialize(v) for k, v in user_resp.get("Item").items()}
        )

        results = self.search_client.search(
            index=self.env["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results=True,
            size=DEFAULT_SEARCH_RESULTS_SIZE,
            body={
                "query": {
                    "terms": {
                        "department.keyword": [
                            dept.lower() for dept in user.get_all_departments()
                        ]
                    }
                },
                "sort": [{"updated_at": {"order": "desc"}}],
            },
            _source_includes=ASSET_CARD_FIELDS,
        )

        self.logger.info(
            f"Searched index: {self.env['OPENSEARCH_INDEX_NAME']} for recommended insights by department and recieved: {results}"
        )

        return results.get("hits")
