import logging

from common.utils.api_request_handler import ApiRequestHandler
from portal_assets_lambda.config.env import ENV
from portal_assets_lambda.config.clients import get_clients
from portal_assets_lambda.config.endpoints import PortalAssetEndpoints

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handle_api_request(event, context):
    endpoint_helper = PortalAssetEndpoints(logger, get_clients(), ENV)
    request_handler = ApiRequestHandler(endpoint_helper, logger)

    return request_handler.handle_api_request(event, context)
