from datetime import datetime
import json
import logging
import boto3
import os
from botocore.exceptions import ClientError
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from collections.abc import Iterable

logger = logging.getLogger()
logger.setLevel(logging.INFO)

secret_name = "smtp/svc_finsights"

def get_secret(secret):
    secret_client = boto3.client(service_name='secretsmanager', region_name=os.environ['AWS_REGION'])
    value = json.loads(secret_client.get_secret_value(SecretId=secret_name)['SecretString'])
    return value[secret]

def get_from_secrets_manager(secret_name):
        region_name = os.environ['AWS_REGION']

        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=region_name
        )

        try:
            get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        except ClientError as e: 
            raise e

        secret = get_secret_value_response['SecretString']
        logging.info("Succesfully retrieved secret")
        return json.loads(secret)

def get_email_credentials(secret_name):
    secret_json_payload = get_from_secrets_manager(secret_name)
    return {"username": secret_json_payload.get('username'), "password": secret_json_payload.get('password')}

def send_smtp_email(msg, recipients):
    host = os.environ['HOST']
    port = os.environ['PORT']
    s = smtplib.SMTP(host, port)

    secret_name = "smtp/svc_finsights"
    if secret_name:

        mail_username, mail_password = get_email_credentials(secret_name).values()
        s.starttls()
        s.login(mail_username, mail_password)

    s.sendmail(msg['From'], recipients, msg.as_string())
    logging.info("Succesfully sent email to: ", recipients)
    s.quit()



def send_email(emailBody, workspace_name, subject):

        emailPrefix = workspace_name.replace('-','_')
        to = "FS_" + emailPrefix + "@cppib.com"
        cc = "ahassan@cppib.com"

        try:
            msg = MIMEMultipart()
            msg['Subject'] = subject
            msg['From'] = "svc_finsights@cppib.com"
            msg['To'] = to
            msg['Cc'] = cc
            msg.attach(MIMEText(emailBody, 'plain'))
            send_smtp_email(msg, [to, cc])

        except Exception as e:
            print(e)


def handle_success_event(event):
     workspaceName = json.loads(event["detail"]["input"]).get("detail").get("object").get("key").split('/')[0]
     environment = json.loads(event["detail"]["input"]).get("detail").get("bucket").get("name").split('-')[-1]

     manifestFilePath = json.loads(event["detail"]["input"]).get("detail").get("object").get("key")
     manifestBucket = json.loads(event["detail"]["input"]).get("detail").get("bucket").get("name")

     manifestContent = get_manifest_content(manifestFilePath, manifestBucket)

     emailBody = f"""
     
     Manifest.json file content: 
     
     {manifestContent}
     
     """
     subject = "SUCCESS [" + workspaceName + "] - " + environment
     send_email(emailBody ,workspaceName, subject)


def handle_failure_event(event):
     sfn = boto3.client(service_name='stepfunctions',region_name='us-east-1')
     
     execution_arn = event["detail"]["executionArn"]  
     workspaceName = json.loads(event["detail"]["input"]).get("detail").get("object").get("key").split('/')[0]
     environment = json.loads(event["detail"]["input"]).get("detail").get("bucket").get("name").split('-')[-1]

     manifestFilePath = json.loads(event["detail"]["input"]).get("detail").get("object").get("key")
     manifestBucket = json.loads(event["detail"]["input"]).get("detail").get("bucket").get("name")

     executionFailure = {}
     taskFailure = {}
     mapFailure = {}
     lowestErrorMessage = []

     history = sfn.get_execution_history(
          executionArn=execution_arn,
          maxResults=1000,
          reverseOrder=True
     )

     for item in history["events"]:
          if item["type"] == "ExecutionFailed":
               executionFailed = item.get("executionFailedEventDetails: ", {})
               executionFailure[executionFailed.get("Error")] = executionFailed.get("cause")
               print("106: ", executionFailed)
               if(executionFailed.get("cause")):
                    lowestErrorMessage.append(json.loads(executionFailed.get("cause")).get("errorMessage"))

          elif item["type"] == "TaskFailed":
               failed = item.get("taskFailedEventDetails", {})
               taskExecutionArn = json.loads(failed.get("cause")).get("ExecutionArn")
               taskFailure[failed.get("error")] = failed.get("cause")
               if(failed.get("cause")):
                    lowestErrorMessage.append(json.loads(failed.get("cause")).get("Cause"))
     if(taskExecutionArn):
        taskHistory = sfn.get_execution_history(
                    executionArn=taskExecutionArn,
                    maxResults=1000,
                    reverseOrder=True
        )
        for item in taskHistory["events"]:

            
            if item["type"] == "ExecutionFailed":
                executionFailed = item.get("executionFailedEventDetails: ", {})
                executionFailure[executionFailed.get("Error")] = executionFailed.get("cause")
                print("129: ", executionFailed)
                if(executionFailed.get("cause")):
                    lowestErrorMessage.append(json.loads(executionFailed.get("cause")).get("errorMessage"))
            elif item["type"] == "TaskFailed":
                failed = item.get("taskFailedEventDetails", {})
                taskFailure[failed.get("error")] = failed.get("cause")
                if(failed.get("cause")):
                    lowestErrorMessage.append(json.loads(failed.get("cause")).get("Cause"))
            elif item["type"] == "MapStateFailed":
                mapRun = find_by_event_type(taskHistory["events"],"MapRunStarted")
                mapRunArn = mapRun["mapRunStartedEventDetails"]["mapRunArn"]
                mapExecutionArn= sfn.list_executions(
                     mapRunArn=mapRunArn,
                     statusFilter='FAILED'
                )["executions"][0]["executionArn"]
                mapRunHistory = sfn.get_execution_history(
                    executionArn=mapExecutionArn,
                    maxResults=1000,
                    reverseOrder=True
                )
                executionFailed = find_by_event_type(mapRunHistory["events"], "ExecutionFailed")
                payloadInfo = find_by_event_type(mapRunHistory["events"], "TaskScheduled")
                mapFailure["FailedExecution"] = executionFailed
                if(executionFailed):
                    lowestErrorMessage.append(json.loads(executionFailed.get("executionFailedEventDetails").get("cause")).get("errorMessage"))
                mapFailure["FailedPayload"] = payloadInfo

     manifestContent = get_manifest_content(manifestFilePath, manifestBucket)
     emailBody = construct_failure_email([mapFailure, taskFailure, executionFailure], lowestErrorMessage, manifestContent )
     subject = "ERROR [" + workspaceName + "] - " + environment
     send_email(emailBody ,workspaceName, subject)


def get_manifest_content( manifestFilePath, manifestBucket):
     s3 = boto3.client(service_name='s3',region_name='us-east-1')
     response = s3.get_object(Bucket=manifestBucket, Key=manifestFilePath)
     return response['Body'].read().decode('utf-8')

def construct_failure_email(failurePayload, lowestErrorMessage, manifestContent):
     failuresFormatted = []
     for item in failurePayload:
       clean_data = normalize_data(item)
       failuresFormatted.append(json.dumps(clean_data, indent=4, default=datetime_serializer))
     
     emailBody = f"""
     Error message list: 

     {lowestErrorMessage}
     
     ---------
     
     Manifest.json file content: 
     
     {manifestContent}
     
     ----------
     
     Error stack trace: 
     
     {"\n\n".join(failuresFormatted)}
     """

     return emailBody    



def find_by_event_type(events, event_type):
     return next((e for e in events if e['type'] == event_type))

def datetime_serializer(obj):
     if isinstance(obj, datetime):
          return obj.isoformat()  

def normalize_data(obj):
     if isinstance(obj, dict):
          return {k: normalize_data(try_parse_json(v)) for k,v in obj.items()}
     elif isinstance(obj, list): 
          return [normalize_data(try_parse_json(i) for i in obj)]
     elif isinstance(obj, datetime):
          return obj.isoformat()
     elif isinstance(obj, Iterable) and not isinstance(obj, (str, bytes)):
          return list(obj)
     else:
          return try_parse_json(obj) 


def try_parse_json(value):
     if isinstance(value, str):
        try:
             return json.loads(value)
        except json.JSONDecodeError:
             return value
     return value              
                                 
