
from event_notification_lambda.utils import handle_failure_event
from event_notification_lambda.utils import handle_success_event

def lambda_handler(event, context):
    if(event["detail"]["status"] == "FAILED"):
        handle_failure_event(event)
    elif(event["detail"]["status"] == "SUCCEEDED"):
        handle_success_event(event)    
