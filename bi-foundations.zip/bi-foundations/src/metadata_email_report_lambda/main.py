

from metadata_email_report_lambda.utils import email_metadata_report, get_metadata_report_content, upload_metadata_report_to_s3, trigger_metadata_report_glue_job



def lambda_handler(event,context):
    print("Generating Metadata Report Generator For Today")
    recipient_emails = ["ahassan@cppib.com", "sdhummad@cppib.com", "datagovernance@cppib.com"]
    #recipient_emails = ["ahassan@cppib.com"]

    # Generate Metadata Report Content and Email to Recipients
    metadata_report_content = get_metadata_report_content()
    email_metadata_report(metadata_report_content,recipient_emails)

    # Upload Metadata Report to S3
    s3_file_path = upload_metadata_report_to_s3(metadata_report_content)

    # Trigger Glue Job to Add Metadata Report to Data Fabric 
    trigger_metadata_report_glue_job(s3_file_path)


    
