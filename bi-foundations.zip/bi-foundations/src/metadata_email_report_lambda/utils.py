import boto3
import os
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import smtplib
import csv
import io
from email.message import EmailMessage
from datetime import datetime

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret

region_name = os.environ['AWS_REGION_NAME']
env = os.environ['ENV_NAME']
qs_client = boto3.client('quicksight', region_name)
sm_client = boto3.client("secretsmanager", region_name)
s3_client = boto3.client("s3", region_name)
glue_client = boto3.client("glue", region_name)

AWS_ACCOUNT_ID = os.environ['ACCOUNT_ID']

FINSIGHTS_PO_TAG = "finsights_detail.product_owners"


def get_opensearch_client() -> OpenSearch:
    es_endpoint = os.environ["OPENSEARCH_ENDPOINT"]

    credentials = boto3.Session().get_credentials()

    awsauth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        region_name,
        "es",
        session_token=credentials.token,
    )

    opensearch_client = OpenSearch(
        hosts=[{"host": es_endpoint, "port": 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
    )

    return opensearch_client


def get_all_dashboard_ids():
    all_dashboard_ids = []

    try:
        print(f"Getting all the Dashboard Ids....")
        response = qs_client.list_dashboards(
        AwsAccountId=AWS_ACCOUNT_ID
        )

        if "DashboardSummaryList" in response.keys():
            all_dashboard_ids += [item["DashboardId"] for item in response["DashboardSummaryList"]]
        
        while "NextToken" in response.keys():
            response = qs_client.list_dashboards(
                            AwsAccountId=AWS_ACCOUNT_ID,
                            NextToken=response["NextToken"]
                            )
            if "DashboardSummaryList" in response.keys():
                all_dashboard_ids += [item["DashboardId"] for item in response["DashboardSummaryList"]]
        
        return [dashboard_id for dashboard_id in all_dashboard_ids if "bif" in dashboard_id]
    
    except Exception as error:
        print(f"Getting all the Dashboard Ids Failed with Error : {error}")


def find_ds_in_dashboard(dashboard_id):
    dashboard_ds_arns = []
    
    try:
        print(f"Finding Dataset Arns in Dashboard Id : {dashboard_id}")
        response = qs_client.describe_dashboard_definition(
                    AwsAccountId=AWS_ACCOUNT_ID,
                    DashboardId=dashboard_id
                )
        if "Definition" in response.keys():
            if "DataSetIdentifierDeclarations" in response["Definition"].keys():
                dashboard_ds_arns += [ds_item["DataSetArn"] for ds_item in response["Definition"]["DataSetIdentifierDeclarations"]]
        
        print(f"Dataset Arns founds for Dashboard Id : {dashboard_id} - Datasets : {dashboard_ds_arns}")
        return dashboard_ds_arns
    except Exception as error:
        print(f"Finding Dataset Arns in Dashboard Id : {dashboard_id} Failed with Error : {error}")


def get_sql_query_ds_source(ds_arn):
    sql_query = ""
    ds_source = "NON_DATAFABRIC"

    try:
        print(f"Finding SQL Query and Dataset Source for Dataset Arn: {ds_arn}")
        ds_id = ds_arn.split("/")[-1]
        response = qs_client.describe_data_set(
                    AwsAccountId=AWS_ACCOUNT_ID,
                    DataSetId=ds_id
                )
        if "DataSet" in response.keys():
            if "PhysicalTableMap" in response["DataSet"].keys():
                for key,value in response["DataSet"]["PhysicalTableMap"].items():
                    if "CustomSql" in value:
                        if "SqlQuery" in value["CustomSql"]:
                            sql_query = value["CustomSql"]["SqlQuery"]
                            ds_source_id = value["CustomSql"]["DataSourceArn"].split("/")[-1]
                            ds_source = "DATAFABRIC" if "fabric_catalog" in ds_source_id else "NON_DATAFABRIC"
        
        return sql_query,ds_source

    except Exception as error:
        print(f"Finding SQL Query and Dataset Source for Dataset Arn: {ds_arn} failed with Error : {error}")
        return "",""

def find_db_tables_in_ds(sql_query,ds_arn=""): 
    import sqlglot
    from sqlglot import exp

    db_table_meta = []
    db_names, table_names = [],[]
    ds_id = ds_arn.split("/")[-1] if ds_arn else ""

    parsed = sqlglot.parse_one(sql_query)

    for table in parsed.find_all(exp.Table):
        db_name = table.args.get("db").this if table.args.get("db") else None
        if db_name:
            db_table_row = {
                "database": table.args.get("db").this if table.args.get("db") else None,
                "table": table.name
            }
            if db_table_row not in db_table_meta:
                db_table_meta.append({
                    "database": db_name,
                    "table": table.name
                })
                db_names.append(db_name)
                table_names.append(table.name)
    
    print(f"Found database and tables for dataset id : {ds_id} - Meta Info: {db_table_meta} ")
    return db_table_meta,db_names,table_names


def get_asset_product_owners(asset_id):
        os_client = get_opensearch_client()

        results = os_client.search(
            index = os.environ["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results = True,
            body = {
                    "query": {
                        "term": {
                        "_id": asset_id
                        }
                    }
                },
                _source_includes = [FINSIGHTS_PO_TAG]
        )

        print(f"Product owners Response for Asset id : {asset_id} are : {results}")

        asset_product_owners = []
        if "hits" in results.get("hits").keys():
                search_results = results.get("hits")
                if search_results["hits"]:
                    if "_source" in search_results["hits"][0].keys():
                        search_hits = search_results["hits"][0]["_source"]
                        if "finsights_detail" in search_hits.keys():
                                if "product_owners" in search_hits["finsights_detail"].keys():
                                    asset_product_owners += search_hits["finsights_detail"]["product_owners"]

        print(f"Product owners for Asset id : {asset_id} are : {asset_product_owners}")

        po_names = [ po["name"] for po in asset_product_owners ]
        po_emails = [ po["email"] for po in asset_product_owners ]

        return asset_product_owners,po_names,po_emails


def get_metadata_report_content():
    metadata_report_rows = []
    metadata_report_header = ["dashboard_id","dataset_id","dataset_source",
                              "database_tables_metadata","databases","tables",
                              "product_owners_metadata","product_owner_names","product_owner_emails"
                              ]
    all_dashboard_ids = get_all_dashboard_ids()

    for dashboard_id in all_dashboard_ids:
        ds_arns = find_ds_in_dashboard(dashboard_id)
        for ds_arn in ds_arns:
            ds_id = ds_arn.split("/")[-1]
            sql_query,ds_source = get_sql_query_ds_source(ds_arn)
            db_table_meta,db_names,table_names = [],[],[]
            if sql_query:
                db_table_meta,db_names,table_names = find_db_tables_in_ds(sql_query,ds_arn)
            dashboard_product_owners,po_names,po_emails = get_asset_product_owners(dashboard_id)
            metadata_report_rows.append(
                [
                    dashboard_id,
                    ds_id,
                    ds_source,
                    db_table_meta,
                    db_names,
                    table_names,
                    dashboard_product_owners,
                    po_names,
                    po_emails
                ]
            )

    all_metadata_report_rows = [metadata_report_header] + metadata_report_rows
    print(f"Generated complete metadata report for the day....")

    return all_metadata_report_rows

def get_daily_metadata_report_email_body():
    DAILY_FINSIGHTS_METADATA_REPORT_HTML = f"""
        <html>
            <body style="font-family: Arial, Helvetica, sans-serif; color: #333333; background-color: #ffffff;">
                
                <p style="font-size: 14px;">Hello,</p>

                <p style="font-size: 14px;">
                Please find attached the <strong>Daily Finsights Metadata Report for Environment: {env}</strong> for today.
                </p>

                <div style="
                border-left: 4px solid #005EB8;
                padding: 12px 16px;
                margin: 16px 0;
                background-color: #f5f8fc;
                font-size: 14px;
                ">
                <strong>📊 What’s included in this report:</strong>
                <ul style="margin-top: 8px; padding-left: 20px;">
                    <li>Dashboards and associated datasets</li>
                    <li>Underlying databases and tables referenced</li>
                    <li>Dataset sources and SQL lineage (where applicable)</li>
                    <li>Mapped product owners and contact details</li>
                </ul>
                </div>

                <p style="font-size: 14px;">
                This report is generated automatically to support <strong>data transparency, ownership, and governance</strong>
                across the Finsights platform.
                </p>

                <p style="font-size: 14px;">
                If you have any questions, notice missing ownership, or require enhancements to this report,
                please feel free to reach out.
                </p>

                <br />

                <p style="font-size: 14px;">
                Regards,<br />
                <strong>Finsights Data Platform</strong><br />
                Technology &amp; Data
                </p>

                <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 24px 0;" />

                <p style="font-size: 11px; color: #666666;">
                This is an automated email. Please do not reply directly to this message.
                </p>

            </body>
        </html>
            """
    return DAILY_FINSIGHTS_METADATA_REPORT_HTML


def send_email_with_csv_rows(
    smtp_host,
    smtp_port,
    smtp_user,
    smtp_password,
    sender_email,
    to_emails,
    subject,
    body,
    rows,
    is_html,
    filename="finsights_daily_metadata_report"
):
    #Create CSV in memory
    csv_buffer = io.StringIO()
    writer = csv.writer(csv_buffer)
    writer.writerows(rows)

    csv_content = csv_buffer.getvalue().encode("utf-8")

    # Create email
    msg = EmailMessage()
    msg["From"] = sender_email
    msg["To"] = ", ".join(to_emails)
    msg["Subject"] = subject
    if is_html:
        msg.set_content(body, subtype="html")
    else:
        msg.set_content(body)

    # Attach CSV
    msg.add_attachment(
        csv_content,
        maintype="text",
        subtype="csv",
        filename=f"{filename}_{env}.csv"
    )

    # Send email
    try:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
    except Exception as error:
        print(f"Sending email to {to_emails} about the daily metadata report failed with Error : {error}")
    
    print(f"Sent email to {to_emails} about the daily metadata report.....")


def email_metadata_report(metadata_report_rows,recipient_emails):
    secret_name = "smtp/svc_finsights"
    smtp_host = os.environ["SMTP_HOST"]
    smtp_port = os.environ["SMTP_PORT"]
    smtp_user, smtp_password = get_smtp_cred_from_secret(
        get_secret_from_secret_manager(sm_client,secret_name)
    )

    sender_email = "svc_finsights@cppib.com"
    email_subject = f"{env.upper()}: Daily Finsights Metadata Report"

    send_email_with_csv_rows(
        smtp_host,
        smtp_port,
        smtp_user,
        smtp_password,
        sender_email,
        recipient_emails,
        email_subject,
        get_daily_metadata_report_email_body(),
        metadata_report_rows,
        True
    )


def upload_metadata_report_to_s3(metadata_report_rows):
    # Create CSV in memory
    csv_buffer = io.StringIO()
    writer = csv.writer(csv_buffer)
    writer.writerows(metadata_report_rows)

    csv_content = csv_buffer.getvalue().encode("utf-8")

    # Use S3 client to upload CSV to S3
    bucket_name = os.environ["S3_BUCKET_NAME"] 

    # Dynamically create file name with timestamp
    time_now = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"finsights_metadata_report_{time_now}.csv"
    file_key = f"finsights_metadata_report/{file_name}"
    s3_file_path = f"s3://{bucket_name}/{file_key}"

    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=file_key,
            Body=csv_content,
            ContentType="text/csv"
        )
        print(f"Uploaded metadata report to S3 at {s3_file_path}")
        return s3_file_path
    except Exception as error:
        print(f"Uploading metadata report to S3 failed with Error : {error}")
        raise error


def trigger_metadata_report_glue_job(s3_input_path):
    glue_job_name = os.environ["GLUE_JOB_NAME"]

    try:
        response = glue_client.start_job_run(
            JobName = glue_job_name,
            Arguments = {
                "--env" : env,
                "--input_s3_path" : s3_input_path
            }
        )
        print(f"Triggered Glue Job : {glue_job_name} with S3 Input Path : {s3_input_path} - Response : {response}")
    except Exception as error:
        print(f"Triggering Glue Job : {glue_job_name} with S3 Input Path : {s3_input_path} failed with Error : {error}")
        raise error
