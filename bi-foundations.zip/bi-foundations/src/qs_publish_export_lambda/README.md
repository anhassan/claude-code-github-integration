## Context

This lambda is triggered on a Cloudwatch event rule listening for the publish action in the QuickSight console. It calls the `describe_dashboard_definition` API, and stores it in an S3 bucket for processing/usage in the asset promotion pipeline. These `dashboard_definition.json` files also serve as version control for dashboards being developed in QuickSight. 