import os
import time
import json

import urllib
import urllib.request

import boto3

from common.utils.quicksight_theme import is_managed_theme

qs_client = boto3.client("quicksight", region_name="us-east-1")
s3_client = boto3.client("s3", region_name="us-east-1")

BUCKET_NAME = os.environ["BUCKET_NAME"]
ACCOUNT_ID = os.environ["ACCOUNT_ID"]

DASHBOARD_EVENTS = [
    "QuickSight Dashboard Creation Successful",
    "QuickSight Dashboard Update Successful",
    "QuickSight Dashboard Published Version Updated",
]

THEME_EVENTS = [
    "QuickSight Theme creation successful",
    "QuickSight Theme update successful",
    "QuickSight Theme Creation Successful",
    "QuickSight Theme Update Successful",
]

ANALYSIS_EVENTS = [
    "QuickSight Analysis Creation Successful",
    "QuickSight Analysis update successful",
]

DASHBOARD_ARN_FMT = "arn:aws:quicksight:us-east-1:{account}:dashboard/{dashboard_id}"


def wait_for_bundle(bundle_id):
    times = [10, 15, 20, 30]
    print("Waiting for status on: {}".format(bundle_id))
    for _time in times:
        response = qs_client.describe_asset_bundle_export_job(
            AwsAccountId=ACCOUNT_ID, AssetBundleExportJobId=bundle_id
        )
        status = response["JobStatus"]
        if "FAILED" in status:
            print("Operation failed: {}".format(response))
            raise
        if "SUCCESSFUL" in status:
            print("Operation succeeded: {}".format(response))
            return response
        print("Status is: {}, waiting {} seconds".format(status, _time))
        time.sleep(_time)
    print("Completed retries, status is still open: {}".format(response))
    raise


def get_dashboard_source_entity(dashboard_id, version):
    response = qs_client.describe_dashboard(
        AwsAccountId=ACCOUNT_ID, DashboardId=dashboard_id, VersionNumber=version
    )
    return response["Dashboard"]["Version"]["SourceEntityArn"]


def export_source_entity(entity_arn):
    print("Exporting {}".format(entity_arn))
    response = qs_client.describe_analysis_definition(
        AwsAccountId=ACCOUNT_ID, AnalysisId=entity_arn.split("analysis/")[-1]
    )
    return response


def export_bundle(dashboard_name, dashboard_id, version):
    response = qs_client.start_asset_bundle_export_job(
        AwsAccountId=ACCOUNT_ID,
        AssetBundleExportJobId="{}-{}".format(dashboard_id, version),
        ResourceArns=[
            DASHBOARD_ARN_FMT.format(account=ACCOUNT_ID, dashboard_id=dashboard_id)
        ],
        IncludeAllDependencies=True,
        ExportFormat="QUICKSIGHT_JSON",
        ValidationStrategy={"StrictModeForAllResources": False},
    )
    bundle_response = wait_for_bundle(response["AssetBundleExportJobId"])
    print("Retrieving .qs...")
    urllib.request.urlretrieve(bundle_response["DownloadUrl"], "/tmp/bundle.qs")
    print("Uploading qs. to S3 ({})".format(BUCKET_NAME))
    s3_client.upload_file(
        "/tmp/bundle.qs",
        BUCKET_NAME,
        "{}/V{}/export/bundle.qs".format(dashboard_name, version),
    )


def export_theme_from_dashboard(event, dashboard_resp):
    """
    Mirror the dashboard's theme into S3.

    Custom theme -> export its definition to the version and latest keys.
    Managed/CLASSIC theme or no theme -> delete any stale custom theme file at
    the latest key so promotion mirrors the (managed) dashboard theme.
    """
    dashboard_name = dashboard_resp["Name"]
    theme_current_key = "{}/latest/theme_definition.json".format(dashboard_name)
    theme_arn = dashboard_resp.get("ThemeArn")

    if not theme_arn or is_managed_theme(theme_arn):
        print(
            f"Dashboard theme is managed/none ({theme_arn}); "
            f"deleting stale s3://{BUCKET_NAME}/{theme_current_key}"
        )
        s3_client.delete_object(Bucket=BUCKET_NAME, Key=theme_current_key)
        return

    account_id = event["account"]
    try:
        theme = qs_client.describe_theme(
            AwsAccountId=account_id, ThemeId=theme_arn.split("/")[-1]
        )
    except Exception as error:
        print("An error has occured while retreiving the Theme Definition: ", error)
        return

    dashboard_version = event["detail"]["versionNumber"]
    theme_version_key = "{}/V{}/theme_definition.json".format(
        dashboard_name, dashboard_version
    )

    print(f"Uploading theme definition to: s3://{BUCKET_NAME}/{theme_version_key} ")
    print(f"Uploading theme definition to: s3://{BUCKET_NAME}/{theme_current_key} ")

    s3_client.put_object(
        Body=json.dumps(theme, default=str, ensure_ascii=False),
        Bucket=BUCKET_NAME,
        Key=theme_version_key,
    )
    s3_client.put_object(
        Body=json.dumps(theme, default=str, ensure_ascii=False),
        Bucket=BUCKET_NAME,
        Key=theme_current_key,
    )


def dashboard_export(event, context):
    # Configure Settings
    account_id = event["account"]
    dashboard_id = event["detail"]["dashboardId"]
    dashboard_version = event["detail"]["versionNumber"]

    try:
        print(f"Boto3 version: {boto3.__version__}")
        dashboard_definition = qs_client.describe_dashboard_definition(
            AwsAccountId=account_id,
            DashboardId=dashboard_id,
            VersionNumber=dashboard_version,
        )
        dashboard_name = dashboard_definition["Name"]
    except Exception as error:
        print("An error has occured while retreiving the Dashboard Definition: ", error)

    # Export Dashboard to S3
    dashboard_version_key = "{}/V{}/dashboard_definition.json".format(
        dashboard_name, dashboard_version
    )
    analysis_version_key = "{}/V{}/analysis_definition.json".format(
        dashboard_name, dashboard_version
    )
    dashboard_current_key = "{}/latest/dashboard_definition.json".format(dashboard_name)
    s3_client.put_object(
        Body=json.dumps(dashboard_definition, default=str, ensure_ascii=False),
        Bucket=BUCKET_NAME,
        Key=dashboard_version_key,
    )
    s3_client.put_object(
        Body=json.dumps(dashboard_definition, default=str, ensure_ascii=False),
        Bucket=BUCKET_NAME,
        Key=dashboard_current_key,
    )

    entity_arn = get_dashboard_source_entity(dashboard_id, dashboard_version)
    analysis_definition = export_source_entity(entity_arn)
    s3_client.put_object(
        Body=json.dumps(analysis_definition, default=str, ensure_ascii=False),
        Bucket=BUCKET_NAME,
        Key=analysis_version_key,
    )

    export_theme_from_dashboard(event, dashboard_definition)


def theme_export_from_theme_id(event, theme_id):
    # Configure Settings
    account_id = event["account"]
    # Get Theme Definition
    try:
        theme = qs_client.describe_theme(AwsAccountId=account_id, ThemeId=theme_id)
    except Exception as error:
        print("An error has occured while retreiving the Theme Definition: ", error)

    # Export Theme to S3
    theme_version_number = theme["Theme"]["Version"]["VersionNumber"]
    theme_name = theme["Theme"]["Name"]

    return {
        "theme_id": theme_id,
        "theme_name": theme_name,
        "theme_version": theme_version_number,
        "theme_definition": theme,
    }


def lambda_handler(event, context):
    print(event)
    if event["detail-type"] in DASHBOARD_EVENTS:
        dashboard_export(event, context)
    elif event["detail-type"] in THEME_EVENTS:
        theme_id = event["detail"]["themeId"]
        theme_info = theme_export_from_theme_id(event, theme_id)
        theme_version_key = "themes/{}/V{}/theme_definition.json".format(
            theme_info["theme_id"], theme_info["theme_version"]
        )
        theme_current_key = "themes/{}/latest/theme_definition.json".format(
            theme_info["theme_id"]
        )
        s3_client.put_object(
            Body=json.dumps(theme_info["theme_definition"], default=str),
            Bucket=BUCKET_NAME,
            Key=theme_version_key,
        )
        s3_client.put_object(
            Body=json.dumps(theme_info["theme_definition"], default=str),
            Bucket=BUCKET_NAME,
            Key=theme_current_key,
        )
