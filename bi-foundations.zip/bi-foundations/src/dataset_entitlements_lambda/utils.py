from datetime import datetime
import hashlib
import json
import logging
import boto3
import os
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Attr
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from collections.abc import Iterable

from openpyxl import load_workbook

logger = logging.getLogger()
logger.setLevel(logging.INFO)
region_name = os.environ['AWS_REGION']
dynamodb = boto3.client('dynamodb', region_name)

MAPPING_TABLE_NAME = "bi-foundations-workspace-rls-entitlements-mapping"

def create_table(table_name):
    try:
        logger.info(f"Creating table {table_name}...") 
        dynamodb.create_table(
            TableName=table_name, 
            KeySchema=[
                {'AttributeName': 'workspace_id', 'KeyType': 'HASH'}, 
                {'AttributeName': 'unique_key', 'KeyType': 'RANGE'},
            ],
            AttributeDefinitions=[
                {'AttributeName': 'workspace_id', 'AttributeType': 'S'}, 
                {'AttributeName': 'unique_key', 'AttributeType': 'S'}, 
            ], 
            BillingMode = 'PAY_PER_REQUEST'
        )
        waiter = dynamodb.get_waiter('table_exists')
        waiter.wait(TableName=table_name)
        logger.info(f"Table {table_name} is active")
    except ClientError as e: 
        if e.response ['Error']['Code'] == 'ResourceInUseException':
            logger.info(f"Table {table_name} already exists")

            logger.info(f"Deleting table {table_name}...")
            dynamodb.delete_table(TableName=table_name)
            waiter = dynamodb.get_waiter('table_not_exists')
            waiter.wait(TableName=table_name)
            logger.info(f"Table {table_name} has been deleted.")

            create_table(table_name)
        else:
            raise


def transform_row_to_items(row, header, workspace_id):
    dataset_id = row[header.index("dataset_id")] if "dataset_id" in header else "*"
    column_name = row[header.index("column_name")] if "column_name" in header else "*"
    column_value = row[header.index("column_value")] if "column_value" in header else "*"

    approver_cols = []
    n=1
    while True:
        approver_col = f"approver_{n}"
        approver_backup_col = f"approver_{n}_backup"

        if approver_col in header:
            approver_idx = header.index(approver_col)
            backup_idx = header.index(approver_backup_col)
            approver_cols.append((approver_idx, backup_idx))
            n += 1
        else:
            break

    items = []    
    for hierarchy, (approver_idx, backup_idx) in enumerate(approver_cols, 1):
        approver_email = []
        if row[approver_idx]:
            approver_email.append(row[approver_idx])
        if row[backup_idx]:
          approver_email.append(row[backup_idx])     
        item = {
            "workspace_id" : workspace_id, 
            "dataset_id" : dataset_id, 
            "column_name" : column_name, 
            "column_value" : column_value, 
            "hierarchy" : str(hierarchy), 
            "approver_email" : approver_email
        }
        if not approver_email: 
            break
        items.append(item)
    return items      
           

def s3_upload(event):
    bucket = event['detail']['bucket']['name']
    key = event['detail']['object']['key']

    table_name = "bi-foundations-entitlements-" + os.path.splitext(os.path.basename(key))[0].lower()

    s3 = boto3.client('s3',region_name)
    download_path = f"/tmp/{os.path.basename(key)}"
    s3.download_file(bucket, key, download_path)

    create_table(table_name)

    dynamodb_resource = boto3.resource('dynamodb',region_name)
    entitlements_table = dynamodb_resource.Table(table_name)
    mapping_table = dynamodb_resource.Table(MAPPING_TABLE_NAME)

    wb = load_workbook(download_path)
    sheet = wb.active

    header = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row = 1))]
    workspace_id = os.path.splitext(os.path.basename(key))[0].lower()

    colNameWild = False
    colValueWild = False

    if "column_name" not in header:
        colNameWild = True
    if "column_value" not in header:
        colValueWild = True
    

    savedRows = []


    with entitlements_table.batch_writer() as batch:
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if is_empty_row(row):
                continue
            if (not colNameWild) and (row[header.index("column_name")] == "*"):
                savedRows.append(row)
                continue
            if (not colValueWild) and (row[header.index("column_value")] == "*"):
                savedRows.append(row)
                continue
            items = transform_row_to_items(row, header, workspace_id)
            for item in items: 
                item['unique_key'] = make_unique_key(item)
                batch.put_item(Item=item)

    for row in savedRows : 
        if row[header.index("column_name")] == "*":
            serch_key = "dataset_id"
            search_value = row[header.index("dataset_id")]
        if  row[header.index("column_value")] == "*":
            serch_key = "column_name"
            search_value = row[header.index("column_name")]  
        try:       
            response = scan_ddb(entitlements_table, serch_key, search_value)
        except ClientError as e:
            logger.info("Search returned no values, inserting wildcard rows...")   
            with entitlements_table.batch_writer() as batch:
                items = transform_row_to_items(row, header, workspace_id)
                for item in items: 
                    item['unique_key'] = make_unique_key(item)
                    batch.put_item(Item=item)
        else: 
            logger.info("Illegal rows found!!!!")
            logger.info("Removing illegal rows...")
            keys_to_delete = set((item['workspace_id'], item['unique_key']) for item in response)
            with entitlements_table.batch_writer() as batch:
                for workspace_id,unique_key in keys_to_delete:
                    batch.delete_item(
                        Key={'workspace_id': workspace_id, 'unique_key': unique_key}
                    )
                logger.info("Batch delete complete")
            logger.info("Uploading correct wildcard rows...")
            with entitlements_table.batch_writer() as batch:
                items = transform_row_to_items(row, header, workspace_id)
                for item in items: 
                    item['unique_key'] = make_unique_key(item)
                    batch.put_item(Item=item)        
                        


    mapping_table.put_item(Item={
        'table_name' : table_name, 
        'workspace_id' : workspace_id,
    })  


    return {
        'statusCode' : 200, 
        'body' : f"Created table {table_name}, inserted data, and updated metadata"
    }


def make_unique_key(row):
    combined = f"{row['workspace_id']}#{row['dataset_id']}#{row['column_name']}#{row['column_value']}#{row['hierarchy']}"
    return hashlib.sha256(combined.encode('utf-8')).hexdigest()

def is_empty_row(row):
    return all((cell is None or (isinstance(cell, str) and cell.strip() == "")) for cell in row) 

def scan_ddb(ddb_table, search_key, search_value):
        logger.info(f"Searching for where {search_key} == {search_value}...")   
        filter_condition = Attr(search_key).eq(search_value)
        response = ddb_table.scan(
                        FilterExpression=filter_condition
                    )
        ddb_result_rows = response.get("Items",[])
        while 'LastEvaluatedKey' in response:
            response = ddb_table.scan(
                FilterExpression=filter_condition,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            ddb_result_rows += response.get("Items",[])
        return ddb_result_rows

                                 