from dataset_entitlements_lambda.utils import s3_upload


def lambda_handler(event, context):
    s3_upload(event)