from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from portal_user_lambda.permissions import ASSET_ENTITLEMENT_PERMISSIONS_USERS


class AssetEntitlementPermissions:
    PRIMARY_KEY = "email"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env

    def get_asset_entitlement_permission(self, event: ApiEventConfig):
        claims = event.get_auth_claims()
        
        for user in ASSET_ENTITLEMENT_PERMISSIONS_USERS:
            self.dynamodb_client.update_item(
                TableName=self.env["ASSET_ENTITLEMENT_PERMISSIONS_TABLE"],
                Key={self.PRIMARY_KEY: {"S": user}},
            )

        try:
            response = self.dynamodb_client.query(
                TableName=self.env["ASSET_ENTITLEMENT_PERMISSIONS_TABLE"],
                KeyConditionExpression=f"{self.PRIMARY_KEY} = :email",
                ExpressionAttributeValues={":email": {"S": claims["email"]}},
            )

        except Exception as e:
            self.logger.exception(e)

        return response
    

    def get_q_topic_permission(self, event: ApiEventConfig):
        email = event.get_email()
        dashboard_id = event.get_path_parameters()["dashboard_id"]

        try:
            response = self.dynamodb_client.query(
                TableName=self.env["Q_TOPIC_SECURITY_TABLE"],
                KeyConditionExpression="asset_id = :id", 
                ExpressionAttributeValues={":id": {"S": dashboard_id}},
                ProjectionExpression="asset_id, #u", 
                ExpressionAttributeNames={ "#u": "users" }
            )
            items = response.get("Items", [])
            if not items:
                return True
            item = items[0]
            users = item.get("users", {}).get("SS", [])

        except Exception as e:
            self.logger.exception(e)

        return email in users
