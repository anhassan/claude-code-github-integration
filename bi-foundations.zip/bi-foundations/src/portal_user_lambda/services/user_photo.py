import json
import boto3
import logging
import os
logger = logging.getLogger()
lambda_client = None

def get_user_photo(user_email):
    global lambda_client
    param = {'user_id': user_email}
    payload = {
            'path': "/user",
            'httpMethod': 'GET',
            'pathParameters': param
        }
    if lambda_client is None:
        lambda_client = boto3.client('lambda', region_name="us-east-1")
    try:
        res = lambda_client.invoke(
                FunctionName=get_discovey_arn(),
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
        res_json = json.loads(res['Payload'].read().decode("utf-8"))
        photo = json.loads(res_json['body']).get('user_photo') if res_json['statusCode'] == 200 else None
        return photo if photo is not None else photo
    except Exception as e:
        logger.exception(e)
        return None
    
def get_discovey_arn():
    match os.environ["ENV_NAME"].lower():
        case "dev":
            return "arn:aws:lambda:us-east-1:200967598245:function:df-data-discovery-service-dev"
        case "qa":
            return "arn:aws:lambda:us-east-1:885014163466:function:df-data-discovery-service-qa"
        case "uat":
            return "arn:aws:lambda:us-east-1:207662059077:function:df-data-discovery-service-uat"
        case "prod":
            return "arn:aws:lambda:us-east-1:679601897237:function:df-data-discovery-service-prod"