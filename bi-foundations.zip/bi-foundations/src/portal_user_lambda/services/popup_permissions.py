from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from portal_user_lambda.permissions import POPUP_PERMISSIONS_USERS


class PopupPermissions:
    PRIMARY_KEY = "email"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env
        self.sync_static_popup_users()

    def sync_static_popup_users(self):
        try:
            existing_users_response = self.dynamodb_client.scan(
                TableName=self.env["POPUP_PERMISSIONS_TABLE"]
            )
            existing_emails = {
                item[self.PRIMARY_KEY]["S"]
                for item in existing_users_response.get("Items", [])
            }

            for email in POPUP_PERMISSIONS_USERS:
                if email not in existing_emails:
                    self.dynamodb_client.put_item(
                        TableName=self.env["POPUP_PERMISSIONS_TABLE"],
                        Item={self.PRIMARY_KEY: {"S": email}}
                    )
                    self.logger.info(f"Synced static user: {email}")

        except Exception as e:
            self.logger.exception("Failed to sync static popup users.")

    def get_popup_edit_permission(self, event: ApiEventConfig):
        claims = event.get_auth_claims()

        try:
            response = self.dynamodb_client.query(
                TableName=self.env["POPUP_PERMISSIONS_TABLE"],
                KeyConditionExpression=f"{self.PRIMARY_KEY} = :email",
                ExpressionAttributeValues={":email": {"S": claims["email"]}},
            )

        except Exception as e:
            self.logger.exception(e)

        return response
    
    
    def get_popup_all_users(self, event: ApiEventConfig):
        try:
            response = self.dynamodb_client.scan(
                TableName=self.env["POPUP_PERMISSIONS_TABLE"]
            )
            return response.get("Items", [])
        except Exception as e:
            self.logger.exception("Failed to scan popup permissions table")
            return []

    
    def popup_add_user(self, event: ApiEventConfig):
        try:
            body = event.get_event_body()
            new_user_email = body.get("email")

            if not new_user_email:
                return {"error": "Email is required."}

            self.dynamodb_client.put_item(
                TableName=self.env["POPUP_PERMISSIONS_TABLE"],
                Item={
                    self.PRIMARY_KEY: {"S": new_user_email}
                }
            )
            self.logger.info(f"Added {new_user_email} to popup permissions table.")

            if new_user_email not in POPUP_PERMISSIONS_USERS:
                POPUP_PERMISSIONS_USERS.append(new_user_email)

            return {"message": f"User {new_user_email} added successfully."}

        except Exception as e:
            self.logger.exception("Failed to add user to popup permissions.")
            return {"error": "Internal server error."}

    
    def popup_remove_user(self, event: ApiEventConfig):
        try:
            body = event.get_event_body()
            email_to_remove = body.get("email")

            if not email_to_remove:
                return {"error": "Email is required to remove a user."}

            self.dynamodb_client.delete_item(
                TableName=self.env["POPUP_PERMISSIONS_TABLE"],
                Key={self.PRIMARY_KEY: {"S": email_to_remove}}
            )
            self.logger.info(f"Removed {email_to_remove} from popup permissions table.")

            if email_to_remove in POPUP_PERMISSIONS_USERS:
                POPUP_PERMISSIONS_USERS.remove(email_to_remove)

            return {"message": f"User {email_to_remove} removed successfully."}

        except Exception as e:
            self.logger.exception("Failed to remove user from popup permissions.")
            return {"error": "Internal server error."}
