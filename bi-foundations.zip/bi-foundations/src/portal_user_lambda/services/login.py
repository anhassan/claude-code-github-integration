from typing import Dict
from logging import Logger
from dataclasses import asdict
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer

from common.models.api_event_config import ApiEventConfig
from common.models.user import User
from portal_user_lambda.services.user_photo import get_user_photo


class Login:
    PRIMARY_KEY = "email"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env

    def _get_user_from_claims(self, event: ApiEventConfig) -> User:
        claims = event.get_auth_claims()

        return User(
            email=claims["email"],  # direct access due to required value
            display_name=claims.get("custom:displayname"),
            department=claims.get("custom:department"),
            sub_department=claims.get("custom:subdepartment"),
            geo=claims.get("custom:country"),
            user_photo=get_user_photo(claims["email"])
        )

    def _get_upsert_user_update_expression(self, user_dict: Dict[str, any]) -> str:
        # override the row value in dynamodb unless the value is a set,
        # if field is of type set, then use default if it doesn't exist
        attributes = [
            (
                f"#{k} = :{k}"
                if not isinstance(v, set)
                else f"#{k} = if_not_exists(#{k}, :{k})"
            )
            for k, v in user_dict.items()
        ]
        return "SET " + ", ".join(attributes)

    def upsert_user(self, event: ApiEventConfig):
        user: User = self._get_user_from_claims(event)

        user_dict = asdict(user)
        email = user_dict.pop("email", None)

        serializer = TypeSerializer()
        expression_attribute_values = {
            f":{k}": serializer.serialize(v) for k, v in user_dict.items()
        }

        self.logger.info(
            f"Upserting into {self.env["USER_TABLE"]} the following data: {user_dict}"
        )

        response = self.dynamodb_client.update_item(
            TableName=self.env["USER_TABLE"],
            Key={self.PRIMARY_KEY: {"S": email}},
            UpdateExpression=self._get_upsert_user_update_expression(user_dict),
            ExpressionAttributeNames={f"#{k}": k for k in user_dict},
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues="ALL_NEW",
        )

        self.logger.info(f"User upsert response: {response}")

        deserializer = TypeDeserializer()
        return {
            k: deserializer.deserialize(v) for k, v in response["Attributes"].items()
        }
