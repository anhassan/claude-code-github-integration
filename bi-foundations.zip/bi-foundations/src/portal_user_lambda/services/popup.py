from dataclasses import asdict
from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from common.utils.data_processing import (
    deserialize_from_dynamodb,
    serialize_to_dynamodb
)
import boto3

class Popup:
    PRIMARY_KEY = "asset_id"
    CURRENT_DISPLAY = "current_display"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
    
    def update_popup(self, event: ApiEventConfig):
        table_name = self.env["POPUP_TABLE"]
        primary_key = self.PRIMARY_KEY

        try:
            scan_response = self.dynamodb_client.scan(TableName=table_name)
            items = scan_response.get("Items", [])

            for item in items:
                key = {primary_key: item[primary_key]}
                self.dynamodb_client.delete_item(TableName=table_name, Key=key)

            while "LastEvaluatedKey" in scan_response:
                scan_response = self.dynamodb_client.scan(
                    TableName=table_name,
                    ExclusiveStartKey=scan_response["LastEvaluatedKey"]
                )
                items = scan_response.get("Items", [])
                for item in items:
                    key = {primary_key: item[primary_key]}
                    self.dynamodb_client.delete_item(TableName=table_name, Key=key)

            request_body = event.get_event_body()

            if isinstance(request_body, list):
                for entry in request_body:
                    item = serialize_to_dynamodb(entry)
                    self.dynamodb_client.put_item(TableName=table_name, Item=item)
            else:
                item = serialize_to_dynamodb(request_body)
                self.dynamodb_client.put_item(TableName=table_name, Item=item)

            self.logger.info(f"Database updated with new popup content.")
            return {"status": "success"}

        except Exception as e:
            self.logger.exception(f"Failed to update popup database: {e}")
            return {"status": "error", "message": str(e)}

    def get_popup(self, event: ApiEventConfig):
        popup_content = []

        try:
            response = self.dynamodb_client.scan(
                TableName=self.env["POPUP_TABLE"]
            )
            popup_content = [deserialize_from_dynamodb(item) for item in response.get("Items", [])]

        except Exception as e:
            self.logger.exception(e)

        return popup_content

    def remove_all_popups(self, event: ApiEventConfig):
        try:
            table_name = self.env["POPUP_TABLE"]
            primary_key = self.PRIMARY_KEY

            response = self.dynamodb_client.scan(TableName=table_name)
            items = response.get("Items", [])

            for item in items:
                key = {primary_key: item[primary_key]}
                self.dynamodb_client.delete_item(TableName=table_name, Key=key)

            while "LastEvaluatedKey" in response:
                response = self.dynamodb_client.scan(
                    TableName=table_name,
                    ExclusiveStartKey=response["LastEvaluatedKey"]
                )
                items = response.get("Items", [])
                for item in items:
                    key = {primary_key: item[primary_key]}
                    self.dynamodb_client.delete_item(TableName=table_name, Key=key)

            self.logger.info(f"All items deleted from table: {table_name}")

        except Exception as e:
            self.logger.exception(f"Failed to delete all items from table: {e}")