from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from portal_user_lambda.permissions import UPLOAD_ENTITLEMENT_PERMISSIONS_USERS


class UploadEntitlementPermissions:
    PRIMARY_KEY = "email"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env

    def get_upload_entitlement_permission(self, event: ApiEventConfig):
        claims = event.get_auth_claims()
        
        for user in UPLOAD_ENTITLEMENT_PERMISSIONS_USERS:
            self.dynamodb_client.update_item(
                TableName=self.env["UPLOAD_ENTITLEMENT_PERMISSIONS_TABLE"],
                Key={self.PRIMARY_KEY: {"S": user}},
            )

        try:
            response = self.dynamodb_client.query(
                TableName=self.env["UPLOAD_ENTITLEMENT_PERMISSIONS_TABLE"],
                KeyConditionExpression=f"{self.PRIMARY_KEY} = :email",
                ExpressionAttributeValues={":email": {"S": claims["email"]}},
            )

        except Exception as e:
            self.logger.exception(e)

        return response
