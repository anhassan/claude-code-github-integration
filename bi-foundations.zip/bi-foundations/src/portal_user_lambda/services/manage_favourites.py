from dataclasses import asdict
from logging import Logger
from typing import Dict

from common.models.api_event_config import ApiEventConfig
from common.models.favourite_asset import FavouriteAsset
from common.utils.data_processing import (
    deserialize_from_dynamodb,
    serialize_to_dynamodb,
)


class ManageFavourites:
    PRIMARY_KEY = "email"
    SORT_KEY = "asset_id"

    def __init__(self, logger: Logger, clients: Dict[str, object], env: Dict[str, str]):
        self.logger = logger
        self.dynamodb_client = clients["dynamodb"]
        self.env = env

    def add_favourite_asset(self, event: ApiEventConfig):
        new_favourite = FavouriteAsset(
            email=event.get_email(), asset_id=event.get_event_body()["asset_id"]
        )

        item = serialize_to_dynamodb(asdict(new_favourite))

        response = self.dynamodb_client.put_item(
            TableName=self.env["FAVOURITE_ASSETS_TABLE"], Item=item
        )

        return response

    def remove_favourite_asset(self, event: ApiEventConfig):
        email = event.get_email()
        asset_id = event.get_path_parameters()["asset_id"]

        response = self.dynamodb_client.delete_item(
            TableName=self.env["FAVOURITE_ASSETS_TABLE"],
            Key={self.PRIMARY_KEY: {"S": email}, self.SORT_KEY: {"S": asset_id}},
        )

        return response

    def get_favourites(self, event: ApiEventConfig):
        email = event.get_email()
        favourites = []

        try:
            response = self.dynamodb_client.query(
                TableName=self.env["FAVOURITE_ASSETS_TABLE"],
                KeyConditionExpression=f"{self.PRIMARY_KEY} = :email",
                ExpressionAttributeValues={":email": {"S": email}},
            )

            favourites.extend(
                [deserialize_from_dynamodb(item) for item in response.get("Items", [])]
            )

            last_evaluated_key = response.get("LastEvaluatedKey")

            while last_evaluated_key:
                response = self.dynamodb_client.query(
                    TableName=self.env["FAVOURITE_ASSETS_TABLE"],
                    KeyConditionExpression=f"{self.PRIMARY_KEY} = :email",
                    ExpressionAttributeValues={":email": {"S": email}},
                    ExclusiveStartKey=last_evaluated_key,
                )
                favourites.extend(
                    [
                        deserialize_from_dynamodb(item)
                        for item in response.get("Items", [])
                    ]
                )

                last_evaluated_key = response.get("LastEvaluatedKey")

        except Exception as e:
            self.logger.exception(e)

        return favourites
