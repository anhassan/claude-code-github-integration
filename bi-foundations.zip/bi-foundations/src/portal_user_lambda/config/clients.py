import boto3
from typing import Dict, Optional
from portal_user_lambda.config.env import ENV

# Built once per Lambda container and reused across invocations — client
# construction is CPU-expensive at low memory and was previously paid on
# every request, including CORS preflights.
_clients: Optional[Dict[str, object]] = None


def get_clients() -> Dict[str, object]:
    global _clients
    if _clients is None:
        _clients = {
            "dynamodb": boto3.client("dynamodb", region_name=ENV["AWS_REGION_NAME"]),
        }
    return _clients
