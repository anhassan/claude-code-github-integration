# all environment variables should be loaded here and
# passed to objects that require them

import os

ENV_VARS = [
    "AWS_REGION_NAME",
    "USER_TABLE",
    "FAVOURITE_ASSETS_TABLE",
    "ENV_NAME",
    "POPUP_TABLE",
    "POPUP_PERMISSIONS_TABLE",
    "UPLOAD_ENTITLEMENT_PERMISSIONS_TABLE",
    "ASSET_ENTITLEMENT_PERMISSIONS_TABLE",
    "HIDDEN_TAB_PERMISSIONS_TABLE",
    "Q_TOPIC_SECURITY_TABLE"
]

ENV = {k: os.environ[k] for k in ENV_VARS}
