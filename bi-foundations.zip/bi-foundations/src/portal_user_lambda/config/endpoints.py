from logging import Logger
from typing import Callable, Dict, List

from common.utils.api_request_handler import BootstrapEndpoints, Endpoint
from portal_user_lambda.services.asset_entitlement_permissions import AssetEntitlementPermissions
from portal_user_lambda.services.hidden_tab_permissions import HiddenTabPermissions
from portal_user_lambda.services.manage_favourites import ManageFavourites
from portal_user_lambda.services.login import Login
from portal_user_lambda.services.popup import Popup
from portal_user_lambda.services.popup_permissions import PopupPermissions
from portal_user_lambda.services.upload_entitlement_permissions import UploadEntitlementPermissions


class PortalUserEndpoints(BootstrapEndpoints):
    def __init__(
        self, logger: Logger, clients: Dict[str, Callable], env: Dict[str, str]
    ):
        self.logger = logger
        self.clients = clients
        self.env = env

        super().__init__(self.init_endpoints())

    def init_endpoints(self) -> List[Endpoint]:
        logger, clients, env = self.logger, self.clients, self.env

        return [
            Endpoint(
                "POST",
                "/user/login",
                Login(logger, clients, env).upsert_user,
            ),
            Endpoint(
                "GET",
                "/user/favourites",
                ManageFavourites(logger, clients, env).get_favourites,
            ),
            Endpoint(
                "POST",
                "/user/favourite",
                ManageFavourites(logger, clients, env).add_favourite_asset,
            ),
            Endpoint(
                "DELETE",
                "/user/favourite/{asset_id}",
                ManageFavourites(logger, clients, env).remove_favourite_asset,
            ),
            Endpoint(
                "GET",
                "/get-popup-content",
                Popup(logger, clients, env).get_popup,
            ),
            Endpoint(
                "POST",
                "/update-popup-content",
                Popup(logger, clients, env).update_popup,
            ),
            Endpoint(
                "DELETE",
                "/delete-popup-content",
                Popup(logger, clients, env).remove_all_popups,
            ),
            Endpoint(
                "GET",
                "/popup-edit-permissions",
                PopupPermissions(logger, clients, env).get_popup_edit_permission,
            ),
            Endpoint(
                "GET",
                "/popup-all-users",
                PopupPermissions(logger, clients, env).get_popup_all_users,
            ),
            Endpoint(
                "POST",
                "/popup-add-user",
                PopupPermissions(logger, clients, env).popup_add_user,
            ),
            Endpoint(
                "DELETE",
                "/popup-remove-user",
                PopupPermissions(logger, clients, env).popup_remove_user,
            ),
            Endpoint(
                "GET",
                "/upload-entitlement-permissions",
                UploadEntitlementPermissions(logger, clients, env).get_upload_entitlement_permission,
            ),
            Endpoint(
                "GET",
                "/asset-entitlement-permissions",
                AssetEntitlementPermissions(logger, clients, env).get_asset_entitlement_permission,
            ),
            Endpoint(
                "GET",
                "/hidden-tab-permissions",
                HiddenTabPermissions(logger, clients, env).get_hidden_tab_permission,
            ),
            #TEMPORARY CODE FOR Q TOPIC PERMISSIONS
            Endpoint(
                "GET",
                "/{dashboard_id}/q-topic-permissions",
                AssetEntitlementPermissions(logger, clients, env).get_q_topic_permission,
            )
            #END TEMPORARY CODE
        ]
