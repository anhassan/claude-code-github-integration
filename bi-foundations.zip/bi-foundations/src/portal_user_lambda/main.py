import logging

from common.utils.api_request_handler import ApiRequestHandler
from portal_user_lambda.config.env import ENV
from portal_user_lambda.config.clients import get_clients
from portal_user_lambda.config.endpoints import PortalUserEndpoints

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handle_api_request(event, context):
    endpoint_helper = PortalUserEndpoints(logger, get_clients(), ENV)
    request_handler = ApiRequestHandler(endpoint_helper, logger)

    return request_handler.handle_api_request(event, context)
