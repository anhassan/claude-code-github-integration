import copy

import boto3
import os

region_name = os.environ['AWS_REGION']
qs_client = boto3.client('quicksight', region_name)

QS_ACCOUNT_ID = os.environ['ACCOUNT_ID']


def get_dataset_owners(dataset_id):
        try:
            print(f"Finding dataset owners for dataset with dataset id : {dataset_id}")
            response = qs_client.describe_data_set_permissions(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSetId=dataset_id
            )

            owner_actions = ['quicksight:DeleteDataSet',
                                'quicksight:ListIngestions',
                                'quicksight:UpdateDataSetPermissions',
                                'quicksight:CancelIngestion',
                                'quicksight:UpdateDataSet',
                                'quicksight:PassDataSet',
                                'quicksight:DescribeDataSetPermissions',
                                'quicksight:DescribeDataSet',
                                'quicksight:CreateIngestion',
                                'quicksight:DescribeIngestion']

            ds_permissions = response["Permissions"]
            ds_owners = [ds_permission["Principal"].split("/")[-1] 
                        for ds_permission in ds_permissions if sorted(ds_permission["Actions"]) == sorted(owner_actions) ]
            
            print(f"dataset with dataset id : {dataset_id} has the owners : {ds_owners}")

            return ds_owners
        
        except Exception as error:
            print(f"Finding dataset owners for dataset with dataset id : {dataset_id} failed with error : {error}")


def get_principal_arns_from_principals(principals):
    principal_arns = []
    for principal in principals:
        if principal.endswith("@cppib.com"):
            principal_arns.append(
                f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:user/default/{principal}"
            )
        else:
            principal_arns.append(
                f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:group/default/{principal}"
            )
    return principal_arns
     

def update_dataset_permissions_from_refresh_notification_config(dataset_id, refresh_notification_principals):
    """
    Update QuickSight dataset permissions using the provided list of users/groups.
    Treats entries ending with '@cppib.com' as QuickSight users; others as groups.
    """
    try:
        # Default principals
        default_principals = ["AWS_SSO_QS_AUTHOR_ALL_DEPARTMENTS", "AWS_SSO_QS_Author_Data_Governance"]

        # Combine defaults with user-provided principals if any
        grant_principals = default_principals + (refresh_notification_principals if refresh_notification_principals else [])

        revoke_principals = [
            principal for principal in get_dataset_owners(dataset_id)
            if principal not in grant_principals
        ]

        owner_actions = [
            'quicksight:DeleteDataSet',
            'quicksight:ListIngestions',
            'quicksight:UpdateDataSetPermissions',
            'quicksight:CancelIngestion',
            'quicksight:UpdateDataSet',
            'quicksight:PassDataSet',
            'quicksight:DescribeDataSetPermissions',
            'quicksight:DescribeDataSet',
            'quicksight:CreateIngestion',
            'quicksight:DescribeIngestion'
        ]

        grant_principal_arns = get_principal_arns_from_principals(grant_principals)
        revoke_principal_arns = get_principal_arns_from_principals(revoke_principals)

        ds_owner_grants = [{"Principal": arn, "Actions": owner_actions} for arn in grant_principal_arns]
        ds_revokes = [{"Principal": arn, "Actions": owner_actions} for arn in revoke_principal_arns]

        base_kwargs = {"AwsAccountId": QS_ACCOUNT_ID, "DataSetId": dataset_id}
        if ds_owner_grants:
            base_kwargs["GrantPermissions"] = ds_owner_grants
        if ds_revokes:
            base_kwargs["RevokePermissions"] = ds_revokes

        print(f"Update Dataset Grant/Revoke Permissions Kwargs : {base_kwargs}")

        if ds_owner_grants or ds_revokes:
            response = qs_client.update_data_set_permissions(**base_kwargs)
            print(f"Successfully updated permissions for dataset '{dataset_id}'.")
            print(f"Permission update response: {response}")
            return response

    except Exception as error:
        print(f"updated permissions for dataset '{dataset_id}' failed with error : {error}")


def enable_email_notification_on_dataset_failure(dataset_id):
    drop_vals = ["RequestId", "ResponseMetadata", "Status"]

    try:
        print(f"Reading the existing dataset refresh properties for dataset with dataset id : {dataset_id}")
        existing_ds_refresh_properties = qs_client.describe_data_set_refresh_properties(
            AwsAccountId=QS_ACCOUNT_ID,
            DataSetId=dataset_id
        )
        print(f"Existing dataset refresh properties : {existing_ds_refresh_properties}")

        for drop_val in drop_vals:
            existing_ds_refresh_properties.pop(drop_val, None)

        new_ds_refresh_properties = copy.deepcopy(existing_ds_refresh_properties)
        new_ds_refresh_properties["AwsAccountId"] = QS_ACCOUNT_ID
        new_ds_refresh_properties["DataSetId"] = dataset_id
        new_ds_refresh_properties["DataSetRefreshProperties"] = {
            "FailureConfiguration": {"EmailAlert": {"AlertStatus": "ENABLED"}}
        }

        response = qs_client.put_data_set_refresh_properties(**new_ds_refresh_properties)
        print(f"Enabling dataset refresh failure notifications for dataset with dataset id : {dataset_id} resulted in response : {response}")
        return response

    except Exception as error:
        print(f"Enabling dataset refresh failure notifications for dataset with dataset id : {dataset_id} failed with error : {error}")
