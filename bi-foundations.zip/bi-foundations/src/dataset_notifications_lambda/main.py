from dataset_notifications_lambda.utils import enable_email_notification_on_dataset_failure, update_dataset_permissions_from_refresh_notification_config


def lambda_handler(event,context):
    dataset_id = event["payload"]["id"]
    refresh_notification_principals = event["payload"]["config"].get("refresh_notifications",[])
    update_dataset_permissions_from_refresh_notification_config(dataset_id, refresh_notification_principals)
    enable_email_notification_on_dataset_failure(dataset_id)
