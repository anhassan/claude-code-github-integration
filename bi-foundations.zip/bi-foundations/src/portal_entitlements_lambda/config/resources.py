import boto3
from typing import Dict
from portal_entitlements_lambda.config.env import ENV

def get_resources() -> Dict[str,object]:
    return {
        "dynamodb" : boto3.resource("dynamodb", region_name=ENV["AWS_REGION_NAME"])
    }