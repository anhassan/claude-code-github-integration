from logging import Logger
from typing import Callable, Dict, List
from common.utils.api_request_handler import BootstrapEndpoints, Endpoint
from portal_entitlements_lambda.services.approve_deny_als_request import ApproveDenyAls
from portal_entitlements_lambda.services.entitlements import Entitlements
from portal_entitlements_lambda.services.entitlements_als import EntitlementsAls
from portal_entitlements_lambda.services.fulfillment_rls_request import RlsFulFillment
from portal_entitlements_lambda.services.revoke_rls_request import RlsRevoke
from portal_entitlements_lambda.services.approve_deny_rls_request import ApproveDeny
from portal_entitlements_lambda.services.update_rls import RlsUpdate
from portal_entitlements_lambda.services.fulfillment_als_request import AlsFulFillment


class PortalEntitlementsEndpoint(BootstrapEndpoints):
    def __init__(self, logger: Logger, clients: Dict[str,Callable], resources: Dict[str,Callable], env: Dict[str,str]) -> None:
        
        self.logger = logger
        self.clients = clients
        self.resources = resources
        self.env = env 

        super().__init__(self.init_endpoints())
    
    def init_endpoints(self) -> List[Endpoint]:
        return [
             Endpoint(
                  "POST",
                  "/entitlements/create_request",
                  Entitlements(self.logger,self.clients,self.resources,self.env).create_entitlement_requests
             ),
             Endpoint(
                 "POST",
                 "/entitlements/fulfill_rls",
                 RlsFulFillment(self.logger,self.clients,self.resources,self.env).fulfill_rls_request
             ),
             Endpoint(
                 "GET",
                 "/entitlements/revoke_rls",
                 RlsRevoke(self.logger,self.clients,self.resources,self.env).revoke_rls_request
             ),
            Endpoint(
                 "GET",
                 "/entitlements/{request_id}/{email}/approve_request",
                 ApproveDeny(self.logger,self.clients,self.resources,self.env).approve_request
             ),
             Endpoint(
                 "GET",
                 "/entitlements/{request_id}/{email}/deny_request",
                 ApproveDeny(self.logger,self.clients,self.resources,self.env).deny_request
             ),
             Endpoint(
                 "POST",
                 "/entitlements/update_rls",
                 RlsUpdate(self.logger,self.clients,self.resources,self.env).update_rls
             ),
             Endpoint(
                  "POST",
                  "/entitlements/create_als_request",
                  EntitlementsAls(self.logger,self.clients,self.resources,self.env).create_als_entitlement_requests
             ),
             Endpoint(
                 "GET",
                 "/entitlements/{request_id}/{email}/approve_als_viewer_request",
                 ApproveDenyAls(self.logger,self.clients,self.resources,self.env).approve_als_viewer
             ),
             Endpoint(
                 "GET",
                 "/entitlements/{request_id}/{email}/approve_als_whitelist_request",
                 ApproveDenyAls(self.logger,self.clients,self.resources,self.env).approve_als_whitelist
             ),
             Endpoint(
                 "GET",
                 "/entitlements/{request_id}/{email}/deny_als_request",
                 ApproveDenyAls(self.logger,self.clients,self.resources,self.env).deny_als
             ),
             Endpoint(
                 "POST",
                 "/entitlements/fulfill_als",
                 AlsFulFillment(self.logger,self.clients,self.resources,self.env).fulfill_als_request
             ),

        ]