import json
import logging
from common.utils.api_request_handler import ApiRequestHandler
from portal_entitlements_lambda.config.clients import get_clients
from portal_entitlements_lambda.config.resources import get_resources
from portal_entitlements_lambda.config.endpoints import PortalEntitlementsEndpoint
from portal_entitlements_lambda.config.env import ENV


logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handle_api_request(event, context):
    json.dumps(event)
    endpoint_helper = PortalEntitlementsEndpoint(logger,get_clients(), get_resources(),ENV)
    request_handler = ApiRequestHandler(endpoint_helper, logger)

    return request_handler.handle_api_request(event,context)