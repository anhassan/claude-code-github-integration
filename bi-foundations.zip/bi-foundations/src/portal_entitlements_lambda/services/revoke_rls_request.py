from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
from datetime import datetime,UTC
import time,os
import json
from common.utils.data_processing import serialize_to_dynamodb
from pprint import pprint
import copy

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.rls_entitlement_utils import RlsEntitlementUitls


class RlsRevoke:
    PATH_PARAM_REQUEST_ID = "request_id"
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.qs_client = boto3.client("quicksight", region_name = "us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.rls_utils = RlsEntitlementUitls()
        self.env = env
    

    #### =================== REVOKE LOGIC FOR AD CLAIMS BASED RLS =======================

    def is_claim_sub_rule_equal_revoke(self,existing_sub_rule,new_sub_rule):
        is_sub_rule_eq = False
        is_sub_rule_partially_eq = False

        column_name_match = existing_sub_rule["column_name"] == new_sub_rule["column_name"]
        auth_group_match = existing_sub_rule["authorized_group"] == new_sub_rule["authorized_group"]
        tag_type_match = existing_sub_rule["tag_type"] == new_sub_rule["tag_type"]

        auth_existing_vals = existing_sub_rule["authorized_values"].lower().split(",")
        auth_new_vals = new_sub_rule["authorized_values"].lower().split(",")   

        auth_values_match = True if set(auth_existing_vals) == set(auth_new_vals) else False

        if column_name_match and auth_group_match and tag_type_match and auth_values_match:
            is_sub_rule_eq = True
        elif column_name_match and auth_group_match and tag_type_match:
            is_sub_rule_partially_eq = True

        return is_sub_rule_eq,is_sub_rule_partially_eq
    
    
    
    def get_matching_rule_revoke(self,new_rule,new_rule_tag_combo, 
        existing_rls, existing_tag_combos):
    
        existing_search_inds = existing_tag_combos[new_rule_tag_combo]

        match_sub_rule_cnt = 0
        match_complete_sub_rule_count = 0
        match_complete_rule = False
        match_rule_ind = -1

        for index in existing_search_inds:
            for new_sub_rule in new_rule:
                for existing_sub_rule in existing_rls[index]:
                    is_sub_rule_eq, is_sub_rule_partially_eq =  self.is_claim_sub_rule_equal_revoke(existing_sub_rule,new_sub_rule)

                    if is_sub_rule_eq or is_sub_rule_partially_eq:
                        match_sub_rule_cnt +=1

                    if is_sub_rule_eq:
                        match_complete_sub_rule_count +=1
                
            if match_sub_rule_cnt == len(new_rule) or match_complete_sub_rule_count == len(new_rule):
                match_rule_ind = index
                if match_complete_sub_rule_count == len(new_rule):
                    match_complete_rule = True
                break
                
            match_sub_rule_cnt = 0
            match_complete_sub_rule_count = 0

        return match_rule_ind,match_complete_rule
    

    
    def revoke_rls_claim_rule(self,new_rule,existing_rule,new_rule_tag_combination):
        distinct_tags = new_rule_tag_combination.split("-")
        updated_rule  = []

        for distinct_tag in distinct_tags:
            revoke_sub_rule = [sub_rule for sub_rule in new_rule if sub_rule["tag_type"] == distinct_tag][0]
            existing_sub_rule = [sub_rule for sub_rule in existing_rule if sub_rule["tag_type"] == distinct_tag][0]
            

            revoke_auth_vals = [auth_val for auth_val in revoke_sub_rule["authorized_values"].split(",")]
            existing_auth_vals = [auth_val for auth_val in existing_sub_rule["authorized_values"].split(",")]

            updt_auth_vals = [auth_val for auth_val in existing_auth_vals if auth_val not in revoke_auth_vals ]

            updated_sub_rule = existing_sub_rule
            updated_sub_rule["authorized_values"] = ",".join(updt_auth_vals)

            if updated_sub_rule["authorized_values"]:
                updated_rule.append(updated_sub_rule)
        
        return updated_rule



    def revoke_rls_by_claims(self,existing_rls,new_rls):
        existing_rls_updt = copy.deepcopy(existing_rls)
        existing_tag_combinations = self.rls_utils.get_rules_tag_combinations(existing_rls_updt)
        invalid_rls = []
        to_delete_rules_indices = []

        for new_rule in new_rls:
            new_rule_tag_combination = self.rls_utils.get_tag_combination_per_rule(new_rule)

            if new_rule_tag_combination in existing_tag_combinations.keys():
                match_rule_ind,match_complete_rule = self.get_matching_rule_revoke(new_rule,new_rule_tag_combination,
                    existing_rls_updt,existing_tag_combinations)
                
                # rule complete match
                if match_complete_rule:
                    to_delete_rules_indices.append(match_rule_ind)
                
                # rule no match
                elif match_rule_ind == -1:
                    invalid_rls.append(new_rule)
                
                # rule partial match
                else:
                    updated_rule = self.revoke_rls_claim_rule(new_rule,existing_rls_updt[match_rule_ind],new_rule_tag_combination)
                    print("===== BEFORE UPDATE RULE =======")
                    print(existing_rls_updt[match_rule_ind])
                    existing_rls_updt[match_rule_ind] = updated_rule
                    print("======= AFTER UPDATE RULE =======")
                    print(existing_rls_updt[match_rule_ind])
            else:
                invalid_rls.append(new_rule)


        existing_rls_updt =  [ rule for index,rule in enumerate(existing_rls_updt) if index not in to_delete_rules_indices ]

        return existing_rls_updt,invalid_rls
    
    
    #### =================== REVOKE LOGIC FOR EMAIL BASED RLS =======================

    def update_email_rule_group_revoke(self,complete_match_group_list,to_update_rule_group_list,existing_rule):
        updated_rule = copy.deepcopy(existing_rule) 

        # complete_match_group_list rules are such that all the authorized_values in them
        # are present in existing_rule but there are some values in existing_rule which are not in complete_match_group_list
        # Example : {"authorized_values": "ABC,CDE","column_name": "entity_lvl_2"} (complete_match_group_list rule)
        # {"authorized_values": "Active Equities,ABC,CDE","column_name": "entity_lvl_2"} (existing_rule)
        # "Active Equities" not found in complete_match_group_list

        full_overlap_indices = []

        for index,updt_rule_group in to_update_rule_group_list+complete_match_group_list:
            revoke_auth_vals = updt_rule_group["authorized_values"].split(",")
            existing_auth_vals = existing_rule["rule_groups"][index]["authorized_values"].split(",")
            updt_auth_vals = [auth_val for auth_val in existing_auth_vals if auth_val not in revoke_auth_vals]

            if updt_auth_vals:
                updated_rule["rule_groups"][index]["authorized_values"] = ",".join(updt_auth_vals)
            else:
                full_overlap_indices.append(index)
        
        updated_rule["rule_groups"] = [rule_group for index,rule_group in enumerate(updated_rule["rule_groups"]) if index not in full_overlap_indices ]

        return updated_rule


    def revoke_rls_by_email(self,existing_rls,new_rls):
        invalid_rls = []
        existing_rls_updt = copy.deepcopy(existing_rls)
        for new_rule in new_rls:
            new_email = new_rule["emails"][0]
            new_rule_groups = copy.deepcopy(new_rule["rule_groups"])

            matched_rule,matched_rule_index = self.rls_utils.get_matching_email_rule(existing_rls_updt,new_rule)

            if not new_rule_groups:
                # remove all rule groups for the email completely
                del existing_rls_updt[matched_rule_index]
            else:
                if matched_rule:
                    invalid_rule_group_list,to_update_rule_group_list,complete_match_group_list = self.rls_utils.to_update_add_rule_group(matched_rule,new_rule)
                    updated_rule = self.update_email_rule_group_revoke(complete_match_group_list,to_update_rule_group_list,matched_rule)
                    existing_rls_updt[matched_rule_index] = updated_rule

                    if invalid_rule_group_list:
                        invalid_rls.append({
                            "emails" : [new_email],
                            "rule_groups" : invalid_rule_group_list
                        })
                        print(f"Ivalid Rule : {invalid_rls[-1]}")
            
                else:
                    print(f"No email : {new_rule['emails'][0]} exists in the existing RLS")
                    invalid_rls.append(new_rule)
        
        existing_rls_updt = [rule for rule in existing_rls_updt if rule["rule_groups"]]

        return existing_rls_updt,invalid_rls
    
    
    def get_to_update_rls_revoke(self,existing_rls,new_rls):
        updated_rls = copy.deepcopy(existing_rls)

        if "rls_by_email_mappings" in new_rls.keys():
            if "rls_by_email_mappings" in existing_rls.keys():
                to_update_rls,_ = self.revoke_rls_by_email(existing_rls["rls_by_email_mappings"],new_rls["rls_by_email_mappings"])
                updated_rls["rls_by_email_mappings"] = to_update_rls
            else:
                updated_rls["rls_by_email_mappings"] = new_rls["rls_by_email_mappings"]
        elif "rls_mappings" in new_rls.keys():
            if "rls_mappings" in existing_rls.keys():
                to_update_rls,_ = self.revoke_rls_by_claims(existing_rls["rls_mappings"],new_rls["rls_mappings"])
                updated_rls["rls_mappings"] = to_update_rls
            else:
                updated_rls["rls_mappings"] = new_rls["rls_mappings"]
        
        updated_rls["last_updated"] = datetime.now(UTC).isoformat()

        return updated_rls
    
    
    def remove_revoke_rls_from_qs_ds(self,dataset_id,new_tag_rules,new_tag_configurations):
        response  = self.qs_client.describe_data_set(
            AwsAccountId = self.env["ACCOUNT_ID"],
            DataSetId = dataset_id
        )

        print(f"============ ADDING NEW CONFIGS TO QS DS : {dataset_id}  ======")

        ds_update_req = response["DataSet"]

        if "RowLevelPermissionTagConfiguration" in response["DataSet"]:
            # Updating already existing RLS
            existing_rls = response["DataSet"]["RowLevelPermissionTagConfiguration"]
            existing_tag_configurations = existing_rls["TagRuleConfigurations"]
            existing_tag_rules = existing_rls["TagRules"]

            updt_tag_rules = [tag_rule for tag_rule in existing_tag_rules if tag_rule not in new_tag_rules]
            updt_tag_configurations = [tag_config for tag_config in existing_tag_configurations if tag_config not in new_tag_configurations ]
            
            updt_tag_rules = existing_tag_rules + [tag_rule for tag_rule in new_tag_rules if tag_rule not in existing_tag_rules]
            updt_tag_configurations = existing_tag_configurations + [tag_config for tag_config in new_tag_configurations if tag_config not in existing_tag_configurations]


            print("====== NEW CONFIGURATIONS =======")
            pprint(updt_tag_rules)
            pprint(updt_tag_configurations)

            remove_cols = ["Arn",
                        "ConsumedSpiceCapacityInBytes",
                        "CreatedTime",
                        "LastUpdatedTime",
                        "OutputColumns"
                        ]
            
            if updt_tag_rules and updt_tag_configurations:

                ds_update_req["RowLevelPermissionTagConfiguration"]["Status"] = "ENABLED"
                ds_update_req["RowLevelPermissionTagConfiguration"]["TagRuleConfigurations"] = updt_tag_configurations
                ds_update_req["RowLevelPermissionTagConfiguration"]["TagRules"] = updt_tag_rules
                ds_update_req["AwsAccountId"] = self.env["ACCOUNT_ID"]

            else:
                remove_cols += ["RowLevelPermissionTagConfiguration"]

            for col in remove_cols:
                ds_update_req.pop(col)

            update_response = self.qs_client.update_data_set(**ds_update_req)

            print("=============== UPDATE RESPONSE ================")
            pprint(update_response)
    

    def revoke_rls_request(self, event: ApiEventConfig):

        entitlement_requests_table_name = os.environ["ENTITLEMENT_REQUESTS_TABLE"]
        rls_table_name = os.environ["DATASET_RLS_TABLE"]

        event_params = event.get_path_parameters()
        request_id = event_params.get(self.PATH_PARAM_REQUEST_ID,None) if event_params else None

        if request_id:
            request_id = request_id.replace("%20", " ")
            revoke_rls,requestor_email = self.rls_utils.get_rls_approved_request(entitlement_requests_table_name,request_id)
        else:
            payload_body = event.get_event_body()
            revoke_rls,requestor_email = payload_body["rls_delta"], payload_body["requestor_email"]

        workspace_id,dataset_id = revoke_rls["workspace_id"], revoke_rls["dataset_id"]

        # # Updating tag rules and configs for the Quicksight dataset after revoking required RLS rules
        # revoke_tag_rules, revoke_tag_configurations = self.rls_utils.get_tags_from_rls(revoke_rls)
        # self.remove_revoke_rls_from_qs_ds(dataset_id,revoke_tag_rules,revoke_tag_configurations)

        # Updating the RLS table in accordance to the new fulfilled RLS revoke request
        existing_rls = self.rls_utils.get_existing_rls(workspace_id,dataset_id,rls_table_name)

        if existing_rls and self.rls_utils.contains_rls(revoke_rls):
            to_update_rls = self.get_to_update_rls_revoke(existing_rls,revoke_rls)

            # Updating tag rules and configs for the Quicksight dataset after revoking required RLS rules
            new_tag_rules, new_tag_configurations = self.rls_utils.get_all_tags_from_rls(to_update_rls)
            self.rls_utils.update_rls_qs_ds(self.env["ACCOUNT_ID"],dataset_id,new_tag_rules,new_tag_configurations)

            self.rls_utils.write_to_rls_ddb(to_update_rls,rls_table_name)

            # Send email after fulfilling the RLS request
            self.rls_utils.notify_requestor_on_fulfillment(revoke_rls,requestor_email,"Revoke")


