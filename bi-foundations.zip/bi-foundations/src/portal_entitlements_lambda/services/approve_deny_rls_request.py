from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
from datetime import datetime,UTC
import time,os
import json
from common.utils.data_processing import serialize_to_dynamodb
from pprint import pprint
import copy

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from portal_entitlements_lambda.services.entitlements import Entitlements
from portal_entitlements_lambda.services.fulfillment_rls_request import RlsFulFillment
from portal_entitlements_lambda.services.revoke_rls_request import RlsRevoke


class ApproveDeny:

    PATH_PARAM_REQUEST_ID = "request_id"
    PATH_PARAM_EMAIL = "email"

    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.rls_utils = RlsEntitlementUitls()
        self.env = env
        self.entitlements = Entitlements(logger, clients, resources, env)
        self.rls_fulfillment = RlsFulFillment(logger, clients, resources, env)
        self.rls_revoke = RlsRevoke(logger, clients, resources, env)


    def approve_request(self, event: ApiEventConfig):
        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID]
        request_id = request_id.replace("%20", " ")
        email = event.get_path_parameters()[self.PATH_PARAM_EMAIL]
        request_info = self.rls_utils.get_request_info(request_id)
        [entry_updated, current_status] = self.rls_utils.update_request_entry(request_id,"APPROVED",email, request_info)
        if(not(entry_updated)):
            print("DUPLICATE CALL")
            raise Exception(f"Error, duplicate request for request ID : {request_id}. Status is currently : {current_status}")
        #TODO : send email to failed approver if someone has already approved/denied the request
        print("APPROVED: ", request_id, email)
        another_approver_exists = self.entitlements.notify_pending_entitlement_approvers([request_id],"bi-foundations-rls-entitlement-request" )
        print("Pending approvers remain? ", another_approver_exists)
        if(not(another_approver_exists)):
            [is_composite_request, composite_rule_key] = self.rls_utils.is_composite_request(request_info)
            print("Is composite request? ", is_composite_request)
            if(is_composite_request):
               other_pending_requests = self.rls_utils.exist_remaining_composite_requests(composite_rule_key,request_id)
               print("Pending approvers on other composite request parts? ", other_pending_requests)
               if(not(other_pending_requests)):
                   self.carry_out_filfillment_action(event, request_info[0]['rls_action'])
                   return "Fulfillment process begun"
            else: #not a composite request and no remaining approvers
                self.carry_out_filfillment_action(event, request_info[0]['rls_action'])
                return "Fulfillment process begun"      

        return "Awaiting additional approvals"
    
    def deny_request(self, event: ApiEventConfig):
        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID]
        request_id = request_id.replace("%20", " ")
        email = event.get_path_parameters()[self.PATH_PARAM_EMAIL]
        request_info = self.rls_utils.get_request_info(request_id)
        [entry_updated, current_status] = self.rls_utils.update_request_entry(request_id,"DENIED",email, request_info)
        if(not(entry_updated)):
            print("DUPLICATE CALL")
            raise Exception(f"Error, duplicate request for request ID : {request_id}. Status is currently : {current_status}")
        #TODO : send email to failed approver if someone has already approved/denied the request
        self.rls_utils.update_remaining_entries_denial(request_id, request_info)
        self.rls_utils.notify_requestor_on_denial(request_info[0], email)
        
        return "Request denied and database updated"
    

    def carry_out_filfillment_action(self, event, action):
        self.rls_fulfillment.fulfill_rls_request(event) if action=="GRANT" else self.rls_revoke.revoke_rls_request(event)
    
