from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
import copy
import time,os
import json
from common.utils.data_processing import serialize_to_dynamodb
from pprint import pprint

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.rls_entitlement_utils import RlsEntitlementUitls


class RlsFulFillment:
    PATH_PARAM_REQUEST_ID = "request_id"
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.qs_client = boto3.client("quicksight", region_name = "us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.rls_utils = RlsEntitlementUitls()
        self.env = env
    
    
    def add_new_rls_to_qs_ds(self,dataset_id,new_tag_rules,new_tag_configurations):
        response  = self.qs_client.describe_data_set(
            AwsAccountId = self.env["ACCOUNT_ID"],
            DataSetId = dataset_id
        )

        print(f"============ ADDING NEW CONFIGS TO QS DS : {dataset_id}  ======")

        ds_update_req = response["DataSet"]

        if "RowLevelPermissionTagConfiguration" in response["DataSet"]:
            # Updating already existing RLS
            existing_rls = response["DataSet"]["RowLevelPermissionTagConfiguration"]
            existing_tag_configurations = existing_rls["TagRuleConfigurations"]
            existing_tag_rules = existing_rls["TagRules"]

            to_add_tag_rules = existing_tag_rules + [tag_rule for tag_rule in new_tag_rules if tag_rule not in existing_tag_rules]
            to_add_tag_configurations = existing_tag_configurations + [tag_config for tag_config in new_tag_configurations if tag_config not in existing_tag_configurations]
        else:
            # Creating new RLS
            ds_update_req["RowLevelPermissionTagConfiguration"] = {}
            to_add_tag_rules = new_tag_rules
            to_add_tag_configurations = new_tag_configurations

        print("====== NEW CONFIGURATIONS =======")
        pprint(to_add_tag_rules)
        pprint(to_add_tag_configurations)

        remove_cols = ["Arn",
                    "ConsumedSpiceCapacityInBytes",
                    "CreatedTime",
                    "LastUpdatedTime",
                    "OutputColumns"
                    ]
        for col in remove_cols:
            ds_update_req.pop(col)

        ds_update_req["RowLevelPermissionTagConfiguration"]["Status"] = "ENABLED"
        ds_update_req["RowLevelPermissionTagConfiguration"]["TagRuleConfigurations"] = to_add_tag_configurations
        ds_update_req["RowLevelPermissionTagConfiguration"]["TagRules"] = to_add_tag_rules
        ds_update_req["AwsAccountId"] = self.env["ACCOUNT_ID"]

        update_response = self.qs_client.update_data_set(**ds_update_req)

        print("=============== UPDATE RESPONSE ================")
        pprint(update_response)

    
    def filter_rls_based_on_new_rls_type(self,to_update_rls,new_rls):
        to_update_rls_filtered = copy.deepcopy(to_update_rls)
        if "rls_by_email_mappings" in new_rls.keys():
            to_update_rls_filtered.pop("rls_mappings")
        elif "rls_mappings" in new_rls.keys():
            to_update_rls_filtered.pop("rls_by_email_mappings")
        return to_update_rls_filtered
    

    def fulfill_rls_request(self, event: ApiEventConfig):

        entitlement_requests_table_name = os.environ["ENTITLEMENT_REQUESTS_TABLE"]
        rls_table_name = os.environ["DATASET_RLS_TABLE"]
        
        event_params = event.get_path_parameters()
        request_id = event_params.get(self.PATH_PARAM_REQUEST_ID,None) if event_params else None

        if request_id:
            request_id = request_id.replace("%20", " ")
            new_rls,requestor_email = self.rls_utils.get_rls_approved_request(entitlement_requests_table_name,request_id)
        else:
            payload_body = event.get_event_body()
            new_rls,requestor_email = payload_body["rls_delta"], payload_body["requestor_email"]

        workspace_id,dataset_id = new_rls["workspace_id"], new_rls["dataset_id"]

        if self.rls_utils.contains_rls(new_rls):

            existing_rls = self.rls_utils.get_existing_rls(workspace_id,dataset_id,rls_table_name)
            
            if existing_rls:
                to_update_rls = self.rls_utils.get_to_update_rls(existing_rls,new_rls)
            else:
                to_update_rls = new_rls

            # Adding new tag rules and configs to the Quicksight dataset
            new_tag_rules, new_tag_configurations = self.rls_utils.get_tags_from_rls(
                self.filter_rls_based_on_new_rls_type(to_update_rls,new_rls))
            
            self.add_new_rls_to_qs_ds(dataset_id,new_tag_rules,new_tag_configurations)

            # Updating the RLS table in accordance to the new fulfilled RLS
            self.rls_utils.write_to_rls_ddb(to_update_rls,rls_table_name)

            # Send email after fulfilling the RLS request
            self.rls_utils.notify_requestor_on_fulfillment(new_rls,requestor_email)
