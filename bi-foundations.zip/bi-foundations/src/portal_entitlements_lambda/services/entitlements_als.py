from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
import time,os
import json
import copy
from pprint import pprint
from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

WORKSPACE_PREFIX = "bif"
FINSIGHTS_PO_TAG = "finsights_detail.product_owners"

class EntitlementsAls:
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.env = env
        self.rls_utils = RlsEntitlementUitls()
    
    def _get_opensearch_client(self) -> OpenSearch:
        credentials = boto3.Session().get_credentials()

        awsauth = AWS4Auth(
            credentials.access_key,
            credentials.secret_key,
            "us-east-1",
            "es",
            session_token=credentials.token,
        )

        opensearch_client = OpenSearch(
            hosts=[{"host": os.environ["OPENSEARCH_ENDPOINT"], "port": 443}],
            http_auth=awsauth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection,
        )

        return opensearch_client
    

    def filter_ddb_rows(self,rows, filter_name, filter_value):
        filtered_row = [
            row
            for row in rows
            if int(row["hierarchy"]) == 1 and filter_value in row[filter_name]
        ]
        return filtered_row
    

    def get_ddb_rows(self,ddb_table,filter_condition):
            """Utility function to scan all the pages of the DDB if the table is paginated"""
            response = ddb_table.scan(FilterExpression=filter_condition)
            ddb_result_rows = response.get("Items",[])

            # Continuing the search in case multiple pages exist - introducing pagination logic in DDB search
            while 'LastEvaluatedKey' in response:
                response = ddb_table.scan(
                    FilterExpression=filter_condition,
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                ddb_result_rows += response.get("Items",[])
            return ddb_result_rows
    
    
    def get_als_entitlement_request_params(self,fe_als_request):
        als_request_params = {}

        try:
            asset_id_splits = fe_als_request["asset_id"].split("-")[0:-1]
            asset_search_key_ind = [index for index,split in enumerate(asset_id_splits) if WORKSPACE_PREFIX in split][-1]
            workspace_id = "-".join(asset_id_splits[asset_search_key_ind:])
            asset_name = "-".join(asset_id_splits[:asset_search_key_ind])

            als_request_params["workspace_id"] = workspace_id
            als_request_params["asset_id"] = asset_name
            als_request_params["requestor_email"] = fe_als_request["requestor_email"]
            als_request_params["message"] = fe_als_request["business_justification"] if "business_justification" in fe_als_request.keys() else ""

            print(f"Als request params received from front end {als_request_params}")
        except Exception as error:
            print(f"Parsing front dashboard access request to get als request params failed with error : {error}")
        return als_request_params
    

    def get_als_entitlement_request_pattern(self,als_request_params, als_entitlements_table_name):
        ddb_als_entitlements_table = self.dynamodb_resource.Table(als_entitlements_table_name)

        workspace_id, asset_id = (
            als_request_params["workspace_id"],
            als_request_params["asset_id"],
        )

        filter_expression_workspace = Attr("workspace_id").eq(workspace_id)

        workspace_als_entitlements = self.get_ddb_rows(
            ddb_als_entitlements_table, filter_expression_workspace
        )

        response_asset = self.filter_ddb_rows(workspace_als_entitlements, "asset_id", asset_id)

        if response_asset:
             return [workspace_id,asset_id]
        else:
             response_all_assets = self.filter_ddb_rows(workspace_als_entitlements, "asset_id", "*")
             if response_all_assets:
                  return [workspace_id,"*"]
             else:
                  raise Exception(
                            f"Error, no corresponding asset id : {asset_id} or * found in the als entitlements table... for the request: {als_request_params}"
                        )
    

    def add_als_entitlement_requests(self,als_request_params, als_entitlements_table_name,als_entitlements_request_table_name ):
        workspace_id, asset_id = self.get_als_entitlement_request_pattern(als_request_params, als_entitlements_table_name)
        
        print(f"Pattern for ALS : {[workspace_id, asset_id]}")

        ddb_als_entitlements_table = self.dynamodb_resource.Table(als_entitlements_table_name)
        filter_condition = Attr("workspace_id").eq(workspace_id) & Attr("asset_id").eq(asset_id)

        asset_als_items = self.get_ddb_rows(ddb_als_entitlements_table,filter_condition)
        asset_als_entitlement_requests = []

        request_uuid = str(int(time.time()))
        als_requestor_email = als_request_params["requestor_email"]
        als_asset_id = als_request_params["asset_id"]
        als_message = als_request_params["message"]
        als_request_ids = []
        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        
        for asset_als_item in asset_als_items:
            print(asset_als_item)
            als_request_id = f"V-{request_uuid}-{workspace_id}-{als_asset_id}-{als_requestor_email}"
            asset_als_entitlement_requests.append({
                "request_id" : als_request_id,
                "workspace_id" : workspace_id,
                "asset_id" : als_asset_id,
                "hierarchy" : asset_als_item["hierarchy"],
                "approver_email" : ",".join(asset_als_item["approver_email"]),
                "requestor_email" : als_requestor_email,
                "status" : "QUEUED",
                "business_justification" : self.rls_utils.compress_text(als_message)
            })

            curr_als_entitlement_request = asset_als_entitlement_requests[-1]
            ddb_als_entitlements_request_table.put_item(Item=curr_als_entitlement_request)
            als_request_ids.append(als_request_id)

            print(f"ALS Entry added in DDB: {curr_als_entitlement_request}")

        return als_request_ids
    

    def notify_als_pending_entitlement_approvers(
        self,request_ids, entitlement_requests_table_name,
        als_message = "",
        approval_type = None
    ):

        another_approver_exists = True
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        env_name = os.environ["ENV_NAME"].lower()
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(self.sm_client,secret_name)
        )
        sender_email = "svc_finsights@cppib.com"

        if env_name=="prod":
            email_link_prefix = "https://finsights.cppinvestments.io"
        else:
            email_link_prefix = "https://finsights." + os.environ["ENV_NAME"] + ".cppinvestments.io"
        
        

        for request_id in request_ids:
            next_approver = self.rls_utils.get_next_approvers(
                entitlement_requests_table_name, request_id
            )
            if(next_approver):
                next_approver = next_approver[0]
            else : 
                print("No more pending approvers for request ", request_id)
                another_approver_exists = False
                break
            recepients = next_approver["approver_email"].split(",")
            recepient_email = recepients[0]
            cc_email = recepients[1] if len(recepients) == 2 else recepient_email

            # recepient_email = "ahassan@cppib.com"
            # cc_email = "ahassan@cppib.com"
            requested_user = next_approver['requestor_email']
            email_subject = f"Request for Approval for Dashboard : {next_approver['asset_id']} ALS by Requestor : {requested_user}"
            email_heading = f"Please approve the ALS request with the following details for {recepients}"

            email_subject = f"{email_subject} for User : {requested_user}" if requested_user else email_subject
            email_heading = f"{email_heading} for User : {requested_user}" if requested_user else email_heading

           
            business_justification = f"""
                                <p style="font-family: Arial, sans-serif; font-size: 14px; color: #333333; line-height: 1.5;">
                                <strong>Business Justification:</strong><br>
                                {als_message if als_message else "No Business Justification Provided"}
                                </p>
                                """

            if approval_type is None:
                approval_links_content = f"""
                                ✅ <a href="{email_link_prefix}/approve-deny-als/{next_approver['request_id']}/approve_whitelist">
                                    Accept ALS Whitelist Request
                                </a><br>
                                ✅ <a href="{email_link_prefix}/approve-deny-als/{next_approver['request_id']}/approve_viewer">
                                    Accept ALS Viewer Request
                                </a><br>
                                """
            elif approval_type == "viewer":
                approval_links_content = f"""
                                ✅ <a href="{email_link_prefix}/approve-deny-als/{next_approver['request_id']}/approve_viewer">
                                    Accept ALS Viewer Request
                                </a><br>
                                """
            elif approval_type == "whitelist":
                approval_links_content = f"""
                                ✅ <a href="{email_link_prefix}/approve-deny-als/{next_approver['request_id']}/approve_whitelist">
                                    Accept ALS Whitelist Request
                                </a><br>
                                """

            email_body = f"""
                            <html>
                            <body>
                                <p>
                                {email_heading}:
                                </p>

                                <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; font-family: Arial, sans-serif;">
                                <tr>
                                    <th align="left">Attribute Name</th>
                                    <th align="left">Attribute Value</th>
                                </tr>
                                <tr>
                                    <td><strong>Requestor</strong></td>
                                    <td>{next_approver['requestor_email']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Workspace</strong></td>
                                    <td>{next_approver['workspace_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Dashboard</strong></td>
                                    <td>{next_approver['asset_id']}</td>
                                </tr>
                                </table>

                                <p>
                                Please take action by clicking one of the following links:
                                </p>
                                <p>
                                {approval_links_content}
                                ❌ <a href="{email_link_prefix}/approve-deny-als/{next_approver['request_id']}/deny">
                                    Decline ALS Request
                                </a>
                                </p>
                                {business_justification}
                            </body>
                            </html>
                            """

            send_email(
                smtp_user,
                smtp_password,
                smtp_host,
                smtp_port,
                sender_email,
                cc_email,
                recepient_email,
                email_subject,
                email_body,
                True,
            )
        return another_approver_exists
    
    
    def asset_exists_in_entitlements(self,als_request_params,als_entitlements_table_name):
        workspace_id, asset_id = als_request_params["workspace_id"], als_request_params["asset_id"]
        ddb_als_entitlements_table = self.dynamodb_resource.Table(als_entitlements_table_name)
        
        filter_condition = Attr("workspace_id").eq(workspace_id)

        asset_als_items = self.get_ddb_rows(ddb_als_entitlements_table,filter_condition)

        all_asset_ids = list(set([item["asset_id"] for item in asset_als_items]))
        return asset_id in all_asset_ids or "*" in all_asset_ids # "*" signifies that all the assets have the same approvers for the given workspace
    
    
    def get_asset_product_owners(self,asset_id):
        results = self._get_opensearch_client().search(
            index = os.environ["OPENSEARCH_INDEX_NAME"],
            allow_partial_search_results = True,
            body = {
                    "query": {
                        "term": {
                        "_id": asset_id
                        }
                    }
                },
                _source_includes = [FINSIGHTS_PO_TAG]
        )

        print(f"Product owners Response for Asset id : {asset_id} are : {results}")

        asset_product_owners = []
        if "hits" in results.get("hits").keys():
                search_results = results.get("hits")
                if search_results["hits"]:
                    if "_source" in search_results["hits"][0].keys():
                        search_hits = search_results["hits"][0]["_source"]
                        if "finsights_detail" in search_hits.keys():
                                if "product_owners" in search_hits["finsights_detail"].keys():
                                    asset_product_owners += search_hits["finsights_detail"]["product_owners"]

        print(f"Product owners for Asset id : {asset_id} are : {asset_product_owners}")
        return asset_product_owners
    

    def add_als_entitlement_requests_product_owner(self,als_request_params,
                                                   als_entitlements_request_table_name,product_owners):

        product_owners_emails = [po["email"] for po in product_owners]
        approver_emails = product_owners_emails[0: 2 if len(product_owners_emails) > 2 else 1]

        request_uuid = str(int(time.time()))
        als_workspace_id = als_request_params["workspace_id"]
        als_requestor_email = als_request_params["requestor_email"]
        als_asset_id = als_request_params["asset_id"]
        als_message = als_request_params["message"]

        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        
 
        als_request_id = f"V-{request_uuid}-{als_workspace_id}-{als_asset_id}-{als_requestor_email}"
        asset_als_entitlement_request= {
            "request_id" : als_request_id,
            "workspace_id" : als_workspace_id,
            "asset_id" : als_asset_id,
            "hierarchy" : 1,
            "approver_email" : ",".join(approver_emails),
            "requestor_email" : als_requestor_email,
            "status" : "QUEUED",
            "business_justification" : self.rls_utils.compress_text(als_message)
        }

        ddb_als_entitlements_request_table.put_item(Item=asset_als_entitlement_request)

        print(f"ALS Entry added in DDB: {asset_als_entitlement_request}")

        return als_request_id
    
    
    def create_als_entitlement_requests(self, event: ApiEventConfig):

        als_entitlements_table_name = os.environ["WORKSPACE_ALS_ENTITLEMENTS_TABLE"]
        als_entitlements_request_table_name = os.environ["ENTITLEMENT_ALS_REQUESTS_TABLE"]
        als_table = os.environ["ASSET_LEVEL_SECURITY_TABLE"]

        payload_body = event.get_event_body()
        entitlements_als_po = False

        if "request" in payload_body:

            request_payload = payload_body["request"]
            als_request_params =self.get_als_entitlement_request_params(request_payload)
            als_message = als_request_params["message"]

            if not self.asset_exists_in_entitlements(als_request_params,als_entitlements_table_name):
                entitlements_als_po = True

            if entitlements_als_po:
                asset_id = request_payload["asset_id"]
                product_owners = self.get_asset_product_owners(asset_id)

                if product_owners:
                    als_request_id = self.add_als_entitlement_requests_product_owner(als_request_params,als_entitlements_request_table_name,product_owners)
                    self.notify_als_pending_entitlement_approvers([als_request_id],als_entitlements_request_table_name,als_message)
                else:
                    raise Exception(f"Asset ID : {als_request_params['asset_id']} has no Product Onwer or Entitlements defined. Please ensure either of the two is present...")

            else:
                als_request_ids = self.add_als_entitlement_requests(als_request_params, als_entitlements_table_name,als_entitlements_request_table_name )
                self.notify_als_pending_entitlement_approvers(als_request_ids,als_entitlements_request_table_name,als_message)

        else:
            raise Exception(f" 'request' should be in the payload of the payload als request..")
