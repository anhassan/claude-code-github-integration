from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
import time,os
import json
import copy
from pprint import pprint

from common.models.entitlement_request import EntitlementRequest
from common.utils.data_processing import serialize_to_dynamodb
from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from portal_entitlements_lambda.services.fulfillment_rls_request import RlsFulFillment
from portal_entitlements_lambda.services.revoke_rls_request import RlsRevoke


class Entitlements:
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.env = env
        self.rls_fulfillment = RlsFulFillment(logger, clients, resources, env)
        self.rls_revoke = RlsRevoke(logger, clients, resources, env)
        self.rls_utils = RlsEntitlementUitls()
        

    def get_entitlement_cols(self, event: ApiEventConfig):
        entitlement_json = event.get_event_body()
        entitlement_values = []
        if entitlement_json["request_type"] == "AD":
            entitlement_values += [
                col
                for request in entitlement_json["requests"]
                for col in request["column_values"]
            ]
        elif entitlement_json["request_type"] == "Email":
            entitlement_values += [
                col
                for request in entitlement_json["requests"]
                for rule in request["rules"]
                for col in rule["column_values"]
            ]
        return entitlement_values

    def explode_requests(self,requests):
        exploded_requests = []
        for request in requests:
            if isinstance(request["column_value"], list):
                for col_val in request["column_value"]:
                    to_explode_request = copy.deepcopy(request)
                    to_explode_request["column_value"] = col_val
                    exploded_requests.append(to_explode_request)
            else:
                exploded_requests.append(request)
        return exploded_requests

    def get_uuid(self):
        return str(int(time.time()))

    def get_validation_token(self,request_id, workspace_id, dataset_id):
        hash_value = abs(hash(f"{request_id}-{workspace_id}-{dataset_id}"))
        return f"{workspace_id}-{dataset_id}-{hash_value}"

    def get_ddb_rows(self,ddb_table, filter_expression):
        return ddb_table.scan(FilterExpression=filter_expression)

    def filter_ddb_rows(self,rows, filter_name, filter_value):
        # filtered_row = [row for row in rows if int(row['hierarchy']) == 1 and row[filter_name] == filter_value]
        filtered_row = [
            row
            for row in rows
            if int(row["hierarchy"]) == 1 and filter_value in row[filter_name]
        ]
        return filtered_row

    def persist_entitlement_requests(self,entitlement_requests, entitlement_requests_table):
        for entitlement_request in entitlement_requests:
            ddb_item = serialize_to_dynamodb(asdict(entitlement_request))
            response = self.dynamodb_client.put_item(
                TableName=entitlement_requests_table, Item=ddb_item
            )

    def get_entitlement_request_pattern(self,entitlement_request, entitlements_table_name):
        ddb_entitlements_table = self.dynamodb_resource.Table(entitlements_table_name)

        entitlement_col_name = entitlement_request["column_name"]
        entitlement_col_value = entitlement_request["column_value"]
        workspace_id, dataset_id = (
            entitlement_request["workspace_id"],
            entitlement_request["dataset_id"],
        )

        request = entitlement_request

        filter_expression_workspace = Attr("workspace_id").eq(workspace_id)

        workspace_entitlements = self.get_ddb_rows(
            ddb_entitlements_table, filter_expression_workspace
        ).get("Items", [])

        response_ds = self.filter_ddb_rows(workspace_entitlements, "dataset_id", dataset_id)

        # ===========================================================================================
        # ================ ENTITLEMENTS PATTERN FOR COLUMN VALUES HAVING WILDCARDS ==================
        # ===========================================================================================

        # Code to deal with wild card column values
        if entitlement_col_value == "*":
            if response_ds:
                # both the workspace and dataset in the request exist as it is in the entitlement table
                response_cn = self.filter_ddb_rows(
                response_ds, "column_name", entitlement_col_name
                )
                if response_cn:
                    # the workspace, dataset, column name in the request exist as it in the entitlement table
                    response_cv = self.filter_ddb_rows(
                        response_cn, "column_value", entitlement_col_value
                    )
                    return [workspace_id,dataset_id,entitlement_col_name,"DEFAULT_APPROVER"]
                else:
                    # the workspace, dataset exists but the column value must be "*"
                    response_cn = self.filter_ddb_rows(response_ds, "column_name", "*")
                    if response_cn:
                        return [workspace_id,dataset_id,"*","DEFAULT_APPROVER"]
                    else:
                        raise Exception(
                            f"Error, no corresponding column name : {entitlement_col_name} or * found in the entitlements table... for the request: {request}"
                        )
            else:
                # the workspace exists but the dataset must be a "*"  in the entitlement table
                response_ds = self.filter_ddb_rows(workspace_entitlements, "dataset_id", "*")
                if response_ds:
                    # the workspace, column name in the request exist as it in the entitlement table but dataset is "*"
                    response_cn = self.filter_ddb_rows(
                        response_ds, "column_name", entitlement_col_name
                    )
                    if response_cn:
                        return [workspace_id,"*",entitlement_col_name,"DEFAULT_APPROVER"]
                    else:
                        # the workspace exists but the dataset, column value must be "*"
                        response_cn = self.filter_ddb_rows(response_ds, "column_name", "*")
                        if response_cn:
                            return [workspace_id,"*","*","DEFAULT_APPROVER"]
                        else:
                            raise Exception(
                                f"Error, no corresponding column name : {entitlement_col_name} or * found in the entitlements table... for the request: {request}"
                            )
                else:
                     raise Exception(
                    f"Error, no corresponding dataset : {dataset_id} or * found in the entitlements table... for the request: {request}"
                )  

        # ===========================================================================================
        # ================ ENTITLEMENTS PATTERN FOR COLUMN VALUES WITHOUT WILDCARDS =================
        # ===========================================================================================

        if response_ds:
            # both the workspace and dataset in the request exist as it is in the entitlement table
            response_cn = self.filter_ddb_rows(
                response_ds, "column_name", entitlement_col_name
            )
            if response_cn:
                # the workspace, dataset, column name in the request exist as it in the entitlement table
                response_cv = self.filter_ddb_rows(
                    response_cn, "column_value", entitlement_col_value
                )
                if response_cv:
                    # the workspace, dataset, column name and column value in the request exist as it in the entitlement table
                    return [
                        workspace_id,
                        dataset_id,
                        entitlement_col_name,
                        entitlement_col_value,
                    ]
                else:
                    # the workspace, dataset, column name exists but column value must be a "*"
                    response_cv = self.filter_ddb_rows(response_cn, "column_value", "*")
                    if response_cv:
                        return [workspace_id, dataset_id, entitlement_col_name, "*"]
                    else:
                        raise Exception(
                            f"Error, no corresponding column value : {entitlement_col_value} or * found in the entitlements table... for request: {request}"
                        )
            else:
                # the workspace, dataset exists but the column value must be "*"
                response_cn = self.filter_ddb_rows(response_ds, "column_name", "*")
                if response_cn:
                    response_cv = self.filter_ddb_rows(
                        response_cn, "column_value", entitlement_col_value
                    )
                    if response_cv:
                        # the workspace, dataset, column value exist and column name is "*"
                        return [workspace_id, dataset_id, "*", entitlement_col_value]
                    else:
                        response_cv = self.filter_ddb_rows(response_cn, "column_value", "*")
                        if response_cv:
                            # the workspace, dataset exist but both column name and column value are "*"
                            return [workspace_id, dataset_id, "*", "*"]
                        else:
                            raise Exception(
                                f"Error, no corresponding column value : {entitlement_col_value} or * found in the entitlements table... for request: {request}"
                            )
                else:
                    raise Exception(
                        f"Error, no corresponding column name : {entitlement_col_name} or * found in the entitlements table... for the request: {request}"
                    )
        else:
            # the workspace exists but the dataset must be a "*"  in the entitlement table
            response_ds = self.filter_ddb_rows(workspace_entitlements, "dataset_id", "*")
            if response_ds:
                response_cn = self.filter_ddb_rows(
                    response_ds, "column_name", entitlement_col_name
                )
                if response_cn:
                    response_cv = self.filter_ddb_rows(
                        response_cn, "column_value", entitlement_col_value
                    )
                    if response_cv:
                        # the workspace, column name and column value exists but dataset : *
                        return [
                            workspace_id,
                            "*",
                            entitlement_col_name,
                            entitlement_col_value,
                        ]
                    else:
                        response_cv = self.filter_ddb_rows(response_cn, "column_value", "*")
                        if response_cv:
                            # the workspace and column name exists but dataset and column value are : *
                            return [workspace_id, "*", entitlement_col_name, "*"]
                        else:
                            raise Exception(
                                f"Error, no corresponding column value : {entitlement_col_value} or * found in the entitlements table.. for the request: {request}."
                            )
                else:
                    response_cn = self.filter_ddb_rows(response_ds, "column_name", "*")
                    if response_cn:
                        response_cv = self.filter_ddb_rows(
                            response_cn, "column_value", entitlement_col_value
                        )
                        if response_cv:
                            # the workspace and column value exists but dataset and column name are "*"
                            return [workspace_id, "*", "*", entitlement_col_value]
                        else:
                            response_cv = self.filter_ddb_rows(
                                response_cn, "column_value", "*"
                            )
                            if response_cv:
                                # the workspace exists but the dataset, column name and column value are "*"
                                return [workspace_id, "*", "*", "*"]
                            else:
                                raise Exception(
                                    f"Error, no corresponding column value : {entitlement_col_value} or * found in the entitlements table.. for the request: {request}."
                                )
                    else:
                        raise Exception(
                            f"Error, no corresponding column name: {entitlement_col_name} or * found in the entitlements table... for the request: {request}"
                        )
            else:
                raise Exception(
                    f"Error, no corresponding dataset : {dataset_id} or * found in the entitlements table... for the request: {request}"
                )

    def get_entitlement_request_approvers(
        self,entitlement_request, entitlement_pattern, entitlements_table_name
    ):
        [workspace_id, dataset_id, column_name, column_value] = entitlement_pattern
        ddb_entitlements_table = self.dynamodb_resource.Table(entitlements_table_name)

        filter_condition = (
            Attr("workspace_id").eq(workspace_id)
            & Attr("dataset_id").eq(dataset_id)
            & Attr("column_name").eq(column_name)
            & Attr("column_value").eq(column_value)
        )
        response =self.get_ddb_rows(ddb_entitlements_table, filter_condition).get(
            "Items", []
        )

        approvers = []
        for item in response:
            approvers.append(
                {
                    "workspace_id": entitlement_request["workspace_id"],
                    "dataset_id": entitlement_request["dataset_id"],
                    "requestor_email": entitlement_request["requestor_email"],
                    "request_type": entitlement_request["request_type"],
                    "column_name": entitlement_request["column_name"],
                    "column_value": entitlement_request["column_value"],
                    "approver_email": item["approver_email"],
                    "hierarchy": int(item["hierarchy"]),
                    "rls_request" : entitlement_request["rls_request"],
                    "composite_rule_key" : entitlement_request["composite_rule_key"],
                    "rls_action" : entitlement_request["rls_action"],
                }
            )

        return approvers

    def get_next_approvers(self,entitlement_requests_table, request_id):
        next_pending_approver = None
        ddb_entitlement_requests_table = self.dynamodb_resource.Table(
            entitlement_requests_table
        )
        filter_condition = Attr("request_id").eq(request_id) & Attr("status").ne(
            "APPROVED"
        )
        entitlement_requests = self.rls_utils.scan_ddb(ddb_entitlement_requests_table,filter_condition)

        if len(entitlement_requests) > 0 :
            lowest_pending_hierarchy = min(
                [int(request["hierarchy"]) for request in entitlement_requests]
            )

            next_pending_approver = [
                request
                for request in entitlement_requests
                if int(request["hierarchy"]) == lowest_pending_hierarchy
            ]

        return next_pending_approver
    
    def ds_exists_in_entitlements(self,dataset_id,entitlements_table_name):
        ddb_entitlements_table = self.dynamodb_resource.Table(entitlements_table_name)
         
        response = ddb_entitlements_table.scan().get(
            "Items", []
        )
        all_ds_ids = list(set([item["dataset_id"] for item in response]))
        return dataset_id in all_ds_ids or "*" in all_ds_ids # "*" signifies that all the datasets are have the same approvers for the given workspace


    def add_entitlement_requests(
        self,requests_in_payload, entitlements_table_name, entitlement_requests_table_name
    ):
        all_approvers = []
        for entitlement_request in requests_in_payload:
            entitlement_pattern = self.get_entitlement_request_pattern(
                entitlement_request, entitlements_table_name
            )
            print(f"Entitlement Pattern : {entitlement_pattern}")

            request_approvers = self.get_entitlement_request_approvers(
                entitlement_request, entitlement_pattern, entitlements_table_name
            )
            print(
                f"Request Approvers: {request_approvers} for Entitlement Request: {entitlement_request}"
            )
            all_approvers += request_approvers

        print(f"All approvers : {all_approvers}")

        ddb_entitlement_requests_table = self.dynamodb_resource.Table(
            entitlement_requests_table_name
        )

        request_ids = []
        uuid_val = self.get_uuid()

        for index, item in enumerate(all_approvers):

            request_id = f'V-{uuid_val}-{item["workspace_id"]}-{item["dataset_id"]}-{item["column_name"]}-{item["column_value"]}'
            
            if item["composite_rule_key"]:
                request_id = f"{request_id}-{item["composite_rule_key"]}"
            
            if item["request_type"] == "email":
                rls_request_email_id = item["rls_request"]["rls_by_email_mappings"][0]["emails"][0]
                request_id = f"{request_id}-email-{rls_request_email_id}"


            validation_id = request_id
            entitlement_request = EntitlementRequest(
                validation_id,
                item["requestor_email"],
                item["request_type"],
                item["workspace_id"],
                item["dataset_id"],
                request_id,
                ",".join(item["approver_email"]),
                item["hierarchy"],
                item["column_name"],
                item["column_value"],
                item["rls_request"],
                item["composite_rule_key"],
                item["rls_action"]
            )
            print(f"Entries added in DDB: {asdict(entitlement_request)}")
            request_ddb_item = serialize_to_dynamodb(asdict(entitlement_request))
            self.dynamodb_client.put_item(
                TableName=entitlement_requests_table_name, Item=request_ddb_item
            )
            request_ids.append(request_id)

        return list(set(request_ids))


    def transform_fe_request(self,rls_request):
        """A utility function that explodes email rule based on the rls_request"""

        if "rls_by_email_mappings" in rls_request.keys():

            to_add_email_mappings = []
            to_del_email_mappings_inds = []

            for index,rls_email_mapping in enumerate(rls_request["rls_by_email_mappings"]):
                num_emails = len(rls_email_mapping["emails"])

                # incase of multiple emails we explode the emails into multiple email mappings
                if num_emails > 1:
                    rls_email_rule_groups = rls_email_mapping["rule_groups"]
                    to_del_email_mappings_inds.append(index)
                    for email in rls_email_mapping["emails"]:
                        to_add_email_mappings.append(
                            {
                                "emails" : [email],
                                "rule_groups": rls_email_rule_groups
                            }
                        )

            new_rls_by_email_mappings = [rls_email_mapping for index,rls_email_mapping in enumerate(rls_request["rls_by_email_mappings"])
                                        if index not in to_del_email_mappings_inds]
            rls_request["rls_by_email_mappings"] = new_rls_by_email_mappings
                

            for additional_email_mappings in to_add_email_mappings:
                rls_request["rls_by_email_mappings"].append(additional_email_mappings)

        return rls_request
    

    def notify_pending_entitlement_approvers(
        self,request_ids, entitlement_requests_table_name
    ):

        another_approver_exists = True
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        env_name = os.environ["ENV_NAME"].lower()
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(self.sm_client,secret_name)
        )
        sender_email = "svc_finsights@cppib.com"

        if env_name=="prod":
            email_link_prefix = "https://finsights.cppinvestments.io"
        else:
            email_link_prefix = "https://finsights." + os.environ["ENV_NAME"] + ".cppinvestments.io"
        
        

        for request_id in request_ids:
            next_approver = self.get_next_approvers(
                entitlement_requests_table_name, request_id
            )
            if(next_approver):
                next_approver = next_approver[0]
            else : 
                print("No more pending approvers for request ", request_id)
                another_approver_exists = False
                break
            recepients = next_approver["approver_email"].split(",")
            recepient_email = recepients[0]
            cc_email = recepients[1] if len(recepients) == 2 else recepient_email

            # recepient_email = "elowney@cppib.com"
            # cc_email = "elowney@cppib.com"

            requested_user = request_id.split("-")[-1] if "-email-" in request_id else ""
            email_subject = f"{next_approver['rls_action']} : Request for Approval for Dataset: {next_approver['dataset_id']} RLS by Requestor : {next_approver['requestor_email']}"
            email_heading = f"Please approve the RLS request with the following details for {recepients}"

            email_subject = f"{email_subject} for User : {requested_user}" if requested_user else email_subject
            email_heading = f"{email_heading} for User : {requested_user}" if requested_user else email_heading

            email_body = f"""
                            <html>
                            <body>
                                <p>
                                {email_heading}:
                                </p>

                                <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; font-family: Arial, sans-serif;">
                                <tr>
                                    <th align="left">Attribute Name</th>
                                    <th align="left">Attribute Value</th>
                                </tr>
                                <tr>
                                    <td><strong>Requestor</strong></td>
                                    <td>{next_approver['requestor_email']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Workspace</strong></td>
                                    <td>{next_approver['workspace_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Dataset</strong></td>
                                    <td>{next_approver['dataset_id']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Column</strong></td>
                                    <td>{next_approver['entitlement_col']}</td>
                                </tr>
                                <tr>
                                    <td><strong>Column Value</strong></td>
                                    <td>{next_approver['entitlement_val']}</td>
                                </tr>
                                </table>

                                <p>
                                Please take action by clicking one of the following links:
                                </p>
                                <p>
                                ✅ <a href="{email_link_prefix}/approve-deny-rls/{next_approver['request_id']}/approve">
                                    Accept RLS Request
                                </a><br>
                                ❌ <a href="{email_link_prefix}/approve-deny-rls/{next_approver['request_id']}/deny">
                                    Decline RLS Request
                                </a>
                                </p>
                            </body>
                            </html>
                            """

            send_email(
                smtp_user,
                smtp_password,
                smtp_host,
                smtp_port,
                sender_email,
                cc_email,
                recepient_email,
                email_subject,
                email_body,
                True,
            )
        return another_approver_exists    
    
    def get_entitlements_table_name(self,workspace_id,entitlements_mapping_table_name):
        ddb_table = self.dynamodb_resource.Table(entitlements_mapping_table_name)
        filter_condition = Attr("workspace_id").eq(workspace_id)
        response = ddb_table.scan(FilterExpression=filter_condition)
        response_items = response.get("Items")
        if response_items:
            if "table_name" in response_items[0].keys():
                return response_items[0]["table_name"]
        return False
    

    def get_entitlement_requests_from_rls(self,rls_request):
    
        workspace_id = rls_request["workspace_id"]
        dataset_id = rls_request["dataset_id"]
        requestor_email = rls_request["requestor_email"]
        rls_action = rls_request["rls_action"]

        entitlement_requests = []

        if "rls_by_email_mappings" in rls_request.keys():
            for rls_email_mapping in rls_request["rls_by_email_mappings"]:
                for email_rule_group in rls_email_mapping["rule_groups"]:
                    for auth_val in email_rule_group["authorized_values"].split(","):

                        entitlement_requests.append({
                            "workspace_id" : workspace_id,
                            "dataset_id" : dataset_id,
                            "column_name" : email_rule_group["column_name"],
                            "column_value" : auth_val,
                            "requestor_email" : requestor_email,
                            "request_type": "email",
                            "composite_rule_key" : "",
                            "rls_action" : rls_action,
                            "rls_request" : {
                                "workspace_id" : workspace_id,
                                "dataset_id" : dataset_id,
                                "requestor_email" : requestor_email,
                                "rls_by_email_mappings" : [{
                                    "emails" : rls_email_mapping["emails"],
                                    "rule_groups" : [{
                                        "authorized_values" : auth_val,
                                        "column_name":  email_rule_group["column_name"]
                                }]
                            }]
                        }
                            
                    })

                        
        elif "rls_mappings" in rls_request.keys():
            for rls_mapping in rls_request["rls_mappings"]:

                rls_mapping_composite = True if len(rls_mapping) > 1 else False
                rls_mapping_tag_type = "-".join([mapping_rule["tag_type"] for mapping_rule in rls_mapping])
                if rls_mapping_composite:
                    composite_rule_key = f"comp-rule-key-{self.get_uuid()}-{rls_mapping_tag_type}"
                else:
                    composite_rule_key = ""

                for mapping_rule in rls_mapping:
                    for auth_val in mapping_rule["authorized_values"].split(","):
                        entitlement_requests.append({
                            "workspace_id" : workspace_id,
                            "dataset_id" : dataset_id,
                            "column_name" : mapping_rule["column_name"],
                            "column_value" : auth_val,
                            "requestor_email" : requestor_email,
                            "request_type": "ad-claims",
                            "composite_rule_key" : composite_rule_key,
                            "rls_action" : rls_action
                        })

                        rls_request = {
                                "workspace_id" : workspace_id,
                                "dataset_id" : dataset_id,
                                "requestor_email" : requestor_email
                            }

                        if rls_mapping_composite:
                            # composite rule exists
                            rls_request["rls_mappings"] = [rls_mapping]
                        else:
                             # simple/no-composite rule
                             rls_request["rls_mappings"] = [
                                 [{
                                "authorized_group": mapping_rule["authorized_group"],
                                "authorized_values": auth_val,
                                "column_name": mapping_rule["column_name"],
                                "tag_type": mapping_rule["tag_type"]
                             }]
                             ]
                        
                        entitlement_requests[-1]["rls_request"] = rls_request

        
        # distinct_entitlement_requests = [ dict(distinct_req) for distinct_req in 
        #                                 set(tuple(request.items()) for request in entitlement_requests)]

        distinct_entitlement_requests = entitlement_requests

        return distinct_entitlement_requests
    

    def get_existing_rls_revoke(self,existing_rls,new_rls):
        existing_rls_revoke = copy.deepcopy(existing_rls)
        if "rls_by_email_mappings" in new_rls.keys():
            if "rls_mappings" in existing_rls_revoke.keys():
                existing_rls_revoke.pop("rls_mappings")
        elif "rls_mappings" in new_rls.keys():
            if "rls_by_email_mappings" in existing_rls_revoke.keys():
                existing_rls_revoke.pop("rls_by_email_mappings")
        return existing_rls_revoke
    
    def create_entitlement_requests(self, event: ApiEventConfig):

        entitlements_mapping_table_name = os.environ["WORKSPACE_ENTITLEMENTS_MAPPING_TABLE"]
        entitlement_requests_table_name = os.environ["ENTITLEMENT_REQUESTS_TABLE"]
        rls_table_name = os.environ["DATASET_RLS_TABLE"]

        # Identify whether this endpoint is getting called after RLS UI request submission
        # OR after a RLS request higher in hierarchy has been approved

        payload_body = event.get_event_body()
        entitlements_bypass = False

        if "requests" in payload_body:
            request = payload_body["requests"]
            workspace_id,dataset_id = request["workspace_id"], request["dataset_id"]
            entitlements_table_name = self.get_entitlements_table_name(workspace_id,entitlements_mapping_table_name)

            new_rls = self.transform_fe_request(payload_body["requests"])
            new_rls_revoke = copy.deepcopy(new_rls)

            existing_rls = self.rls_utils.get_existing_rls(workspace_id,dataset_id,rls_table_name)
            existing_rls_revoke = self.get_existing_rls_revoke(existing_rls,new_rls)

            if existing_rls:
                rls_to_add = self.rls_utils.get_rls_delta(existing_rls,new_rls)
                rls_to_remove = self.rls_utils.get_rls_delta(new_rls_revoke,existing_rls_revoke)

                rls_deltas = [
                    [rls_to_add, "GRANT"],
                    [rls_to_remove, "REVOKE"]
                ]
            else:
                rls_deltas = [
                    [new_rls, "GRANT"]
                ]

            
            # Checking if entitlement rules exist for a given workspace and dataset defined in the RLS
            if not entitlements_table_name:
                entitlements_bypass = True
            else:
              if not self.ds_exists_in_entitlements(dataset_id,entitlements_table_name):
                entitlements_bypass = True


            # Bypassing all the entitlements in case the workspace and dataset in the request does not have any entitlements requirements
            if entitlements_bypass:
                for rls_delta, rls_action in rls_deltas:
                    rls_event = json.dumps({
                            "requestor_email" : request["requestor_email"],
                            "rls_delta" : rls_delta
                        })
                    event.set_event_body(rls_event)

                    if rls_action == "GRANT":
                        print("GRANT EVENT:")
                        pprint(event.get_event_body())
                        self.rls_fulfillment.fulfill_rls_request(event)
                    elif rls_action == "REVOKE":
                        print("REVOKE EVENT:")
                        pprint(event.get_event_body())
                        self.rls_revoke.revoke_rls_request(event)

            # Applying entitlement rules in case the workspace and dataset in the request has strict entitlements requirements
            else:
                for rls_delta,rls_action in rls_deltas:
                    rls_delta["rls_action"] = rls_action
                    rls_delta["requestor_email"] = request["requestor_email"]

                    print(f"Entitlement RLS Request - {rls_action}")
                    print(rls_delta)

                    entitlement_requests = self.get_entitlement_requests_from_rls(rls_delta)
                    request_ids = self.add_entitlement_requests(entitlement_requests,entitlements_table_name,entitlement_requests_table_name)
                    self.notify_pending_entitlement_approvers(request_ids,entitlement_requests_table_name)
        else:
            raise Exception(f"Either 'requests' or 'request_id' should be in the payload of the payload request..")
