from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
import boto3
import copy
import time,os
import json
from pprint import pprint

from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from portal_entitlements_lambda.services.entitlements_als import EntitlementsAls


class AlsFulFillment:
    PATH_PARAM_REQUEST_ID = "request_id"
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.qs_client = boto3.client("quicksight", region_name = "us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.entitlements_als = EntitlementsAls(logger, clients, resources, env)
        self.rls_utils = RlsEntitlementUitls()
        self.env = env


    def fulfill_als_request(self,event: ApiEventConfig):

        from datetime import datetime

        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID].replace("%20", " ")

        als_entitlements_request_table_name = os.environ["ENTITLEMENT_ALS_REQUESTS_TABLE"]
        als_table_name = os.environ["ASSET_LEVEL_SECURITY_TABLE"]
        env = os.environ["ENV_NAME"]

        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        filter_condition = Attr("request_id").eq(request_id)

        approved_entries = self.entitlements_als.get_ddb_rows(ddb_als_entitlements_request_table,filter_condition)
        approved_status = [entry.get("status", "") for entry in approved_entries]

        print(f"Approved Enteries : {approved_entries}")
        print(f"Approved Status : {approved_status}")

        if approved_status:

            asset_id = f'{approved_entries[0].get("asset_id")}-{approved_entries[0].get("workspace_id")}-{env}'
            asset_access_type = approved_status[0].split("_")[-1].lower()
            requestor_email = approved_entries[0].get("requestor_email")

            ddb_als_table = self.dynamodb_resource.Table(als_table_name)
            filter_condition = Attr("asset_id").eq(asset_id)
            als_item = self.entitlements_als.get_ddb_rows(ddb_als_table,filter_condition)

            if als_item:
                als_item = als_item[0]

                current_acl = list(als_item[asset_access_type])

                updated_acl = list(set(current_acl + [requestor_email]))
                updated_acl = [acl for acl in updated_acl if len(acl) > 0]
                als_item[asset_access_type] = set(updated_acl)
                als_item["last_updated"] = datetime.now().strftime("%Y%m%d-%H%M%S")

                ddb_als_table.put_item(Item=als_item)

                print(f"Added {requestor_email} to current {asset_access_type} of : {current_acl}")
                print(f"Sending fulfillment email for access: {asset_access_type} on asset: {asset_id} to requestor: {requestor_email}")

                self.rls_utils.notify_requestor_on_als_fulfillment(approved_entries[0],requestor_email,asset_access_type)