from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
from boto3.dynamodb.conditions import Attr
from dataclasses import dataclass
from dataclasses import asdict
import boto3
from datetime import datetime,UTC
import time,os
import json
from common.utils.data_processing import serialize_to_dynamodb
from pprint import pprint
import copy

class RlsUpdate:
    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.env = env

    
    def update_rls(self, event:ApiEventConfig):
        """Endpoint to update/add item in a given ddb table"""

        request_body = event.get_event_body()

        ddb_table_name = request_body["table_name"]
        ddb_item_json = request_body["item"]

        ddb_item = serialize_to_dynamodb(ddb_item_json)

        update_response = self.dynamodb_client.put_item(
            TableName = ddb_table_name,
            Item = ddb_item
        )

        return update_response



        