from logging import Logger
from typing import Callable, Dict
from common.models.api_event_config import ApiEventConfig
import boto3
import json
from boto3.dynamodb.conditions import Attr
import os

from common.utils.rls_entitlement_utils import RlsEntitlementUitls
from portal_entitlements_lambda.services.entitlements_als import EntitlementsAls
from portal_entitlements_lambda.services.fulfillment_als_request import AlsFulFillment

class ApproveDenyAls:

    PATH_PARAM_REQUEST_ID = "request_id"
    PATH_PARAM_EMAIL = "email"

    def __init__(
        self,
        logger: Logger,
        clients: Dict[str, Callable],
        resources: Dict[str, Callable],
        env: Dict[str, str],
    ):
        self.logger = logger
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        self.sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        self.entitlements_als = EntitlementsAls(logger, clients, resources, env)
        self.als_fulfillment = AlsFulFillment(logger, clients, resources, env)
        self.rls_utils = RlsEntitlementUitls()
    

    def get_entry_to_update(self,request_id,approver_email,als_entitlements_request_table_name):
     
        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        filter_condition = Attr("request_id").eq(request_id) & Attr("approver_email").contains(approver_email)

        entry_to_update = self.entitlements_als.get_ddb_rows(ddb_als_entitlements_request_table,filter_condition)
        if entry_to_update:
            print(f"DDB Entry to Update : {entry_to_update}")
            return entry_to_update[0]
        else:
            print(f"Nothing found in the als request for request_id : {request_id} and approver_email: {approver_email}")

    
    def update_ddb_entry(self,entry_to_update,action,als_entitlements_request_table_name):

        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        entry_status = entry_to_update.get("status","")
        entry_request_id = entry_to_update["request_id"]

        if entry_status == "QUEUED":
            response = ddb_als_entitlements_request_table.update_item(
                Key = {
                    "request_id" : entry_to_update["request_id"],
                    "approver_email" : entry_to_update["approver_email"]
                },
                UpdateExpression="SET #als_status = :new_als_status",
                ExpressionAttributeNames={"#als_status" : "status"},
                ExpressionAttributeValues={":new_als_status" : action},
                ReturnValues="UPDATED_NEW"
            )
            print(f"update response: {response} for entry: {entry_to_update}")
        
        else:
            print("DUPLICATE CALL")
            raise Exception(f'Error, duplicate request for request ID : {entry_request_id}. Status is currently : {entry_status}')
        
    
    def skip_pending_approvers(self,request_id,als_entitlements_request_table_name):
        ddb_als_entitlements_request_table = self.dynamodb_resource.Table(als_entitlements_request_table_name)
        filter_condition = Attr("request_id").eq(request_id) & Attr("status").contains("QUEUED")

        entries_to_update = self.entitlements_als.get_ddb_rows(ddb_als_entitlements_request_table,filter_condition)

        for entry_to_update in entries_to_update:
            self.update_ddb_entry(entry_to_update,"SKIPPED",als_entitlements_request_table_name)

    def get_als_message(self,ddb_entry):
        als_message = ddb_entry.get("business_justification","")
        return self.rls_utils.decompress_text(als_message) if als_message else ""
    
    def deny_als(self,event: ApiEventConfig):
        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID]
        denier_email = event.get_path_parameters()[self.PATH_PARAM_EMAIL]
        als_entitlements_request_table_name = os.environ["ENTITLEMENT_ALS_REQUESTS_TABLE"]

        entry_to_update = self.get_entry_to_update(request_id,denier_email,als_entitlements_request_table_name)
        self.update_ddb_entry(entry_to_update,"DENIED",als_entitlements_request_table_name)
        self.skip_pending_approvers(request_id,als_entitlements_request_table_name)
        self.rls_utils.notify_requestor_on_denial(entry_to_update,denier_email,"als")

    
    def approve_als_viewer(self,event: ApiEventConfig):
        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID]
        approver_email = event.get_path_parameters()[self.PATH_PARAM_EMAIL]
        als_entitlements_request_table_name = os.environ["ENTITLEMENT_ALS_REQUESTS_TABLE"]

        entry_to_update = self.get_entry_to_update(request_id,approver_email,als_entitlements_request_table_name)
        self.update_ddb_entry(entry_to_update,"APPROVED_VIEWERS",als_entitlements_request_table_name)
        als_message = self.get_als_message(entry_to_update)
        another_approver_exists = self.entitlements_als.notify_als_pending_entitlement_approvers([request_id],als_entitlements_request_table_name,als_message,"viewer")

        if not another_approver_exists:
            # call fulfillment api to add the user in the viewers of dashboard
            self.als_fulfillment.fulfill_als_request(event)
    
    def approve_als_whitelist(self,event: ApiEventConfig):
        request_id = event.get_path_parameters()[self.PATH_PARAM_REQUEST_ID]
        approver_email = event.get_path_parameters()[self.PATH_PARAM_EMAIL]
        als_entitlements_request_table_name = os.environ["ENTITLEMENT_ALS_REQUESTS_TABLE"]

        entry_to_update = self.get_entry_to_update(request_id,approver_email,als_entitlements_request_table_name)
        self.update_ddb_entry(entry_to_update,"APPROVED_WHITELIST",als_entitlements_request_table_name)
        als_message = self.get_als_message(entry_to_update)
        another_approver_exists = self.entitlements_als.notify_als_pending_entitlement_approvers([request_id],als_entitlements_request_table_name,als_message,"whitelist")

        if not another_approver_exists:
            # call fulfillment api to add the user in the whitelist of dashboard
            self.als_fulfillment.fulfill_als_request(event)
