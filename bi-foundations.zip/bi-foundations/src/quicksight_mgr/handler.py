# quicksight apis are not entirely exposed via Terraform
# this handler fills any operational gaps we want to automate

# to simplify operations, this lambda syncs all settings in the bucket
# if a setting does not need to be changed, it confirms the state and takes
# no actions -- the general flow is list, diff, apply

# this allows us to invoke and wait on the lambda in the GitHub actions flow
# providing immediate feedback to the end-user on the state of their changes

# the lambda is idempotent on every run relying on declarative config in s3
import os
import boto3
import logging
import importlib

from .base import snake_to_camel

QS_ACCOUNT_ID = os.environ["ACCOUNT_ID"]
AWS_REGION = os.environ["AWS_REGION"]
VPC_CONNECTION_ARN = os.environ["VPC_CONNECTION_ARN"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

qs_client = boto3.client("quicksight", region_name=AWS_REGION)
s3_client = boto3.client("s3", region_name=AWS_REGION)


def handler(event, context):
    dryrun = event.get("dryrun", False)
    resource = event["resource"]
    _resource = getattr(importlib.import_module("quicksight_mgr.resources"), snake_to_camel(resource))
    r = _resource(logger, qs_client, event, s3_client, dryrun)
    r.sync()
