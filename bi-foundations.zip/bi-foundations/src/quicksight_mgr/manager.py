import os
import json
import importlib

from resources import theme

DASHBOARD_BUCKET = os.environ["DASHBOARD_BUCKET"]
ACCOUNT_ID = os.environ["ACCOUNT_ID"]

EVENT_TEMPLATE = {
    "resource": str, # the resource type to act on
    "payload": {
        "dev_account_id": str, # used when replacing arns
        "account_id": str, # current account id
        "s3_definition_key": str, # key for fetching definition files
        "definition": {}, # resource-dependant config, fetched from s3
        "config": {}, # custom-config used to drive actions
        "id": str, # id to use when creating/updating a resource
        "version": str # version of the asset to use
    }
}

class QSManager(object):
    def __init__(self, logger, event, qs_client, s3_client):
        self.event = event
        self.logger = logger
        self.qs_client = qs_client
        self.s3_client = s3_client

    def parse_event_type(self):
        resource = self.event["resource"]
        event = self.event["payload"]
        if event.get("s3_definition_key") != None:
            use_fixed = event["config"].get("use_fixed", False)
            def_body = self.fetch_s3_definition(event["s3_definition_key"], use_fixed)
            event["definition"] = def_body
            if resource == "dashboard":
                self.logger.info("Syncing dashboard theme")
                self.sync_dashboard_theme(def_body)
        return resource, event

    def sync_dashboard_theme(self, dashboard_definition):
        theme_arn_present = dashboard_definition.get("ThemeArn", False)
        if theme_arn_present:
            theme_id = dashboard_definition["ThemeArn"].split("theme/")[-1]
            self.logger.info("Dashboard theme present, performing sync on theme: {}".format(theme_id))
            latest_theme_definition = self.fetch_s3_definition("themes/{}/latest/theme_definition.json".format(theme_id))
            custom_event = {"account_id": ACCOUNT_ID, "definition": latest_theme_definition}
            theme.sync(self.qs_client, custom_event)
        else:
            self.logger.info("Dashboard has no theme, skipping sync")

    def fetch_s3_definition(self, key, used_fixed=False):
        if used_fixed:
            key = "{}/fixed_dashboard_definition.json".format(key.split("/dashboard_definition.json")[0])
        self.logger.info("Fetching {}".format(key))
        response = self.s3_client.get_object(
            Bucket=DASHBOARD_BUCKET,
            Key=key
        )
        content = response['Body'].read().decode('utf-8')
        return json.loads(content)

    def call_resource_method(self):
        self.logger.info("Event: {}".format(self.event))
        resource, event = self.parse_event_type()
        action = event.get("action", "sync")
        _resource = getattr(importlib.import_module("resources"), resource)
        _action = getattr(_resource, action)
        self.logger.info("Calling {} on {}".format(action, resource))
        _action(self.qs_client, event)
