import json
import os
import csv
import yaml
import functools
from botocore.exceptions import ClientError

ENV_NAME = os.environ["ENV_NAME"]


ROLE_GROUP_MAP = {"owners": "Author", "viewers": "Reader", "contributors": "Author"}


def get_from_path(dictionary, path_list):
    key = path_list.pop(0)
    if len(path_list) == 0:
        return dictionary[key]
    return get_from_path(dictionary[key], path_list)


class BIFoundationsConfigS3(object):
    def __init__(self, logger, s3_client, bucket, s3_event):
        self.logger = logger
        self.bucket = bucket
        self.s3_client = s3_client
        self.event_manifest = self.init_manifest(s3_event)
        self.changed_folders = self.init_changed_folders(self.event_manifest)

        self.logger.info(self.event_manifest)
        self.logger.info(f"Changed workspace folders: {self.changed_folders}")

        self.prefix = self.event_manifest["config_path"]
        self._config = {}
        self.map_config_dir()

    def init_manifest(self, s3_event: dict):
        self.logger.info(f"Raw S3 Event: {s3_event}")
        key = s3_event["detail"]["object"]["key"]
        return self.get_s3_path(key)

    def init_changed_folders(self, event_manifest):
        return set(
            [os.path.dirname(file) for file in event_manifest.get("changed_files", [])]
        )

    @property
    def config(self):
        return self._config
    
    """
    EXAMPLE:
    INPUT:
        configs/app/config.yaml
        configs/app/queries/query.sql
        configs/data/data.csv
        configs/README.md
    OUTPUT:
            {
            "app": {
                "config.yaml": None,
                "queries": {
                    "query.sql": None
                }
            },
            "data": {
                "data.csv": None
            }
        }
    """

    def map_config_dir(self):
        if not self.s3_client:
            raise ValueError("S3 client is required")
        ALLOWED_EXTENSIONS = (".yaml", ".sql", ".csv", ".json")
        paginator = self.s3_client.get_paginator("list_objects_v2")
        prefix = self.prefix

        try:
            for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    if prefix:
                        rel_path = key[len(prefix) :]
                    else:
                        rel_path = key

                    if not rel_path:
                        continue

                    # Split path into components
                    parts = [
                        p
                        for p in rel_path.rstrip("/").split("/")
                        if p and p is not None
                    ]

                    # Build nested structure
                    current = self._config
                    for part in parts[:-1]:  # Process directories
                        if part not in current:
                            current[part] = {}
                        current = current[part]

                    # Add file with None value
                    if len(parts) > 0 and any(
                        parts[-1].endswith(ext) for ext in ALLOWED_EXTENSIONS
                    ):
                        current[parts[-1]] = None

        except Exception as e:
            self.logger.error(f"Error mapping S3 directory: {str(e)}")
            raise

        return self._config

    def parse_dataset_rls_requests(self):
        rls_map = {}
        if not self.config.get("datasets", {}):
            return rls_map
        rls_requests = self.config["datasets"].keys()
        for rls in rls_requests:
            try:
                rls_map[rls] = self.get_s3_path(
                    "{}/datasets/{}/rls.yaml".format(self.prefix, rls)
                )
            except Exception:
                rls_map[rls] = []
        return rls_map
    
    
    def parse_dataset_cls_requests(self):
        cls_map = {}
        if not self.config.get("datasets",{}):
            return cls_map
        cls_requests = self.config["datasets"].keys()
        for cls in cls_requests:
            try:
                cls_map[cls] = self.get_s3_path(
                    "{}/datasets/{}/cls.yaml".format(self.prefix, cls)
                )
            except Exception:
                cls_map[cls] = []
        return cls_map

    def parse_dataset_s3_manifest_requests(self, metadata_results=None):
        s3_manifest_map = {}
        if not self.config.get("datasets", {}):
            return s3_manifest_map

        metadata_provided = metadata_results is not None
        metadata_results = metadata_results or {}
        dataset_requests = (
            metadata_results.keys()
            if metadata_provided
            else self.config["datasets"].keys()
        )
        for dataset in dataset_requests:
            metadata_config = metadata_results.get(dataset, {})
            is_s3_dataset = (metadata_config.get("dataset_source") or "").upper() == "S3"
            manifest_key = "{}/datasets/{}/s3_manifest.yaml".format(
                self.prefix, dataset
            )

            if not metadata_provided:
                try:
                    s3_manifest_map[dataset] = self.get_s3_path(manifest_key)
                except Exception:
                    s3_manifest_map[dataset] = {}
                continue

            if not is_s3_dataset:
                s3_manifest_map[dataset] = {}
                continue

            try:
                s3_manifest_map[dataset] = self.get_s3_path(manifest_key)
            except Exception as error:
                message = (
                    "Failed to read required s3_manifest.yaml for S3 dataset "
                    f"'{dataset}' from s3://{self.bucket}/{manifest_key}: {error}"
                )
                self.logger.error(message)
                raise ValueError(message) from error
        return s3_manifest_map

    def get_s3_path(self, key):
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=key)
            content = response["Body"].read().decode("utf-8")

            if key.endswith("yaml"):
                return yaml.safe_load(content)
            elif key.endswith("sql"):
                return content
            elif key.endswith(".json"):
                return json.loads(content)
            else:
                raise ValueError(f"Unsupported file type: {key}")
        except Exception as e:
            self.logger.error(f"Error reading from S3: {str(e)}")
            raise

    def should_sync(self, config, workspace_folder) -> bool:
        if config.get("force_sync"):
            return config.get("force_sync")

        return workspace_folder in self.changed_folders

    def parse_dataset_metadata_requests(self):
        data_fabric_arn = os.environ["FABRIC_DATASOURCE_ARN"]
        dataset_map = {}
        if not self.config.get("datasets", {}):
            return dataset_map

        dataset_requests = self.config["datasets"].keys()
        for dataset in dataset_requests:
            metadata_config = self.get_s3_path(
                "{}/datasets/{}/metadata.yaml".format(self.prefix, dataset)
            )

            workspace_folder = f"{ENV_NAME.lower()}/datasets/{dataset}"
            if self.should_sync(metadata_config, workspace_folder):
                self.logger.info(f"Defining sync configuration for {workspace_folder}")

                dataset_map[dataset] = metadata_config
                physical_table_map_id = (
                    f"{dataset_map[dataset]['name']}_{ENV_NAME.lower()}"
                )
                physical_table_map_id = physical_table_map_id.replace("_", "-")
                dataset_map[dataset]["physical_table_map_id"] = physical_table_map_id
                dataset_source = dataset_map.get(dataset, {}).get('dataset_source') or ''
                is_s3_dataset = dataset_source.upper() == "S3"
                if not is_s3_dataset:
                    dataset_map[dataset]["sql_query"] = self.format_dataset_sql_requests(
                        dataset, ENV_NAME.lower()
                    )

                data_source_arn = dataset_map.get(dataset,{}).get('data_source_arn','')
                if not is_s3_dataset and not data_source_arn:
                    # SQL/Athena datasets default to the environment Data Fabric source.
                    # S3 datasets must be explicit: managed mode uses data_source_id and
                    # s3_manifest.yaml; legacy external mode uses data_source_arn.
                    dataset_map[dataset]["data_source_arn"] = data_fabric_arn

                dataset_map[dataset]["folders"] = [
                    f"{workspace}-{ENV_NAME.lower()}"
                    for workspace in dataset_map[dataset]["workspaces"]
                ]
            else:
                self.logger.info(f"Skipping sync on {workspace_folder}, no changes detected and force_sync = false")

        return dataset_map

    def format_dataset_sql_requests(self, dataset, env_name):
        """
        Formats a query string based on environment name.
        For prod, removes '_${env}' suffix.
        For non-prod, replaces '${env}' with environment name.

        Args:
            dataset (str): the dataset to grab the sql query for
            env_name (str): Environment name ('prod' or other)

        Returns:
            str: Formatted query string
        """

        sql_query = self.get_s3_path(
            "{}/datasets/{}/query.sql".format(self.prefix, dataset)
        )
        sql_query_parsed = (
            sql_query.replace("_${env}", "")
            if env_name == "prod"
            else sql_query.replace("${env}", env_name)
        )
        return sql_query_parsed

    def parse_asset_configs(self):
        """
        Parses config.yaml files per asset in S3 for the workspace,
        and supplements any additional values needed to create/update the resource in QuickSight using the QS manager.
        """
        asset_map = {}

        for asset in self.config.get("assets", []):
            asset_map[asset] = self.get_s3_path(
                "{}/assets/{}/config.yaml".format(self.prefix, asset)
            )
            asset_map[asset]["workspace"] = f"{self.prefix}-{ENV_NAME.lower()}"
            asset_map[asset][
                "asset_id"
            ] = f"{asset_map[asset]["id_prefix"]}-{asset_map[asset]["workspace"]}"

        return asset_map

    def get_s3_definition_folder(self, config: dict) -> str:
        return f"{config['base_dashboard_name']}/{config['branch']}/{config.get('version', 'latest')}"

    def file_exists(self, bucket_name: str, s3_key: str) -> bool:
        try:
            self.s3_client.head_object(Bucket=bucket_name, Key=s3_key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                self.logger.error(e)
                return False
            else:
                raise
