import os
import csv
import json

ACCOUNT_ID = os.environ["ACCOUNT_ID"]
AWS_REGION = os.environ["AWS_REGION"]
ENV_NAME = os.environ["ENV_NAME"].lower()

arn_kwargs = {
    "region": AWS_REGION,
    "account": ACCOUNT_ID,
    "qs_role_name": "aws-quicksight-service-role-v0"
}

quicksight_user_arn_fmt = "arn:aws:quicksight:{region}:{account}:user/default".format(**arn_kwargs)
quicksight_group_arn_fmt = "arn:aws:quicksight:{region}:{account}:group/default".format(**arn_kwargs)

SERVICE_ROLES = [
    "arn:aws:iam::{account}:role/service-role/{qs_role_name}".format(**arn_kwargs),
    "arn:aws:iam::{account}:role/AWSControlTowerExecution".format(**arn_kwargs)
]

SUFFIXED_ENVS = ["dev", "qa", "uat"]

QS_PERMISSIONS = [
    "SELECT",
    "DESCRIBE"
]

CSV_HEADERS = [
    "requestor",
    "source_env",
    "database_name",
    "table_name",
    "target_account",
    "permissions",
    "target_role_arn"
]

class NamedShareGenerator(object):
    def __init__(self, access_map):
        self.access_map = access_map

    def make_entries(self, _map):
        entries = []
        for role in SERVICE_ROLES:
            for db, cfg in _map["service"].items():
                tables = cfg["tables"]
                source_env = cfg.get("override_source_env", ENV_NAME)
                db_environment = "_{}".format(ENV_NAME) if ENV_NAME in SUFFIXED_ENVS else ""
                for table in tables:
                    entries.append({
                        "requestor": _map["requestor"],
                        "source_env": source_env,
                        "database_name": db.format(env=db_environment),
                        "table_name": table,
                        "target_account": ACCOUNT_ID,
                        "permissions": json.dumps(QS_PERMISSIONS),
                        "target_role_arn": role
                    })
        return entries

    def generate_csv(self, name):
        entries = self.make_entries(self.access_map[name])
        with open("{}_quicksight_{}_requests.csv".format(ACCOUNT_ID, name), "w") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
            writer.writeheader()
            writer.writerows(entries)

    def generate_csvs(self):
        for name in self.access_map.keys():
            self.generate_csv(name)
