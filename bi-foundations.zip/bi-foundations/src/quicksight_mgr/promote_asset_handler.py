import json
import os
import boto3
import logging
from datetime import datetime
from dataclasses import asdict

from common.models.qs_trigger_config import QSManagerPayload, QSPayload
from quicksight_mgr.cfg import BIFoundationsConfigS3

aws_region = os.environ["AWS_REGION_NAME"]
config_s3_bucket = os.environ["CONFIG_BUCKET"]
dashboard_definition_s3_bucket = os.environ["DASHBOARD_BUCKET"]
aws_account = os.environ["ACCOUNT_ID"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3", region_name=aws_region)


def handler(event, _):
    """
    Triggered when there are the respective configuration files in the assets folder for the workspace.
    Creates a quicksight dashboard asset based on the config.yaml in Quicksight,
    creating a version of the developed dashboard that is now managed by BI foundations.

    This handler is a step in a step function that prepares configurations for the QS manager.
    """
    cfg = BIFoundationsConfigS3(
        logger=logger,
        s3_client=s3_client,
        bucket=config_s3_bucket,
        s3_event=event,
    )
    payloads = []

    asset_configs = cfg.parse_asset_configs()

    for asset in cfg.config.get("assets", {}):
        if "config.yaml" in cfg.config["assets"][asset]:
            s3_definition_folder = cfg.get_s3_definition_folder(asset_configs[asset])

            dashboard_definition_key = (
                f"{s3_definition_folder}/dashboard_definition.json"
            )

            if cfg.file_exists(
                dashboard_definition_s3_bucket, dashboard_definition_key
            ):
                theme_definition_key = f"{s3_definition_folder}/theme_definition.json"
                qs_dashboard_manager_payload = QSManagerPayload(
                    resource="dashboard",
                    payload=QSPayload(
                        id=asset,
                        account_id=aws_account,
                        force_sync=asset_configs[asset].get("force_sync", False),
                        config=asset_configs[asset],
                        s3_definition_key=dashboard_definition_key,
                        s3_theme_key=(
                            theme_definition_key
                            if cfg.file_exists(
                                dashboard_definition_s3_bucket, theme_definition_key
                            )
                            else None
                        ),
                    ),
                )
                payloads.append(asdict(qs_dashboard_manager_payload))
            else:
                logger.warning(
                    f"File not found for {dashboard_definition_key} in {dashboard_definition_s3_bucket}, skipping processing."
                )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_key = f"{cfg.prefix}/{timestamp}_asset_payloads.json"
    try:
        s3_client.put_object(
            Bucket=config_s3_bucket,
            Key=output_key,
            Body=json.dumps(payloads),
            ContentType="application/json",
        )
        logger.info(
            f"Successfully wrote payloads to s3://{config_s3_bucket}/{output_key}"
        )
    except Exception as e:
        logger.error(f"Error writing to S3: {str(e)}")
        raise

    return {
        "s3_bucket": config_s3_bucket,
        "s3_key": output_key,
        "asset_count": len(payloads),
    }
