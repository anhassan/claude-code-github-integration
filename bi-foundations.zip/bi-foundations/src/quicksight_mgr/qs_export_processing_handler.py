"""
#####
Description:  Lambda function to handle the processing of QuickSight exports.  It reads in the export file, copies it to the bi-control-plane bucket,
 processes the data, and writes the processed data to S3
#####

Input:  sqs payload
Output:  S3 object containing the processed data which wil eventually be loaded into opensearch
"""

import os
import boto3
import logging
from quicksight_mgr.cfg import BIFoundationsConfigS3
from quicksight_mgr.qs_asset_manager import (
    YamlProcessingManager,
    read_json_from_s3,
    process_datasets,
    set_finsights_detail,
    set_row_level_security_keys,
    process_sheets,
    process_calculated_fields,
    add_datetime_from_definition_file,
    qs_keys_to_keep,
    base_keys_to_keep,
    extract_keys,
    rename_nested_dict_keys,
    qs_key_mapping,
    write_dict_to_s3_json,
    get_opensearch_client,
    get_workspace_assets_os,
    remove_retired_bi_assets_os,
)


output_bucket = os.environ["BUCKET_NAME"]
dashboard_bucket = os.environ["DASHBOARD_DEFINITION_BUCKET"]
aws_environment = os.environ["AWS_ENVIRONMENT"]

s3_client = boto3.client("s3")
s3_output_key = "filename/asset_operational_metadata.json"

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    # get the config file from the S3 bucket
    cfg = BIFoundationsConfigS3(
        logger=logger, s3_client=s3_client, bucket=output_bucket, s3_event=event
    )
    workspace_directory = cfg.prefix
    payloads = []
    github_asset_id = []
    for asset in cfg.config.get("assets", {}):

        if "config.yaml" in cfg.config["assets"][asset]:
            s3_key = f"{workspace_directory}/assets/{asset}/config.yaml"
            # 1. copy dashboard_definition to workspace asset folder
            workspace_id = workspace_directory
            s3_asset_directory = f"{workspace_directory}/assets/{asset}/"
            config_yaml_data = YamlProcessingManager(output_bucket, s3_key, s3_client)
            config_metadata = config_yaml_data.prepare_config_metadata(
                s3_key, aws_environment
            )
            github_asset_id.append(config_metadata["asset_id"])
            dashboard_key = config_yaml_data.get_dashboard_definition_key()
            dashboard_output_key = f"{s3_asset_directory}dashboard_definition.json"
            s3_client.copy_object(
                CopySource={"Bucket": dashboard_bucket, "Key": dashboard_key},
                Bucket=output_bucket,
                Key=dashboard_output_key,
            )
            qs_describe_payload = read_json_from_s3(
                output_bucket, dashboard_output_key, s3_client
            )
            qs_describe_payload = set_finsights_detail(
                qs_describe_payload, config_metadata
            )
            qs_describe_payload = process_datasets(qs_describe_payload)
            qs_describe_payload = set_row_level_security_keys(
                qs_describe_payload, workspace_id
            )
            qs_describe_payload = process_sheets(qs_describe_payload)
            qs_describe_payload = process_calculated_fields(qs_describe_payload)
            qs_describe_payload = add_datetime_from_definition_file(
                dashboard_bucket, dashboard_key, qs_describe_payload, s3_client
            )
            keys_to_keep = qs_keys_to_keep(base_keys_to_keep)
            qs_describe_payload_filtered = extract_keys(
                qs_describe_payload, keys_to_keep
            )
            qs_describe_payload_filtered["is_restricted"] = (
                "embedding_access.yaml" in cfg.config["assets"][asset]
            )
            final_payload = rename_nested_dict_keys(
                qs_describe_payload_filtered,
                qs_key_mapping,
            )
            asset_operational_metadata = (
                f"{s3_asset_directory}asset_operational_metadata.json"
            )
            write_dict_to_s3_json(
                final_payload, output_bucket, asset_operational_metadata
            )
            # pass the inital s3_key and s3_bucket from the SQS queue to the output payload so the next lambda function can use the parameters
            payloads.append(
                {
                    "s3_key": asset_operational_metadata,
                    "bucket": output_bucket,
                    "statusCode": 200,
                }
            )
    # delete outdated assets from os.
    os_client = get_opensearch_client()
    index_name = os.environ.get("OPENSEARCH_INDEX_NAME")
    try:
        os_assets = get_workspace_assets_os(workspace_id, index_name, os_client)
        remove_retired_bi_assets_os(
            github_asset_id, os_assets, workspace_id, index_name, os_client
        )
    except Exception as e:
        logging.error(f"Error searching OpenSearch: {str(e)}")
        logging.error("skipping step to retire assets")

    return {"payloads": payloads, "asset_count": len(payloads)}

    # generate csv files and send to S3 for authors to fill out.  This will be used to populate the opensearch index
    # qs_asset.qs_manager.generate_dataset_csv(final_payload,output_bucket,s3_output_key, s3_client )
    # qs_asset.qs_manager.generate_sheet_csv(final_payload, output_bucket,s3_output_key, s3_client)
    # qs_asset.qs_manager.generate_overview_csv(final_payload, s3_output_key, s3_client)
    # qs_asset.qs_manager.generate_visualization_csv(final_payload,output_bucket, s3_output_key, s3_client)
    # qs_asset.qs_manager.generate_parameter_csv(final_payload,output_bucket, output_bucket, s3_client)
