import boto3
import logging

logger = logging.getLogger()
import os
import json
from datetime import datetime
from quicksight_mgr.cfg import BIFoundationsConfigS3
from dataclasses import asdict
from common.models.qs_trigger_config import QSPayload, QSManagerPayload

aws_region = os.environ["AWS_REGION_NAME"]
s3_bucket = os.environ["BUCKET_NAME"]
aws_account = os.environ["ACCOUNT_ID"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3", region_name=aws_region)


def _topological_sort_payloads(payloads):
    """Order dataset payloads so each dataset's join targets come before it.

    The downstream Distributed Map runs sequentially with
    `toleratedFailureCount: 0`, so a dataset that joins to a sibling fails
    `CreateDataSet` with `ResourceNotFoundException: Parent dataSet ...` if
    the sibling isn't already in central. Sorting topologically by joins
    deps removes the alphabetical-luck dependency.

    Refresh-properties payloads (`resource: dataset_refresh_properties`) and
    refresh-schedule payloads (`resource: refresh_schedule`) stay adjacent to
    their dataset, ordered dataset -> refresh_properties -> refresh_schedule so
    the incremental LookbackWindow is set before an INCREMENTAL_REFRESH schedule
    runs. Non-dataset payloads preserve order at the tail.

    Raises ValueError on a join cycle.
    """
    dataset_payloads = {}
    refresh_properties_for = {}
    schedules_for = {}
    other_payloads = []
    for p in payloads:
        resource = p.get("resource")
        if resource == "dataset":
            slug = p["payload"]["id"]
            dataset_payloads[slug] = p
        elif resource == "dataset_refresh_properties":
            slug = p["payload"]["id"]
            refresh_properties_for.setdefault(slug, []).append(p)
        elif resource == "refresh_schedule":
            slug = p["payload"]["id"]
            schedules_for.setdefault(slug, []).append(p)
        else:
            other_payloads.append(p)

    deps = {}
    dependents = {slug: set() for slug in dataset_payloads}
    for slug, p in dataset_payloads.items():
        joins = ((p["payload"].get("config") or {}).get("joins")) or []
        slug_deps = set()
        for j in joins:
            right = j.get("right_dataset") if isinstance(j, dict) else None
            if right and right in dataset_payloads:
                slug_deps.add(right)
        deps[slug] = slug_deps
        for d in slug_deps:
            dependents[d].add(slug)

    in_degree = {slug: len(slug_deps) for slug, slug_deps in deps.items()}
    queue = sorted(slug for slug, n in in_degree.items() if n == 0)
    sorted_slugs = []
    while queue:
        slug = queue.pop(0)
        sorted_slugs.append(slug)
        next_ready = []
        for child in dependents[slug]:
            in_degree[child] -= 1
            if in_degree[child] == 0:
                next_ready.append(child)
        queue.extend(sorted(next_ready))

    if len(sorted_slugs) != len(dataset_payloads):
        unresolved = [slug for slug, n in in_degree.items() if n > 0]
        raise ValueError(
            f"Cyclic dataset join dependency detected; {len(unresolved)} "
            f"datasets cannot be ordered: {unresolved}"
        )

    ordered = []
    for slug in sorted_slugs:
        ordered.append(dataset_payloads[slug])
        ordered.extend(refresh_properties_for.get(slug, []))
        ordered.extend(schedules_for.get(slug, []))
    ordered.extend(other_payloads)
    return ordered


def handler(event, context):
    cfg = BIFoundationsConfigS3(
        logger=logger, s3_client=s3_client, bucket=s3_bucket, s3_event=event
    )
    metadata_results = cfg.parse_dataset_metadata_requests()
    rls_results = cfg.parse_dataset_rls_requests()
    cls_results = cfg.parse_dataset_cls_requests()
    s3_manifest_results = cfg.parse_dataset_s3_manifest_requests(metadata_results)
    payloads = []

    if not metadata_results:
        logger.info("No datasets found in config")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_key = f"{cfg.prefix}/{timestamp}_dataset_payloads.json"
        try:
            s3_client.put_object(
                Bucket=s3_bucket,
                Key=output_key,
                Body=json.dumps(payloads),
                ContentType="application/json",
            )
            logger.info(f"Successfully wrote payloads to s3://{s3_bucket}/{output_key}")
        except Exception as e:
            logger.error(f"Error writing to S3: {str(e)}")
            raise
        return {
            "s3_bucket": s3_bucket,
            "s3_key": output_key,
            "dataset_count": 0,
            "config_path": cfg.prefix,
        }

    for dataset in metadata_results:
        qs_payload = QSPayload(
            id=dataset,
            account_id=aws_account,
            force_sync=metadata_results[dataset].get("force_sync", False),
        )
        qs_dataset_manager_payload = QSManagerPayload(
            resource="dataset",
            payload=qs_payload,
        )
        qs_dataset_manager_payload.payload.rls = rls_results[dataset]
        qs_dataset_manager_payload.payload.cls = cls_results[dataset]
        qs_dataset_manager_payload.payload.s3_manifest = s3_manifest_results.get(
            dataset, {}
        )
        qs_dataset_manager_payload.payload.config = metadata_results[dataset]

        payloads.append(asdict(qs_dataset_manager_payload))

        # SPICE incremental-refresh config (sets the LookbackWindow via
        # put_data_set_refresh_properties). Emitted as its own resource so the
        # topological sort can sequence it dataset -> refresh_properties ->
        # refresh_schedule (the LookbackWindow must exist before an
        # INCREMENTAL_REFRESH schedule runs).
        incremental_refresh = metadata_results[dataset].get("incremental_refresh")
        if incremental_refresh:
            payloads.append(
                {
                    "resource": "dataset_refresh_properties",
                    "payload": {
                        "force_sync": qs_payload.force_sync,
                        "id": qs_payload.id,
                        "account_id": qs_payload.account_id,
                        "config": {"incremental_refresh": incremental_refresh},
                    },
                }
            )
            logger.info(f"Added Incremental Refresh properties for Dataset : {dataset}...")

        # Adding dataset refresh schedule related metadata in dataset payload json file in case it exists
        ds_refresh_schedule = metadata_results[dataset].get("refresh_schedule",False)

        ### ============================================================================ ###
        ### ======= Adding support for a list of refresh schedules for a dataset ======= ###
        ### ============================================================================ ###

        """{
        "resource": "refresh_schedule",
        "payload": {
            "force_sync": "true",
            "id": "cost_insights_report",
            "account_id": "200967598245",
            "config": {
                "ScheduleId": "monthly_refresh",
                "RefreshType": "FULL_REFRESH",
                "ScheduleFrequency": {
                    "Interval": "MONTHLY",
                    "RefreshOnDay": {
                        "DayOfMonth": "3"
                    },
                    "Timezone": "Canada/Eastern",
                    "TimeOfTheDay": "00:00"
                }
            }
        }
        }"""

        if ds_refresh_schedule and isinstance(ds_refresh_schedule, list) and len(ds_refresh_schedule) > 0:
            qs_dataset_schedule_payload = {
                "resource": "refresh_schedule",
                "payload": {
                    "force_sync": qs_payload.force_sync,
                    "id": qs_payload.id,
                    "account_id": qs_payload.account_id,
                    "config": {"schedules": ds_refresh_schedule}
                }
            }
            payloads.append(qs_dataset_schedule_payload)
            logger.info(f"Added List of Refresh Schedules for Dataset : {dataset}...")

        elif ds_refresh_schedule and isinstance(ds_refresh_schedule, dict):
            qs_dataset_schedule_payload = QSManagerPayload(
                resource="refresh_schedule",
                payload=qs_payload
            )
            qs_dataset_schedule_payload.payload.config = {"schedules": ds_refresh_schedule}
            payloads.append(asdict(qs_dataset_schedule_payload))
            logger.info(f"Added Refresh Schedule for Dataset : {dataset}...")

    # Reorder so a dataset's join targets are processed before it.
    payloads = _topological_sort_payloads(payloads)

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_key = f"{cfg.prefix}/{timestamp}_dataset_payloads.json"
        s3_client.put_object(
            Bucket=s3_bucket,
            Key=output_key,
            Body=json.dumps(payloads),
            ContentType="application/json",
        )
        logger.info(f"Successfully wrote payloads to s3://{s3_bucket}/{output_key}")
    except Exception as e:
        logger.error(f"Error writing to S3: {str(e)}")
        raise

    return {
        "s3_bucket": s3_bucket,
        "s3_key": output_key,
        "dataset_count": len(payloads),
        "config_path": cfg.prefix,
    }
