import os
from logging import Logger
from dataclasses import asdict
from common.models.asset_level_security import AssetLevelSecurity
from common.models.q_topic_security import QTopicSecurity
from common.utils.data_processing import serialize_to_dynamodb
import json
import boto3
from boto3.dynamodb.conditions import Attr

WORKSPACE_PREFIX = "bif"
PROHIBITED_WORKSPACES = ["bif-talent"]

class EmbeddingAccess:
    def __init__(self, logger: Logger, asset_id: str, dynamodb_client):
        self.logger = logger
        self.asset_id = asset_id
        self.dynamodb_client = dynamodb_client
        self.dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
        self.s3_client = boto3.client("s3",region_name="us-east-1")
        self.qs_client = boto3.client("quicksight",region_name="us-east-1")
    
    def get_workspace_from_asset_id(self,asset_id):
        asset_id_splits = asset_id.split("-")[0:-1]
        asset_search_key_ind = [index for index,split in enumerate(asset_id_splits) if WORKSPACE_PREFIX in split][-1]
        workspace_id = "-".join(asset_id_splits[asset_search_key_ind:])
        return workspace_id
    
    def scan_ddb(self,ddb_table_name,dataset_id):
        """Utility function to scan all the pages of the DDB if the table is paginated"""
        ddb_table = self.dynamodb_resource.Table(ddb_table_name)
        filter_condition = Attr("dataset_id").eq(dataset_id)
        response = ddb_table.scan(FilterExpression=filter_condition)
        ddb_result_rows = response.get("Items",[])

        # Continuing the search in case multiple pages exist - introducing pagination logic in DDB search
        while 'LastEvaluatedKey' in response:
            response = ddb_table.scan(
                FilterExpression=filter_condition,
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            ddb_result_rows += response.get("Items",[])
        return ddb_result_rows
    
    def write_file_to_s3(self,s3_bucket,s3_key,s3_payload):
        try:
            self.s3_client.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=s3_payload,
                ContentType="application/json",
            )
            print(f"Successfully wrote payloads to s3://{s3_bucket}/{s3_key}")
        except Exception as e:
            print(f"Error writing to S3: {str(e)}")
            raise
    
    def read_file_from_s3(self,s3_bucket,s3_key,jsonl=False):
        try:
            response = self.s3_client.get_object(Bucket=s3_bucket,Key=s3_key)
            file_content = response['Body'].read().decode('utf-8')

            if jsonl:
                json_lines = []
                for json_line in file_content.splitlines():
                    if json_line.strip():
                        try:
                            json_line_obj = json.loads(json_line)
                            json_lines.append(json_line_obj)
                        except json.JSONDecodeError as e:
                            print(f"Error decoding JSON line : {json_line} with Error : {e}")
                return json_lines
            else:
                return json.loads(file_content)
            
        except ExceptionGroup as e:
            print(f"Error reading from s3 : {str(e)}")


    def get_rule_set_rules_from_ddb(self,ddb_table_name,dataset_id):
        rls = self.scan_ddb(ddb_table_name,dataset_id)
        print(rls)
        rule_set_rules = []
        if rls and "rls_by_adgroup" in rls[0]:
            rls = rls[0]
            for ad_rule in rls["rls_by_adgroup"]:
                principals = ad_rule['adgroup']
                
                for principal in principals:

                    if principal.endswith("@cppib.com"):
                        rule_set_rule = {"UserName": principal}
                    else:
                        rule_set_rule = {"GroupName" : principal}

                    for rule in ad_rule['rules']:
                        rule_set_rule[rule["column_name"]] = ",".join(rule["authorized_values"])

                    rule_set_rules.append(rule_set_rule)
            
        rule_set_rules_content = "\n".join([json.dumps(rule) for rule in rule_set_rules])
        return rule_set_rules_content
    
    def get_rule_set_cols(self,rule_set_rules,suppress_cols=["UserName","GroupName"]):
        rule_set_cols = []
        for rule_set_rule in rule_set_rules:
            for col in list(rule_set_rule.keys()):
                if col not in rule_set_cols and col not in suppress_cols:
                    rule_set_cols.append(col)
        return rule_set_cols
    
    def get_rule_set_cols_str(self,rule_set_rules_content):
        rule_set_rules = []
        for rule in rule_set_rules_content.split("\n"):
            rule_set_rules.append(json.loads(rule))
        return self.get_rule_set_cols(rule_set_rules,[])
    
    def update_ds(self,rule_set_rules_content,datasource_id,dataset_id,aws_account_id):
        ds_input_cols = [ {
                "Name" : col,
                "Type" : "STRING"
            } for col in self.get_rule_set_cols_str(rule_set_rules_content)]
        response = self.qs_client.update_data_set(
                            AwsAccountId=aws_account_id,
                            DataSetId=dataset_id,
                            Name=dataset_id,
                            PhysicalTableMap={
                                'jsonTable': {
                                    'S3Source': {
                                        'DataSourceArn': f"arn:aws:quicksight:us-east-1:{aws_account_id}:datasource/{datasource_id}",
                                        'InputColumns': ds_input_cols,
                                        'UploadSettings': {
                                            'Format': 'JSON'
                                        }
                                    }
                                }
                            },
                            ImportMode='SPICE'
                        )
            
        rule_dataset_arn = response['Arn']
        print(f"Updated RuleSet Dataset with Arn : {rule_dataset_arn} with input columns : {ds_input_cols}")
    

    def refresh_ds(self,dataset_id,aws_account_id):
        from datetime import datetime

        ingestion_id = f'{dataset_id}-{datetime.now().strftime("%Y%m%d-%H%M%S")}'
        try:
            print(f"Started Refresh DataSet with DataSet Id : {dataset_id}")
            response = self.qs_client.create_ingestion(
                AwsAccountId = aws_account_id,
                DataSetId = dataset_id,
                IngestionId = ingestion_id
            )
            return response
        except Exception as error:
            print(f"DataSet Refresh for DataSet Id : {dataset_id} failed with Error: {error}")
            return None
    

    def get_ds_refresh_status(self,ingestion_id,dataset_id,aws_account_id):
        try:
            print(f"Checking refresh status of ingestion with ingestion id : {ingestion_id} and dataset id : {dataset_id}")
            response = self.qs_client.describe_ingestion(
                DataSetId=dataset_id,
                IngestionId=ingestion_id,
                AwsAccountId=aws_account_id
            )
            ingestion_status = response['Ingestion']['IngestionStatus']
            return ingestion_status
        except Exception as error:
            print(f"Checking refresh status of ingestion with ingestion id : {ingestion_id} failed with Error : {error}")
        

    def get_asset_ds(self,asset_id,aws_account_id):
        try:
            print(f"Finding all the dataset ids in asset_id : {asset_id}")
            response = self.qs_client.describe_dashboard_definition(
            AwsAccountId=aws_account_id,
            DashboardId=asset_id
            )
            all_ds = [ds_meta["DataSetArn"].split("/")[-1] 
                    for ds_meta in response["Definition"]["DataSetIdentifierDeclarations"]]
            
            print(f"The dataset ids in asset_id : {asset_id} are : {all_ds}")
            return all_ds
        except Exception as error:
            print(f"Finding all the dataset ids in asset_id : {asset_id} failed with Error: {error}")
            return []

    
    def remove_whitelist_principals_from_rls_ds(self,dataset_id,ddb_table_name,aws_account_id,refresh=False):
        ruleset_datasource_id = f"{dataset_id}-rule-set-ds"
        ruleset_dataset_id = f"{dataset_id}-rule-set"
        try:
            response = self.qs_client.describe_data_source(
            AwsAccountId=aws_account_id,
            DataSourceId=ruleset_datasource_id
            )

            manifest_file_loc = response["DataSource"]["DataSourceParameters"]["S3Parameters"]["ManifestFileLocation"]
            rule_set_bucket = manifest_file_loc["Bucket"]
            rule_set_key = manifest_file_loc["Key"].replace("manifest","rule_set")

            new_rule_set_rules_content = self.get_rule_set_rules_from_ddb(ddb_table_name,dataset_id)
            print(f"Removed whitelisted principals to the RLS Rule Set of DataSet with Id: {dataset_id}")
            
            self.write_file_to_s3(rule_set_bucket,rule_set_key,new_rule_set_rules_content)
            self.update_ds(new_rule_set_rules_content,ruleset_datasource_id,ruleset_dataset_id,aws_account_id)

            if refresh:
                refresh_response = self.refresh_ds(ruleset_dataset_id,aws_account_id)
                if refresh_response:
                    return refresh_response
                return []
        except Exception as error:
            print(f"Removing whitelisted principals to the RLS Rule Set of DataSet with Id: {dataset_id} failed with Error : {error}")
            return []
        
        
    def add_whitelist_principals_to_rls_ds(self,dataset_id,ddb_table_name,aws_account_id,embedding_access_data,refresh=False):
        ruleset_datasource_id = f"{dataset_id}-rule-set-ds"
        ruleset_dataset_id = f"{dataset_id}-rule-set"

        whitelist_principals = list(set(embedding_access_data.get("whitelist", [])))

        try:
            response = self.qs_client.describe_data_source(
            AwsAccountId=aws_account_id,
            DataSourceId=ruleset_datasource_id
            )

            manifest_file_loc = response["DataSource"]["DataSourceParameters"]["S3Parameters"]["ManifestFileLocation"]
            rule_set_bucket = manifest_file_loc["Bucket"]
            rule_set_key = manifest_file_loc["Key"].replace("manifest","rule_set")

            self.remove_whitelist_principals_from_rls_ds(dataset_id,ddb_table_name,aws_account_id,refresh=False)

            rule_set_rules = self.read_file_from_s3(rule_set_bucket,rule_set_key,True)
            rule_set_cols = self.get_rule_set_cols(rule_set_rules)

            whitelist_rule_set_rules = []

            for principal in whitelist_principals:
                principal_key = "UserName" if principal.endswith("@cppib.com") else "GroupName"
                new_rule = {principal_key: principal}
                for col in rule_set_cols:
                    new_rule[col] = None
                if new_rule not in rule_set_rules and new_rule not in whitelist_rule_set_rules:
                    whitelist_rule_set_rules.append(new_rule)
            
            if whitelist_rule_set_rules:
                print(f"Added whitelisted principals to the RLS Rule Set of DataSet with Id: {dataset_id}")
                new_rule_set_rules = rule_set_rules + whitelist_rule_set_rules
                new_rule_set_rules_content = "\n".join([json.dumps(rule) for rule in new_rule_set_rules])

                self.write_file_to_s3(rule_set_bucket,rule_set_key,new_rule_set_rules_content)
                self.update_ds(new_rule_set_rules_content,ruleset_datasource_id,ruleset_dataset_id,aws_account_id)

                if refresh:
                    refresh_response = self.refresh_ds(ruleset_dataset_id,aws_account_id)
                    if refresh_response:
                        return refresh_response
                    return []

            return whitelist_rule_set_rules

        except Exception as error:
            print(f"No RLS for the dataset with dataset id : {dataset_id}")
            return []
    

    def add_whitelist_principals_to_rls(self,asset_id,ddb_table_name,aws_account_id,embedding_access_data):
        import time

        print(f"Adding whitelist users to rls of dashboard with asset id : {asset_id}")
        dataset_ids = self.get_asset_ds(asset_id,aws_account_id)

        datasets_to_refresh = []
        refresh_data_sources = []

        for dataset_id in dataset_ids:
            refresh_data_source = self.add_whitelist_principals_to_rls_ds(dataset_id,ddb_table_name,aws_account_id,
                                                                          embedding_access_data,refresh=True)
            if refresh_data_source:
                refresh_data_sources.append(refresh_data_source)
                datasets_to_refresh.append(dataset_id)
        
        # wait for data sources refreshes to finish
        ingestion_ds_count = 0
        while ingestion_ds_count < len(refresh_data_sources):
            print(f"Checking to ensure that all the rule set datasets for asset id: {asset_id} have refreshed before triggering dataset refreshes")
            ingestion_ds_count = 0
            for refresh_data_source in refresh_data_sources:

                ingestion_id = refresh_data_source["IngestionId"]
                dataset_id = refresh_data_source["Arn"].replace(f"/ingestion/{ingestion_id}","").split("/")[-1]

                if self.get_ds_refresh_status(ingestion_id,dataset_id,aws_account_id) in ['COMPLETED', 'FAILED', 'CANCELLED']:
                    ingestion_ds_count +=1
            time.sleep(5)
        
        for dataset_id in datasets_to_refresh:
            self.refresh_ds(dataset_id,aws_account_id)
    

    def remove_whitelist_principals_from_rls(self,asset_id,ddb_table_name,aws_account_id):
        import time

        print(f"Removing whitelist users from rls of dashboard with asset id : {asset_id}")
        dataset_ids = self.get_asset_ds(asset_id,aws_account_id)

        datasets_to_refresh = []
        refresh_data_sources = []

        for dataset_id in dataset_ids:
            refresh_data_source = self.remove_whitelist_principals_from_rls_ds(dataset_id,ddb_table_name,aws_account_id,refresh=True)
            if refresh_data_source:
                refresh_data_sources.append(refresh_data_source)
                datasets_to_refresh.append(dataset_id)
        
        # wait for data sources refreshes to finish
        ingestion_ds_count = 0
        while ingestion_ds_count < len(refresh_data_sources):
            print(f"Checking to ensure that all the rule set datasets for asset id: {asset_id} have refreshed before triggering dataset refreshes")
            ingestion_ds_count = 0
            for refresh_data_source in refresh_data_sources:

                ingestion_id = refresh_data_source["IngestionId"]
                dataset_id = refresh_data_source["Arn"].replace(f"/ingestion/{ingestion_id}","").split("/")[-1]

                if self.get_ds_refresh_status(ingestion_id,dataset_id,aws_account_id) in ['COMPLETED', 'FAILED', 'CANCELLED']:
                    ingestion_ds_count +=1
            time.sleep(5)
        
        for dataset_id in datasets_to_refresh:
            self.refresh_ds(dataset_id,aws_account_id)
    

    def add_whitelist_principals_to_cls_ds(self,dataset_id,ddb_table_name,aws_account_id,embedding_access_data):
        whitelist_principals = list(set(embedding_access_data.get("whitelist", [])))
        try:
            response = self.qs_client.describe_data_set(
            AwsAccountId=aws_account_id,
            DataSetId=dataset_id
            )

            if "ColumnLevelPermissionRules" in response["DataSet"]:
                if response["DataSet"]["ColumnLevelPermissionRules"]:

                    self.remove_whitelist_principals_from_cls_ds(dataset_id,ddb_table_name,aws_account_id)

                    cls = response["DataSet"]["ColumnLevelPermissionRules"]
                    for cls_rule in cls:
                        for principal in whitelist_principals:

                            if principal.endswith("@cppib.com"):
                                principal_arn = f"arn:aws:quicksight:us-east-1:{aws_account_id}:user/default/{principal}"
                            else:
                                principal_arn = f"arn:aws:quicksight:us-east-1:{aws_account_id}:group/default/{principal}"

                            if principal_arn not in cls_rule["Principals"]:
                                    cls_rule["Principals"].append(principal_arn)

                    remove_cols = ["Arn",
                            "ConsumedSpiceCapacityInBytes",
                            "CreatedTime",
                            "LastUpdatedTime",
                            "OutputColumns"
                            ]
                    
                    ds_update_req = response["DataSet"]
                    for col in remove_cols:
                        ds_update_req.pop(col)

                    ds_update_req["ColumnLevelPermissionRules"] = cls
                    ds_update_req["AwsAccountId"] = aws_account_id
                    self.qs_client.update_data_set(**ds_update_req)
                    print(f"Added whitelisted principals to the CLS of DataSet with Id: {dataset_id}")

        except Exception as error:
            print(f"No CLS for the dataset with dataset id : {dataset_id}")
            return []
        
    
    def remove_whitelist_principals_from_cls_ds(self,dataset_id,ddb_table_name,aws_account_id):
        try:
            response = self.qs_client.describe_data_set(
            AwsAccountId=aws_account_id,
            DataSetId=dataset_id
            )
            if "ColumnLevelPermissionRules" in response["DataSet"]:
                if response["DataSet"]["ColumnLevelPermissionRules"]:
                    cls = self.scan_ddb(ddb_table_name,dataset_id)
                    print(cls)
                    cls_payload = []
                    if cls and cls[0]["cls"]:
                        cls = cls[0]
                        for cls_rule in cls["cls"]:
                            principals = []
                            for principal in cls_rule["principals"]:
                                if principal.endswith("@cppib.com"):
                                    principals.append(f"arn:aws:quicksight:us-east-1:{aws_account_id}:user/default/{principal}")
                                else:
                                    principals.append(f"arn:aws:quicksight:us-east-1:{aws_account_id}:group/default/{principal}")

                            cls_payload.append(
                                {
                                    "Principals" : principals,
                                    "ColumnNames" : [cls_rule["column_name"]]
                                }
                            )

                    remove_cols = ["Arn",
                            "ConsumedSpiceCapacityInBytes",
                            "CreatedTime",
                            "LastUpdatedTime",
                            "OutputColumns"
                            ]
                    
                    ds_update_req = response["DataSet"]
                    for col in remove_cols:
                        ds_update_req.pop(col)

                    ds_update_req["ColumnLevelPermissionRules"] = cls_payload
                    ds_update_req["AwsAccountId"] = aws_account_id

                    self.qs_client.update_data_set(**ds_update_req)
                    print(f"Removed whitelisted principals from CLS of DataSet with Id: {dataset_id}")
        except Exception as error:
            print(f"No CLS for the dataset with dataset id : {dataset_id}")
            print(f"Error : {error}")
            return []
    

    def add_whitelist_principals_to_cls(self,asset_id,ddb_table_name,aws_account_id,embedding_access_data):
        print(f"Adding whitelist users to cls of dashboard with asset id : {asset_id}")
        dataset_ids = self.get_asset_ds(asset_id,aws_account_id)

        for dataset_id in dataset_ids:
            self.add_whitelist_principals_to_cls_ds(dataset_id,ddb_table_name,aws_account_id,embedding_access_data)

    
    def remove_whitelist_principals_from_cls(self,asset_id,ddb_table_name,aws_account_id):
        print(f"Removing whitelist users from cls of dashboard with asset id : {asset_id}")
        dataset_ids = self.get_asset_ds(asset_id,aws_account_id)

        for dataset_id in dataset_ids:
            self.remove_whitelist_principals_from_cls_ds(dataset_id,ddb_table_name,aws_account_id)


    def _get_asset_level_security_from_file(
        self, embedding_access_data: dict
    ) -> AssetLevelSecurity:
        return AssetLevelSecurity(
            asset_id=self.asset_id,
            whitelist=set(embedding_access_data.get("whitelist", [])),
            viewers=set(embedding_access_data.get("viewers", [])),
        )


#TEMPORARY CODE FOR Q BAR SECURITY

    def _get_q_topic_security_from_file(
        self, q_topic_security: dict
    ) -> QTopicSecurity:
        return QTopicSecurity(
            asset_id=self.asset_id,
            users=set(q_topic_security.get("users", []))
        )

# END TEMPORARY CODE

    def upsert_asset_level_security(self, embedding_access_data: dict):
        asset_level_security = self._get_asset_level_security_from_file(
            embedding_access_data
        )

        item = serialize_to_dynamodb(asdict(asset_level_security))

        response = self.dynamodb_client.put_item(
            TableName=os.environ["ASSET_LEVEL_SECURITY_TABLE"], Item=item
        )

        self.logger.info(
            f"Upserted asset level security: {item} for asset: {self.asset_id}, response: {response}"
        )

        return response
    

# TEMPORARY CODE FOR Q BAR SECURITY

    def upsert_q_topic_security(self, q_security_data: dict):

            q_topic_security = self._get_q_topic_security_from_file(
                q_security_data
            )

            item = serialize_to_dynamodb(asdict(q_topic_security))

            response = self.dynamodb_client.put_item(
                TableName=os.environ["Q_TOPIC_SECURITY_TABLE"], Item=item
            )

            self.logger.info(
                f"Upserted Q topic level security: {item} for asset: {self.asset_id}, response: {response}"
            )

 # END TEMPORARY CODE   

    def add_embedd_users_to_asset(self,qs_client,embedding_access_data: dict, asset_id, aws_account):

        self.remove_embedd_users_from_asset(qs_client, asset_id, aws_account)

        allowed_user_groups = list(set(list(set(embedding_access_data.get("whitelist", []))) + list(set(embedding_access_data.get("viewers", [])))))

        viewer_actions = ['quicksight:DescribeDashboard',
                              'quicksight:ListDashboardVersions',
                              'quicksight:QueryDashboard'
                              ]
        
        allowed_principals = []
        asset_grants = []

        for principal in allowed_user_groups:
            if principal.endswith("@cppib.com"):
                allowed_principals += [f'arn:aws:quicksight:us-east-1:{aws_account}:user/default/{principal}']
            else:
                allowed_principals += [f'arn:aws:quicksight:us-east-1:{aws_account}:group/default/{principal}']
        
        
        for principal in allowed_principals:
            asset_grants.append({
                "Principal" : principal,
                "Actions": viewer_actions
            })
        
        try:
            response = qs_client.update_dashboard_permissions(
                        AwsAccountId=aws_account,
                        DashboardId=asset_id,
                        GrantPermissions=asset_grants
                        )
            print(f"Granting access on asset id : {asset_id} returned with response : {response}")
        except Exception as error:
            print(f"Granting access on asset id : {asset_id} failed with error : {error}")

    
    def remove_embedd_users_from_asset(self,qs_client, asset_id, aws_account):
        default_principal = "AWS_SSO_QS_AUTHOR_ALL_DEPARTMENTS"
        default_principal_arn = f'arn:aws:quicksight:us-east-1:{aws_account}:group/default/{default_principal}'
        workspace_id = self.get_workspace_from_asset_id(asset_id)

        viewer_actions = ['quicksight:DescribeDashboard',
                              'quicksight:ListDashboardVersions',
                              'quicksight:QueryDashboard'
                              ]
        asset_grants = [{
            "Principal" : default_principal_arn,
            "Actions": viewer_actions
        }]

        if workspace_id in PROHIBITED_WORKSPACES:
            asset_grants = []

        try:
            response = qs_client.update_dashboard_permissions(
                        AwsAccountId=aws_account,
                        DashboardId=asset_id,
                        GrantPermissions=asset_grants
                        )
            print(f"Removing access on asset id : {asset_id} returned with response : {response}")
        except Exception as error:
            print(f"Removing access on asset id : {asset_id} failed with error : {error}")


    def delete_asset_level_security(self):
        response = self.dynamodb_client.delete_item(
            TableName=os.environ["ASSET_LEVEL_SECURITY_TABLE"],
            Key={"asset_id": {"S": self.asset_id}},
        )

        self.logger.info(
            f"Deleted asset level security for asset: {self.asset_id}, response: {response}"
        )

        return response
