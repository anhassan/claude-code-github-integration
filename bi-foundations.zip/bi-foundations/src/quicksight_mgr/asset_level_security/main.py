import os
import boto3
import logging

from quicksight_mgr.cfg import BIFoundationsConfigS3
from quicksight_mgr.asset_level_security.embedding_access import EmbeddingAccess

aws_region = os.environ["AWS_REGION_NAME"]
s3_bucket = os.environ["BUCKET_NAME"]
aws_account = os.environ["ACCOUNT_ID"]
ddb_rls_table_name = os.environ["DATASET_RLS_TABLE"]
ddb_cls_table_name = os.environ["DATASET_CLS_TABLE"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3", region_name=aws_region)
dynamodb_client = boto3.client("dynamodb", region_name=aws_region)
qs_client = boto3.client("quicksight",region_name=aws_region)


def handler(event, _):
    cfg = BIFoundationsConfigS3(
        logger=logger,
        s3_client=s3_client,
        bucket=s3_bucket,
        s3_event=event,
    )

    asset_configs = cfg.parse_asset_configs()

    for asset in cfg.config.get("assets", {}):
        asset_id = asset_configs[asset]["asset_id"]
        embedding_access = EmbeddingAccess(logger, asset_id, dynamodb_client)

# TEMPORARY CODE FOR UPLOADING Q TOPIC ACCESS INTO DYNAMO 

        if "q_access.yaml" in cfg.config["assets"][asset]:
            s3_file_key = f"{cfg.prefix}/assets/{asset}/q_access.yaml"
            yaml_file_data = cfg.get_s3_path(s3_file_key)
            embedding_access.upsert_q_topic_security(yaml_file_data)
            print(yaml_file_data)


# END TEMPORARY CODE

        block_embedding_access = asset_configs[asset].get("block_embedding_access", False)
        if not block_embedding_access:
            if "embedding_access.yaml" in cfg.config["assets"][asset]:
                s3_file_key = f"{cfg.prefix}/assets/{asset}/embedding_access.yaml"
                yaml_file_data = cfg.get_s3_path(s3_file_key)
                embedding_access.upsert_asset_level_security(yaml_file_data)

                # Required for asset ids that support AD groups and CLS
                embedding_access.add_embedd_users_to_asset(qs_client,yaml_file_data, asset_id, aws_account)
                embedding_access.add_whitelist_principals_to_rls(asset_id,ddb_rls_table_name,aws_account,yaml_file_data)
                embedding_access.add_whitelist_principals_to_cls(asset_id,ddb_cls_table_name,aws_account,yaml_file_data)
            else:
                embedding_access.delete_asset_level_security()

                # Required for asset ids that support AD groups and CLS
                embedding_access.remove_embedd_users_from_asset(qs_client, asset_id, aws_account)
                embedding_access.remove_whitelist_principals_from_rls(asset_id,ddb_rls_table_name,aws_account)
                embedding_access.remove_whitelist_principals_from_cls(asset_id,ddb_cls_table_name,aws_account)

    return event
