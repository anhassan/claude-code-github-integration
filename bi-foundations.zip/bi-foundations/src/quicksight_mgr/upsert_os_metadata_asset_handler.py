import json
import boto3
import os
import logging
from quicksight_mgr.qs_asset_manager import (
    create_asset_index_if_not_exists,
    get_bucket_key_from_sqs_queue,
    read_json_from_s3, get_opensearch_client
)

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    try:
        key = event['asset_metadata_key']
        s3_bucket = event['bucket']
        s3_client = boto3.client('s3')
        json_content = read_json_from_s3(s3_bucket, key, s3_client)

        # Step 2: Get OpenSearch client
        os_client = get_opensearch_client()

        # Step 3: Define index name and document ID (if applicable)
        index_name = os.environ.get('OPENSEARCH_INDEX_NAME')

        # If you have a specific ID for the document, include it
        doc_id = json_content.get('asset_id', None)

        #Step 4: Create the index if it does not exist

        if not os_client.indices.exists(index=index_name):
            create_asset_index_if_not_exists(os_client, index_name)

        upsert_request = {
            "index": index_name,
            "body": json_content,
            "refresh": True
        }

        if doc_id:
            upsert_request['id'] = doc_id

        # Step 5: Index the document
        response = os_client.index(**upsert_request)

        logger.info(f"Successfully indexed document: {response}")

        return {
            'statusCode': 200,
            'body': json.dumps(f'Successfully processed {index_name}')
        }

    except Exception as e:
        logger.error(f"Error processing records: {str(e)}")
        raise
