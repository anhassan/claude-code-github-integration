import os
import boto3
import logging
from quicksight_mgr.cfg import BIFoundationsConfigS3

aws_region = os.environ["AWS_REGION_NAME"]
s3_bucket = os.environ["BUCKET_NAME"]
aws_account = os.environ["ACCOUNT_ID"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3", region_name=aws_region)


def handler(event, context):
    cfg = BIFoundationsConfigS3(
        logger=logger, s3_client=s3_client, bucket=s3_bucket, s3_event=event
    )
    payloads = []
    workspace_directory = cfg.prefix
    for dataset in cfg.config.get("datasets", {}):
        if "rls.yaml" in cfg.config["datasets"][dataset]:
            s3_key = f"{workspace_directory}/datasets/{dataset}/rls.yaml"
            rls_workflow_trigger = {"s3_key": s3_key, "s3_bucket": s3_bucket}
            payloads.append(rls_workflow_trigger)

        if "cls.yaml" in cfg.config["datasets"][dataset]:
            s3_key = f"{workspace_directory}/datasets/{dataset}/cls.yaml"
            cls_workflow_trigger = {"s3_key": s3_key, "s3_bucket": s3_bucket}
            payloads.append(cls_workflow_trigger)
        
    return {"payloads": payloads, "rls_dataset_count": len(payloads)}
