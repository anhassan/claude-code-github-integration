#standalone script to generate a manifest.json file that will trigger the step function workflow to start. the script will generate a manifest file in the directory
import sys
from datetime import datetime
import boto3

import json


#todo figure out if there is a better way to get aws s3 buckets for pushing these files to
buckets = {"dev":  "bi-foundations-control-plane-200967598245-dev",
               "qa": "bi-foundations-control-plane-885014163466-qa",
               "uat": "bi-foundations-control-plane-207662059077-uat",
               "prod": "bi-foundations-control-plane-679601897237-prod"}


def generate_changed_file_list(changed_files:str):
    changed_file_list=changed_files.split(" ")
    return changed_file_list


def _filter_asset_paths(file_path):
    # Split the path by forward slashes
    parts = file_path.split('/')
    # Check if we have at least 3 parts (to safely check the second position)
    # and verify if the second part is "assets"
    return len(parts) >= 3 and parts[1] == "assets"


def get_asset_directories(changed_file_list:list):
    """
    filters the list of changed files to only include asset directories and deduplicates entries
    :param changed_file_list: list of changed files
    :return: list of asset directories
    """
    asset_directories = []
    for path in changed_file_list:
            if _filter_asset_paths(path):
                asset_directories.append(path)
    base_paths = set()
    for path in asset_directories:
        # Split the path into parts
        parts = path.split('/')
        if len(parts) >= 3:
            # Join first three parts and add a trailing slash
            base_path = '/'.join(parts[:3]) + '/'
            base_paths.add(base_path)
    return list(base_paths)
    return asset_directories


def create_manifest_json_payload(asset_directory):

    """
    creates a manifest.json payload for the step function workflow to trigger
    :param asset_directory: the asset directory to create the manifest for
    :return: manifest.json payload
    """
    manifest_payload = {
        "version": "1.0" ,
        "asset_directory": asset_directory,
        "created_at": datetime.now().isoformat()
    }
    return manifest_payload


def write_manifest_json_s3(s3_client, bucket_name, manifest_payload, github_repo_name, asset_directory):
    """
    writes the manifest.json payload to s3
    :param s3_client: the s3 client to use
    :param bucket_name: the bucket name to write the manifest to
    :param manifest_payload: the manifest.json payload
    :param asset_directory: the asset directory to create the manifest for
    :return: None
    """
    workspace_name = github_repo_name.split("-")[1]
    manifest_key = f"raw/{workspace_name}/{asset_directory}manifest.json"
    s3_client.put_object(Bucket=bucket_name, Key=manifest_key, Body=json.dumps(manifest_payload))


def get_s3_asset_bucket_name(asset_directory):
    """
    gets the s3 bucket name from the github repo name
    :param github_repo_name: the github repo name
    :return: the s3 bucket name
    """

    env = asset_directory.split("/")[0]
    bucket_name = buckets.get(env)
    return bucket_name

def main(changed_files,s3_client, github_repo_name,bucket_name):
    changed_file_list = generate_changed_file_list(changed_files)
    asset_directories = get_asset_directories(changed_file_list)
    for asset_directory in asset_directories:
        manifest_payload = create_manifest_json_payload(asset_directory)
        bucket_name = get_s3_asset_bucket_name(asset_directory)
        write_manifest_json_s3(s3_client, bucket_name, manifest_payload, github_repo_name, asset_directory)

if __name__ == "__main__":
    changed_files = sys.argv[1]
    github_repo_name = sys.argv[2]
    s3_client = boto3.client('s3')
    main(changed_files,s3_client,github_repo_name)