# Context

This folder of bi-foundations deploys multiple lambdas that belong to the same step function orchestration workflow. The purpose of these lambdas is to manage the process of creating and updating resources in Quicksight.

# S3 Events

`Present state:` the orchestration flow is initiated by a Github action from a workspace repo that triggers the `sync_workspace.yaml` github workflow to sync the calling workspace to S3. It uploads a manifest.json file to the folder in S3, which triggers an S3 event which starts the orchestration from step 1. Each step of the orchestration flow is triggered sequentially after the previous step completes successfully.

`Future state:` the orchestration flow is driven through user actions done by BI admins in the finsights portal. This allows us to ensure that pre-requisites are met prior to executing a sub workflow, and can allow us to isolate updates/events at a more granular level.

## Lambda Publish Dataset Handler

This handler is triggered as part of the orchestration flow and is responsible from creating consumable dataset resources in Quicksight that will be used by BI authors in the Quicksight console to develop dashboards.

## Lambda Promote Asset Handler

This handler is triggered as part of the orchestration flow and is responsible from creating a `managed` dashboard resource in Quicksight that was developed by BI authors in the Quicksight console. This managed dashboard serves as a versioned artifact and is made available in the finsights portal for the environment the sync was triggered for using the config.yaml provided in the asset resource folders of the workspace. The event passed to the lambda is the workspace folder in S3 that had changed. 

## Lambda QuickSight Manager

The handler.py is the generic entrypoint for the QS manager lambda which is responsible for all the CRUD operations on Quicksight resources. This handler is to be the gateway to manage operations on Quicksight exclusively. In current state, it will be triggered by the other handlers in the quicksight_mgr.
