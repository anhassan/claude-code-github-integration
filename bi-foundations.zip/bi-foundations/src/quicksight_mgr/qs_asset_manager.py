import json
from typing import List
import boto3
from botocore.exceptions import ClientError
import xml.etree.ElementTree as ET
import csv
import logging
import io
import deepdiff
import os
import yaml
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

logger = logging.getLogger()
logger.setLevel(logging.INFO)
from datetime import UTC, datetime
import deepdiff


base_keys_to_keep = [
    "Name",
    "sheets.name",
    "sheets.visualizations.visualization_type",
    "sheets.visualizations.visual_id",
    "sheets.visualizations.visual_name",
    "sheets.visualizations.visual_datasets",
    "sheets.visualizations.visual_datasets.name",
    "sheets.visualizations.visual_datasets.column_name",
    "sheets.visualizations.visual_datasets.visual_dimension_fields",
    "sheets.visualizations.visual_datasets.visual_numerical_fields",
    "sheets.parameters.name",
    "sheets.parameters.source_parameter_name",
    "sheets.parameters.dataset_id",
    "sheets.parameters.column_name",
    "calculated_fields.dataset_identifier",
    "calculated_fields.name",
    "calculated_fields.expression",
    "asset_url",
    "asset_display_name",
    "asset_id_prefix",
    "asset_type",
    "artifact_source",
    "source_account",
    "source_region",
    "target_account",
    "created_at",
    "updated_at",
    "department",
    "description",
    "env",
    "owners",
    "owner_names",
    "associated_dp",
    "tags",
    "datasets.*",
    "row_level_security.dataset_id",
    "row_level_security.workspace_id",
    "finsights_detail.*",
]

csv_column_names = {
    "overview": {"asset_id": "Asset ID", "description": "Description"},
    "dataset": {
        "dataset_id": "Dataset Identifier",
        "dataset_name": "Dataset Name",
        "dataset_description": "Dataset Description",
        "is_data_product": "Is Data Product",
        "portal_url": "Portal URL",
    },
    "sheet": {"sheet_name": "Sheet Name", "sheet_description": "Sheet Description"},
    "visualization": {
        "visual_name": "Visual Name",
        "visual_type": "Visual Type",
        "visual_description": "Visual Description",
        "sheet_name": "Sheet Name",
    },
    "parameter": {
        "parameter_name": "Parameter Name",
        "dataset_id": "Dataset Identifier",
        "parameter_description": "Parameter Description",
        "sheet_name": "Sheet Name",
    },
    "config": {"asset_id": "id_prefix", "asset_display_name": "display_name"},
}


def get_matching_csv_files(bucket_name: str, prefix: str, s3_client) -> list[str]:
    """
    Retrieves a list of CSV files from an S3 bucket/prefix that match names in the provided dictionary

    Args:
        bucket_name (str): The name of the S3 bucket
        prefix (str): The S3 prefix/folder path (e.g., 'ma_cost_dashboard/metadata/')
        name_dictionary (Dict): Dictionary containing the names to match against

    Returns:
        list[str]: List of matching S3 keys for CSV files
    """
    matching_files = {}
    # Ensure the prefix ends with a forward slash
    if not prefix.endswith("/"):
        prefix += "/"

    try:
        # Use paginator to handle cases with many files
        paginator = s3_client.get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)

        for page in page_iterator:
            if "Contents" not in page:
                continue

            for obj in page["Contents"]:
                key = obj["Key"]

                # Check if the file is a CSV
                if not key.endswith(".csv"):
                    continue

                # Extract the filename from the full path
                last_part = key.split("\\")[-1]
                for file_type in csv_column_names.keys():
                    if file_type in last_part.lower():
                        matching_files.update({file_type: key})
        logger.info(f"the matching file list is: {matching_files}")
        return matching_files
    except ValueError as e:
        logger.info(f"Error: {e}")
        return []


def detect_metadata_csv_name(s3_key: str):
    """
    Detects the type of metadata csv file based on the s3 key
    :param s3_key: s3 key of the metadata csv file
    :return: type of metadata csv file
    """
    if not s3_key.endswith(".csv"):
        raise ValueError("csv name does not end with .csv")

    last_part = s3_key.split("\\")[-1]
    # Check if the last part starts with any of the keys in csv_column_names
    for file_type in csv_column_names.keys():
        if file_type in last_part.lower():
            return file_type

    # If no match is found, return None
    raise ValueError(
        "csv name does not contain overview, dataset, sheet, visualization or parameter"
    )


def qs_keys_to_keep(base_keys_to_keep):
    """
    defines which base keys and dynamic keys to keep in the json file
    :return: list of keys to keep
    """
    keys_to_keep = base_keys_to_keep
    return keys_to_keep


qs_key_mapping = {
    "Name": "asset_display_name"
    # "Definition.Sheets": "sheets",
    # "Definition.Sheets.*.Name": "sheet_name",
    # "Definition.Sheets.*.SheetId": "sheet_id",
    # "Definition.Sheets.*.Visuals": "visualizations",
    # "Definition.Sheets.*.Visuals.*.PivotTableVisual.Title.RichText": "visual_name",
    # "Definition.CalculatedFields.*.DataSetIdentifier": "dataset_identifier",
    # "Definition.CalculatedFields.*.Name": "name",
    # "Definition.CalculatedFields.*.Expression": "expression",
}


def read_json_from_s3(bucket_name: str, key: str, s3_client):
    """
    Read a JSON file from an S3 bucket and return its contents as a Python object.

    :param bucket_name: Name of the S3 bucket
    :param file_key: Key (path) of the JSON file in the bucket
    :return: Python object representing the JSON content
    """
    # Create an S3 client

    try:
        # Get the object from S3
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        # Read the content of the file
        file_content = response["Body"].read().decode("utf-8")
        # Parse the JSON content
        json_content = json.loads(file_content)
        return json_content

    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            logger.info(f"The object {key} does not exist in bucket {bucket_name}.")
        elif e.response["Error"]["Code"] == "NoSuchBucket":
            logger.info(f"The bucket {bucket_name} does not exist.")
        else:
            logger.info(f"An error occurred: {e}")
        return None


def _extract_title_by_position(rich_text: str):
    """Parses title from a string based on its position in the XML structure"""
    try:
        # Wrap the content in a root element to make it valid XML
        xml_string = f"<root>{rich_text}</root>"

        # Parse the XML
        root = ET.fromstring(xml_string)

        # Navigate to the title element
        # Assuming the title is always in the first <inline> tag's <b> tag
        title_element = root.find(".//inline/b")

        if title_element is not None:
            # Extract and clean the text
            title = "".join(title_element.itertext()).strip()
            return title
        else:
            return None
    except ET.ParseError:
        logger.info("Error parsing XML. The input might not be valid XML.")
        return None


def rename_nested_dict_keys(obj, key_mapping, current_path=None):
    """
    Recursively rename keys in a nested dictionary based on a provided mapping.

    :param obj: The dictionary or list to process
    :param key_mapping: A dictionary mapping paths to new key names
    :param current_path: The current path in the nested structure (used internally)
    :return: A new dictionary or list with renamed keys
    """
    if current_path is None:
        current_path = []

    if isinstance(obj, dict):
        new_dict = {}
        for key, value in obj.items():
            new_key = key
            full_path = current_path + [key]
            path_str = ".".join(map(str, full_path))

            if path_str in key_mapping:
                new_key = key_mapping[path_str]
            elif key in key_mapping:
                new_key = key_mapping[key]

            new_dict[new_key] = rename_nested_dict_keys(value, key_mapping, full_path)
        return new_dict
    elif isinstance(obj, list):
        return [
            rename_nested_dict_keys(item, key_mapping, current_path + ["*"])
            for item in obj
        ]
    else:
        return obj


def extract_keys(data, keys_to_keep: List[str]):
    def extract_recursive(obj, current_path=""):
        if isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                new_path = f"{current_path}.{k}" if current_path else k

                for key in keys_to_keep:
                    if key.startswith(new_path) or key == new_path:
                        # if there's a wildcard, include the entire subtree in the result
                        if len(new_path) < len(key) and key[len(new_path) :][1] == "*":
                            result[k] = v
                        else:
                            result[k] = extract_recursive(v, new_path)
            return result
        elif isinstance(obj, list):
            return [extract_recursive(item, f"{current_path}") for item in obj]
        else:
            return obj if current_path in keys_to_keep else None

    result = extract_recursive(data)

    # Remove None values and empty dictionaries
    def clean_result(obj):
        if isinstance(obj, dict):
            return {
                k: clean_result(v) for k, v in obj.items() if v is not None and v != {}
            }
        elif isinstance(obj, list):
            return [clean_result(item) for item in obj if item is not None]
        else:
            return obj

    return clean_result(result)


def set_row_level_security_keys(json_data: dict, workspace_id: str) -> dict:
    row_level_security = []

    datasets = json_data.get("datasets", [])

    for item in datasets:
        row_level_security.append(
            {
                "workspace_id": workspace_id,
                "dataset_id": item.get("dataset_id", "").split("/")[-1],
            }
        )

    json_data["row_level_security"] = row_level_security
    return json_data


def set_finsights_detail(json_data, asset_config):
    """
    Updates OS json payload to include finsights_detail object from asset config yaml for usage in the finsights portal.

    The OS payload has some top level fields that come from the config field for finsights_detail.
    The finsights_detail is dynamically set, so it may contain fields not explicitly defined at the top-level of the asset payload.
    """
    finsights_detail = asset_config.get("finsights_detail", {})

    json_data["finsights_detail"] = finsights_detail
    json_data["description"] = finsights_detail.get("description")
    json_data["tags"] = [tag.lower() for tag in finsights_detail.get("tags", [])]
    json_data["asset_type"] = finsights_detail.get("asset_type")
    json_data["artifact_source"] = finsights_detail.get("artifact_source")

    if finsights_detail.get("department"):
        json_data["department"] = finsights_detail.get("department").lower()

    if finsights_detail.get("product_owners"):
        json_data["owners"] = []
        json_data["owner_names"] = []
        for product_owner in finsights_detail.get("product_owners", []):
            json_data["owners"].append(product_owner.get("email"))
            json_data["owner_names"].append(product_owner.get("name"))

    return json_data


def process_datasets(json_data):
    """Function to parse through the QuickSight payload to identify used datasets in this analysis"""
    datasets_final = []
    if (
        "Definition" in json_data
        and "DataSetIdentifierDeclarations" in json_data["Definition"]
    ):
        datasets = json_data["Definition"]["DataSetIdentifierDeclarations"]
        if isinstance(datasets, list):
            for dataset in datasets:
                if isinstance(dataset, dict):
                    datasets_final.append(
                        {
                            "dataset_id": dataset["DataSetArn"],
                            "dataset_name": dataset["Identifier"],
                        }
                    )
    json_data["datasets"] = datasets_final
    return json_data


def extract_visual_dataset_fields(visual_payload):
    visual_datasets = []
    dataset_map = {}

    def map_visual_datasets_from_fields(field_type, fields):
        for field in fields:
            # Handle different field types
            for field_key in [
                "NumericalMeasureField",
                "DimensionField",
                "CategoryField",
                "CategoricalDimensionField",
                "DateDimensionField",
            ]:
                if field_key in field:
                    field_data = field[field_key]
                    if "Column" in field_data:
                        column = field_data["Column"]
                        dataset_name = column.get("DataSetIdentifier")
                        column_name = column.get("ColumnName")

                        if dataset_name:
                            if dataset_name not in dataset_map:
                                dataset_map[dataset_name] = {
                                    "name": dataset_name,
                                    "visual_dimension_fields": set(),
                                    "visual_numerical_fields": set(),
                                }
                            # Categorize the field based on its type
                            field_category = (
                                "visual_numerical_fields"
                                if field_key == "NumericalMeasureField"
                                or field_type == "TableUnaggregatedFieldWells"
                                else "visual_dimension_fields"
                            )
                            dataset_map[dataset_name][field_category].add(column_name)
                            dataset_map[dataset_name]["column_name"] = column_name

    def process_field_wells(field_wells):
        for field_type, fields in field_wells.items():
            if isinstance(fields, list):
                map_visual_datasets_from_fields(field_type, fields)

            if "Values" in fields and isinstance(fields["Values"], list):
                map_visual_datasets_from_fields(field_type, fields["Values"])

    # Process the field wells if they exist
    for visual_type, visual_data in visual_payload.items():
        if "ChartConfiguration" in visual_data:
            chart_config = visual_data["ChartConfiguration"]
            if "FieldWells" in chart_config:
                if isinstance(chart_config["FieldWells"], list):
                    for field_well in chart_config["FieldWells"]:
                        process_field_wells(field_well)
                else:
                    process_field_wells(chart_config["FieldWells"])

    # Convert sets to lists and prepare final output
    for dataset in dataset_map.values():
        dataset["visual_dimension_fields"] = list(dataset["visual_dimension_fields"])
        dataset["visual_numerical_fields"] = list(dataset["visual_numerical_fields"])
        visual_datasets.append(dataset)

    return visual_datasets


def process_sheets(json_data):
    def find_dataset_and_columns(obj):
        if isinstance(obj, dict) and len(obj) > 0:
            visualization_name = str(
                list(obj.keys())[0]
            )  # contains the visualization name
            if visualization_name.endswith("Visual"):
                visual_processed = {}
                visual_processed.update({"visualization_type": visualization_name})
                visual_processed.update(
                    {"visual_id": obj[visualization_name]["VisualId"]}
                )
                visual_title = _extract_title_by_position(
                    obj.get(visualization_name, {})
                    .get("Title", {})
                    .get("FormatText", {})
                    .get("RichText", None)
                )
                visual_processed.update({"visual_name": visual_title})
                if visualization_name == "CustomContentVisual":
                    visual_processed.update(
                        {
                            "visual_datasets": [
                                {
                                    "name": obj.get(
                                        obj.get(visualization_name, {}).get(
                                            "DataSetIdentifier", None
                                        )
                                    )
                                }
                            ]
                        }
                    )
                logger.info("appending visualizations for sheet")
                visualizations.append(visual_processed)
                visual_datasets = extract_visual_dataset_fields(obj)
                visual_processed.update({"visual_datasets": visual_datasets})

        else:
            logging.error(
                "Invalid object type..expected a dictionary for each visualization"
            )

    if "Definition" in json_data and "Sheets" in json_data["Definition"]:
        sheets_processed = []
        sheets = json_data["Definition"]["Sheets"]
        if isinstance(sheets, list):
            for sheet in sheets:
                logger.info(f"processing sheet {sheet}")
                processed_sheet = {"name": sheet.get("Name")}
                if "Visuals" in sheet:
                    visualizations = []
                    logger.info("attempting to find datasets in json")
                    for visual in sheet["Visuals"]:
                        find_dataset_and_columns(visual)
                    processed_sheet.update({"visualizations": visualizations})
                control_types = [
                    "ParameterControls",
                    "FilterControls",
                ]  # Can add controls here
                for control in control_types:
                    if control in sheet:
                        logger.info("attempting to find sheet parameters")
                        parameter_payload = _process_parameters(sheet, control)
                        processed_sheet.update({"parameters": parameter_payload})

                sheets_processed.append(processed_sheet)
        json_data.update({"sheets": sheets_processed})

    return json_data


def _process_parameters(sheet_payload: list, control_type: str):
    """
    This method processes the parameters associated with each sheet creates a
    dictionary of required parameters and appends it to a list
    """
    processed_parameters = []
    sheet_parameters = sheet_payload.get(control_type)
    for parameter in sheet_parameters:
        parameter_options = ["Dropdown", "DateTimePicker"]
        matching_option = next(
            (opt for opt in parameter_options if opt in parameter), None
        )
        if matching_option:
            try:
                if (
                    parameter[matching_option]["DisplayOptions"]["TitleOptions"][
                        "Visibility"
                    ]
                    == "VISIBLE"
                ):
                    processed_parameter_dict = {
                        "name": parameter.get(matching_option, {}).get("Title", None),
                        "source_parameter_name": parameter.get(matching_option, {}).get(
                            "SourceParameterName"
                        ),
                    }
                    processed_parameters.append(processed_parameter_dict)
            except Exception as e:
                logger.warning(
                    f"Error processing parameter {matching_option}: {str(e)}"
                )
                continue  # Skip this parameter and continue with the next one
    return processed_parameters


def process_calculated_fields(json_data: dict):
    calculated_fields_final = []
    if "Definition" in json_data and "CalculatedFields" in json_data["Definition"]:
        calculated_fields = json_data["Definition"]["CalculatedFields"]
        if isinstance(calculated_fields, list):
            for field in calculated_fields:
                calculated_fields_final.append(
                    {
                        "dataset_identifier": field["DataSetIdentifier"],
                        "name": field["Name"],
                        "expression": field["Expression"],
                    }
                )
    json_data["calculated_fields"] = calculated_fields_final
    return json_data


def write_dict_to_s3_json(dictionary: dict, bucket_name: str, file_key: str):
    """
    Write a Python dictionary to a JSON file in an S3 bucket.

    Args:
    dictionary (dict): The Python dictionary to be written to JSON.
    bucket_name (str): The name of the S3 bucket.
    file_key (str): The key (path) where the file will be stored in the bucket.
    Returns:
    bool: True if successful, False otherwise.
    """
    # Initialize the S3 client
    s3_client = boto3.client("s3")

    try:
        # Convert the dictionary to a JSON string
        json_data = json.dumps(dictionary, indent=2)

        # Write the JSON string to S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=file_key,
            Body=json_data,
            ContentType="application/json",
        )
        logger.info(f"Successfully wrote JSON to s3://{bucket_name}/{file_key}")
        return True

    except ClientError as e:
        logger.info(f"Error writing to S3: {e}")
        return False


import csv
from io import StringIO

from io import StringIO
import csv


def generate_sheet_csv(processed_json, bucket_name, s3_key, s3_client):
    """
    Generates a csv file for each sheet in the processed json file
    :param processed_json: the json file to be processed
    :param bucket_name: the bucket name where the csv files will be stored
    :param s3_client: the s3 client to be used
    :return: None
    """
    csv_buffer = StringIO()
    fieldnames = [
        csv_column_names["overview"]["asset_id"],
        csv_column_names["overview"]["description"],
    ]

    writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
    writer.writeheader()

    sheets = processed_json.get("sheets", [])
    for sheet in sheets:
        writer.writerow(
            {
                csv_column_names["overview"]["asset_id"]: sheet.get("name"),
                csv_column_names["overview"]["description"]: "",
            }
        )
    s3_client.put_object(Bucket=bucket_name, Key=s3_key, Body=csv_buffer.getvalue())
    logger.info(f"Successfully wrote CSV to s3://{bucket_name}/{s3_key}")


def generate_visual_csv(processed_json, bucket_name, s3_key, s3_client):
    """
    Generates a csv file for each visual in the processed json file
    :param processed_json: the json file to be processed
    :param bucket_name: the bucket name where the csv files will be stored
    :param s3_key: the key where the csv file will be stored
    :param s3_client: the s3 client to be used
    :return: None
    """
    csv_buffer = StringIO()
    fieldnames = [
        csv_column_names["visualization"]["visual_name"],
        csv_column_names["visualization"]["visual_type"],
        csv_column_names["visualization"]["visual_description"],
        csv_column_names["visualization"]["sheet_name"],
    ]

    writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
    writer.writeheader()

    sheets = processed_json.get("sheets", [])
    for sheet in sheets:
        visualizations = sheet.get("visualizations", [])
        for visual in visualizations:
            writer.writerow(
                {
                    csv_column_names["visualization"]["visual_name"]: visual.get(
                        "visual_name"
                    ),
                    csv_column_names["visualization"]["visual_type"]: visual.get(
                        "visualization_type"
                    ),
                    csv_column_names["visualization"]["visual_description"]: "",
                    csv_column_names["visualization"]["sheet_name"]: sheet.get("name"),
                }
            )
    s3_client.put_object(Bucket=bucket_name, Key=s3_key, Body=csv_buffer.getvalue())
    logger.info(f"Successfully wrote CSV to s3://{bucket_name}/{s3_key}")


def generate_dataset_csv(processed_json, bucket_name, s3_key, s3_client):
    """
    Generates a csv file for each dataset in the processed json file
    :param processed_json: the json file to be processed
    :param bucket_name: the bucket name where the csv files will be stored
    :param s3_key: the key where the csv file will be stored
    :param s3_client: the s3 client to be used
    :return: None
    """
    csv_buffer = StringIO()
    fieldnames = [
        csv_column_names["dataset"]["dataset_id"],
        csv_column_names["dataset"]["dataset_name"],
        csv_column_names["dataset"]["dataset_description"],
        csv_column_names["dataset"]["is_data_product"],
        csv_column_names["dataset"]["portal_url"],
    ]

    writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
    writer.writeheader()

    datasets = processed_json.get("datasets", [])
    for dataset in datasets:
        writer.writerow(
            {
                csv_column_names["dataset"]["dataset_id"]: dataset.get("dataset_id"),
                csv_column_names["dataset"]["dataset_name"]: dataset.get(
                    "dataset_name"
                ),
                csv_column_names["dataset"]["dataset_description"]: "",
                csv_column_names["dataset"]["is_data_product"]: "",
                csv_column_names["dataset"]["portal_url"]: "",
            }
        )
    s3_client.put_object(Bucket=bucket_name, Key=s3_key, Body=csv_buffer.getvalue())
    logger.info(f"Successfully wrote CSV to s3://{bucket_name}/{s3_key}")


def generate_parameter_csv(processed_json: dict, bucket_name: str, s3_key, s3_client):
    """
    Generates a csv file for each parameter in the processed json file
    :param processed_json: the json file to be processed
    :param bucket_name: the bucket name where the csv files will be stored
    :param s3_key: the key where the csv file will be stored
    :param s3_client: the s3 client to be used
    :return: None
    """
    csv_buffer = StringIO()
    fieldnames = [
        csv_column_names["parameter"]["parameter_name"],
        csv_column_names["parameter"]["dataset_id"],
        csv_column_names["parameter"]["parameter_description"],
        csv_column_names["parameter"]["sheet_name"],
    ]

    writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
    writer.writeheader()

    sheets = processed_json.get("sheets", [])
    for sheet in sheets:
        parameters = sheet.get("parameters", [])
        for parameter in parameters:
            writer.writerow(
                {
                    csv_column_names["parameter"]["parameter_name"]: parameter.get(
                        "name"
                    ),
                    csv_column_names["parameter"]["dataset_id"]: None,
                    csv_column_names["parameter"]["parameter_description"]: "",
                    csv_column_names["parameter"]["sheet_name"]: sheet.get("name"),
                }
            )
    s3_client.put_object(Bucket=bucket_name, Key=s3_key, Body=csv_buffer.getvalue())
    logger.info(f"Successfully wrote CSV to s3://{bucket_name}/{s3_key}")


def generate_overview_csv(bucket_name: str, s3_key, s3_client):
    """
    Generates a csv file formatted for the information in the overview page
    """
    csv_key = "csv/parameters.csv"
    csv_buffer = StringIO()
    fieldnames = [
        csv_column_names["overview"]["asset_name"],
        csv_column_names["overview"]["description"],
    ]

    writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerow(
        {
            csv_column_names["overview"]["asset_name"]: None,
            csv_column_names["overview"]["description"]: None,
        }
    )
    s3_client.put_object(Bucket=bucket_name, Key=csv_key, Body=csv_buffer.getvalue())
    logger.info(f"Successfully wrote CSV to s3://{bucket_name}/{s3_key}")


def normalize_boolean(value):
    """
    Normalize boolean values to True or False.

    Args:
    value (any): The value to be normalized.

    Returns:
    bool: True if the value is True, False if the value is False, or None if the value is not a boolean or a string that can be interpreted as a boolean.
    """
    if value is None:
        return False

    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        # Convert to lowercase for consistent comparison
        value = value.lower().strip()
        # List of strings that should be considered True
        true_values = {"true", "yes", "1", "t", "y"}
        false_values = {"false", "no", "0", "f", "n"}
        if value in true_values:
            return True
        if value in false_values:
            return False
        return False  # Default case for unrecognized strings

    return False


class CSVProcessingManager(object):
    """contains methods to transform results from csv into the json schema that S3 needs"""

    def __init__(self, s3_bucket, s3_key, delimiter, s3_client):
        self.data = self.read_csv_from_s3(s3_bucket, s3_key, delimiter, s3_client)

    # method to read csv from s3
    def read_csv_from_s3(self, s3_bucket: str, s3_key: str, delimiter: str, s3_client):
        """
        Reads a CSV file from an S3 bucket and returns its contents as a list of dictionaries.

        Args:
        s3_bucket (str): The name of the S3 bucket.
        s3_key (str): The key (path) of the CSV file in the S3 bucket.
        delimiter (str): The delimiter used in the CSV file.
        s3_client, s3_client to read in a file

        Returns:
        list: A list of dictionaries, where each dictionary represents a row in the CSV file.
        """
        # Initialize the S3 client

        try:
            # Get the CSV file from S3
            response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
            csv_content = response["Body"].read().decode("utf-8")
            # Use StringIO to create a file-like object from the string
            csv_file = io.StringIO(csv_content)
            # Parse the CSV content
            csv_reader = list(csv.DictReader(csv_file, delimiter=delimiter))
            return csv_reader

        except ClientError as e:
            logger.info(f"Error reading from S3: {e}")
            return None

    def prepare_sheet_metadata(self):
        sheets = []
        for row in self.data:
            sheet = {
                "name": row[csv_column_names["sheet"]["sheet_name"]],
                "description": row[csv_column_names["sheet"]["sheet_name"]],
            }
            sheets.append(sheet)
        return sheets

    def prepare_overview_metadata(self):
        """parses the metadata overview fields from the file uploaded to S3"""
        try:
            overview = {
                "asset_id": self.data[0][csv_column_names["overview"]["asset_id"]],
                "description": self.data[0][
                    csv_column_names["overview"]["description"]
                ],
            }
            return overview
        except KeyError as e:
            logging.error(
                f"Key error while attempting to parse the overview csv, check to ensure the correct names"
                f" are used which should be Asset ID and Description: {str(e)}"
            )
            raise

    def prepare_dataset_metadata(self):
        """parses the metadata dataset fields from the file uploaded to S3"""
        datasets = []
        try:
            for row in self.data:
                normalized_boolean_value_is_data_product = normalize_boolean(
                    row[csv_column_names["dataset"]["is_data_product"]]
                )
                dataset = {
                    "dataset_id": row[csv_column_names["dataset"]["dataset_id"]],
                    "dataset_name": row[csv_column_names["dataset"]["dataset_name"]],
                    "dataset_description": row[
                        csv_column_names["dataset"]["dataset_description"]
                    ],
                    "is_data_product": normalized_boolean_value_is_data_product,
                    "portal_url": row[csv_column_names["dataset"]["portal_url"]],
                }
                datasets.append(dataset)
            return datasets
        except KeyError as e:
            logging.error(
                f"Key error while attempting to parse the dataset csv, check to ensure the correct names"
                f" are used which should be dataset_id,dataset_name,dataset_description, is_data_product,"
                f"portal_url: {str(e)}"
            )
            raise

    def prepare_parameter_metadata(self):
        """parses the metadata parameter fields from the file uploaded to S3"""
        parameters = []
        try:
            for row in self.data:
                parameter = {
                    "name": row[csv_column_names["parameter"]["parameter_name"]],
                    "dataset_id": row[csv_column_names["parameter"]["dataset_id"]],
                    "description": row[
                        csv_column_names["parameter"]["parameter_description"]
                    ],
                    "sheet_name": row[csv_column_names["parameter"]["sheet_name"]],
                }
                parameters.append(parameter)
            return parameters
        except KeyError as e:
            logging.error(
                f"Key error while attempting to parse the parameter csv, check to ensure the correct names"
                f" are used which should be Parameter Name, Dataset Identifier, Sheet Name, Description: {str(e)}"
            )
            raise

    def prepare_visualization_metadata(self):

        visualizations = []
        try:
            for row in self.data:
                visualization = {
                    "visual_name": row[
                        csv_column_names["visualization"]["visual_name"]
                    ],
                    "visualization_type": row[
                        csv_column_names["visualization"]["visual_type"]
                    ],
                    "visual_description": row[
                        csv_column_names["visualization"]["visual_description"]
                    ],
                    "sheet_name": row[csv_column_names["visualization"]["sheet_name"]],
                }
                visualizations.append(visualization)
            return visualizations
        except KeyError as e:
            logging.error(
                f"Key error while attempting to parse the visualization csv, check to ensure the correct names"
                f" are used which should be Visual Name, Visual Type, Sheet Name, Description: {str(e)}"
            )
            raise

    def insert_sheets_metadata_payload(
        self, new_metadata_payload, existing_metadata_payload
    ) -> dict:
        """
        Updates the sheets metadata payload with new metadata. If the sheet name is not found in the existing payload,
        it adds the new sheet metadata to the payload.

        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated

        Returns:
            dict: The updated metadata payload
        """

        existing_metadata_payload.update({"sheets": new_metadata_payload})
        logger.info("successfully inserted sheet data into the metadata payload")
        return existing_metadata_payload

    def merge_and_update_sheets_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Synchronizes and merges two JSON dictionaries. The new_metadata_payload serves as the source of truth:
        - Updates existing keys with new values based on the primary_key in the new_metadata_payload
        - Adds new keys that don't exist in existing payload for that record
        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated


        Returns:
            dict: The synchronized and updated metadata payload
        """
        try:
            # Create a deep copy of existing payload to avoid modifying the original
            updated_payload = existing_metadata_payload.copy()

            # If search_key doesn't exist in existing payload, add it with new payload
            if "sheets" not in updated_payload:
                updated_payload.update({"sheets": new_metadata_payload})
                return updated_payload

            diff = deepdiff.DeepDiff(updated_payload["sheets"], new_metadata_payload)
            # Handle values_changed
            if "values_changed" in diff:
                for path, change in diff["values_changed"].items():
                    # Parse the path to find the index and key
                    # Path format example: "root[0]['description']"
                    parts = path.replace("root[", "").split("]")
                    index = int(parts[0])
                    key = parts[1].strip("['']")

                    # Update the value in the original object
                    updated_payload["sheets"][index][key] = change["new_value"]

            # Handle new items if needed
            if "iterable_item_added" in diff:
                for path, item in diff["iterable_item_added"].items():
                    updated_payload["sheets"].append(item)

            return updated_payload

        except KeyError as e:
            logging.error(f"Key error while merging metadata: {str(e)}")
            raise
        except Exception as e:
            logging.error(f"Error merging metadata payloads: {str(e)}")
            raise

    def insert_overview_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Updates the overview metadata payload with new metadata. If the overview name is not found in the existing payload,
        it adds the new overview metadata to the payload.

        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated

        Returns:
            dict: The updated metadata payload
        """

        existing_metadata_payload.update(new_metadata_payload)
        logger.info("successfully inserted overview data into the metadata payload")
        return existing_metadata_payload

    def merge_and_update_overview_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Synchronizes and merges the overview input with the existing metadata json payload. The new_metadata_payload serves as the source of truth:
        - Updates existing keys with new values based on the primary_key in the new_metadata_payload
        - Adds new keys that don't exist in existing payload for that record
        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated
        Returns:
            dict: The synchronized and updated metadata payload
        """
        try:
            # Create a deep copy of existing payload to avoid modifying the original
            updated_payload = existing_metadata_payload.copy()
            diff = deepdiff.DeepDiff(updated_payload, new_metadata_payload)
            if "values_changed" in diff:
                for key, value in diff["values_changed"]["root"]["new_value"].items():
                    # Update the value in the original object
                    updated_payload[key] = value

                # Handle new items if needed
            if "iterable_item_added" in diff:
                for key, value in diff["iterable_item_added"]["root"][
                    "new_value"
                ].items():
                    updated_payload.append(value)
                    logger.info(f"new item added to overview payload: {key}:{value}")
            return updated_payload

        except KeyError as e:
            logging.error(f"Key error while merging metadata: {str(e)}")
            raise

    def insert_datasets_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Updates the datasets metadata payload with new metadata. If the dataset name is not found in the existing payload,
        it adds the new dataset metadata to the payload.

        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated

        Returns:
            dict: The updated metadata payload
        """

        existing_metadata_payload.update({"datasets": new_metadata_payload})
        logger.info("successfully inserted dataset payload to metadata asset ")
        return existing_metadata_payload

    def merge_and_update_datasets_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Synchronizes and merges two JSON dictionaries. The new_metadata_payload serves as the new dataset uploaded by the author:
        - Updates existing keys with new values based on the primary_key in the new_metadata_payload
        - Adds new keys that don't exist in existing payload for that record
        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated
        Returns:
            dict: The synchronized and updated metadata payload
        """
        try:
            # Create a deep copy of existing payload to avoid modifying the original
            updated_payload = existing_metadata_payload.copy()

            # If search_key doesn't exist in existing payload, add it with new payload
            if "datasets" not in updated_payload:
                updated_payload.update({"datasets": new_metadata_payload})
                logger.info("no existing datasets dict existed..adding payload to json")
                return updated_payload

            diff = deepdiff.DeepDiff(updated_payload["datasets"], new_metadata_payload)
            # Handle values_changed
            if "values_changed" in diff:
                for path, change in diff["values_changed"].items():
                    # Parse the path to find the index and key
                    # Path format example: "root[0]['description']"
                    parts = path.replace("root[", "").split("]")
                    index = int(parts[0])
                    key = parts[1].strip("['']")
                    # Update the value in the original object
                    updated_payload["datasets"][index][key] = change["new_value"]

            # Handle new items if needed
            if "iterable_item_added" in diff:
                for path, item in diff["iterable_item_added"].items():
                    updated_payload["datasets"].append(item)

            return updated_payload

        except KeyError as e:
            logging.error(f"Key error while merging metadata: {str(e)}")
            raise

    def insert_parameters_metadata_payload(
        self, new_metadata_payload: dict, existing_metadata_payload: dict
    ) -> dict:
        """
        Updates the parameters metadata payload with new metadata only for sheets that match the keys in the new payload.

        Args:
            new_metadata_payload (dict): The new metadata payload containing sheet names and their parameters
            existing_metadata_payload (dict): The existing metadata payload with sheets to be updated

        Returns:
            dict: The updated metadata payload
        """
        if "sheets" not in existing_metadata_payload:
            logging.warning("No 'sheets' key found in existing metadata payload")
            return existing_metadata_payload

        # Iterate through each sheet in the existing metadata
        for sheet in existing_metadata_payload["sheets"]:

            # Get matching parameters for this sheet
            matching_parameters = [
                param
                for param in new_metadata_payload
                if param.get("sheet_name") == sheet.get("name")
            ]
            if matching_parameters:
                for param in matching_parameters:
                    param.pop(
                        "sheet_name", None
                    )  # Remove 'sheet_name' from the parameter payload
                sheet["parameters"] = matching_parameters

        logger.info("Completed parameter payload updates to metadata asset")
        return existing_metadata_payload

    def merge_and_update_parameters_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Synchronizes and merges two JSON dictionaries. The new_metadata_payload serves as the new dataset uploaded by the author:
        - Updates existing keys with new values based on the primary_key in the new_metadata_payload
        - Adds parameters that don't exist in existing payload for that record
        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated
        Returns:
            dict: The synchronized and updated metadata payload
        """
        try:
            # Create a deep copy of existing payload to avoid modifying the original
            updated_payload = existing_metadata_payload.copy()

            # If search_key doesn't exist in existing payload, add it with new payload
            if "parameters" not in updated_payload:
                updated_payload.update({"parameters": new_metadata_payload})
                logger.info(
                    "no existing parameters dict existed..adding payload to json"
                )
                return updated_payload

            diff = deepdiff.DeepDiff(
                updated_payload["sheets"]["parameters"], new_metadata_payload
            )
            # Handle values_changed
            if "values_changed" in diff:
                for path, change in diff["values_changed"].items():
                    # Parse the path to find the index and key
                    # Path format example: "root[0]['description']"
                    parts = path.replace("root[", "").split("]")
                    index = int(parts[0])
                    key = parts[1].strip("['']")
                    # Update the value in the original object
                    updated_payload["sheets"]["parameters"][index][key] = change[
                        "new_value"
                    ]

            # Handle new items if needed
            if "iterable_item_added" in diff:
                for path, item in diff["iterable_item_added"].items():
                    updated_payload["sheets"]["parameters"].append(item)

            return updated_payload

        except KeyError as e:
            logging.error(f"Key error while merging metadata: {str(e)}")
            raise

    def insert_visualizations_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Updates the visualizations metadata payload with new metadata. If the visualization name is not found in the existing payload,
        it adds the new visualization metadata to the payload.

        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated

        Returns:
            dict: The updated metadata payload
        """

        if "sheets" not in existing_metadata_payload:
            logging.warning("No 'sheets' key found in existing metadata payload")
            return existing_metadata_payload

            # Iterate through each sheet in the existing metadata
        for sheet in existing_metadata_payload["sheets"]:

            # Get matching parameters for this sheet
            matching_parameters = [
                param
                for param in new_metadata_payload
                if param.get("sheet_name") == sheet.get("name")
            ]
            if matching_parameters:
                for param in matching_parameters:
                    param.pop(
                        "sheet_name", None
                    )  # Remove 'sheet_name' from the parameter payload
                sheet["visualizations"] = matching_parameters

        logger.info("Completed visualizations payload updates to metadata asset")
        return existing_metadata_payload

    def merge_and_update_visualizations_metadata_payload(
        self,
        new_metadata_payload: dict,
        existing_metadata_payload: dict,
    ) -> dict:
        """
        Synchronizes and merges two JSON dictionaries. The new_metadata_payload serves as the new dataset uploaded by the author:
        - Updates existing keys with new values based on the primary_key in the new_metadata_payload
        - Adds parameters that don't exist in existing payload for that record
        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated
        Returns:
            dict: The synchronized and updated metadata payload
        """
        try:
            # Create a deep copy of existing payload to avoid modifying the original
            updated_payload = existing_metadata_payload.copy()
            for existing_sheet in updated_payload["sheets"]:
                for new_visualization in new_metadata_payload:
                    if new_visualization.get("sheet_name") == existing_sheet.get(
                        "name"
                    ):
                        for old_visualization in existing_sheet["visualizations"]:
                            if old_visualization.get(
                                "visual_name"
                            ) == new_visualization.get("visual_name"):
                                vis_difference = deepdiff.DeepDiff(
                                    old_visualization, new_visualization
                                )
                                if "values_changed" in vis_difference:
                                    for path, change in vis_difference[
                                        "values_changed"
                                    ].items():
                                        parts = path.replace("root[", "").split("]")
                                        key = parts[0].strip("['']")
                                        # Update the value in the original object
                                        old_visualization[key] = change["new_value"]
            return updated_payload
        except KeyError as e:
            logging.error(f"Key error while merging metadata: {str(e)}")
            raise


def check_asset_status_dynamodb(asset_id: str, table_name, dynamodb_client):
    """
    Checks the status of an asset in DynamoDB
    :param asset_id: the asset id to check
    :param dynamodb_client: the dynamodb client to use
    :return: the status of the asset
    """
    response = dynamodb_client.get_item(
        TableName=table_name, Key={"asset_id": {"S": asset_id}}
    )
    if "Item" in response:
        return response["Item"]["metadata_update_in_progress"]["BOOL"]
    else:
        return None


def update_asset_status_dynamodb(
    asset_id: str, metadata_update_in_progress: bool, table_name, dynamodb_client
):
    """
    Updates the status of an asset in DynamoDB
    :param asset_id: the asset id to update
    :param status: the status to update
    :param dynamodb_client: the dynamodb client to use
    :return: None
    """

    dynamodb_client.put_item(
        TableName=table_name,
        Item={
            "asset_id": {"S": asset_id},
            "metadata_update_in_progress": {"BOOL": metadata_update_in_progress},
        },
    )


def get_bucket_key_from_sqs_queue(event):
    """
    :param event: event from lambda
    :return: bucket key from sqs message
    """
    try:
        sqs_payload = event["body"]
        body = json.loads(sqs_payload)

        s3_key = body["detail"]["object"]["key"]
        s3_bucket = body["detail"]["bucket"]["name"]
        return s3_bucket, s3_key
    except Exception as e:
        raise ValueError(e)


def get_workspace_assets_os(workspace_id: str, index_name: str, os_client):
    """
    Get assets_ids from OpenSearch for a specific workspace_id.
    :param workspace_id: the workspace id to search for
    :param index_name: the OpenSearch index to search in
    :param os_client: OpenSearch client
    :return: list of matching asset_ids
    """
    try:
        # Build the query to search for workspace_id
        query = {
            "_source": ["asset_id"],
            "query": {"term": {"workspace_id.keyword": workspace_id}},
        }

        # Execute the search
        response = os_client.search(index=index_name, body=query, size=10000)

        # Extract the hits from the response
        assets = [hit["_source"]["asset_id"] for hit in response["hits"]["hits"]]
        return assets

    except Exception as e:
        raise ValueError(f"Error searching OpenSearch: {str(e)}")


def remove_retired_bi_assets_os(
    github_os_assets: list,
    existing_os_assets: list,
    workspace_id: str,
    index_name: str,
    os_client,
):
    """
    remove assets from os that are not in os_upsert_asset_list they will be deleted from OS by workspace.
    :param github_os_assets: List of asset IDs from GitHub that should be maintained
    :param existing_os_assets: List of asset IDs that currently exist in OpenSearch
    :param workspace_id: The workspace identifier to filter deletions
    :param index_name: The name of the OpenSearch index to delete from
    :param os_client: OpenSearch client instance for performing delete operations
    :return: a list of assets to upsert
    """
    remove_assets = set(existing_os_assets) - set(github_os_assets)
    remove_assets = list(remove_assets)
    if len(remove_assets) == 0:
        logger.info(f"No assets to remove from OS for workspace {workspace_id}")
        return None
    else:
        try:
            delete_query = {
                "query": {
                    "bool": {
                        "must": [
                            {"terms": {"asset_id": remove_assets}},
                            {"term": {"workspace_id.keyword": workspace_id}},
                        ]
                    }
                }
            }
            # Delete by query
            response = os_client.delete_by_query(
                index=index_name,
                body=delete_query,
                refresh=True,  # Ensure the index is refreshed after deletion
            )

            deleted_count = response.get("deleted", 0)
            logging.info(
                f"Successfully deleted {deleted_count} documents from {index_name}"
            )

            return deleted_count

        except Exception as e:
            raise ValueError(e)


def create_asset_index_if_not_exists(os_client, index_name):
    """
    Creates an index in OpenSearch for the asset_index if it does not exist
    :param os_client: the opensearch client to use
    :param index_name: the name of the index to create
    :return: None
    """
    try:
        # Check if index exists
        if not os_client.indices.exists(index=index_name):
            # Define your index settings and mappings
            index_settings = {
                "settings": {
                    "index": {"refresh_interval": "30s"},
                    "analysis": {
                        "analyzer": {
                            "edge_ngram_analyzer": {
                                "type": "custom",
                                "tokenizer": "standard",
                                "filter": ["lowercase", "edge_ngram_filter"],
                            }
                        },
                        "filter": {
                            "edge_ngram_filter": {
                                "type": "edge_ngram",
                                "min_gram": 1,
                                "max_gram": 20,
                            }
                        },
                    },
                },
                "mappings": {
                    "properties": {
                        "asset_id": {"type": "keyword"},
                        "asset_url": {"type": "text"},
                        "workspace_id": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "is_restricted": {"type": "boolean"},
                        "asset_display_name": {
                            "type": "search_as_you_type",
                        },
                        "artifact_source": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "associated_dp": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "department": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "owners": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "owner_names": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "status": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "asset_type": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "tags": {
                            "type": "text",
                            "fields": {"keyword": {"type": "keyword"}},
                        },
                        "source_account": {"type": "text"},
                        "target_account": {"type": "text"},
                        "created_at": {"type": "date"},
                        "updated_at": {"type": "date"},
                        "description": {"type": "text"},
                        "update_frequency": {"type": "text"},
                        "dataset_last_updated": {"type": "text"},
                        "dashboard_last_updated": {"type": "text"},
                        "row_level_security": {
                            "type": "nested",
                            "properties": {
                                "workspace_id": {"type": "keyword"},
                                "dataset_id": {"type": "keyword"},
                            },
                        },
                        "datasets": {
                            "type": "nested",
                            "properties": {
                                "dataset_id": {"type": "text"},
                                "dataset_name": {"type": "text"},
                                "portal_url": {"type": "text"},
                                "is_data_product": {"type": "boolean"},
                                "dataset_description": {"type": "text"},
                            },
                        },
                        "sheets": {
                            "type": "nested",
                            "properties": {
                                "visualizations": {
                                    "type": "nested",
                                    "properties": {
                                        "visualization_type": {"type": "text"},
                                        "visual_id": {
                                            "type": "text"
                                        },  # Changed from "string" to "text"
                                        "visual_name": {"type": "text"},
                                        "visual_description": {
                                            "type": "text"
                                        },  # Changed from "string" to "text"
                                        "visual_dataset": {
                                            "type": "nested",  # Changed from "string" to "nested"
                                            "properties": {
                                                "name": {
                                                    "type": "text"
                                                },  # Changed from "string" to "text"
                                                "visual_dimension_fields": {
                                                    "type": "text"
                                                },
                                                "visual_numerical_fields": {
                                                    "type": "text"
                                                },  # Changed from "string" to "text"
                                            },
                                        },
                                        "calculated_fields": {
                                            "type": "nested",
                                            "properties": {
                                                "dataset_identifier": {"type": "text"},
                                                "name": {"type": "text"},
                                                "expression": {"type": "text"},
                                            },
                                        },
                                    },
                                }
                            },
                        },
                    }
                },
            }

            # Create the index
            os_client.indices.create(index=index_name, body=index_settings)
            logger.info(f"Created new index: {index_name}")
        else:
            logger.info(f"Index {index_name} already exists")

    except Exception as e:
        logging.error(f"Error creating index: {str(e)}")
        raise


class YamlProcessingManager(object):
    """contains methods to transform results from yaml config fil into the json schema that S3 needs"""

    def __init__(self, s3_bucket, s3_key, s3_client):
        self.data = self.read_yaml_from_s3(s3_bucket, s3_key, s3_client)

    def read_yaml_from_s3(self, bucket, key, s3_client):
        """
        Read and parse a YAML file from S3

        Args:
            bucket (str): S3 bucket name
            key (str): S3 object key (path to file)
            s3_client: boto3 S3 client

        Returns:
            dict: Parsed YAML content

        Raises:
            Exception: If there's an error reading or parsing the file
        """
        try:
            # Get the object from S3
            response = s3_client.get_object(Bucket=bucket, Key=key)
            # Read the file content
            yaml_content = response["Body"].read().decode("utf-8")
            # Parse YAML content
            yaml_data = yaml.safe_load(yaml_content)
            return yaml_data

        except s3_client.exceptions.NoSuchKey:
            raise Exception(f"File not found in S3: {key}")
        except s3_client.exceptions.NoSuchBucket:
            raise Exception(f"Bucket not found: {bucket}")
        except yaml.YAMLError as e:
            raise Exception(f"Error parsing YAML content: {str(e)}")
        except Exception as e:
            raise Exception(f"Error reading file from S3: {str(e)}")

    def prepare_config_metadata(self, s3_key, aws_environment):
        """parses the metadata config fields from the YAML file uploaded to S3"""
        workspace_id = s3_key.split("/")[0]
        try:
            print(self.data)
            config = {
                "asset_id": f"{self.data[csv_column_names['config']['asset_id']]}-{workspace_id}-{aws_environment.lower()}",
                "asset_display_name": self.data[
                    csv_column_names["config"]["asset_display_name"]
                ],
                "workspace_id": workspace_id,
                "finsights_detail": self.data.get("finsights_detail", {}),
            }
            return config
        except KeyError as e:
            raise KeyError(f"Required field missing in YAML configuration: {e}")

    def insert_config_payload(
        self, new_metadata_payload: dict, existing_metadata_payload: dict
    ) -> dict:
        """
        Updates the config metadata payload with new metadata.

        Args:
            new_metadata_payload (dict): The new metadata payload that has updates to key value pairs we want to append to existing metdata payload
            existing_metadata_payload (dict): The existing metadata payload to be updated

        Returns:
            dict: The updated metadata payload
        """

        existing_metadata_payload["asset_id"] = new_metadata_payload["asset_id"]
        existing_metadata_payload["asset_display_name"] = new_metadata_payload[
            "asset_display_name"
        ]
        existing_metadata_payload["workspace_id"] = new_metadata_payload["workspace_id"]
        return existing_metadata_payload

    def get_dashboard_definition_key(self):
        """
        get the s3 dashboard defintiion key based on yaml file parameters and return the path.
        """
        base_dashboard_name = self.data["base_dashboard_name"]
        branch = self.data["branch"]
        version = self.data["version"]
        logging.info("generating path for dashboard definition")
        if version != "latest":
            return f"{base_dashboard_name}/{branch}/{version}/dashboard_definition.json"
        else:
            return f"{base_dashboard_name}/{branch}/latest/dashboard_definition.json"


# add datetime with utc offset
def add_datetime_timestamp_utc(payload: dict):
    """
    Adds a datetime timestamp to the payload with utc to the last_modified column
    :param payload: the payload to add the timestamp to
    :return: the payload with the timestamp added
    """
    try:
        payload["updated_at"] = datetime.now(UTC).isoformat()
        return payload
    except Exception as e:
        logging.error(f"Error adding timestamp to payload: {str(e)}")
        raise


def add_datetime_from_definition_file(s3_bucket: str, S3_key: str, payload, s3_client):
    date_value = get_s3file_upload_datetime(s3_bucket, S3_key, s3_client)
    try:
        payload["updated_at"] = date_value.isoformat()
        logging.info("updating dashboard update_at time")
        return payload
    except Exception as e:
        logging.error(f"Error adding timestamp to payload: {str(e)}")
        raise


def update_payload_with_changes(operational_metadata, business_metadata):

    combined_metadata = operational_metadata.copy()
    diff_result = deepdiff.DeepDiff(
        operational_metadata,
        business_metadata,
        ignore_order=True,  # Ignore list order
        report_repetition=True,  # Report when items are repeated
        verbose_level=2,
        group_by=[
            "sheets.name",
            "sheets.visualizations.visual_name",
            "sheets.parameters.name",
            "datasets.dataset_name",
        ],
    )  # Detailed output

    # Handle changed values
    if "values_changed" in diff_result:
        for path, change in diff_result["values_changed"].items():
            # Convert path string to list of keys
            # Remove 'root' and clean up the path string
            clean_path = path.replace("root['", "").replace("']", "").split("']['")

            # Navigate to the correct position in the payload
            current = combined_metadata
            for key in clean_path[:-1]:
                if key.isdigit():
                    key = int(key)
                current = current[key]

            # Update the value
            last_key = clean_path[-1]
            if last_key.isdigit():
                last_key = int(last_key)
            current[last_key] = change["new_value"]

    return combined_metadata


def get_opensearch_client():
    # Get credentials
    credentials = boto3.Session().get_credentials()
    region = os.environ.get("AWS_REGION_NAME")

    # Create AWS4Auth instance for OpenSearch
    awsauth = AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        region,
        "es",
        session_token=credentials.token,
    )

    # Get OpenSearch endpoint from environment variable
    host = os.environ.get("OPENSEARCH_ENDPOINT")

    # Create OpenSearch client
    opensearch_client = OpenSearch(
        hosts=[{"host": host, "port": 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
    )

    return opensearch_client


def get_s3file_upload_datetime(bucket_name, file_key, s3_client):
    """
    Retrieves the last modified datetime of an S3 object using head_object operation.

    This function makes a HEAD request to S3 to get metadata about the object,
    including its LastModified timestamp. The timestamp represents when the object
    was last uploaded or modified in S3.

    Args:
        bucket_name (str): The name of the S3 bucket containing the file
        file_key (str): The full path/key of the file within the bucket

    Returns:
        datetime: The UTC datetime when the file was last modified in S3
                 Returns None if the file doesn't exist or there's an error
    """
    try:
        response = s3_client.head_object(Bucket=bucket_name, Key=file_key)
        # LastModified returns a datetime object
        return response["LastModified"]
    except Exception as e:
        print(f"Error getting file date: {e}")
        return None
