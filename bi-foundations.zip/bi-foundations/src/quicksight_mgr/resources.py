import os
import re
import uuid
import json
import time
import copy

from quicksight_mgr.handler import QS_ACCOUNT_ID
from common.utils.email_handler import get_secret_from_secret_manager, get_smtp_cred_from_secret, send_email
from common.utils.quicksight_theme import is_managed_theme

from .base import QuickSightResource

QS_DEV_ACCOUNT_ID = "200967598245"

Q_TOPIC_WAIT_TIMEOUT_SECS = 90

VPC_CONNECTION_ARN = os.environ["VPC_CONNECTION_ARN"]

VALID_DATA_SOURCE_TYPES = [
    "POSTGRESQL",
    "AURORA_POSTGRESQL",
    "AURORA",
    "MYSQL",
    "ORACLE",
    "REDSHIFT",
    "S3",
    "SQLSERVER",
]

dashboard_actions = {
    "owners": [
        "quicksight:DescribeDashboard",
        "quicksight:ListDashboardVersions",
        "quicksight:UpdateDashboardPermissions",
        "quicksight:QueryDashboard",
        "quicksight:UpdateDashboard",
        "quicksight:DeleteDashboard",
        "quicksight:DescribeDashboardPermissions",
        "quicksight:UpdateDashboardPublishedVersion",
    ],
    "viewers": [
        "quicksight:DescribeDashboard",
        "quicksight:ListDashboardVersions",
        "quicksight:QueryDashboard",
    ],
    "contributors": [],
}

theme_actions = {
    "user": [
        "quicksight:DescribeTheme",
        "quicksight:DescribeThemeAlias",
        "quicksight:ListThemeAliases",
        "quicksight:ListThemeVersions",
    ],
    "owner": [
        "quicksight:DescribeTheme",
        "quicksight:DescribeThemeAlias",
        "quicksight:ListThemeAliases",
        "quicksight:ListThemeVersions",
        "quicksight:DeleteTheme",
        "quicksight:UpdateTheme",
        "quicksight:CreateThemeAlias",
        "quicksight:DeleteThemeAlias",
        "quicksight:UpdateThemeAlias",
        "quicksight:UpdateThemePermissions",
        "quicksight:DescribeThemePermissions",
    ],
}

# qs parameter block naming is unpredictable
# use mapped lookup where required ...
data_source_parameter_map = {
    "POSTGRESQL": "PostgreSql",
    "MYSQL": "MySql",
    "SQLSERVER": "SqlServer",
    "AURORA_POSTGRESQL": "AuroraPostgreSql",
}


class Dashboard(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(
            logger, "dashboard", qs_client, event, dashboard_actions, s3_client, dryrun
        )
        self.load_definition()

    @property
    def asset_id(self):
        return f"{self.config['id_prefix']}-{self.config['workspace']}"
    
    @property
    def datasets(self):
        return self.config.get("datasets",[])

    @property
    def invalid_definition_values(self) -> list:
        return [""]
    
    @property
    def topics(self):
        return self.config.get("topics",[])
    
    @property
    def block_topic_refresh(self):
        return self.config.get("block_refresh",False)

    # Lists where an empty string is a meaningful *value*, not export noise:
    # filter value lists (a "" entry includes/excludes the blank bucket, e.g.
    # CONTAINS ["", ...] or DOES_NOT_CONTAIN [""]) and parameter static
    # defaults. Stripping "" from these silently changes filter semantics
    # while the create still succeeds.
    preserve_empty_string_lists = ("CategoryValues", "StaticValues")

    def remove_invalid_definition_keys(self, definition, parent_key=None):
        """
        The Quicksight API definition file is often exported with many invalid configuration values not allowed when creating a dashboard.
        This function recursively removes keys with invalid values. For example, many times visual objects have a value that's an empty string.
        This however fails validation on the create dashboard api, even though it was created successfully in the console.

        Exception: lists named in preserve_empty_string_lists keep their empty
        strings — there "" is a legitimate filter/default value the API accepts.
        """

        if isinstance(definition, dict):
            keys_to_delete = [
                k for k, v in definition.items() if v in self.invalid_definition_values
            ]
            for k in keys_to_delete:
                self.logger.info(
                    f"Removing key: {k}, from definition file because it is an invalid value: {definition[k]} in the list {self.invalid_definition_values}"
                )

                del definition[k]

            for k, v in definition.items():
                self.remove_invalid_definition_keys(v, parent_key=k)
        elif isinstance(definition, list):
            if parent_key not in self.preserve_empty_string_lists:
                definition[:] = [
                    v for v in definition if v not in self.invalid_definition_values
                ]
            for v in definition:
                self.remove_invalid_definition_keys(v, parent_key=parent_key)

    def clean_quicksight_definition(self, definition):
        """Cleans QS JSON defintion in place based on required transformations for API"""
        self.remove_invalid_definition_keys(definition)

        for sheet in definition.get("Sheets", []):
            # 1. Remove empty objects from "Visuals"
            valid_visuals = [v for v in sheet.get("Visuals", []) if v]
            sheet["Visuals"] = valid_visuals  # mutate in place

            # 2. Extract visual ids
            visual_ids = set()
            for visual in valid_visuals:
                for visual_obj in visual.values():
                    if "VisualId" in visual_obj:
                        visual_ids.add(visual_obj["VisualId"])

                    # Fix for alt text needing length if any is specified
                    if "VisualContentAltText" in visual_obj and not visual_obj.get(
                        "VisualContentAltText"
                    ):
                        visual_obj["VisualContentAltText"] = " "

            # 3. Clean "Layouts" -> "Configuration" -> Dynamic Layout Key -> "Elements"
            for layout in sheet.get("Layouts", []):
                config = layout.get("Configuration", {})
                for layout_obj in config.values():
                    if "Elements" in layout_obj:
                        elements = layout_obj["Elements"]

                        # Remove visual elements where element id is not in valid set
                        filtered_elements = [
                            e
                            for e in elements
                            if e.get("ElementType") != "VISUAL"
                            or e.get("ElementId") in visual_ids
                        ]
                        layout_obj["Elements"] = filtered_elements

        return definition

    def replace_account_id(self, arn: str, new_account_id: str):
        return re.sub(r":\d{12}:", f":{new_account_id}:", arn)

    def get_dataset_id_from_arn(self, arn: str):
        return (arn or "").split("/")[-1]

    def get_target_logical_table_ids(self, definition):
        target_lt_by_identifier = {}

        for decl in definition.get("DataSetIdentifierDeclarations", []):
            identifier = decl.get("Identifier")
            dataset_id = self.get_dataset_id_from_arn(decl.get("DataSetArn"))
            if not identifier or not dataset_id:
                continue

            try:
                response = self.qs_client_call(
                    "describe_data_set",
                    {"DataSetId": dataset_id},
                )
            except Exception as error:
                self.logger.warning(
                    f"Skipping field ID normalization for dataset {dataset_id}: {error}"
                )
                continue

            logical_table_map = (
                response.get("DataSet", {}).get("LogicalTableMap", {}) or {}
            )
            if len(logical_table_map) != 1:
                self.logger.info(
                    "Skipping field ID normalization for dataset "
                    f"{dataset_id}; expected 1 logical table, found "
                    f"{len(logical_table_map)}"
                )
                continue

            target_lt_by_identifier[identifier] = next(iter(logical_table_map.keys()))

        return target_lt_by_identifier

    def rebuild_field_id(self, old_field_id, logical_table_id, column_name):
        if not old_field_id:
            return old_field_id

        if "." not in old_field_id:
            return f"{logical_table_id}.{column_name}.{old_field_id}"

        parts = old_field_id.rsplit(".", 2)
        if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
            return f"{logical_table_id}.{column_name}.{parts[1]}.{parts[2]}"

        _, rest = old_field_id.split(".", 1)
        return f"{logical_table_id}.{rest}"

    def collect_field_id_rewrites(self, definition, target_lt_by_identifier):
        rewrites = {}

        # Calc-field-backed visual fields use FieldIds shaped as
        # <calc_field_uuid>.<idx>.<ts> (no embedded column name). Rewriting
        # those to <logical_table>.<column>.<idx>.<ts> makes QS resolve them
        # as dataset columns and apply numeric formatting to the calc field's
        # string output. Preserve source FieldIds for columns matching a
        # dashboard-level CalculatedField.
        calc_field_keys = {
            (cf.get("DataSetIdentifier"), cf.get("Name"))
            for cf in (definition.get("CalculatedFields") or [])
            if cf.get("DataSetIdentifier") and cf.get("Name")
        }

        def visit(obj):
            if isinstance(obj, dict):
                column = obj.get("Column")
                if isinstance(column, dict):
                    dataset_identifier = column.get("DataSetIdentifier")
                    column_name = column.get("ColumnName")
                    logical_table_id = target_lt_by_identifier.get(dataset_identifier)
                    is_calc_field = (
                        dataset_identifier,
                        column_name,
                    ) in calc_field_keys
                    if logical_table_id and column_name and not is_calc_field:
                        for key in ("FieldId", "HierarchyId"):
                            old_value = obj.get(key)
                            if isinstance(old_value, str) and old_value:
                                new_value = self.rebuild_field_id(
                                    old_value,
                                    logical_table_id,
                                    column_name,
                                )
                                if new_value != old_value:
                                    rewrites.setdefault(old_value, new_value)

                for value in obj.values():
                    visit(value)
            elif isinstance(obj, list):
                for item in obj:
                    visit(item)

        visit(definition)
        return rewrites

    def apply_field_id_rewrites(self, definition, rewrites):
        if not rewrites:
            return

        def visit(obj):
            if isinstance(obj, dict):
                for key, value in list(obj.items()):
                    if isinstance(value, str):
                        new_value = rewrites.get(value)
                        if new_value is not None:
                            obj[key] = new_value
                    else:
                        visit(value)
            elif isinstance(obj, list):
                for index, value in enumerate(obj):
                    if isinstance(value, str):
                        new_value = rewrites.get(value)
                        if new_value is not None:
                            obj[index] = new_value
                    else:
                        visit(value)

        visit(definition)

    def normalize_field_ids_to_target_logical_tables(self, definition):
        target_lt_by_identifier = self.get_target_logical_table_ids(definition)
        if not target_lt_by_identifier:
            return

        rewrites = self.collect_field_id_rewrites(
            definition,
            target_lt_by_identifier,
        )
        self.apply_field_id_rewrites(definition, rewrites)
        self.logger.info(
            "Rewrote {} QuickSight field ID values to target logical table IDs".format(
                len(rewrites)
            )
        )

    def prep_dashboard_inputs(self, theme_arn):
        definition = self.payload["definition"]["Definition"]

        # used in case we are providing custom datasets not created by the pipeline
        if self.datasets:
            ds_id_decls = [
                {
                    "Identifier" : decl["Identifier"],
                    "DataSetArn" : [dataset["arn"] for dataset in self.datasets if dataset["name"] == decl["Identifier"]][0]
                }
                for decl in definition["DataSetIdentifierDeclarations"]
            ]
            
        else:
            ds_id_decls = [
                {
                    "Identifier": decl["Identifier"],
                    "DataSetArn": self.replace_account_id(
                        decl["DataSetArn"], QS_ACCOUNT_ID
                    ),
                }
                for decl in definition["DataSetIdentifierDeclarations"]
            ]
        
        definition["DataSetIdentifierDeclarations"] = ds_id_decls

        self.normalize_field_ids_to_target_logical_tables(definition)
        self.clean_quicksight_definition(definition)

        payload = {
            "DashboardId": self.asset_id,
            "Name": self.config["display_name"],
            "Definition": definition,
            "DashboardPublishOptions": self.payload["definition"][
                "DashboardPublishOptions"
            ],
            "ValidationStrategy": {"Mode": "LENIENT"},
        }

        if theme_arn:
            payload["ThemeArn"] = theme_arn

        return payload

    def update_published_version(self, version):
        self.logger.info(
            "Updating published version of {} to {}".format(self.asset_id, version)
        )
        response = self.qs_client_call(
            "update_dashboard_published_version",
            {"DashboardId": self.asset_id, "VersionNumber": int(version)},
        )
        self.logger.info(response)
        return response

    def resolve_theme_arn(self):
        """Mirror the authoring dashboard's theme.

        Managed/CLASSIC theme -> pass the managed ARN straight through and do
        NOT build a custom theme (so a stale theme_definition.json can never
        override it). Custom theme -> build {asset_id}-theme from the exported
        theme file. No theme -> None.
        """
        dash_theme = self.payload["definition"].get("ThemeArn")
        if not dash_theme:
            return None
        if is_managed_theme(dash_theme):
            self.logger.info(
                "Dashboard uses managed theme {}; passing through".format(dash_theme)
            )
            return dash_theme
        theme_arn = self.sync_theme()
        if theme_arn is None:
            self.logger.warning(
                "Dashboard ThemeArn {} is custom but no theme definition was "
                "available to sync; promoting without a custom theme".format(
                    dash_theme
                )
            )
        return theme_arn

    def sync_theme(self):
        if theme_key := self.payload.get("s3_theme_key"):
            self.payload["theme"] = self.fetch_s3_json(theme_key)
            theme = Theme(
                self.logger,
                self.qs_client,
                {
                    "resource": "theme",
                    "payload": {**self.payload, "id": f"{self.asset_id}-theme"},
                },
                self.s3_client,
                self.dryrun,
            )

            response = theme.sync()

            return response["Arn"]

        return None
    
    # =========================================================================
    # ================ QS Q TOPIC RELATED UTILITIES START =====================
    # =========================================================================

    def update_topic_datasets(self,topic_definition):
        try:
            updated_ds_arns = []
            if "Topic" in topic_definition.keys():
                if "DataSets" in topic_definition["Topic"].keys():
                    for ds in topic_definition["Topic"]["DataSets"]:

                        old_ds_arn = ds["DatasetArn"]
                        new_ds_arn = self.replace_account_id(old_ds_arn, QS_ACCOUNT_ID)
                        updated_ds_arns.append(new_ds_arn)
                        print(f"Replacing dataset arn : {old_ds_arn} with new dataset arn : {new_ds_arn} in topic definition")
                        ds["DatasetArn"] = new_ds_arn

                    print(f"Updated the dataset arns in topic definition to point to current account id : {QS_ACCOUNT_ID}")
                    return topic_definition, updated_ds_arns
        except Exception as error:
            print(f"ERROR: {error} occured while updating the dataset arns in topic definition to point to current account id : {QS_ACCOUNT_ID}")
            raise


    def write_file_to_s3(self,s3_bucket,s3_key,s3_payload):
        try:
            self.s3_client.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=s3_payload,
                ContentType="application/json",
            )
            print(f"Successfully wrote payloads to s3://{s3_bucket}/{s3_key}")
        except Exception as e:
            print(f"Error writing to S3: {str(e)}")
            raise
    

    def read_file_from_s3(self,s3_bucket,s3_key):
        try:
            response = self.s3_client.get_object(Bucket=s3_bucket,Key=s3_key)
            file_content = response['Body'].read().decode('utf-8')
            return json.loads(file_content)
            
        except ExceptionGroup as e:
            print(f"Error reading from s3 : {str(e)}")
            raise
    

    def write_topic_definition_to_s3(self,topic_definition,ui_topic_name,s3_bucket="bi-foundations-published-qs-definitions"):
        try:
            s3_key = f"bif/topics/topic_definitions/{ui_topic_name}.json"
            self.write_file_to_s3(s3_bucket,s3_key,json.dumps(topic_definition,indent=4))
            print(f"Successfully wrote topic definition to s3://{s3_bucket}/{s3_key}")
        except Exception as e:
            print(f"Error writing topic definition to S3: {str(e)}")
            raise
    

    def read_topic_definition_from_s3(self,ui_topic_name,s3_bucket="bi-foundations-published-qs-definitions"):
        try:
            s3_key = f"bif/topics/topic_definitions/{ui_topic_name}.json"
            topic_definition = self.read_file_from_s3(s3_bucket,s3_key)
            print(f"Successfully read topic definition from s3://{s3_bucket}/{s3_key}")
            updated_topic_definition, updated_topic_datasets = self.update_topic_datasets(topic_definition)
            print(f"Updated the dataset arns in topic definition to point to current account id : {QS_ACCOUNT_ID} and the updated dataset arns are : {updated_topic_datasets}")
            return updated_topic_definition
        except Exception as e:
            print(f"Error reading topic definition from S3: {str(e)}")
            raise


    def get_topic_permissions(self,account_id,topic_id):
        """Utility function to get the existing topic permissions for a topic given a topic id"""
        try:
            print(f"Getting topic permissions for topic id : {topic_id}")
            response = self.qs_client.describe_topic_permissions(
                AwsAccountId = account_id,
                TopicId = topic_id
            )

            if "Permissions" in response.keys():
                return response["Permissions"]
            return None
        
        except Exception as error:
            print(f"Finding Permissions for topic with Topic Id : {topic_id} failed with Error : {error}")

    
    def update_topic_permissions(self,account_id,topic_id,principal_value,principal_type="user",existing_topic_id=None):
        """Utility function to add permissions based on principal value and type on given topic"""

        try:
            principal = f'arn:aws:quicksight:us-east-1:{account_id}:{principal_type}/default/{principal_value}'
            new_topic_permissions = {
                'Principal': principal,
                'Actions': ['quicksight:DescribeTopic',
                                'quicksight:DescribeTopicRefresh',
                                'quicksight:ListTopicRefreshSchedules',
                                'quicksight:DescribeTopicRefreshSchedule',
                                'quicksight:DeleteTopic',
                                'quicksight:UpdateTopic',
                                'quicksight:CreateTopicRefreshSchedule',
                                'quicksight:DeleteTopicRefreshSchedule',
                                'quicksight:UpdateTopicRefreshSchedule',
                                'quicksight:DescribeTopicPermissions',
                                'quicksight:UpdateTopicPermissions'
                            ]
                    }
            
            existing_topic_permissions = [] if existing_topic_id is None else self.get_topic_permissions(account_id,existing_topic_id)
            all_topic_permissions = existing_topic_permissions + [new_topic_permissions]

            response = self.qs_client.update_topic_permissions(
                AwsAccountId = account_id,
                TopicId = topic_id,
                GrantPermissions= all_topic_permissions
                )
            print(f"Response of updating permission for Topic with Topic Id : {topic_id} , Principal Type : {principal_type} and Principal Value : {principal_value} resulted in Response : {response}")
        except Exception as error:
            print(f"Response of updating permission for Topic with Topic Id : {topic_id} , Principal Type : {principal_type} and Principal Value : {principal_value} failed with Error : {error}")
    

    def get_topic_id(self,topic_name):
        """ Utility function to get the topic id from topic name"""
        try:
            print(f"Getting topic id for topic name: {topic_name}")
            all_topics = []

            response = self.qs_client.list_topics(AwsAccountId = QS_DEV_ACCOUNT_ID, )
            if "TopicsSummaries" in response.keys():
                all_topics += response["TopicsSummaries"]

            # Paginating over all the topics
            while "NextToken" in response.keys():
                response = self.qs_client.list_topics(AwsAccountId = QS_DEV_ACCOUNT_ID,NextToken=response["NextToken"])
                if "TopicsSummaries" in response.keys():
                    all_topics += response["TopicsSummaries"]
            
            # Finding the topic id for the required topic name
            for topic_info in all_topics:
                if topic_info["Name"] == topic_name:
                    return topic_info["TopicId"]
            raise Exception(f"No Topic found for Topic Name: {topic_name}")

        except Exception as error:
            print(f"Listing topics for finding topic id for topic name : {topic_name} failed with error : {error}")

    
    def is_topic_name_available(self,topic_id,topic_name):
        """ Utility function to find whether the topic name is available or not. 
            It returns True if the topic name is available else it returns False
        """
        try:
            print(f"Checking availability for topic name: {topic_name}")
            all_topics = []

            response = self.qs_client.list_topics(AwsAccountId = QS_ACCOUNT_ID, )
            if "TopicsSummaries" in response.keys():
                all_topics += response["TopicsSummaries"]

            # Paginating over all the topics
            while "NextToken" in response.keys():
                response = self.qs_client.list_topics(AwsAccountId = QS_ACCOUNT_ID,NextToken=response["NextToken"])
                if "TopicsSummaries" in response.keys():
                    all_topics += response["TopicsSummaries"]
            
            # Finding whether the topic name is available or not
            for topic_info in all_topics:
                if topic_info["Name"] == topic_name and topic_info["TopicId"] != topic_id:
                    print(f"Topic with topic name : {topic_name} already exists with TopicId: {topic_info['TopicId']}")
                    return False
            print(f"No Topic found for Topic Name: {topic_name}")
            return True

        except Exception as error:
            print(f"Listing topics for finding topic availability for topic name : {topic_name} failed with error : {error}")

    
    def get_topic_definition(self,topic_id):
        """Utility function to get topic definition using topic id"""
        try:
            print(f"Getting topic definition for topic id : {topic_id}")
            response = self.qs_client.describe_topic(
                AwsAccountId = QS_ACCOUNT_ID,
                TopicId = topic_id
            )
            return response
        except Exception as error:
            print(f"Getting Topic Definition for Topic Id: {topic_id} failed with Error: {error}")
            return None
    
    def get_topic_status(self,topic_create_update_response,topic_id):
        if 'RefreshArn' in topic_create_update_response.keys():
            refresh_arn = topic_create_update_response['RefreshArn']
            refresh_id = refresh_arn.split("/")[-1]

            try:
                response = self.qs_client.describe_topic_refresh(
                        AwsAccountId=QS_ACCOUNT_ID,
                        TopicId=topic_id,
                        RefreshId=refresh_id
                    )
                
                # Possible Status: # 'INITIALIZED'|'RUNNING'|'FAILED'|'COMPLETED'|'CANCELLED'
                topic_refresh_status = response["RefreshDetails"]["RefreshStatus"]
                print(f"Topic status for Topic Id : {topic_id} and Refresh Arn : {refresh_arn} is : {topic_refresh_status} ...")
                return topic_refresh_status
            
            except Exception as error:
                print(f"Finding the refresh status of Q topic with topic id : {topic_id} failed with Error : {error}")

        return "UNDEFINED"
    
    def delete_topic(self,topic_id,topic_name):
        try:
            response = self.qs_client.delete_topic(
                AwsAccountId=QS_ACCOUNT_ID,
                TopicId=topic_id
            )
            print(f"Successfully deleted Topic with Topic Name : {topic_name} and Topic Id : {topic_id} with response : {response}")
        except Exception as error:
            print(f"Failed deleting Topic with Topic Name : {topic_name} and Topic Id : {topic_id}")

    
    def create_update_topic(self,topic_id,topic_name,topic_definition,asset_id):
        """Utility function to create or update existing topic given a topic id and topic definition"""

        # Creating the payload for topic create/update command
        new_topic_definition = copy.deepcopy(topic_definition)
        to_keep_cols = ["Topic","CustomInstructions"]
        remove_cols = [topic_key for topic_key in new_topic_definition.keys() if topic_key not in to_keep_cols]
        #topic_name = new_topic_definition["Topic"]["Name"]
        env = self.config["workspace"].split("-")[-1]

        for col in remove_cols:
            new_topic_definition.pop(col)
        
        new_topic_definition["AwsAccountId"] = QS_ACCOUNT_ID
        new_topic_definition["TopicId"] = topic_id
        new_topic_definition["Topic"]["Name"] = topic_name
        
        print(f"Prepared topic definition for topic name : {topic_name} and topic id : {topic_id} is : {new_topic_definition}")

        # Check whether topic already exists or has to be created
        to_create_topic = True if self.get_topic_definition(topic_id) is None else False

        if to_create_topic:
            print(f"Creating topic with topic id : {topic_id}")
            response = self.qs_client.create_topic(**new_topic_definition)
            print(f"Creation Response : {response}")
        else:
            print(f"Updating topic with topic id : {topic_id}")
            response = self.qs_client.update_topic(**new_topic_definition)
            print(f"Updation Response : {response}")
        
        topic_status = self.get_topic_status(response,topic_id)
        while topic_status == "RUNNING":
            time.sleep(5)
            print("Sleeping for 5 seconds...")
            topic_status = self.get_topic_status(response,topic_id)
            print(f"Topic Status Recieved : {topic_status}")
        return topic_status
    
    def get_datasets_in_topic(self,topic_definition):
        try:
            if "Topic" in topic_definition.keys():
                if "DataSets" in topic_definition["Topic"].keys():
                    ds_arns = [ ds["DatasetArn"] for ds in topic_definition["Topic"]["DataSets"]]
                    print(f"Following datasets are found in the topic : {ds_arns}")
                    return ds_arns
        except Exception as error:
            print(f"ERROR: {error} occured while finding the datasets associated with the topic")
        return []
    
    
    def get_refreshing_ds(self,topic_ds_list):
        refreshing_ds = []
        try:
            for ds_arn in topic_ds_list:
                ds_id = ds_arn.split("/")[-1]
                print(f"Finding Refresh History of Dataset : {ds_id}")

                ds_ingestions = self.qs_client.list_ingestions(
                            AwsAccountId=QS_ACCOUNT_ID,
                            DataSetId=ds_id
                )["Ingestions"]
                top_5_ingestion_ids = [ds_ingestion["IngestionId"] for ds_ingestion in ds_ingestions][0:5]

                for ingestion_id in top_5_ingestion_ids:
                    response = self.qs_client.describe_ingestion(
                    AwsAccountId=QS_ACCOUNT_ID,
                    DataSetId=ds_id,
                    IngestionId=ingestion_id
                    )

                    ingestion_status = response['Ingestion']['IngestionStatus']
                    print(f"Dataset Id : {ds_id}, Ingestion Id: {ingestion_id}, Ingestion Status: {ingestion_status}")
                    
                    if ingestion_status == "RUNNING":
                        refreshing_ds.append(ds_arn)
                        print(f"Dataset Id : {ds_id} is undergoing refresh")
                        break

            return refreshing_ds

        except Exception as error:
            print(f"Getting Refresh Status of the following dataset arns : {topic_ds_list} failed with Error : {error}")
            return refreshing_ds
    
    def notify_on_q_topic_promotion_failure(self,topic_name,topic_refreshing_ds,asset_id,recepient_email,env):
        import boto3
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        env_name = os.environ["ENV_NAME"].lower()

        sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(sm_client,secret_name)
        )
        sender_email = "svc_finsights@cppib.com"
        # recepient_email = "ahassan@cppib.com"

        email_subject = f"{env.upper()}: Topic Promotion for Topic: {topic_name} and Dashboard: {asset_id} Failed"

        refreshing_ds_ids = [ds_arn.split("/")[-1] for ds_arn in topic_refreshing_ds]
        ds_table_rows = ""

        for ds_id in refreshing_ds_ids:
            ds_table_rows += f"""
                            <tr>
                            <td style="border:1px solid #cccccc;">{ds_id}</td>
                            <td style="border:1px solid #cccccc; color:#2000b0;">Refresh in Progress</td>
                            </tr>

                            """
        
        email_body = f"""
                    <table width="100%" cellpadding="0" cellspacing="0" style="font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#333333;">
                        <tr>
                            <td>
                            <p>Hello,</p>

                            <p>
                                The promotion of the following topic has <strong style="color:#b00020;">failed</strong> due to dataset refresh issues.
                            </p>

                            <table cellpadding="4" cellspacing="0" style="margin:12px 0;">
                                <tr>
                                <td style="font-weight:bold;">Topic Name:</td>
                                <td>{topic_name}</td>
                                </tr>
                                <tr>
                                <td style="font-weight:bold;">Environment:</td>
                                <td>{env}</td>
                                </tr>
                                <tr>
                                <td style="font-weight:bold;">Dashboard Id:</td>
                                <td>{asset_id}</td>
                                </tr>
                            </table>

                            <p>
                                The promotion could not be completed because the following datasets are still undergoing progress:
                            </p>

                            <table width="100%" cellpadding="6" cellspacing="0" style="border-collapse:collapse; margin-top:10px;">
                                <tr style="background-color:#f0f2f5;">
                                <th align="left" style="border:1px solid #cccccc;">Dataset ID</th>
                                <th align="left" style="border:1px solid #cccccc;">Status</th>
                                </tr>
                                {ds_table_rows}
                            </table>

                            <p style="margin-top:16px;">
                                Please ensure the dataset refresh for pending datasets have completed and reattempt the promotion once the refreshes are complete. In order to block dataset refreshes please use tag <span style="font-weight:bold;">block_refresh:true</span> in the metadata.yaml of the required datasets
                            </p>

                            <p>
                                Regards,<br />
                                <strong>BI Foundations Automation</strong>
                            </p>

                            <p style="font-size:12px; color:#666666; margin-top:20px;">
                                This is an automated notification. Please do not reply to this email.
                            </p>
                            </td>
                        </tr>
                    </table>
                    """

        send_email(
                smtp_user,
                smtp_password,
                smtp_host,
                smtp_port,
                sender_email,
                recepient_email,
                recepient_email,
                email_subject,
                email_body,
                True,
            )
    

    def notify_on_q_topic_duplicate_name_failure(self,topic_name,asset_id,recepient_email,env):
        import boto3
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        env_name = os.environ["ENV_NAME"].lower()

        sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(sm_client,secret_name)
        )
        sender_email = "svc_finsights@cppib.com"
        # recepient_email = "ahassan@cppib.com"

        email_subject = f"{env.upper()}: Topic Promotion for Topic: {topic_name} and Dashboard: {asset_id} Failed"
        
        email_body = f"""
                    <table width="100%" cellpadding="0" cellspacing="0" style="font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#333333;">
                        <tr>
                            <td>
                            <p>Hello,</p>

                            <p>
                                The requested topic creation has <strong style="color:#b00020;">failed</strong> because the topic name is not available.
                            </p>

                            <table cellpadding="4" cellspacing="0" style="margin:12px 0;">
                                <tr>
                                <td style="font-weight:bold;">Topic Name:</td>
                                <td>{topic_name}</td>
                                </tr>
                                <tr>
                                <td style="font-weight:bold;">Environment:</td>
                                <td>{env}</td>
                                </tr>
                            </table>

                            <p>
                                The topic name specified above is already in use or reserved and cannot be created.
                            </p>

                            <p style="margin-top:16px;">
                                Please choose a different topic name and retry the request. Ensure that the new name is unique within the selected environment.
                            </p>

                            <p>
                                Regards,<br />
                                <strong>BI Foundations Automation</strong>
                            </p>

                            <p style="font-size:12px; color:#666666; margin-top:20px;">
                                This is an automated notification. Please do not reply to this email.
                            </p>
                            </td>
                        </tr>
                    </table>
                    """

        send_email(
                smtp_user,
                smtp_password,
                smtp_host,
                smtp_port,
                sender_email,
                recepient_email,
                recepient_email,
                email_subject,
                email_body,
                True,
            )
    

    def notify_on_q_topic_promotion_success(self,topic_name,asset_id,recepient_email,env):
        import boto3
        secret_name = "smtp/svc_finsights"
        smtp_host = os.environ["SMTP_HOST"]
        smtp_port = os.environ["SMTP_PORT"]
        env_name = os.environ["ENV_NAME"].lower()

        sm_client = boto3.client("secretsmanager", region_name="us-east-1")
        smtp_user, smtp_password = get_smtp_cred_from_secret(
            get_secret_from_secret_manager(sm_client,secret_name)
        )
        sender_email = "svc_finsights@cppib.com"
        # recepient_email = "ahassan@cppib.com"

        email_subject = f"{env.upper()}: Topic Promotion for Topic: {topic_name} and Dashboard: {asset_id} Succeeded"

        email_body = f"""
            <table width="100%" cellpadding="0" cellspacing="0"
                style="font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#333333;">
                <tr>
                    <td>
                        <p>Hello,</p>

                        <p>
                            The promotion of the following topic has completed
                            <strong style="color:#2e7d32;">successfully</strong>.
                        </p>

                        <table cellpadding="4" cellspacing="0" style="margin:12px 0;">
                            <tr>
                                <td style="font-weight:bold;">Topic Name:</td>
                                <td>{topic_name}</td>
                            </tr>
                            <tr>
                                <td style="font-weight:bold;">Environment:</td>
                                <td>{env}</td>
                            </tr>
                            <tr>
                                <td style="font-weight:bold;">Dashboard ID:</td>
                                <td>{asset_id}</td>
                            </tr>
                        </table>

                        <p>
                            Regards,<br />
                            <strong>BI Foundations Automation</strong>
                        </p>

                        <p style="font-size:12px; color:#666666; margin-top:20px;">
                            This is an automated notification. Please do not reply to this email.
                        </p>
                    </td>
                </tr>
            </table>
            """
        send_email(
                smtp_user,
                smtp_password,
                smtp_host,
                smtp_port,
                sender_email,
                recepient_email,
                recepient_email,
                email_subject,
                email_body,
                True,
            )
    
    # =========================================================================
    # ================ QS Q TOPIC RELATED UTILITIES END =======================
    # =========================================================================

    def sync(self):
        print(f"Topic(s) name(s) outside : {self.topics}")
        theme_arn = self.resolve_theme_arn()

        response = self.create_or_update(self.prep_dashboard_inputs(theme_arn))
        version = int(response["VersionArn"].split("/")[-1])
        self.wait_for_status(
            {"DashboardId": self.asset_id, "VersionNumber": version},
            "Dashboard.Version.Status",
        )
        self.update_permissions()
        self.update_published_version(version)
        self.add_to_folder(self.asset_id, "DASHBOARD", self.config["workspace"])
        
        # ===========================================================
        # ======= Syncing and Promoting Quicksight Q Topics =========
        # ===========================================================

        if self.topics:
            # Finding the recipient email in order to send the topic failure email.
            # Only needed when the dashboard has Q topics; computing it unconditionally
            # KeyErrors for configs without bi_admins/product_owners and aborts the
            # asset pipeline before the downstream metadata/ALS stage runs.
            if "bi_admins" in self.config["finsights_detail"].keys():
                recepient_email = self.config["finsights_detail"]["bi_admins"][0]["email"]
            else:
                recepient_email = self.config["finsights_detail"]["product_owners"][0]["email"]

            # topic_detail ---> topic detail defined in the config
            for topic_detail in self.topics:

                # topic_detail ---> topic detail defined in the config
                ui_topic_name = topic_detail.get("name")
                topic_name = topic_detail.get("display_name", None)
                topic_name_delimited = topic_name.replace(" ","__") if topic_name is not None else None
                print(f"Topic Name Delimited : {topic_name_delimited}")
                q_topic_id_pipeline = f"{ui_topic_name}-{topic_name_delimited}-{self.asset_id}-topic"

                print(f"Topic name being deployed by pipeline : {ui_topic_name}")

                # If display name is not provided for the topic then using the topic name provided in the config for the topic creation, else using the display name for topic creation. 
                # This is because topic name has to be unique across the environment whereas display name can be same for multiple topics and does not have to be unique.
                if topic_name is None:
                    topic_name = f"{ui_topic_name}-{self.asset_id}"
                else:
                    is_topic_name_available = self.is_topic_name_available(q_topic_id_pipeline,topic_name)
                    if not is_topic_name_available:
                        print(f"Topic name : {topic_name} is not available for use. Sending out failure notification email to the BI Admin or Product Owner : {recepient_email} for Asset Id : {self.asset_id}")
                        self.notify_on_q_topic_duplicate_name_failure(topic_name,self.asset_id,recepient_email,self.config["workspace"].split("-")[-1])
                        continue

                if ui_topic_name is not None and self.block_topic_refresh == False:

                    print(f"Topic name to be copied : {ui_topic_name}")
                    env = self.config["workspace"].split("-")[-1]
                    has_pipeline_topic_failed = False

                    # Getting existing bi-author created q topic artifacts

                    # Reading the topic definition from quicksight in dev account and writing it to s3 if the topic is created by pipeline in dev account. 
                    # For other environments we are reading the topic definition from s3 since pipeline does not have access to dev account topics
                    if QS_ACCOUNT_ID == QS_DEV_ACCOUNT_ID:
                        q_topic_id = self.get_topic_id(ui_topic_name)
                        q_topic_def = self.get_topic_definition(q_topic_id)
                        self.write_topic_definition_to_s3(q_topic_def,ui_topic_name)
                    else:
                        q_topic_def = self.read_topic_definition_from_s3(ui_topic_name)

                    if q_topic_def:

                        # Create or update new topic created by the pipeline
                        topic_start_time = time.time()

                        topic_status = self.create_update_topic(q_topic_id_pipeline,topic_name,q_topic_def,self.asset_id)
                        topic_refreshing_ds,topic_refreshing_ds_ids = [],[]
                        is_failure_notification_submitted = False

                        while topic_status == "FAILED" and (time.time() - topic_start_time < Q_TOPIC_WAIT_TIMEOUT_SECS):
                            # delete topic
                            self.delete_topic(q_topic_id_pipeline,topic_name)

                            topic_ds_list = self.get_datasets_in_topic(q_topic_def)
                            topic_refreshing_ds = self.get_refreshing_ds(topic_ds_list)
                            topic_refreshing_ds_ids = [ds_arn.split("/")[-1] for ds_arn in topic_refreshing_ds]


                            while topic_refreshing_ds and (time.time() - topic_start_time < Q_TOPIC_WAIT_TIMEOUT_SECS):
                                time.sleep(30)
                                print(f"Retrying after waiting for all the pending datasets : {topic_refreshing_ds} to get refreshed - Time Elapsed : {time.time() - topic_start_time} seconds")
                                topic_refreshing_ds = self.get_refreshing_ds(topic_refreshing_ds)
                            
                            if topic_refreshing_ds:
                                # send out email with the datasets refreshing
                                print(f"Sending out an email to the BI Admin or Product Owner : {recepient_email} since wait time of {Q_TOPIC_WAIT_TIMEOUT_SECS} seconds expired for Q Topic Name : {topic_name} with Topic Id : {q_topic_id_pipeline} with Refresh Status : {topic_status} and Refreshing Datasets : {topic_refreshing_ds_ids} for Asset Id : {self.asset_id}")
                                self.notify_on_q_topic_promotion_failure(ui_topic_name,topic_refreshing_ds,self.asset_id,recepient_email,env)
                                has_pipeline_topic_failed = True
                                is_failure_notification_submitted = True
                            else:
                                print(f"Retrying topic creation for Topic : {topic_name} and Topic Id : {q_topic_id_pipeline} after all the dataset associated with topic have refreshed - Time Elapsed : {time.time() - topic_start_time} seconds")
                                #self.delete_topic(q_topic_id_pipeline,topic_name)
                                topic_status = self.create_update_topic(q_topic_id_pipeline,topic_name,q_topic_def,self.asset_id)
                
                        
                        if topic_status == "FAILED":
                            # send out email with datasets refreshing if it has not been sent before
                            if not is_failure_notification_submitted:
                                print(f"Sending out an email to the BI Admin or Product Owner : {recepient_email} since wait time of {Q_TOPIC_WAIT_TIMEOUT_SECS} seconds expired for Q Topic Name : {topic_name} with Topic Id : {q_topic_id_pipeline} with Refresh Status : {topic_status} and Refreshing Datasets : {topic_refreshing_ds_ids} for Asset Id : {self.asset_id}")
                                self.notify_on_q_topic_promotion_failure(ui_topic_name,topic_refreshing_ds,self.asset_id,recepient_email,env)
                            has_pipeline_topic_failed = True
                            is_failure_notification_submitted = False
                        else:
                            print(f"Topic Name : {topic_name} with Topic Id : {q_topic_id_pipeline} created with Refresh Status : {topic_status} for Asset Id : {self.asset_id}")

                        if not has_pipeline_topic_failed:
                            # Adding the required permissions for pipeline created topic
                            if QS_ACCOUNT_ID == QS_DEV_ACCOUNT_ID:
                                self.update_topic_permissions(QS_DEV_ACCOUNT_ID,q_topic_id_pipeline,"ahassan@cppib.com","user",q_topic_id)
                            else:
                                self.update_topic_permissions(QS_ACCOUNT_ID,q_topic_id_pipeline,"AWS_SSO_QS_AUTHOR_ALL_DEPARTMENTS","group",None)
                            
                            self.add_to_folder(q_topic_id_pipeline,"TOPIC", self.config["workspace"])
                            
                            # Adding a success email notification on successful promotion of a q topic
                            self.notify_on_q_topic_promotion_success(topic_name,self.asset_id,recepient_email,env)







class Theme(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(
            logger, "theme", qs_client, event, theme_actions, s3_client, dryrun
        )
        self.theme = self.payload["theme"]["Theme"]

    def sync(self):
        response = self.create_or_update(
            {
                "ThemeId": self.resource_id,
                "Name": self.theme["Name"],
                "BaseThemeId": self.theme["Version"]["BaseThemeId"],
                "Configuration": self.theme["Version"]["Configuration"],
            }
        )
        return response


class DataSource(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(logger, "data_source", qs_client, event, {}, s3_client, dryrun)

    def prep_inputs(self):
        return {
            "DataSourceId": self.resource_id,
            "Name": self.config["name"],
            "Type": self.config["type"].upper(),
            "DataSourceParameters": {
                "{}Parameters".format(
                    data_source_parameter_map.get(
                        self.config["type"].upper(), self.config["type"].title()
                    )
                ): dict((k.title(), v) for k, v in self.config["parameters"].items())
            },
            "Credentials": {"SecretArn": self.config["secret_arn"]},
            "VpcConnectionProperties": {"VpcConnectionArn": VPC_CONNECTION_ARN},
            "SslProperties": {"DisableSsl": self.config.get("disable_ssl", False)},
        }

    def sync(self):
        self.create_or_update(self.prep_inputs())
        self.wait_for_status({"DataSourceId": self.resource_id}, "DataSource.Status")
        self.add_to_folder(self.resource_id, "DATASOURCE", self.config["folder_id"])


class Dataset(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(logger, "data_set", qs_client, event, {}, s3_client, dryrun)
    
    def write_file_to_s3(self,s3_bucket,s3_key,s3_payload):
        try:
            self.s3_client.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=s3_payload,
                ContentType="application/json",
            )
            print(f"Successfully wrote payloads to s3://{s3_bucket}/{s3_key}")
        except Exception as e:
            print(f"Error writing to S3: {str(e)}")
            raise

    def read_file_from_s3(self,s3_bucket,s3_key,jsonl=False):
        try:
            response = self.s3_client.get_object(Bucket=s3_bucket,Key=s3_key)
            file_content = response['Body'].read().decode('utf-8')

            if jsonl:
                json_lines = []
                for json_line in file_content.splitlines():
                    if json_line.strip():
                        try:
                            json_line_obj = json.loads(json_line)
                            json_lines.append(json_line_obj)
                        except json.JSONDecodeError as e:
                            print(f"Error decoding JSON line : {json_line} with Error : {e}")
                return json_lines
            else:
                return json.loads(file_content)
            
        except ExceptionGroup as e:
            print(f"Error reading from s3 : {str(e)}")

    def has_managed_s3_manifest(self):
        if self.config.get("dataset_source", "").upper() != "S3":
            return False

        s3_manifest = self.s3_manifest or {}
        return bool(s3_manifest.get("data_uris") or s3_manifest.get("data_uri_prefixes"))

    def is_s3_dataset(self):
        return self.config.get("dataset_source", "").upper() == "S3"

    def get_s3_upload_settings(self):
        upload_settings = (self.s3_manifest or {}).get("upload_settings")
        if not isinstance(upload_settings, dict):
            raise ValueError(
                f"S3 dataset '{self.resource_id}' requires s3_manifest.upload_settings"
            )

        required_settings = [
            "format",
            "start_from_row",
            "contains_header",
            "text_qualifier",
            "delimiter",
        ]
        missing = [
            key for key in required_settings
            if key not in upload_settings
        ]
        if missing:
            missing_keys = ", ".join(
                f"s3_manifest.upload_settings.{key}" for key in missing
            )
            raise ValueError(
                f"S3 dataset '{self.resource_id}' is missing required config: "
                f"{missing_keys}"
            )

        return upload_settings

    def get_managed_s3_manifest_location(self):
        manifest_location = (self.s3_manifest or {}).get("manifest_location")
        if not isinstance(manifest_location, dict):
            raise ValueError(
                f"Managed S3 dataset '{self.resource_id}' requires "
                "s3_manifest.manifest_location.key"
            )
        if "bucket" in manifest_location:
            raise ValueError(
                f"Managed S3 dataset '{self.resource_id}' must not set "
                "s3_manifest.manifest_location.bucket; bucket is derived from "
                "FOUNDATION_BUCKET at runtime"
            )
        if not manifest_location.get("key"):
            raise ValueError(
                f"Managed S3 dataset '{self.resource_id}' requires "
                "s3_manifest.manifest_location.key"
            )

        foundation_bucket = os.environ.get("FOUNDATION_BUCKET")
        if not foundation_bucket:
            raise ValueError(
                "FOUNDATION_BUCKET environment variable must be set for managed "
                f"S3 dataset '{self.resource_id}'"
            )

        return {
            "bucket": foundation_bucket,
            "key": manifest_location["key"],
        }

    def validate_s3_dataset_config(self):
        if not self.is_s3_dataset():
            return

        self.get_s3_upload_settings()
        if self.has_managed_s3_manifest():
            self.get_managed_s3_manifest_location()
            return

        if not self.config.get("data_source_arn"):
            raise ValueError(
                f"S3 dataset '{self.resource_id}' requires either managed "
                "s3_manifest.data_uris/data_uri_prefixes with manifest_location.key, "
                "or legacy config.data_source_arn with upload-settings-only "
                "s3_manifest.yaml"
            )

    def _resolve_s3_location_entries(self, entries):
        """Resolve managed-S3 location entries (data_uris / data_uri_prefixes)
        to fully-qualified s3:// URIs.

        Each entry must be a mapping with a `key` (required) and an optional
        `bucket` (defaults to DROPBOX_BUCKET when omitted). Returns a list of
        s3:// URI strings ready to embed in the QuickSight manifest.
        """
        if not entries:
            return []
        if not isinstance(entries, list):
            raise ValueError(
                f"S3 dataset '{self.resource_id}' data_uris/data_uri_prefixes "
                "must be a list of {key, bucket?} entries"
            )

        default_bucket = os.environ.get("DROPBOX_BUCKET")
        resolved = []
        for idx, entry in enumerate(entries):
            if not isinstance(entry, dict):
                raise ValueError(
                    f"S3 dataset '{self.resource_id}' location[{idx}] must be "
                    "a mapping with required 'key' and optional 'bucket'"
                )
            key = entry.get("key")
            if not key or not isinstance(key, str):
                raise ValueError(
                    f"S3 dataset '{self.resource_id}' location[{idx}].key is "
                    "required and must be a non-empty string"
                )
            bucket = entry.get("bucket") or default_bucket
            if not bucket:
                raise ValueError(
                    f"S3 dataset '{self.resource_id}' location[{idx}] has no "
                    "bucket and DROPBOX_BUCKET is not set in the environment"
                )
            resolved.append(f"s3://{bucket}/{key}")
        return resolved

    def build_quicksight_s3_manifest(self):
        s3_manifest = self.s3_manifest or {}
        file_locations = []

        data_uris = self._resolve_s3_location_entries(
            s3_manifest.get("data_uris") or []
        )
        data_uri_prefixes = self._resolve_s3_location_entries(
            s3_manifest.get("data_uri_prefixes") or []
        )

        if data_uris:
            file_locations.append({"URIs": data_uris})
        if data_uri_prefixes:
            file_locations.append({"URIPrefixes": data_uri_prefixes})

        upload_settings = self.get_s3_upload_settings()
        global_upload_settings = {}

        if "format" in upload_settings:
            global_upload_settings["format"] = upload_settings["format"]
        if "start_from_row" in upload_settings:
            global_upload_settings["startFromRow"] = upload_settings["start_from_row"]
        if "delimiter" in upload_settings:
            global_upload_settings["delimiter"] = upload_settings["delimiter"]
        if "contains_header" in upload_settings:
            global_upload_settings["containsHeader"] = str(
                upload_settings["contains_header"]
            ).lower()
        if "text_qualifier" in upload_settings:
            text_qualifier = upload_settings["text_qualifier"]
            global_upload_settings["textqualifier"] = {
                "SINGLE_QUOTE": "'",
                "DOUBLE_QUOTE": '"',
            }.get(text_qualifier, text_qualifier)

        return {
            "fileLocations": file_locations,
            "globalUploadSettings": global_upload_settings,
        }

    def write_managed_s3_manifest(self):
        manifest_location = self.get_managed_s3_manifest_location()
        manifest_body = json.dumps(
            self.build_quicksight_s3_manifest(), sort_keys=True
        )

        print(
            "Writing QuickSight S3 manifest file to "
            f"s3://{manifest_location['bucket']}/{manifest_location['key']}"
        )
        self.write_file_to_s3(
            manifest_location["bucket"], manifest_location["key"], manifest_body
        )

    def get_managed_s3_data_source_id(self):
        data_source_id = self.config.get("data_source_id")
        if data_source_id:
            return data_source_id

        data_source_arn = self.config.get("data_source_arn")
        if data_source_arn:
            return data_source_arn.rstrip("/").split("/")[-1]

        return f"{self.resource_id}-s3-source"

    def create_or_update_managed_s3_data_source(self):
        data_source_id = self.get_managed_s3_data_source_id()
        manifest_location = self.get_managed_s3_manifest_location()
        data_source_parameters = {
            "S3Parameters": {
                "ManifestFileLocation": {
                    "Bucket": manifest_location["bucket"],
                    "Key": manifest_location["key"],
                }
            }
        }

        if self.dryrun:
            return (
                f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:"
                f"datasource/{data_source_id}"
            ), data_source_id

        try:
            existing = self.qs_client.describe_data_source(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSourceId=data_source_id,
            )
            print(f"Updating managed S3 data source with Id : {data_source_id}")
            self.qs_client.update_data_source(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSourceId=data_source_id,
                Name=data_source_id,
                DataSourceParameters=data_source_parameters,
            )
            return existing["DataSource"]["Arn"], data_source_id

        except self.qs_client.exceptions.ResourceNotFoundException:
            print(f"Creating managed S3 data source with Id : {data_source_id}")
            response = self.qs_client.create_data_source(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSourceId=data_source_id,
                Name=data_source_id,
                Type="S3",
                DataSourceParameters=data_source_parameters,
            )
            return response["Arn"], data_source_id

    def prepare_managed_s3_data_source(self):
        if not self.has_managed_s3_manifest():
            return None

        self.write_managed_s3_manifest()
        data_source_arn, data_source_id = self.create_or_update_managed_s3_data_source()
        self.config["data_source_arn"] = data_source_arn
        return data_source_id
    
    def get_ds_env(self,ds_config):
        ds_folder = ds_config["config"]["folders"][0]
        ds_env = ds_folder.split("-")[-1]
        return ds_env
    
    def get_rule_set_cols(self,rule_set_rules):
        rule_set_cols = []
        for rule_set_rule in rule_set_rules:
            for col in list(rule_set_rule.keys()):
                if col not in rule_set_cols:
                    rule_set_cols.append(col)
        return rule_set_cols

    def write_manifest_file_to_s3(self,ds_config):
        #bucket = f"bi-foundations-control-plane-{aws_account_id}-{get_ds_env(ds_config)}"
        bucket = f"cppib-df-ramcdashboard-{self.get_ds_env(ds_config)}"
        base_key = f"rls/{ds_config['config']['workspaces'][0]}/{ds_config['id']}"
        manifest_key = f"{base_key}/manifest/manifest.json"

        print(f"Writing manifest file to s3 location : {manifest_key}")

        manifest_file =  json.dumps({
            "fileLocations": [
                {
                    "URIs": [
                        f"s3://{bucket}/{base_key}/rule_set/rule_set.json"
                    ]
                }
            ],
            "globalUploadSettings": {
                "format": "JSON"
                }
            })
        self.write_file_to_s3(bucket,manifest_key,manifest_file)
    

    def write_rule_set_file_to_s3(self,rls,ds_config):
        #bucket = f"bi-foundations-control-plane-{aws_account_id}-{get_ds_env(ds_config)}"
        bucket = f"cppib-df-ramcdashboard-{self.get_ds_env(ds_config)}"
        base_key = f"rls/{ds_config['config']['workspaces'][0]}/{ds_config['id']}"
        
        rule_set_key = f"{base_key}/rule_set/rule_set.json"
        rule_set_rules = []

        if "rls_by_adgroup" in rls:

            for ad_rule in rls["rls_by_adgroup"]:
                principals = ad_rule['adgroup']
                
                for principal in principals:

                    if principal.endswith("@cppib.com"):
                        rule_set_rule = {"UserName": principal}
                    else:
                        rule_set_rule = {"GroupName" : principal}

                    for rule in ad_rule['rules']:
                        rule_set_rule[rule["column_name"]] = ",".join(rule["authorized_values"])

                    rule_set_rules.append(rule_set_rule)
        
        rule_set_rules_content = "\n".join([json.dumps(rule) for rule in rule_set_rules])

        print(f"Writing Rule Set for RLS to s3 location: {rule_set_key}")
        self.write_file_to_s3(bucket,rule_set_key,rule_set_rules_content)

        return rule_set_rules
    
    def check_if_data_source_exists(self,ds_id):
        all_data_sources = []

        try:

            response = self.qs_client.list_data_sources(AwsAccountId=QS_ACCOUNT_ID)
            all_data_sources += response['DataSources']

            while 'NextToken' in response.keys():
                response = self.qs_client.list_data_sources(AwsAccountId=QS_ACCOUNT_ID,
                                                            NextToken=response['NextToken'])
                all_data_sources += response['DataSources']
            
            ds_meta = [ds for ds in all_data_sources if ds["DataSourceId"] == ds_id]
            ds_exists =  ds_meta[0] if len(ds_meta) > 0 else None
            
            return ds_exists

        except Exception as error:
            print(f"Listing data sources failed with Error : {error}")
            return []
    
    def create_update_rule_set_ds(self,rls,ds_config):
        data_source_id = f"{ds_config['id']}-rule-set-ds"
        dataset_id = f"{ds_config['id']}-rule-set"

        #bucket = f"bi-foundations-control-plane-{aws_account_id}-{get_ds_env(ds_config)}"
        bucket = f"cppib-df-ramcdashboard-{self.get_ds_env(ds_config)}"
        base_key = f"rls/{ds_config['config']['workspaces'][0]}/{ds_config['id']}"
        
        manifest_key = f"{base_key}/manifest/manifest.json"
        rule_set_key = f"{base_key}/rule_set/rule_set.json"

        data_source_meta = self.check_if_data_source_exists(data_source_id)

        if data_source_meta:
            # update dataset
            rule_set_rules = self.write_rule_set_file_to_s3(rls,ds_config)

            self.write_manifest_file_to_s3(ds_config)

            rule_set_rules = self.read_file_from_s3(bucket,rule_set_key,True)
            print(f"RuleSet S3 File Contents : {rule_set_rules}")
            rule_set_cols = self.get_rule_set_cols(rule_set_rules)
            print(f"RuleSet S3 File Columns : {rule_set_rules}")

            ds_input_cols = [ {
                "Name" : col,
                "Type" : "STRING"
            } for col in rule_set_cols]

            print(f"Updating RuleSet Dataset with Id : {dataset_id}")
            response = self.qs_client.update_data_set(
                            AwsAccountId=QS_ACCOUNT_ID,
                            DataSetId=dataset_id,
                            Name=dataset_id,
                            PhysicalTableMap={
                                'jsonTable': {
                                    'S3Source': {
                                        'DataSourceArn': data_source_meta['Arn'],
                                        'InputColumns': ds_input_cols,
                                        'UploadSettings': {
                                            'Format': 'JSON'
                                        }
                                    }
                                }
                            },
                            ImportMode='SPICE'
                        )
            
            rule_dataset_arn = response['Arn']
            print(f"Updated RuleSet Dataset with Arn : {rule_dataset_arn} with input columns : {ds_input_cols}")
            self.add_to_folder(dataset_id, "DATASET", ds_config["config"]["folders"][0])

            return rule_dataset_arn

        else:

            # push rule set rules to s3 bucket
            rule_set_rules = self.write_rule_set_file_to_s3(rls,ds_config)

            # write manifest file for rule set rules to s3
            self.write_manifest_file_to_s3(ds_config)

            # create data source
            print(f"Creating Rule Set Data Source with Id : {data_source_id}")
            response = self.qs_client.create_data_source(
                            AwsAccountId=QS_ACCOUNT_ID,
                            DataSourceId=data_source_id,
                            Name=data_source_id,
                            Type='S3',
                            DataSourceParameters={
                                'S3Parameters': {
                                    'ManifestFileLocation': {
                                        'Bucket': bucket,
                                        'Key': manifest_key
                                    }
                                }
                            }
                        )
            data_source_arn = response['Arn']
            print(f"Created Rule Set Data Source with Arn : {data_source_arn}")
            self.add_to_folder(data_source_id, "DATASOURCE", ds_config["config"]["folders"][0])

            # create data set
            rule_set_cols = self.get_rule_set_cols(rule_set_rules)
            ds_input_cols = [ {
                "Name" : col,
                "Type" : "STRING"
            } for col in rule_set_cols]

            print(f"Creating RuleSet Dataset with Id : {dataset_id}")
            response = self.qs_client.create_data_set(
                            AwsAccountId=QS_ACCOUNT_ID,
                            DataSetId=dataset_id,
                            Name=dataset_id,
                            PhysicalTableMap={
                                'jsonTable': {
                                    'S3Source': {
                                        'DataSourceArn': data_source_arn,
                                        'InputColumns': ds_input_cols,
                                        'UploadSettings': {
                                            'Format': 'JSON'
                                        }
                                    }
                                }
                            },
                            ImportMode='SPICE'
                        )
            
            rule_dataset_arn = response['Arn']
            print(f"Created RuleSet Dataset with Arn : {rule_dataset_arn}")
            self.add_to_folder(dataset_id, "DATASET", ds_config["config"]["folders"][0])

            return rule_dataset_arn
    

    def prepare_rls_by_email_configuration_payload(self, rls_config):
        email_tag_rules, email_tag_configurations = [], []
        if "rls_by_email" not in rls_config:
            return email_tag_rules, email_tag_configurations

        unique_rules = set()
        unique_configs = set()
        for group in rls_config["rls_by_email"]:
            rule_group = []
            for rule in group.get("rules", []):
                column_name = rule.get("column_name")
                # adding the word email to distinguish between email rls and claims rls on the same columns
                tag_key = f"{self.resource_id}-{column_name}-email"

                rule_group.append(tag_key)

                if tag_key not in unique_rules:
                    unique_rules.add(tag_key)
                    email_tag_rules.append(
                        {
                            "TagKey": tag_key,
                            "ColumnName": column_name,
                            "TagMultiValueDelimiter": ",",
                            "MatchAllValue": "*",
                        }
                    )

            hashable_config = tuple(rule_group)

            if hashable_config not in unique_configs:
                unique_configs.add(tuple(rule_group))
                email_tag_configurations.append(rule_group)

        return email_tag_rules, email_tag_configurations
    
    
    def prepare_rls_ad_configuration_payload(self,ds_config,rls_config):
        rule_set_dataset_arn = self.create_update_rule_set_ds(rls_config,ds_config)
        return {
            "RowLevelPermissionDataSet": {
            "Namespace": "default",
            "Arn": rule_set_dataset_arn,
            "PermissionPolicy": "GRANT_ACCESS",
            "FormatVersion": "VERSION_1",
            "Status": "ENABLED"
                }
            }   


    def prepare_rls_configuration_payload(self, rls_config):
        tag_rules = []
        tag_configurations = []
        if "rls" not in rls_config:
            return tag_rules, tag_configurations

        section_order = ["department", "sub_department", "geo"]

        # First create the tag rules
        for section in section_order:
            if section in rls_config and "column_name" in rls_config[section]:
                tag_rules.append(
                    {
                        "TagKey": f"{self.resource_id}-{section}",
                        "ColumnName": rls_config[section]["column_name"],
                        "TagMultiValueDelimiter": ",",
                        "MatchAllValue": "*",
                    }
                )

        configuration_set = set()
        # Then create the tag configurations
        for rule in rls_config["rls"]:
            rule_config = []
            for section in section_order:
                if section in rule:
                    rule_config.append(f"{self.resource_id}-{section}")

            hashable_config = tuple(rule_config)
            # Add the configuration if we have at least one section
            if hashable_config and hashable_config not in configuration_set:
                configuration_set.add(hashable_config)
                tag_configurations.append(rule_config)

        return tag_rules, tag_configurations
    
    def prepare_cls_configuration_payload(self,cls):
        cls_payload = []
        if "cls" not in cls:
            return {
            "ColumnLevelPermissionRules" : []
            }
        
        for cls_rule in cls["cls"]:
            principals = []
            for principal in cls_rule["principals"]:
                if principal.endswith("@cppib.com"):
                    principals.append(f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:user/default/{principal}")
                else:
                    principals.append(f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:group/default/{principal}")

            cls_payload.append(
                {
                    "Principals" : principals,
                    "ColumnNames" : [cls_rule["column_name"]]
                }
            )

        return {
            "ColumnLevelPermissionRules" : cls_payload
        }

    def _build_calculated_columns(self):
        """Parse the optional `calculated_columns:` block into CreateColumnsOperation
        inputs. These are DERIVED columns (e.g. an ifelse over other columns) — they
        are NOT physical CSV/SQL columns, so they must never be emitted as S3
        InputColumns or CustomSql.Columns; doing so binds them to a non-existent
        source column and ingests as all-NULL (see central IODP `Program Name`).

        Each entry maps a column name to either a bare expression string, or a dict
        with `expression` and optional `type` (default STRING). A deterministic
        ColumnId is derived from the dataset id + column name so repeated syncs
        produce a stable definition instead of churning a fresh UUID each run.
        """
        _calc = []
        for name, _spec in (self.config.get("calculated_columns") or {}).items():
            if isinstance(_spec, dict):
                expression = _spec.get("expression", "")
                _type = _spec.get("type", "STRING")
            else:
                expression = _spec
                _type = "STRING"
            _calc.append({
                "Name": name,
                "Expression": expression,
                "Type": _type,
                "ColumnId": str(uuid.uuid5(uuid.NAMESPACE_OID, f"{self.resource_id}:{name}")),
            })
        return _calc

    def _build_columns(self):
        _columns = []
        for column, _spec in self.config["columns"].items():
            if isinstance(_spec, dict):
                _type = _spec.get("type", "")
                _format = _spec.get("format")
                _geo_role = _spec.get("geographic_role")
            else:
                _type = _spec
                _format = None
                _geo_role = None
            type_tuple = _type.split(".")
            entry = {"Name": column, "Type": type_tuple[0]}
            # Column SubType (DECIMAL.FLOAT/FIXED) is SPICE-only; QuickSight
            # rejects it on DIRECT_QUERY ("Only SPICE dataset can have sub-type").
            # DIRECT_QUERY resolves types from the live source query instead.
            if len(type_tuple) == 2 and self.config.get("import_mode") == "SPICE":
                entry["SubType"] = type_tuple[1]
            if _format:
                entry["Format"] = _format
            if _geo_role:
                entry["GeographicRole"] = _geo_role
            _columns.append(entry)
        return _columns

    def _new_prep_already_satisfied(self, existing_dataset):
        if existing_dataset.get("ImportMode") != self.config.get("import_mode"):
            return False

        def fingerprint(column):
            return (column.get("Type"), column.get("SubType"))

        desired_by_name = {
            column["Name"]: fingerprint(column)
            for column in self._build_columns()
        }
        # Calculated columns surface as OutputColumns too, so include them or the
        # existing (correct) dataset is mistaken for drifted and re-updated every run.
        for calc in self._build_calculated_columns():
            desired_by_name[calc["Name"]] = (calc["Type"], None)
        actual_by_name = {
            column["Name"]: fingerprint(column)
            for column in existing_dataset.get("OutputColumns", [])
        }
        return desired_by_name == actual_by_name

    def _create_spice_ingestion_response(self):
        if self.config.get("import_mode") != "SPICE":
            raise ValueError(
                "New-prep legacy update fallback only supports SPICE datasets. "
                f"Dataset {self.resource_id} has import_mode="
                f"{self.config.get('import_mode')}"
            )

        ingestion_id = uuid.uuid4().hex
        self.qs_client_call(
            "create_ingestion",
            {
                "DataSetId": self.resource_id,
                "IngestionId": ingestion_id,
                "IngestionType": "FULL_REFRESH",
            },
        )
        return {"IngestionId": ingestion_id}

    def prep_inputs(self):
        _columns = self._build_columns()
        _calc_columns = self._build_calculated_columns()

        def build_cast_transforms(columns):
            transforms = []
            for col in columns:
                transform = {
                    "CastColumnTypeOperation": {
                        "ColumnName": col['Name'],
                        "NewColumnType": col['Type']
                    }
                }
                if 'SubType' in col:
                    transform["CastColumnTypeOperation"]["SubType"] = col['SubType']
                if 'Format' in col:
                    transform["CastColumnTypeOperation"]["Format"] = col['Format']
                transforms.append(transform)
                if col.get('GeographicRole'):
                    transforms.append({
                        "TagColumnOperation": {
                            "ColumnName": col['Name'],
                            "Tags": [{"ColumnGeographicRole": col['GeographicRole']}],
                        }
                    })
            return transforms

        def build_calculated_column_transforms(input_columns, calc_columns):
            """CreateColumnsOperation for derived columns, followed by a
            ProjectOperation that keeps every column (physical first, then
            calculated, in declared order). The casts of the columns the
            expression references run earlier in DataTransforms, so the calc
            evaluates against typed columns."""
            if not calc_columns:
                return []
            transforms = [{
                "CreateColumnsOperation": {
                    "Columns": [
                        {
                            "ColumnName": c["Name"],
                            "ColumnId": c["ColumnId"],
                            "Expression": c["Expression"],
                        }
                        for c in calc_columns
                    ]
                }
            }]
            transforms.append({
                "ProjectOperation": {
                    "ProjectedColumns": (
                        [col["Name"] for col in input_columns]
                        + [c["Name"] for c in calc_columns]
                    )
                }
            })
            return transforms

        def create_logical_table_map(columns, physical_table_id):
            """Single-table LogicalTableMap with type-cast transforms (plus any
            calculated-column transforms)."""
            return {
                "logicaltable": {
                    "Alias": physical_table_id[:64],
                    "DataTransforms": (
                        build_cast_transforms(columns)
                        + build_calculated_column_transforms(columns, _calc_columns)
                    ),
                    "Source": {
                        "PhysicalTableId": physical_table_id[:64]
                    }
                }
            }

        def create_joined_logical_table_map(columns, physical_table_id, joins):
            """Multi-table LogicalTableMap with one entry per joined sibling
            dataset (Source.DataSetArn) plus an Intermediate-Table entry
            whose Source is a JoinInstruction chain rooted on the primary.

            joins: list of dicts shaped like
              [
                {
                  "right_dataset": "fx_rate",   # sibling dataset slug
                  "type": "LEFT",                # LEFT | INNER | RIGHT | OUTER
                  "on_clause": [{"left": "M_Z_RPT_DTE", "right": "Date Parsed"}, ...],
                },
                ...
              ]
            Key is `on_clause` (not `on`) because YAML 1.1 parses bare
            `on` as boolean true, which breaks .get("on") lookups.

            Column-name collisions: QuickSight projects join output into a
            single flat column namespace; two same-named columns from LEFT
            and RIGHT cause ALIAS_NAME_CONFLICT at CreateDataSet. The QS UI
            (and AWS re:Post canonical pattern) handles this by renaming
            colliding RIGHT columns to `col[RightDatasetName]` via a
            RenameColumnOperation on the right LT, and emitting a final
            ProjectOperation listing the kept columns. This function does
            the same: DescribeDataSet on each right_dataset to learn its
            OutputColumns + Name, rename collisions, rewrite OnClause to
            reference renamed names, and ProjectOperation on the final
            intermediate. Topo sort in dataset_publish_payload_handler
            guarantees the right side is already in central.
            """
            primary_alias = physical_table_id[:64]
            ltm = {
                primary_alias: {
                    "Alias": primary_alias,
                    "DataTransforms": build_cast_transforms(columns),
                    "Source": {"PhysicalTableId": physical_table_id[:64]},
                }
            }
            # Track the column set currently in the intermediate's projected
            # output. Start with the primary's metadata-declared columns; grow
            # per join with renamed-right columns appended.
            current_columns = [col["Name"] for col in columns]
            current_columns_set = set(current_columns)
            current_root = primary_alias

            # QS LogicalTableMap keys must match [A-Za-z0-9-]* (no underscores).
            def lt_id_sanitize(s):
                return s.replace("_", "-")

            for idx, join in enumerate(joins):
                right_slug = join["right_dataset"]
                right_arn = (
                    f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:dataset/{right_slug}"
                )
                right_lt_id = lt_id_sanitize(f"joined-{right_slug}")[:64]

                right_describe = self.qs_client.describe_data_set(
                    AwsAccountId=QS_ACCOUNT_ID,
                    DataSetId=right_slug,
                )
                right_ds = right_describe["DataSet"]
                right_name = right_ds.get("Name", right_slug)
                right_columns = [c["Name"] for c in right_ds.get("OutputColumns", [])]

                # Rename right columns that collide with the current intermediate
                # column set. Convention: `col` -> `col[RightDatasetName]`.
                right_rename_map = {}
                for col_name in right_columns:
                    if col_name in current_columns_set:
                        right_rename_map[col_name] = f"{col_name}[{right_name}]"

                right_lt_entry = {
                    "Alias": right_name[:64],
                    "Source": {"DataSetArn": right_arn},
                }
                if right_rename_map:
                    right_lt_entry["DataTransforms"] = [
                        {"RenameColumnOperation": {
                            "ColumnName": old,
                            "NewColumnName": new,
                        }}
                        for old, new in right_rename_map.items()
                    ]
                ltm[right_lt_id] = right_lt_entry

                # Rewrite OnClause to reference renamed right keys.
                on_clause = " AND ".join(
                    "{{{}}} {} {{{}}}".format(
                        c["left"],
                        c.get("op", "="),
                        right_rename_map.get(c["right"], c["right"]),
                    )
                    for c in join["on_clause"]
                )

                # Grow current_columns with right's columns (renames applied).
                for col_name in right_columns:
                    resolved = right_rename_map.get(col_name, col_name)
                    if resolved not in current_columns_set:
                        current_columns.append(resolved)
                        current_columns_set.add(resolved)

                intermediate_id = (
                    "intermediate" if len(joins) == 1 else f"intermediate-{idx}"
                )[:64]
                intermediate_entry = {
                    "Alias": (
                        "Intermediate Table"
                        if len(joins) == 1
                        else f"Intermediate Table {idx}"
                    )[:64],
                    "Source": {
                        "JoinInstruction": {
                            "LeftOperand": current_root,
                            "RightOperand": right_lt_id,
                            "Type": str(join.get("type", "LEFT")).upper(),
                            "OnClause": on_clause,
                        }
                    },
                }
                if idx == len(joins) - 1:
                    intermediate_entry["DataTransforms"] = [
                        {"ProjectOperation": {
                            "ProjectedColumns": list(current_columns),
                        }}
                    ]
                ltm[intermediate_id] = intermediate_entry
                current_root = intermediate_id
            return ltm

        joins = self.config.get("joins") or []
        if _calc_columns and joins:
            raise NotImplementedError(
                f"Dataset {self.resource_id}: calculated_columns combined with joins "
                "is not supported; the calc transforms are only applied to the "
                "single-table LogicalTableMap."
            )
        if (dataset_source := self.config.get("dataset_source", "")) and dataset_source.upper() == "S3":
            upload_settings = self.get_s3_upload_settings()
            physical_table_map = {
                self.config["physical_table_map_id"][:64]: {
                    "S3Source": {
                        "DataSourceArn": self.config["data_source_arn"],
                        'InputColumns': [{'Name': col['Name'], 'Type': 'STRING'} for col in _columns],
                        "UploadSettings": {
                            'Format': upload_settings['format'],
                            'StartFromRow': upload_settings['start_from_row'],
                            'ContainsHeader': upload_settings['contains_header'],
                            'TextQualifier': upload_settings['text_qualifier'],
                            'Delimiter': upload_settings['delimiter']
                        }
                    }
                }
            }
            if joins:
                logical_table_map = create_joined_logical_table_map(
                    _columns, self.config["physical_table_map_id"][:64], joins
                )
            else:
                logical_table_map = create_logical_table_map(
                    _columns, self.config["physical_table_map_id"][:64]
                )
            _base_kwargs = {
                "DataSetId": self.resource_id,
                "Name": self.config["name"],
                "PhysicalTableMap": physical_table_map,
                "ImportMode": self.config["import_mode"],
                "LogicalTableMap": logical_table_map
            }
        else:
            if _calc_columns:
                raise NotImplementedError(
                    f"Dataset {self.resource_id}: calculated_columns is only supported "
                    "for S3 (dataset_source: S3) datasets; derive columns in the SQL "
                    "for CustomSql/Athena datasets instead."
                )
            # CustomSql.Columns only accepts Name/Id/Type/SubType — Format and
            # GeographicRole (and any other transform-only fields) must not leak
            # in here, even though they live on the same column metadata entries.
            custom_sql_column_keys = {"Name", "Id", "Type", "SubType"}
            physical_table_map = {
                self.config["physical_table_map_id"][:64]: {
                    "CustomSql": {
                        "DataSourceArn": self.config["data_source_arn"],
                        "Name": self.config["name"],
                        "SqlQuery": self.config["sql_query"],
                        "Columns": [
                            {k: v for k, v in col.items() if k in custom_sql_column_keys}
                            for col in _columns
                        ],
                    }
                }
            }
            _base_kwargs = {
                "DataSetId": self.resource_id,
                "Name": self.config["name"],
                "PhysicalTableMap": physical_table_map,
                "ImportMode": self.config["import_mode"],
            }
            if joins:
                _base_kwargs["LogicalTableMap"] = create_joined_logical_table_map(
                    _columns, self.config["physical_table_map_id"][:64], joins
                )
            elif any(col.get("GeographicRole") for col in _columns):
                # CustomSql without joins normally has no LogicalTableMap, but
                # TagColumnOperations need to live there. Build a minimal LTM with
                # only the geographic-role tags — keep CustomSql.Columns as the
                # source of type info so we don't double up on CastColumnType.
                alias = self.config["physical_table_map_id"][:64]
                _base_kwargs["LogicalTableMap"] = {
                    alias: {
                        "Alias": alias,
                        "Source": {"PhysicalTableId": alias},
                        "DataTransforms": [
                            {
                                "TagColumnOperation": {
                                    "ColumnName": col["Name"],
                                    "Tags": [{"ColumnGeographicRole": col["GeographicRole"]}],
                                }
                            }
                            for col in _columns
                            if col.get("GeographicRole")
                        ],
                    }
                }

        if len(self.event["payload"]["rls"]) == 0 and len(self.event["payload"]["cls"]) == 0:
            return _base_kwargs
        else:
            if len(self.event["payload"]["rls"]) != 0:
                rls = self.event["payload"]["rls"]

                if "rls_by_adgroup" in rls:
                    rls_config = self.prepare_rls_ad_configuration_payload(self.event["payload"],rls)
                    _base_kwargs = _base_kwargs | rls_config

                else:
                    claims_tag_rules, claims_tag_configurations = (
                        self.prepare_rls_configuration_payload(rls)
                    )
                    email_tag_rules, email_tag_configurations = (
                        self.prepare_rls_by_email_configuration_payload(
                            rls
                        )
                    )
                    rls_config = {
                        "RowLevelPermissionTagConfiguration": {
                            "TagRules": claims_tag_rules + email_tag_rules,
                            "Status": "ENABLED",
                            "TagRuleConfigurations": claims_tag_configurations
                            + email_tag_configurations,
                        }
                    }
                    return _base_kwargs | rls_config
                
            if len(self.event["payload"]["cls"]) != 0:
                cls_config =  self.prepare_cls_configuration_payload(self.event["payload"]["cls"])
                _base_kwargs = _base_kwargs | cls_config
            
            return _base_kwargs
        
    
    def get_dataset_owners(self,dataset_id):
        try:
            print(f"Finding dataset owners for dataset with dataset id : {dataset_id}")
            response = self.qs_client.describe_data_set_permissions(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSetId=dataset_id
            )

            owner_actions = ['quicksight:DeleteDataSet',
                                'quicksight:ListIngestions',
                                'quicksight:UpdateDataSetPermissions',
                                'quicksight:CancelIngestion',
                                'quicksight:UpdateDataSet',
                                'quicksight:PassDataSet',
                                'quicksight:DescribeDataSetPermissions',
                                'quicksight:DescribeDataSet',
                                'quicksight:CreateIngestion',
                                'quicksight:DescribeIngestion']

            ds_permissions = response["Permissions"]
            ds_owners = [ds_permission["Principal"].split("/")[-1] 
                        for ds_permission in ds_permissions if sorted(ds_permission["Actions"]) == sorted(owner_actions) ]
            
            print(f"dataset with dataset id : {dataset_id} has the owners : {ds_owners}")

            return ds_owners
        
        except Exception as error:
            print(f"Finding dataset owners for dataset with dataset id : {dataset_id} failed with error : {error}")


    
    def update_dataset_permissions_from_refresh_notification_config(self, dataset_id, refresh_notification_principals):
        """
        Update QuickSight dataset permissions using the provided list of users/groups.
        Treats entries ending with '@cppib.com' as QuickSight users; others as groups.
        """
        try:
            
            principals = ["AWS_SSO_QS_AUTHOR_ALL_DEPARTMENTS"] + refresh_notification_principals

            ds_owner_grants = []

            owner_actions = ['quicksight:DeleteDataSet',
                              'quicksight:ListIngestions',
                              'quicksight:UpdateDataSetPermissions',
                              'quicksight:CancelIngestion',
                              'quicksight:UpdateDataSet',
                              'quicksight:PassDataSet',
                              'quicksight:DescribeDataSetPermissions',
                              'quicksight:DescribeDataSet',
                              'quicksight:CreateIngestion',
                              'quicksight:DescribeIngestion']

            for principal in principals:
                if principal.endswith("@cppib.com"):
                    principal_arn = (
                        f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:user/default/{principal}"
                    )
                else:
                    principal_arn = (
                        f"arn:aws:quicksight:us-east-1:{QS_ACCOUNT_ID}:group/default/{principal}"
                    )
                ds_owner_grants.append({"Principal": principal_arn, "Actions": owner_actions})

            response = self.qs_client.update_data_set_permissions(
                AwsAccountId=QS_ACCOUNT_ID,
                DataSetId=dataset_id,
                GrantPermissions=ds_owner_grants
            )
            print(f"Successfully updated permissions for dataset '{dataset_id}'.")
            print(f"Permission update response: {response}")
            return response

        except Exception as error:
            print(f"updated permissions for dataset '{dataset_id}' failed with error : {error}")
    


    def enable_email_notification_on_dataset_failure(self,dataset_id):

        import copy

        drop_vals = ["RequestId","ResponseMetadata","Status"]

        try:
            print(f"Reading the existing dataset refresh properties for dataset with dataset id : {dataset_id}")
            existing_ds_refresh_properties = self.qs_client.describe_data_set_refresh_properties(
                                                                AwsAccountId=QS_ACCOUNT_ID,
                                                                DataSetId=dataset_id
                                                                )
            print(f"Existing dataset refresh properties : {existing_ds_refresh_properties}")
            
            print(f"Enabling dataset refresh failure notifications for dataset with dataset id : {dataset_id}")

            for drop_val in drop_vals:
                del existing_ds_refresh_properties[drop_val]
            
            new_ds_refresh_properties = copy.deepcopy(existing_ds_refresh_properties)
            new_ds_refresh_properties["AwsAccountId"] = QS_ACCOUNT_ID
            new_ds_refresh_properties["DataSetId"] = dataset_id

            ds_owners = self.get_dataset_owners(dataset_id)

            if ds_owners == ["AWS_SSO_QS_AUTHOR_ALL_DEPARTMENTS"]:
                email_config = {"FailureConfiguration": {"EmailAlert": {"AlertStatus": "DISABLED"}}}
            else:
                email_config = {"FailureConfiguration": {"EmailAlert": {"AlertStatus": "ENABLED"}}}

            new_ds_refresh_properties["DataSetRefreshProperties"] = email_config

            response = self.qs_client.put_data_set_refresh_properties(**new_ds_refresh_properties)

            print(f"Enabling dataset refresh failure notifications for dataset with dataset id : {dataset_id} resulted in response : {response}")
        
        except Exception as error:
            print(f"Enabling dataset refresh failure notifications for dataset with dataset id : {dataset_id} failed with error : {error}")
    


    def sync(self):
        if self.event["resource"] == "dataset":
            dataset_id = self.payload["id"]
            if not self.config.get("block_refresh",False):
                self.validate_s3_dataset_config()
                managed_s3_data_source_id = self.prepare_managed_s3_data_source()
                try:
                    response = self.create_or_update(self.prep_inputs())
                except self.qs_client.exceptions.InvalidParameterValueException:
                    existing_dataset = self.qs_client_call(
                        "describe_data_set",
                        {"DataSetId": self.resource_id},
                    )["DataSet"]

                    if "DataPrepConfiguration" not in existing_dataset:
                        raise

                    if not self._new_prep_already_satisfied(existing_dataset):
                        self.logger.error(
                            "Dataset %s is in new-prep mode but OutputColumns "
                            "do not match desired config; cannot apply legacy "
                            "UpdateDataSet payload.",
                            self.resource_id,
                        )
                        raise

                    self.logger.warning(
                        "Dataset %s is in new-prep mode and OutputColumns "
                        "already match desired config; skipping legacy "
                        "UpdateDataSet payload and kicking SPICE ingestion. "
                        "Long-term fix: teach prep_inputs() to emit "
                        "DataPrepConfiguration.",
                        self.resource_id,
                    )
                    response = self._create_spice_ingestion_response()

                ##############################################################
                ######## dataset refresh failure notification logic ##########
                ##############################################################
                refresh_notification_principals = self.config.get("refresh_notifications",[])
                #self.update_dataset_permissions_from_refresh_notification_config(dataset_id, refresh_notification_principals)
                #self.enable_email_notification_on_dataset_failure(dataset_id)

                # DIRECT_QUERY create/update returns no IngestionId (no SPICE
                # ingestion is kicked); only SPICE responses carry one.
                ingestion_id = response.get("IngestionId")
                if ingestion_id:
                    self.logger.info(
                        "Dataset operation succeeded, setting folder membership.  An ingestion is in progress: {}".format(
                            ingestion_id
                        )
                    )
                else:
                    self.logger.info(
                        "Dataset operation succeeded (no SPICE ingestion - DIRECT_QUERY), setting folder membership."
                    )
                responses = self.add_to_folders()

                if managed_s3_data_source_id:
                    for folder_id in self.config["folders"]:
                        responses.append(
                            self.add_to_folder(
                                managed_s3_data_source_id, "DATASOURCE", folder_id
                            )
                        )

                return responses
            else:
                print(f"Dataset Refresh/Creation/Update blocked for Dataset Id: {dataset_id} since block_refresh is set to True in metadata.yaml")

    def add_to_folders(self):
        responses = []
        for folder_id in self.config["folders"]:
            response = self.qs_client_call(
                "create_folder_membership",
                {
                    "FolderId": folder_id,
                    "MemberId": self.resource_id,
                    "MemberType": "DATASET",
                },
            )
            responses.append(response)
        return responses


class Ingestion(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(logger, "ingestion", qs_client, event, {}, s3_client, dryrun)

    def create_ingestion(self):
        ingest_type = self.config["ingestion_type"]
        ingest_id = uuid.uuid4().hex
        self.logger.info(
            "Creating ingestion {} for: {}".format(ingest_id, self.resource_id)
        )
        response = self.qs_client_call(
            "create_ingestion",
            {
                "DataSetId": self.resource_id,
                "IngestionId": ingest_id,
                "IngestionType": ingest_type,
            },
        )
        self.logger.info(response)
        return response

    def sync(self):
        ingestion = self.create_ingestion()
        self.wait_for_status(
            {"DataSetId": self.resource_id, "IngestionId": ingestion["IngestionId"]},
            "Ingestion.IngestionStatus",
        )


class RefreshSchedule(QuickSightResource):
    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(
            logger, "refresh_schedule", qs_client, event, {}, s3_client, dryrun
        )
    
    """
    Example:
    {
        "resource": "refresh_schedule",
        "payload": {
            "force_sync": "true",
            "id": "cost_insights_report",
            "account_id": "200967598245",
            "config": {
                "ScheduleId": "monthly_refresh",
                "RefreshType": "FULL_REFRESH",
                "ScheduleFrequency": {
                    "Interval": "MONTHLY",
                    "RefreshOnDay": {
                        "DayOfMonth": "3"
                    },
                    "Timezone": "Canada/Eastern",
                    "TimeOfTheDay": "00:00"
                }
            }
        }
    }
    """

    def prep_inputs(self):
        if self.event["resource"] == "refresh_schedule":
            inputs = []
            refresh_schedules = self.config.get("schedules", [])

            if isinstance(refresh_schedules, list):
                for schedule in refresh_schedules:
                    inputs.append({
                        "DataSetId" : self.resource_id,
                        "AwsAccountId" : self.payload["account_id"],
                        "Schedule" : schedule
                        })
            else:
                inputs.append({
                    "DataSetId" : self.resource_id,
                    "AwsAccountId" : self.payload["account_id"],
                    "Schedule" : self.config.get("schedules", {})
                })

            return inputs
        
    def sync(self):
        rs_inputs = self.prep_inputs()
        declared_ids = {rs_input["Schedule"]["ScheduleId"] for rs_input in rs_inputs}

        # Prune BEFORE creating: QuickSight enforces schedule limits at
        # CreateRefreshSchedule time (an HOURLY/MINUTE15/MINUTE30 schedule must
        # be the dataset's only schedule), so a stale publisher schedule still
        # in place would make the create fail with LimitExceededException.
        manual_ids = self._prune_stale_schedules(declared_ids)

        for rs_input in rs_inputs:
            schedule_id = rs_input["Schedule"]["ScheduleId"]
            try:
                schedule_response = self.create_or_update(rs_input)
            except self.qs_client.exceptions.LimitExceededException as error:
                if manual_ids:
                    # Manually created console schedules survive pruning by
                    # design, and QuickSight's sole-schedule rule can then
                    # reject the declared schedule. The operator override
                    # wins; don't fail the dataset pipeline over it.
                    self.logger.warning(
                        f"Skipping declared refresh schedule {schedule_id} on "
                        f"{self.resource_id}: QuickSight schedule limits conflict "
                        f"with manually created schedule(s) {manual_ids}; manual "
                        f"override wins. Error: {error}"
                    )
                    continue
                raise
            http_response_status = str(schedule_response["Status"])
            logger_stmt = f"Refresh schedule creation for Dataset : {self.resource_id} with Schedule Id : {schedule_id}"
            if http_response_status.startswith("2"):
                self.logger.info(
                    f"{logger_stmt} got SUCCESSFULLY created"
                )
            else:
                self.logger.info(
                    f"{logger_stmt} FAILED with error code : {http_response_status}"
                )
                raise

    # Console-created schedules get auto-generated UUID ScheduleIds;
    # publisher-declared ones use readable slugs from metadata.
    _MANUAL_SCHEDULE_ID_RE = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        re.IGNORECASE,
    )

    def _prune_stale_schedules(self, declared_ids):
        """Delete remote refresh schedules no longer declared in metadata.

        The publisher upserts the declared schedules but, without this, a
        schedule that was renamed or removed in metadata (e.g. an old daily
        FULL replaced by daily-incremental + weekly-full) lingers in QuickSight
        and keeps firing — defeating the incremental refresh. Reconcile by
        deleting any remote ScheduleId not in the declared set.

        Schedules added by hand in the QuickSight console carry auto-generated
        UUID ScheduleIds; those are operator overrides, not publisher state, so
        they are never pruned. Only metadata-style (readable) ids the publisher
        once created are reconciled away.

        Returns the list of kept manual (console-created) ScheduleIds so the
        caller can attribute a subsequent CreateRefreshSchedule limit conflict
        to them.
        """
        manual_ids = []
        try:
            existing = self.qs_client_call(
                "list_refresh_schedules", {"DataSetId": self.resource_id}
            ).get("RefreshSchedules", [])
        except self.qs_client.exceptions.ResourceNotFoundException:
            return manual_ids
        for schedule in existing:
            schedule_id = schedule.get("ScheduleId")
            if not schedule_id or schedule_id in declared_ids:
                continue
            if self._MANUAL_SCHEDULE_ID_RE.match(schedule_id):
                manual_ids.append(schedule_id)
                self.logger.info(
                    f"Keeping manually created refresh schedule {schedule_id} on "
                    f"{self.resource_id} (console-added, not publisher-managed)"
                )
                continue
            self.logger.info(
                f"Pruning stale refresh schedule {schedule_id} on "
                f"{self.resource_id} (not present in metadata)"
            )
            self.qs_client_call(
                "delete_refresh_schedule",
                {"DataSetId": self.resource_id, "ScheduleId": schedule_id},
            )
        return manual_ids


class DatasetRefreshProperties(QuickSightResource):
    """Sets the SPICE incremental-refresh LookbackWindow on a dataset.

    Uses describe-overlay-put: read the existing refresh properties, preserve
    their FailureConfiguration (refresh-failure email alerts), overlay the
    incremental RefreshConfiguration, then put the merged object back. This is
    robust whether or not put_data_set_refresh_properties merges, and never
    clobbers an existing email-alert configuration.

    Example payload:
    {
        "resource": "dataset_refresh_properties",
        "payload": {
            "id": "rmv_analytics",
            "account_id": "200967598245",
            "config": {
                "incremental_refresh": {
                    "column_name": "business_date_dt",
                    "size": 14,
                    "size_unit": "DAY"
                }
            }
        }
    }
    """

    def __init__(self, logger, qs_client, event, s3_client=None, dryrun=False):
        super().__init__(
            logger, "dataset_refresh_properties", qs_client, event, {}, s3_client, dryrun
        )

    def _lookback_window(self):
        cfg = self.config["incremental_refresh"]
        return {
            "ColumnName": cfg["column_name"],
            "Size": cfg["size"],
            "SizeUnit": cfg["size_unit"],
        }

    def sync(self):
        try:
            existing = self.qs_client_call(
                "describe_data_set_refresh_properties",
                {"DataSetId": self.resource_id},
            ).get("DataSetRefreshProperties", {})
        except self.qs_client.exceptions.ResourceNotFoundException:
            existing = {}

        merged = dict(existing)
        merged["RefreshConfiguration"] = {
            "IncrementalRefresh": {"LookbackWindow": self._lookback_window()}
        }

        # The dataset's own UpdateDataSet (edit) and configuring incremental
        # refresh can leave an in-flight refresh, so the put may hit
        # ConflictException. Retry with exponential backoff so the config lands.
        max_attempts = 5
        for attempt in range(max_attempts):
            try:
                self.qs_client_call(
                    "put_data_set_refresh_properties",
                    {"DataSetId": self.resource_id, "DataSetRefreshProperties": merged},
                )
                return
            except self.qs_client.exceptions.ConflictException:
                if attempt == max_attempts - 1:
                    raise
                self.logger.warning(
                    f"put_data_set_refresh_properties conflict for {self.resource_id}, "
                    f"retry {attempt + 1}/{max_attempts - 1}"
                )
                time.sleep(2 ** attempt)
