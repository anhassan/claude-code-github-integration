import os
import time
import json

from .cfg import get_from_path
from jsonschema import validate

ACCOUNT_ID = os.environ["ACCOUNT_ID"]
DEFAULT_ADMIN_GROUP = os.environ["DEFAULT_ADMIN_GROUP"]
ARTIFACTS_BUCKET = os.environ["ARTIFACTS_BUCKET"]
DROPBOX_BUCKET = os.environ["DROPBOX_BUCKET"]

# these role group assignments are never removed
PROTECTED_GROUPS = ["AWS Operations", DEFAULT_ADMIN_GROUP]

group_arn_format = "arn:aws:quicksight:us-east-1:{}:group/default/{}"
user_arn_format = "arn:aws:quicksight:us-east-1:{}:user/default/{}"
folder_arn_format = "arn:aws:quicksight:us-east-1:{}:folder/{}"

VALID_RESOURCES = [
    "folder",
    "data_source",
    "data_set",
    "dashboard",
    "theme",
    "analysis",
    "ingestion",
    "refresh_schedule",
    "dataset_refresh_properties",
]

NAMESPACED_RESOURCES = [
    "folder",
    "group"
]

EVENT_SCHEMA = {
    "type": "object",
    "properties": {
        "resource": {"type": "string"},
        "payload": {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "config": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "owners": {"type": "array"},
                        "viewers": {"type": "array"},
                        "contributors": {"type": "array"}
                    }
                }
            },
            "required": ["id", "config"]
        }
    },
    "required": ["resource", "payload"]
}

EVENT_TEMPLATE = {
    "resource": str, # the resource type to act on
    "payload": {
        "dev_account_id": str, # used when replacing arns
        "account_id": str, # current account id
        "s3_definition_key": str, # key for fetching definition files
        "definition": {}, # resource-dependant config, fetched from s3
        "config": {}, # custom-config used to drive actions
        "id": str, # id to use when creating/updating a resource
        "version": str # version of the asset to use
    }
}

def snake_to_camel(snake_case_string):
        return snake_case_string.replace("_", " ").title().replace(" ", "")


class InvalidResourceTypeException(Exception):
    pass


class QuickSightResource(object):
    """
    Base resource manager
    actions is a dictionary of the form:
    {
        owners: [owner_iam_actions],
        viewers: [viewer_iam_actions],
        contributors: [contributor_iam_actions]
    }
    If a resource does not have contributor actions, provide an empty list as 
    contributor_iam_actions: e.g. { contributors: [] }

    Subclasses should provide a sync() method which carries out operations 
    to bring a resource in sync with config input.  This method is called on
    the resource by the handler and _must_ be idempotent.

    Generally a prep_inputs() method is used to marshall kwargs from config
    inputs but this is optional

    Currently only dashboards and datasets are "versioned" by QuickSight,
    however, there is no API for restoring or retrieving a  previous data set version 
    """
    def __init__(self, logger, resource, qs_client, event, actions, s3_client=None, dryrun=False):
        validate(event, EVENT_SCHEMA)
        self.resource = resource
        if resource not in VALID_RESOURCES:
            raise InvalidResourceTypeException("{} is not a valid resource type".format(resource))
        self.logger = logger
        self.qs_client = qs_client
        self.event = event
        self.actions = actions
        self.account_id = ACCOUNT_ID
        self.s3_client = s3_client
        self.dryrun = dryrun

    def fetch_s3_json(self, key, bucket=ARTIFACTS_BUCKET):
        self.logger.info("Fetching s3://{}/{}".format(bucket, key))
        response = self.s3_client.get_object(
            Bucket=bucket,
            Key=key
        )
        return json.loads(response['Body'].read().decode('utf-8'))

    def upload_to_dropbox(self, fpath, key, bucket=DROPBOX_BUCKET):
        self.logger.info("Uploading {} to s3://{}/{}".format(fpath, bucket, key))
        response = self.s3_client.upload_file(fpath, bucket, key)
        return response

    def load_definition(self):
        if self.payload.get("s3_definition_key") != None:
            self.payload["definition"] = self.fetch_s3_json(self.payload["s3_definition_key"])

    def add_to_folder(self, member_id, member_type, folder_id):
        return self.qs_client_call(
            "create_folder_membership",
            {
                "FolderId": folder_id,
                "MemberId": member_id,
                "MemberType": member_type.upper()
            }
        )

    # @property
    # def resource(self):
    #     return self.event["resource"]

    @property
    def payload(self):
        return self.event["payload"]

    @property
    def resource_id(self):
        return self.event["payload"]["id"]

    @property
    def config(self):
        return self.event["payload"]["config"]

    @property
    def s3_manifest (self):
        return self.event["payload"].get("s3_manifest", {})

    @property
    def resource_id_kwarg(self):
        return { snake_to_camel("{}_id".format(self.resource)): getattr(self, "asset_id", "resource_id") }

    def make_permission(self, principal, role):
        principal_fmt = user_arn_format if "@" in principal else group_arn_format
        return {
            "Principal": principal_fmt.format(ACCOUNT_ID, principal),
            "Actions": self.actions[role]
        }

    def make_permission_list(self, role_group_map):
        """
        role_group_map is of the form:
        role : [principals]
        """
        return [
            self.make_permission(principal, role)
            for role, principals in role_group_map.items() if principals is not None
            for principal in principals
        ]

    @staticmethod
    def get_list_changes(old, new):
        if new is None:
            new = []
        if old is None:
            old = []
        new_set = set(new)
        old_set = set(old)
        unchanged = new_set & old_set
        return new_set - unchanged, old_set - unchanged, unchanged

    def qs_client_call(self, method, kwargs):
        kwargs["AwsAccountId"] = ACCOUNT_ID
        self.logger.info("Calling {}".format(method))
        self.logger.info("Args: {}".format(kwargs))
        _action = getattr(self.qs_client, method)
        if self.dryrun:
            self.logger.info("DRYRUN enabled -- no response")
            return {"DRYRUN": self.dryrun}
        response = _action(**kwargs)
        self.logger.info(response)
        return response

    def create_or_update(self, kwargs):
        try:
            response = self.qs_client_call("create_{}".format(self.resource), kwargs)
            self.logger.info(response)
            return response
        except self.qs_client.exceptions.ResourceExistsException:
            self.logger.info("Resource {} already exists, attempting update...")
            return self.qs_client_call("update_{}".format(self.resource), kwargs)

    def get_current_permissions(self):
        kwargs = self.resource_id_kwarg
        if self.resource in NAMESPACED_RESOURCES:
            kwargs["Namespace"] = "default"
        response = self.qs_client_call("describe_{}_permissions".format(self.resource), kwargs)
        owners = [
            p["Principal"].split("/")[-1] for p in response["Permissions"] if set(p["Actions"]) == set(self.actions["owners"])
        ]
        viewers = [
            p["Principal"].split("/")[-1] for p in response["Permissions"] if set(p["Actions"]) == set(self.actions["viewers"])
        ]
        contributors = [
            p["Principal"].split("/")[-1] for p in response["Permissions"] if set(p["Actions"]) == set(self.actions["contributors"])
        ]
        return owners, viewers, contributors

    def update_permissions(self):
        new_owners = self.config.get("owners", [])
        new_viewers = self.config.get("viewers", [])
        new_contributors = self.config.get("contributors", [])
        current_owners, current_viewers, current_contributors = self.get_current_permissions()
        self.logger.info("Current owners: {}".format(current_owners))
        self.logger.info("Current viewers: {}".format(current_viewers))
        self.logger.info("Current contributors: {}".format(current_contributors))
        self.logger.info("New owners: {}".format(new_owners))
        self.logger.info("New viewers: {}".format(new_viewers))
        self.logger.info("New contributors: {}".format(new_contributors))
        owners_added, owners_deleted, _ = self.get_list_changes(current_owners, new_owners)
        viewers_added, viewers_deleted, _ = self.get_list_changes(current_viewers, new_viewers)
        contributors_added, contributors_deleted, _ = self.get_list_changes(current_contributors, new_contributors)
        added_members = {"owners": owners_added, "viewers": viewers_added, "contributors": contributors_added}
        deleted_members = {"owners": owners_deleted, "viewers": viewers_deleted, "contributors": contributors_deleted}
        grants = self.make_permission_list(added_members)
        revokes = self.make_permission_list(deleted_members)
        self.logger.info("Updating Permissions...")
        self.logger.info("Grants: {}".format(grants))
        self.logger.info("Revokes: {}".format(revokes))
        if len(grants) == 0 and len(revokes) == 0:
            self.logger.info("Nothing to do, skipping permission update")
            return
        revoke_response = None
        grant_response = None
        if len(revokes) != 0:
            self.logger.info("Performing revokes")
            kwargs = { "RevokePermissions": revokes }
            kwargs.update(self.resource_id_kwarg)
            revoke_response = self.qs_client_call(
                "update_{}_permissions".format(self.resource),
                kwargs
            )
            self.logger.info(revoke_response)
        if len(grants) != 0:
            self.logger.info("Performing grants")
            kwargs = { "GrantPermissions": grants }
            kwargs.update(self.resource_id_kwarg)
            grant_response = self.qs_client_call(
                "update_{}_permissions".format(self.resource),
                kwargs
            )
            self.logger.info(grant_response)
        return revoke_response, grant_response

    def wait_for_status(self, kwargs, path=None):
        times = [5, 10, 15, 20]
        self.logger.info("Waiting for status on: {}".format(self.resource_id))
        if path is None:
            path = "{}.Version.Status".format(self.resource.title()).split(".")
        for _time in times:
            response = self.qs_client_call("describe_{}".format(self.resource), kwargs)
            status = get_from_path(response, path.split("."))
            if "FAILED" in status:
                self.logger.error("Operation failed: {}".format(response))
                raise
            if "SUCCESSFUL" in status:
                self.logger.info("Operation succeeded: {}".format(response))
                return
            self.logger.info("Status is: {}, waiting {} seconds".format(status, _time))
            time.sleep(_time)
        self.logger.info("Completed retries, status is still open: {}".format(response))


class RoleGroup(QuickSightResource):
    def __init__(self, logger, qs_client, event):
        super().__init__(logger, 'rolegroup', qs_client, event, {})

    def list_role_members(self, role):
        self.logger.info("Getting {} groups")
        response = self.qs_client_call(
            "list_role_memberships",
            {"Role": role.upper(), "Namespace": "default"}
        )
        self.logger.info(response)
        return response["MembersList"]

    def sync(self):
        self.update()

    def update(self, resolved_role_groups):
        """
        resolved_role_groups is a dict of the form:
        {
            "Reader": [],
            "Author": [],
            "Admin": []
        }

        It is resolved by analyzing across all project owners/contributors,
        dashboard viewers, and admins
        """
        added = {}
        deleted = {}
        added_responses = []
        deleted_responses = []
        current_roles = {
            "Reader": self.list_role_members("READER"),
            "Author": self.list_role_members("AUTHOR"),
            "Admin": self.list_role_members("ADMIN")
        }
        self.logger.info("Current role groups: {}".format(current_roles))
        for k in ["Reader", "Author", "Admin"]:
            new_members = resolved_role_groups.get(k, [])
            current_members = current_roles[k]
            self.logger.info("New {}s: {}".format(k, new_members))
            self.logger.info("Current {}s: {}".format(k, current_members))
            _added, _deleted, _ = QuickSightResource.get_list_changes(current_members, new_members)
            added[k.upper()] = list(_added)
            deleted[k.upper()] = list(_deleted)
        self.logger.info("Adding: {}".format(added))
        self.logger.info("Deleting: {}".format(deleted))
        for role, members in added.items():
            for member in members:
                response = self.qs_client_call(
                    "create_role_membership",
                    {
                        "MemberName": member,
                        "Namespace": "default",
                        "Role": role
                    }
                )
                added_responses.append(response)
        for role, members in deleted.items():
            for member in members:
                if member in PROTECTED_GROUPS:
                    print("Not removing protected group: {}".format(member))
                    continue
                response = self.qs_client_call(
                    "delete_role_membership",
                    {
                        "MemberName": member,
                        "Namespace": "default",
                        "Role": role
                    }
                )
                deleted_responses.append(response)
        self.logger.info("Added: {}".format(added_responses))
        self.logger.info("Deleted: {}".format(deleted_responses))
        return
