import boto3
import os
import quicksight_mgr.qs_asset_manager
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

output_bucket = os.environ["BUCKET_NAME"]
aws_environment = os.environ["AWS_ENVIRONMENT"]
s3_client = boto3.client('s3')
dynamodb_client = boto3.client('dynamodb')

def lambda_handler(event, context):
    s3_key = event["s3_key"]
    bucket = event["bucket"]

    # 1: extract parquet file location from SQS record
    s3_asset_directory = s3_key.rsplit('/', 1)[0] + "/"  # get directory of asset file
    s3_metadata_directory = s3_asset_directory + "metadata/"
    final_export_metadata_key = s3_metadata_directory + "asset_business_metadata.json"
    final_metadata_payload = {}
    os_upsert_asset_list = []

    csv_files = quicksight_mgr.qs_asset_manager.get_matching_csv_files(bucket, s3_metadata_directory, s3_client)
    if len(csv_files) < 5:
        logger.info("missing required metadata files..sending only operaitonal metadata to S3")
        operational_metadata = quicksight_mgr.qs_asset_manager.read_json_from_s3(bucket, s3_key, s3_client)
        config_key = s3_asset_directory + "config.yaml"
        logger.info(config_key)
        config_yaml_data = quicksight_mgr.qs_asset_manager.YamlProcessingManager(bucket, config_key, s3_client)
        insert_payload = config_yaml_data.prepare_config_metadata(s3_key, aws_environment)
        final_metadata_payload = config_yaml_data.insert_config_payload(insert_payload, operational_metadata)
        asset_id = final_metadata_payload["asset_id"]
        os_upsert_asset_list.append(asset_id)
        quicksight_mgr.qs_asset_manager.write_dict_to_s3_json(final_metadata_payload, output_bucket,
                                                              final_export_metadata_key)
        return {
            'statusCode': 200,
            'body': f'Business Metadata update was not performed on asset {asset_id}',
            'asset_metadata_key': final_export_metadata_key,
            'bucket': bucket
        }
    else:
        # 2. process csv sheet metadata data
        response = quicksight_mgr.qs_asset_manager.CSVProcessingManager(bucket, csv_files["sheet"], ',', s3_client)
        formatted_payload = response.prepare_sheet_metadata()
        final_metadata_payload = response.insert_sheets_metadata_payload(formatted_payload,
                                                                         final_metadata_payload)
        # 3. insert csv overview metadata data
        response = quicksight_mgr.qs_asset_manager.CSVProcessingManager(bucket, csv_files["overview"], ',', s3_client)
        formatted_payload = response.prepare_overview_metadata()
        final_metadata_payload = response.insert_overview_metadata_payload(formatted_payload, final_metadata_payload)

        # 4.  insert csv dataset metadata data
        response = quicksight_mgr.qs_asset_manager.CSVProcessingManager(bucket, csv_files["dataset"], ',', s3_client)
        formatted_payload = response.prepare_dataset_metadata()
        final_metadata_payload = response.insert_datasets_metadata_payload(formatted_payload, final_metadata_payload)

        # 5. insert csv parameter metadata data
        response = quicksight_mgr.qs_asset_manager.CSVProcessingManager(bucket, csv_files["parameter"], ',', s3_client)
        formatted_payload = response.prepare_parameter_metadata()
        final_metadata_payload = response.insert_parameters_metadata_payload(formatted_payload, final_metadata_payload)

        # 6. insert csv  visualization metadata data
        response = quicksight_mgr.qs_asset_manager.CSVProcessingManager(bucket, csv_files["visualization"], ",",
                                                                        s3_client)
        formatted_payload = response.prepare_visualization_metadata()
        final_metadata_payload = response.insert_visualizations_metadata_payload(formatted_payload,
                                                                                 final_metadata_payload)

        # 7. insert config.yaml parameters into metadata json file
        config_key = s3_asset_directory + "config.yaml"
        logger.info(config_key)
        config_yaml_data = quicksight_mgr.qs_asset_manager.YamlProcessingManager(bucket, config_key, s3_client)
        insert_payload = config_yaml_data.prepare_config_metadata(s3_key, aws_environment)
        final_metadata_payload = config_yaml_data.insert_config_payload(insert_payload, final_metadata_payload)


        # 8. Merge operational metadata with business metadata
        operational_metadata = quicksight_mgr.qs_asset_manager.read_json_from_s3(bucket, s3_key, s3_client)
        merged_metadata_payload = quicksight_mgr.qs_asset_manager.update_payload_with_changes(operational_metadata,
                                                                                              final_metadata_payload)

        # 10. write updated json payload to s3
        asset_id = final_metadata_payload["asset_id"]
        os_upsert_asset_list.append(asset_id)
        quicksight_mgr.qs_asset_manager.write_dict_to_s3_json(merged_metadata_payload, output_bucket,
                                                              final_export_metadata_key)
        logger.info("Metadata update in progress for asset: " + asset_id + " completed successfully")
        return {
            'statusCode': 200,
            'body': 'Metadata update in progress for asset: ' + asset_id + ' completed successfully',
            'asset_metadata_key': final_export_metadata_key,
            'bucket': bucket
        }