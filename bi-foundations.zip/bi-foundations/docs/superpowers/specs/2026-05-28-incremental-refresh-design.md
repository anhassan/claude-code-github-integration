# Incremental Refresh for bif SPICE Datasets — Design

Date: 2026-05-28
Status: Draft for review (rev 2 — incorporates expert review + empirical pruning probe)
Author: (migration workstream)

## Problem

bif has no incremental-refresh support; every SPICE dataset does a FULL_REFRESH.
For large datasets this is acutely expensive. The motivating case, `rmv_analytics`
(bif-risk, backs Public Market Risk + SSG dashboards):

- **967,642,866 rows**, 607 trading days of immutable daily snapshots (2023-06-30 → today), ~1.45M rows/day.
- A FULL_REFRESH ingests all ~968M rows and takes **~9 hours** (last completed run: 964,738,392 rows / 32,489s).
- It carries `force_sync: true` and has **no `refresh_schedule`**, so its only refresh path is the publisher re-issuing `UpdateDataSet` + full ingestion **on every bif sync** — regardless of whether `rmv_analytics` itself changed. Multiple deploys/day each trigger a fresh 9h reload.

Goal: refresh only the recent window each run (~5 min) instead of the full ~9h, and stop the per-sync full re-ingest.

## Goals

- Publisher support for QuickSight SPICE **incremental refresh** driven from dataset `metadata.yaml`.
- Apply it to `rmv_analytics` as the pilot.
- No regression to dashboards consuming the pilot dataset.

## Non-goals

- Back-filling incremental config across all bif datasets (opt-in per dataset later).
- Changing the existing FULL_REFRESH behavior for datasets that don't opt in.

## Research findings (constraints that shape the design)

Sources: AWS QuickSight SPICE refresh docs, AWS launch post, QuickSight community, plus an empirical probe on `ae_analytics`.

1. **Lookback column must be DATE/timestamp type.** Empirically confirmed: a STRING column is rejected — *"not supported as lookback window. Please provide a column of DATE type."* A DATETIME column is accepted. `rmv_analytics.business_date` is STRING today → we must supply a DATETIME column.
2. **SQL-based sources only** (Athena/Redshift/PostgreSQL/Snowflake). `rmv_analytics` is Athena CustomSql ✓.
3. **First refresh after config is always FULL** — and *any* dataset edit (`UpdateDataSet`) triggers a full "edit-type" refresh. Unavoidable per AWS. Implication: a `force_sync: true` dataset that's re-published every sync would never benefit from incremental → **must remove `force_sync` from the pilot** so it's only re-published when its own metadata changes.
4. **`put_data_set_refresh_properties` MERGES per top-level key** (empirically confirmed: setting `RefreshConfiguration` then `FailureConfiguration` left both present). So setting the incremental config preserves any existing `FailureConfiguration.EmailAlert`, and vice versa. → The previously-feared "email-config wipe" is a non-issue; that task is dropped from scope. (Caveat: *removing* incremental config requires `delete_data_set_refresh_properties`, which clears everything — handled as an edge case, see Open Questions.)
5. Schema changes silently invalidate the lookback ("lookback window column is not valid") → require re-save + full refresh. Acceptable: a metadata change already triggers a full refresh (per #3).
6. Refresh frequency cap: 15 min minimum interval.
7. SPICE historically capped at 500M rows; `rmv_analytics` ingests 964M successfully → account is on the raised capacity tier.
8. For **append-only immutable daily snapshots** (our assumption — historical `business_date`s never change), the delete-and-replace-within-window mechanism produces **no duplicate-record problem**. ⚠️ This immutability is an *assumption to confirm with the risk-data owners* (see Risks).
9. **SPICE capacity is now 2B rows / 2TB** for Enterprise (raised July 2025). `rmv_analytics` at 968M is well within limits. (Earlier "500M" figure was stale.)

### Empirical pruning probe (resolves the biggest risk)

`risk_prod.rmv_analytics` is `PARTITIONED BY (business_date string)`. Bytes scanned, reading the `analytic_value` data column over a 14-day window:

| Query shape | Data scanned |
|---|---|
| Full table | 7.73 GB |
| Raw predicate `WHERE business_date >= cutoff` | 0.116 GB |
| QS-style predicate on computed `cast(date_parse(business_date,'%Y-%m-%d') as timestamp)` | **0.116 GB (identical)** |

→ Athena/Trino pushes the predicate on the *computed* watermark column down to **partition pruning** on the underlying string partition (66× less scanned). Design B's computed watermark prunes correctly. Since the 9h full is dominated by SPICE row-ingest (964M rows), not the 7.7 GB scan, a 14-day incremental (~14.5M rows) is estimated at **~8 min**. To be re-verified post-deploy against QS's actual generated wrapper query (check `DataScannedInBytes` on the first real incremental ingestion).

## Design

### Metadata schema (dataset `metadata.yaml`)

```yaml
incremental_refresh:
  column_name: business_date_dt   # must be a DATETIME column declared in `columns:`
  size: 14                        # widened from 7: a midnight-stamped column + a
  size_unit: DAY                  #   non-midnight run time can drop the boundary
                                  #   date from a tight window; 14d also absorbs a
                                  #   couple of missed runs. HOUR | DAY | WEEK.

refresh_schedule:                  # existing schema; RefreshType per schedule
  - ScheduleId: rmv_analytics_daily_incremental
    RefreshType: INCREMENTAL_REFRESH
    ScheduleFrequency: { Interval: DAILY, Timezone: America/Toronto, TimeOfTheDay: "07:00" }
  - ScheduleId: rmv_analytics_monthly_full          # monthly (not weekly): data is
    RefreshType: FULL_REFRESH                         # immutable, so full is just gap
    ScheduleFrequency:                                # insurance. Timed so its ~9h run
      Interval: MONTHLY                               # clears well before the next daily
      RefreshOnDay: { DayOfMonth: "7" }               # incremental (no overlap).
      Timezone: America/Toronto
      TimeOfTheDay: "12:00"
```

One `incremental_refresh` block per dataset (QS `LookbackWindow` is single-column).
**Schedule-overlap rule:** a FULL_REFRESH must finish before the next INCREMENTAL_REFRESH starts. QS serializes ingestions per dataset (an overlap queues/supersedes rather than hard-fails), but we schedule with ≥ full-duration + margin clearance regardless. The earlier "weekly Sunday 02:00 full + daily 07:00 incremental" would have had the ~9h full still running at the 07:00 incremental — avoided here.

### Publisher changes (bi-foundations)

1. **Payload handler** (`dataset_publish_payload_handler.py`): when a dataset's metadata has `incremental_refresh`, emit a new payload `resource: dataset_refresh_properties` for it (mirrors how `refresh_schedule` payloads are emitted).
2. **Ordering** (`_topological_sort_payloads`): enforce `dataset` → `dataset_refresh_properties` → `refresh_schedule`. The LookbackWindow must exist before an `INCREMENTAL_REFRESH` schedule runs, else the schedule errors.
3. **New resource class** (`resources.py`): `DatasetRefreshProperties(QuickSightResource)` whose `sync()` uses **describe-overlay-put** (do NOT rely on undocumented merge behavior):
   - `describe_data_set_refresh_properties` → start from the existing object (or `{}` on `ResourceNotFound`);
   - preserve its `FailureConfiguration`; overlay `RefreshConfiguration.IncrementalRefresh.LookbackWindow` from config;
   - `put_data_set_refresh_properties` with the merged object.
   - Wrap in **ConflictException retry/backoff** — `UpdateDataSet` from the dataset sync may leave an in-flight "edit" refresh; configuring incremental also kicks a one-time full. Retry on conflict so the property set lands.
4. **Double full-load on first rollout — RESOLVED via Gate 1 probe; no suppression built.** Empirically confirmed on `ae_analytics` (2026-05-28): `put_data_set_refresh_properties` with a LookbackWindow **auto-triggers a full refresh** (a RUNNING ingestion appeared immediately; cancelled + restored clean). Separately, `UpdateDataSet`/`CreateDataSet` for SPICE **also auto-trigger** an ingestion intrinsically (the response carries `IngestionId`) — there is no API flag to suppress it. So on a metadata-change deploy both fire, but **QuickSight serializes ingestions per dataset**: the config-triggered one supersedes the dataset-update one (`INGESTION_SUPERSEDED`), and the property put may raise `ConflictException`, handled by the resource's **retry/backoff**. Because the pilot **removes `force_sync`**, `UpdateDataSet` only runs on actual metadata changes (rare), so the collision is infrequent and self-resolving — one baseline full completes. Decision: rely on conflict-retry + QS serialization + force_sync removal; do **not** build fragile auto-ingestion suppression (not cleanly achievable anyway).
5. **Register** the resource type in `base.py`.
6. **Validators** (config parse): `column_name` exists in `columns:` and is `DATETIME`; `size` is int > 0; `size_unit ∈ {HOUR, DAY, WEEK}`; `import_mode == SPICE`; dataset is SQL-based (reject S3/file source); if any schedule is `INCREMENTAL_REFRESH` then `incremental_refresh` must be present (and warn if `incremental_refresh` present with no incremental schedule — inert). **Schedule constraints:** max 5 schedules per dataset; sub-hourly intervals (`MINUTE15`/`MINUTE30`/`HOURLY`) cannot coexist with other schedules; timezone must be a valid QS Java zone ID (`America/Toronto` preferred; `Canada/Eastern` is already used in bif-risk and accepted).
7. **IAM** (`dfp-tf-deploy` manager role): add `quicksight:PutDataSetRefreshProperties`, `quicksight:DescribeDataSetRefreshProperties`, `quicksight:DeleteDataSetRefreshProperties`.
8. **Email-config**: the describe-overlay-put in (3) inherently preserves `FailureConfiguration` — no separate fix needed. Add a unit test asserting an existing `FailureConfiguration` survives a `RefreshConfiguration` put via the overlay path.

### Pilot: `rmv_analytics` (bif-risk) — Design B (dedicated watermark)

- **`query.sql`**: add a DATETIME watermark derived from the existing string date:
  `, cast(date_parse(business_date, '%Y-%m-%d') as timestamp) as business_date_dt`
- **`metadata.yaml`**: add `business_date_dt: DATETIME`; **remove `force_sync: true`**; add the `incremental_refresh` block (column `business_date_dt`, size **14**, unit DAY) + the daily-incremental / monthly-full schedules above.
- `business_date` stays STRING → SSG / Public Market Risk calc fields untouched (Design A — converting `business_date` — is rejected here because those calc fields work against the STRING type today).

Resulting behavior: first post-merge refresh is a one-time ~9h full reload (establishes the incremental baseline); subsequent daily runs ingest only the last ~14 business-dates (~14.5M rows, **~8 min**, partition-pruned to ~0.12 GB scanned); monthly full as gap insurance; no more accidental full re-ingest on unrelated syncs.

## Risks & open questions

- **Immutability assumption (data-semantics — confirm with risk-data owners).** The design assumes a historical `business_date`'s rows are never restated. If restatements land **>14 days** after the fact, the daily incremental misses them and only the monthly full corrects. If late restatements are common, widen the window or increase full frequency. This is the one assumption I cannot prove from the table alone.
- **Initial full refresh (~9h) is unavoidable** on first config and on any future `rmv_analytics` metadata change. SPICE keeps serving the prior data during a refresh, so no dashboard downtime. Schedule the pilot merge for off-hours.
- **First-rollout double-full / conflict** (expert #4) — **RESOLVED (Gate 1 done)**: probe confirmed the config put auto-triggers a full, and `UpdateDataSet` auto-triggers one too (no suppress flag). QS serializes per dataset → second supersedes first; conflict-retry handles the put. `force_sync` removal keeps `UpdateDataSet` to rare metadata changes. No suppression code built (see Publisher changes #4). The `date_parse` validity check also passed (0 malformed of 607 partitions). Still confirm immutability with data owners + re-verify pruning on the first real incremental ingestion.
- **Removal handling (v1 = manual, documented).** Emitting `dataset_refresh_properties` only when the block exists means the resource cannot auto-remove a deleted block. v1: removing `incremental_refresh` from a YAML requires a manual `delete_data_set_refresh_properties` + re-put of the email config (delete clears everything). v2 option: always emit a reconciliation payload for changed datasets that deletes remote refresh config when the block is absent. (This resolves the rev-1 contradiction where the spec both skipped emission and expected removal handling.)
- **`date_parse` robustness**: `business_date` is the partition key and should always be valid `YYYY-MM-DD`. Confirm zero malformed partition values before the pilot PR; if any exist, use `try_cast`/`try(date_parse(...))` so the watermark is NULL rather than failing ingestion.
- **Post-deploy pruning re-verification**: the probe used a representative wrapper shape; confirm `DataScannedInBytes` on QS's first *actual* incremental ingestion matches (~0.12 GB, not ~7.7 GB).
- **Other large `force_sync` datasets** likely carry the same per-sync full-ingest cost; out of scope here but worth a follow-up audit.

## Test plan

- **Unit** (`tests/`): payload handler emits `dataset_refresh_properties` when `incremental_refresh` present; topological order dataset→properties→schedule; describe-overlay-put preserves an existing `FailureConfiguration` while setting `RefreshConfiguration`; validators reject non-DATETIME column / bad `size_unit` / file source / missing column / >5 schedules / sub-hourly-coexisting-with-others.
- **Dev sequence test (gating) — DONE 2026-05-28**: probed on `ae_analytics` that `put_data_set_refresh_properties` auto-triggers a full refresh (it does), confirming the conflict-retry path is the right mechanism; restored clean. Full publish-path sequence (update → put → schedule) will be exercised on the pilot deploy under conflict-retry.
- **Pre-pilot Athena check — DONE 2026-05-28**: 0 of 607 `business_date` partitions are malformed; `date_parse` is safe.
- **Dev integration (pilot)**: deploy framework, then pilot. Verify `describe_data_set_refresh_properties` shows the LookbackWindow; first refresh is FULL; a subsequent INCREMENTAL run ingests only window rows (check `RowInfo.RowsIngested` ≈ 14-day count, not 968M) **and** re-verify `DataScannedInBytes` ≈ 0.12 GB; Public Market Risk + SSG dashboards still render current data.

## Rollout sequence

1. Framework PR (bi-foundations) + unit tests (11 green) → **dev sequence test (gating) DONE** → merge → deploy. IAM PR (dfp-tf-deploy) adds Put/Describe/Delete DataSetRefreshProperties.
2. Pre-pilot: Athena `date_parse` validity check DONE; confirm immutability assumption with risk-data owners.
3. Pilot PR (bif-risk `rmv_analytics`: watermark column, remove `force_sync`, incremental + schedules) → merge → sync (one-time ~9h full, off-hours) → next-day verify incremental (rows + bytes scanned).
4. Confirm dashboards; document; follow-up audit of other large `force_sync` datasets.
