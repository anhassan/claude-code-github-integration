# scripts/verify_staging_parity.py
"""Gate the migration staging-copy cleanup: diff each UUID working-copy
dashboard against its managed twin before the working copy is deleted.

Pairs are discovered by duplicate display name in the central account: a
managed dashboard (DashboardId ends with -bif-<domain>-<env>) whose Name is
also carried by exactly one UUID-id dashboard. For each pair the published
definitions are normalized (volatile/identity fields dropped) and diffed.

Verdicts:
  PARITY      definitions identical after normalization -> safe to delete
  THEME_ONLY  only ThemeArn differs (e.g. managed mirror added later)
  DIFF        real content drift -> investigate before deleting

Read-only: never mutates dashboards. Use --dump-dir to write per-pair
unified diffs for review.
"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import sys

import boto3

CENTRAL_PROFILE = "CPPIB-Quicksight-Admin-200967598245"
CENTRAL_ACCOUNT = "200967598245"
MANAGED_ID_RE = re.compile(r"-bif-[a-z0-9-]+-(dev|qa|uat|prod)$")

# Fields that legitimately differ between the staging copy and the managed
# twin (identity / publication metadata), never content.
_DROP_KEYS = {
    "DashboardId", "Arn", "Name", "RequestId", "Status", "ResponseMetadata",
    "CreatedTime", "LastUpdatedTime", "LastPublishedTime", "VersionNumber",
}


def normalize(payload: dict) -> dict:
    out = json.loads(json.dumps(payload, default=str))  # deep copy; datetimes -> str
    for k in _DROP_KEYS:
        out.pop(k, None)
    return out


def canonicalize(node):
    """Order-insensitive form: describe-definition serializes some arrays
    (e.g. FilterGroups) in nondeterministic order, which floods a naive diff
    with false adds/removes. Sorting every list by its canonical JSON makes
    the comparison order-blind; real content drift still differs."""
    if isinstance(node, dict):
        return {k: canonicalize(v) for k, v in node.items()}
    if isinstance(node, list):
        return sorted(
            (canonicalize(v) for v in node),
            key=lambda v: json.dumps(v, sort_keys=True, default=str),
        )
    return node


def is_managed_id(dashboard_id: str) -> bool:
    return bool(MANAGED_ID_RE.search(dashboard_id))


def discover_pairs(summaries: list[dict]) -> tuple[dict[str, tuple[str, str]], list[str]]:
    """Return ({name: (managed_id, staging_uuid_id)}, ambiguous_names)."""
    by_name: dict[str, list[str]] = {}
    for s in summaries:
        by_name.setdefault(s["Name"], []).append(s["DashboardId"])
    pairs: dict[str, tuple[str, str]] = {}
    ambiguous: list[str] = []
    for name, ids in by_name.items():
        managed = [i for i in ids if is_managed_id(i)]
        staging = [i for i in ids if not is_managed_id(i)]
        if len(managed) == 1 and len(staging) == 1:
            pairs[name] = (managed[0], staging[0])
        elif managed and staging:
            ambiguous.append(name)
    return pairs, ambiguous


def diff_pair(qs, managed_id: str, staging_id: str) -> tuple[str, list[str]]:
    defs = {}
    for label, did in (("managed", managed_id), ("staging", staging_id)):
        resp = qs.describe_dashboard_definition(
            AwsAccountId=CENTRAL_ACCOUNT, DashboardId=did
        )
        defs[label] = canonicalize(normalize(resp))
    a = json.dumps(defs["staging"], indent=1, sort_keys=True, default=str).splitlines()
    b = json.dumps(defs["managed"], indent=1, sort_keys=True, default=str).splitlines()
    diff = list(difflib.unified_diff(a, b, "staging", "managed", lineterm=""))
    if not diff:
        return "PARITY", diff
    sans_theme = [
        {k: v for k, v in d.items() if k != "ThemeArn"} for d in (defs["staging"], defs["managed"])
    ]
    if sans_theme[0] == sans_theme[1]:
        return "THEME_ONLY", diff
    return "DIFF", diff


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profile", default=CENTRAL_PROFILE)
    p.add_argument("--name-filter", default="", help="substring filter on dashboard display name")
    p.add_argument("--domain", default="", help="only pairs whose managed id contains -bif-<domain>- (e.g. risk)")
    p.add_argument("--dump-dir", help="write per-pair unified diffs here")
    args = p.parse_args(argv)

    qs = boto3.Session(profile_name=args.profile, region_name="us-east-1").client("quicksight")
    summaries = []
    for page in qs.get_paginator("list_dashboards").paginate(AwsAccountId=CENTRAL_ACCOUNT):
        summaries.extend(page["DashboardSummaryList"])

    pairs, ambiguous = discover_pairs(summaries)
    if args.name_filter:
        pairs = {n: v for n, v in pairs.items() if args.name_filter.lower() in n.lower()}
        ambiguous = [n for n in ambiguous if args.name_filter.lower() in n.lower()]
    if args.domain:
        tag = f"-bif-{args.domain}-"
        pairs = {n: v for n, v in pairs.items() if tag in v[0]}

    worst = 0
    for name in sorted(pairs):
        managed_id, staging_id = pairs[name]
        verdict, diff = diff_pair(qs, managed_id, staging_id)
        marks = {"PARITY": 0, "THEME_ONLY": 1, "DIFF": 2}
        worst = max(worst, marks[verdict])
        print(f"{verdict:10s} {name}  [managed={managed_id} staging={staging_id}]"
              + (f"  ({sum(1 for l in diff if l[:1] in '+-')} diff lines)" if diff else ""))
        if args.dump_dir and diff:
            from pathlib import Path
            d = Path(args.dump_dir)
            d.mkdir(parents=True, exist_ok=True)
            slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
            (d / f"{slug}.diff").write_text("\n".join(diff), encoding="utf-8")
    for name in ambiguous:
        print(f"AMBIGUOUS  {name}  (multiple managed or staging candidates — resolve manually)")
    if not pairs:
        print("no managed/staging pairs matched")
    return 0 if worst < 2 and not ambiguous else 1


if __name__ == "__main__":
    sys.exit(main())
