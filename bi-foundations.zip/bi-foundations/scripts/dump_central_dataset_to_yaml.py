"""
Dump a central QuickSight dataset into the bif-risk YAML layout.

For each input dataset id, fetches the central dataset, converts it into
metadata.yaml + (query.sql | s3_manifest.yaml), and writes the files under
<output_root>/<slug>/ . Run from bi-foundations after `aws sso login`.

Example:
    python scripts/dump_central_dataset_to_yaml.py \
        --target-profile CPPIB-Quicksight-Admin-200967598245 \
        --target-account-id 200967598245 \
        --output-root ../bif-risk/dev/datasets \
        --workspace bif-risk \
        --dataset-id 07f4c934-efef-47fb-a811-31e0207f3a3a \
        --dataset-id bb84117a-5e19-4287-a447-35510e42f8f3
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import boto3


def slugify(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9]+", "_", value or "").strip("_").lower()
    return safe or "dataset"


def normalize_type(col: dict[str, Any]) -> str:
    t = col.get("Type") or "STRING"
    sub = col.get("SubType")
    if sub:
        return f"{t}.{sub}"
    return t


def yaml_quote_key(name: str) -> str:
    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name) and name not in {"true", "false", "null", "yes", "no", "on", "off"}:
        return name
    return '"' + name.replace('"', '\\"') + '"'


def dump_metadata_yaml(dataset: dict[str, Any], workspace: str, dataset_source: str | None) -> str:
    lines = [
        f"name: {dataset['Name']}",
        f"import_mode: {dataset.get('ImportMode', 'SPICE')}",
        "force_sync: true",
        "workspaces:",
        f"  - {workspace}",
    ]
    if dataset_source == "S3":
        lines.append('dataset_source: "S3"')
        # data_source_id derived later by caller and patched in
    lines.append("columns:")
    for col in dataset.get("OutputColumns", []):
        key = yaml_quote_key(col["Name"])
        lines.append(f"  {key}: {normalize_type(col)}")
    return "\n".join(lines) + "\n"


def dump_query_sql(custom_sql: dict[str, Any]) -> str:
    return (custom_sql.get("SqlQuery") or "").rstrip() + "\n"


def dump_s3_manifest_yaml(s3_source: dict[str, Any], slug: str) -> str:
    # We can't recover the original manifest URIs from a created datasource via the public API
    # (DescribeDataSource on S3Source returns ManifestFileLocation only as Bucket+Key, not the
    # source files). The publisher writes the manifest itself; we surface the placeholder so
    # the owner can fill in the actual data URIs.
    upload = s3_source.get("UploadSettings", {})
    lines = [
        "# AUTO-GENERATED: data_uris must be filled in by the dataset owner before the",
        "# next sync. The QuickSight Public API does not return the source URIs that",
        "# were embedded in the local-manifest upload at creation time.",
        "data_uris:",
        '  - "s3://REPLACE_WITH_BUCKET/REPLACE_WITH_KEY.csv"',
        "manifest_location:",
        f'  key: "bif-risk/s3-manifests/{slug}/manifest.json"',
        "upload_settings:",
        f"  format: {upload.get('Format', 'CSV')}",
        f"  start_from_row: {upload.get('StartFromRow', 1)}",
        f"  contains_header: {str(upload.get('ContainsHeader', True)).lower()}",
        f'  text_qualifier: "{upload.get("TextQualifier", "DOUBLE_QUOTE")}"',
        f'  delimiter: "{upload.get("Delimiter", ",")}"',
    ]
    return "\n".join(lines) + "\n"


def classify(dataset: dict[str, Any]) -> str:
    ptm = dataset.get("PhysicalTableMap", {}) or {}
    if not ptm:
        return "unknown"
    pt = next(iter(ptm.values()))
    if "CustomSql" in pt:
        return "CustomSql"
    if "RelationalTable" in pt:
        return "RelationalTable"
    if "S3Source" in pt:
        return "S3Source"
    return "unknown"


def dump_one(qs_client, account_id: str, dataset_id: str, output_root: Path, workspace: str) -> tuple[str, str]:
    dataset = qs_client.describe_data_set(AwsAccountId=account_id, DataSetId=dataset_id)["DataSet"]
    kind = classify(dataset)
    slug = slugify(dataset["Name"])
    target_dir = output_root / slug
    target_dir.mkdir(parents=True, exist_ok=True)

    if kind == "CustomSql":
        ptm = dataset["PhysicalTableMap"]
        cs = next(iter(ptm.values()))["CustomSql"]
        (target_dir / "metadata.yaml").write_text(dump_metadata_yaml(dataset, workspace, None), encoding="utf-8")
        (target_dir / "query.sql").write_text(dump_query_sql(cs), encoding="utf-8")
    elif kind == "RelationalTable":
        ptm = dataset["PhysicalTableMap"]
        rt = next(iter(ptm.values()))["RelationalTable"]
        sql = f"SELECT * FROM {rt.get('Schema')}.{rt.get('Name')}\n"
        (target_dir / "metadata.yaml").write_text(dump_metadata_yaml(dataset, workspace, None), encoding="utf-8")
        (target_dir / "query.sql").write_text(sql, encoding="utf-8")
    elif kind == "S3Source":
        ptm = dataset["PhysicalTableMap"]
        s3 = next(iter(ptm.values()))["S3Source"]
        meta = dump_metadata_yaml(dataset, workspace, "S3")
        meta = meta.replace(
            'dataset_source: "S3"\n',
            f'dataset_source: "S3"\ndata_source_id: awb-{slug.replace("_", "-")}-s3-source\n',
        )
        (target_dir / "metadata.yaml").write_text(meta, encoding="utf-8")
        (target_dir / "s3_manifest.yaml").write_text(dump_s3_manifest_yaml(s3, slug), encoding="utf-8")
    else:
        (target_dir / "metadata.yaml").write_text(dump_metadata_yaml(dataset, workspace, None), encoding="utf-8")
        (target_dir / "UNKNOWN.txt").write_text(
            f"Could not classify dataset {dataset_id} ({dataset['Name']}). "
            f"PhysicalTableMap keys: {list((dataset.get('PhysicalTableMap') or {}).keys())}\n",
            encoding="utf-8",
        )
    return slug, kind


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--target-account-id", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--output-root", required=True, help="e.g. ../bif-risk/dev/datasets")
    parser.add_argument("--workspace", default="bif-risk")
    parser.add_argument(
        "--dataset-id",
        action="append",
        required=True,
        help="Repeat for each central dataset to dump.",
    )
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.target_profile, region_name=args.region)
    qs = session.client("quicksight")
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    for dataset_id in args.dataset_id:
        try:
            slug, kind = dump_one(qs, args.target_account_id, dataset_id, output_root, args.workspace)
            print(f"OK  {dataset_id} -> {output_root / slug}  ({kind})")
        except Exception as exc:
            print(f"ERR {dataset_id}: {exc}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
