"""
Build a QuickSight migration matrix from a source dependency scan and a target
inventory scan.

The matrix is intentionally conservative: exact or normalized name/id matches
are shown as candidates, while semantic matches must still be confirmed by a
human.
"""

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path


def read_json(path):
    with Path(path).open(encoding="utf-8") as file:
        return json.load(file)


def read_csv(path):
    if not path:
        return []
    csv_path = Path(path)
    if not csv_path.exists():
        return []
    with csv_path.open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=str)
        file.write("\n")


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: stringify(row.get(key)) for key in fieldnames})


def stringify(value):
    if value in (None, "", [], {}):
        return ""
    if isinstance(value, (list, dict)):
        return json.dumps(value, default=str, sort_keys=True)
    return str(value)


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "_", (value or "").lower()).strip("_")


def source_id_from_arn(arn):
    return (arn or "").split("/")[-1]


def split_dashboard_names(value):
    return [name.strip() for name in (value or "").split(",") if name.strip()]


def load_yaml_metadata(path):
    text = path.read_text(encoding="utf-8")
    try:
        import yaml

        payload = yaml.safe_load(text) or {}
        if isinstance(payload, dict):
            return payload
    except Exception:
        pass

    metadata = {}
    for line in text.splitlines():
        match = re.match(r"^([A-Za-z0-9_]+):\s*(.*?)\s*(?:#.*)?$", line)
        if match:
            metadata[match.group(1)] = match.group(2).strip("'\" ")
    return metadata


def extract_table_refs(sql_text):
    refs = []
    for match in re.finditer(
        r"\b(?:from|join)\s+([A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)?)",
        sql_text,
        flags=re.IGNORECASE,
    ):
        refs.append(match.group(1))
    return sorted(set(refs))


def load_bif_risk_datasets(root):
    if not root:
        return []
    root_path = Path(root)
    if not root_path.exists():
        return []

    datasets = []
    for metadata_path in sorted(root_path.glob("dev/datasets/*/metadata.yaml")):
        dataset_dir = metadata_path.parent
        metadata = load_yaml_metadata(metadata_path)
        query_path = dataset_dir / "query.sql"
        table_refs = []
        if query_path.exists():
            table_refs = extract_table_refs(query_path.read_text(encoding="utf-8"))
        datasets.append(
            {
                "repo_dataset_dir": dataset_dir.name,
                "repo_dataset_name": metadata.get("name") or dataset_dir.name,
                "metadata_path": str(metadata_path),
                "query_path": str(query_path) if query_path.exists() else "",
                "import_mode": metadata.get("import_mode"),
                "table_refs": table_refs,
            }
        )
    return datasets


def index_by(rows, key_func):
    lookup = defaultdict(list)
    for row in rows:
        key = key_func(row)
        if key:
            lookup[key].append(row)
    return lookup


def load_dashboard_status(rows):
    by_id = {}
    by_name = defaultdict(list)
    for row in rows:
        dashboard_id = row.get("dashboard_id")
        dashboard_name = row.get("dashboard_name") or row.get("requested_name")
        if dashboard_id:
            by_id[dashboard_id] = row
        if dashboard_name:
            by_name[dashboard_name].append(row)
    return by_id, by_name


def load_blockers(rows):
    by_dashboard_name = defaultdict(list)
    by_dataset_id = defaultdict(list)
    by_dataset_name = defaultdict(list)
    for row in rows:
        for dashboard_name in split_dashboard_names(row.get("dashboard_names")):
            by_dashboard_name[dashboard_name].append(row)
        if row.get("dataset_id"):
            by_dataset_id[row["dataset_id"]].append(row)
        dataset_name = row.get("dataset_name") or row.get("dataset_identifier")
        if dataset_name:
            by_dataset_name[normalize(dataset_name)].append(row)
    return by_dashboard_name, by_dataset_id, by_dataset_name


def select_dashboard_status(dashboard, error_by_id, status_by_id):
    dashboard_id = dashboard.get("dashboard_id")
    if dashboard_id in status_by_id:
        status = status_by_id[dashboard_id]
        return status.get("status") or "", status.get("issue_summary") or ""
    if dashboard_id in error_by_id:
        return "Dependency error", error_by_id[dashboard_id].get("error") or ""
    if dashboard.get("has_s3_dependency"):
        return "S3 dependency", "Dashboard references one or more S3-backed datasets."
    return "No blocker detected", "No S3, missing dataset, file-source, or missing-datasource blocker detected by scan."


def format_data_sources(dataset, data_source_by_id):
    labels = []
    for data_source_arn in dataset.get("data_source_arns") or []:
        data_source_id = source_id_from_arn(data_source_arn)
        data_source = data_source_by_id.get(data_source_id) or {}
        labels.append(
            "{} ({})".format(
                data_source.get("name") or data_source_id,
                data_source.get("type") or "unknown",
            )
        )
    return sorted(labels)


def infer_dataset_blocker(dataset, data_source_by_id, blocker_rows):
    issue_types = sorted({row.get("issue_type") for row in blocker_rows if row.get("issue_type")})
    if issue_types:
        return "; ".join(issue_types), "; ".join(
            sorted({row.get("detail") or "" for row in blocker_rows if row.get("detail")})
        )

    s3_data_sources = []
    s3_manifest_missing = []
    s3_manifest_present = []
    s3_manifest_unknown = []
    for data_source_arn in dataset.get("data_source_arns") or []:
        data_source_id = source_id_from_arn(data_source_arn)
        data_source = data_source_by_id.get(data_source_id) or {}
        if data_source.get("type") == "S3":
            name = data_source.get("name") or data_source_id
            s3_data_sources.append(name)
            if data_source.get("has_manifest_file_location") is True:
                s3_manifest_present.append(name)
            elif data_source.get("has_manifest_file_location") is False:
                s3_manifest_missing.append(name)
            else:
                s3_manifest_unknown.append(name)

    if s3_manifest_missing:
        return (
            "S3_MANIFEST_LOCATION_MISSING",
            "S3 data source has no ManifestFileLocation: {}".format(
                ", ".join(sorted(s3_manifest_missing))
            ),
        )
    if s3_manifest_unknown:
        return (
            "S3_MANIFEST_LOCATION_UNKNOWN",
            "S3 data source exists but manifest location was not present in scan output: {}".format(
                ", ".join(sorted(s3_manifest_unknown))
            ),
        )
    if s3_manifest_present:
        return (
            "S3_MANIFEST_LOCATION_PRESENT",
            "S3 data source references an S3 manifest: {}".format(
                ", ".join(sorted(s3_manifest_present))
            ),
        )
    if dataset.get("has_s3_source") or s3_data_sources:
        return "S3_SOURCE", "Dataset is S3-backed."
    return "NONE_DETECTED", ""


def find_target_candidate(source_dataset_id, source_dataset_name, lookups):
    if source_dataset_id and source_dataset_id in lookups["target_by_id"]:
        target = lookups["target_by_id"][source_dataset_id]
        return {
            "target_candidate_type": "target_dataset_id_match",
            "target_dataset_name": target.get("name"),
            "target_dataset_id": target.get("dataset_id"),
            "target_dataset_arn": target.get("arn"),
            "bif_risk_dataset": "",
            "bif_risk_table_refs": [],
        }

    if source_dataset_name and source_dataset_name in lookups["target_by_name"]:
        target = lookups["target_by_name"][source_dataset_name][0]
        return {
            "target_candidate_type": "target_dataset_name_match",
            "target_dataset_name": target.get("name"),
            "target_dataset_id": target.get("dataset_id"),
            "target_dataset_arn": target.get("arn"),
            "bif_risk_dataset": "",
            "bif_risk_table_refs": [],
        }

    normalized = normalize(source_dataset_name)
    if normalized and normalized in lookups["target_by_normalized_name"]:
        target = lookups["target_by_normalized_name"][normalized][0]
        return {
            "target_candidate_type": "target_dataset_normalized_name_match",
            "target_dataset_name": target.get("name"),
            "target_dataset_id": target.get("dataset_id"),
            "target_dataset_arn": target.get("arn"),
            "bif_risk_dataset": "",
            "bif_risk_table_refs": [],
        }

    if source_dataset_name and source_dataset_name in lookups["bif_by_name"]:
        candidate = lookups["bif_by_name"][source_dataset_name][0]
        return {
            "target_candidate_type": "bif_risk_repo_dataset_name_match",
            "target_dataset_name": "",
            "target_dataset_id": "",
            "target_dataset_arn": "",
            "bif_risk_dataset": candidate.get("repo_dataset_name"),
            "bif_risk_table_refs": candidate.get("table_refs") or [],
        }

    if normalized and normalized in lookups["bif_by_normalized_name"]:
        candidate = lookups["bif_by_normalized_name"][normalized][0]
        return {
            "target_candidate_type": "bif_risk_repo_dataset_normalized_name_match",
            "target_dataset_name": "",
            "target_dataset_id": "",
            "target_dataset_arn": "",
            "bif_risk_dataset": candidate.get("repo_dataset_name"),
            "bif_risk_table_refs": candidate.get("table_refs") or [],
        }

    return {
        "target_candidate_type": "no_candidate_found",
        "target_dataset_name": "",
        "target_dataset_id": "",
        "target_dataset_arn": "",
        "bif_risk_dataset": "",
        "bif_risk_table_refs": [],
    }


def recommendation_for(row):
    blocker_type = row.get("blocker_type") or ""
    status = row.get("dashboard_status") or ""
    candidate_type = row.get("target_candidate_type") or ""

    if "MISSING_DATASET" in blocker_type:
        return "Create or remap the missing dataset, or export with this dataset excluded for a controlled test."
    if "FILE_SOURCE_UNSUPPORTED" in blocker_type:
        return "Recreate as a repo-managed dataset or an S3 manifest-backed dataset before migration."
    if "S3_MANIFEST_LOCATION_MISSING" in blocker_type:
        return "Move the manifest definition to S3 and update the QuickSight S3 data source to ManifestFileLocation."
    if "S3_MANIFEST_LOCATION_PRESENT" in blocker_type:
        return "Confirm target QuickSight can access the manifest bucket/key before import."
    if candidate_type.startswith("target_dataset"):
        return "Candidate target dataset exists; validate schema before remapping dashboard definitions."
    if candidate_type.startswith("bif_risk_repo"):
        return "Candidate exists in bif-risk repo; confirm it is deployed to target, then remap."
    if status == "No blocker detected" or status == "Clean candidate":
        return "Use asset-bundle export/import."
    if "Dependency error" in status:
        return "Resolve dependency blocker or use a deliberate exclusion/remap path."
    return "Review manually."


def build_matrix(source_scan, target_inventory, bif_risk_datasets, dashboard_status_rows, blocker_rows):
    target_datasets = target_inventory.get("datasets") or []
    lookups = {
        "target_by_id": {row.get("dataset_id"): row for row in target_datasets if row.get("dataset_id")},
        "target_by_name": index_by(target_datasets, lambda row: row.get("name")),
        "target_by_normalized_name": index_by(target_datasets, lambda row: normalize(row.get("name"))),
        "bif_by_name": index_by(bif_risk_datasets, lambda row: row.get("repo_dataset_name")),
        "bif_by_normalized_name": index_by(
            bif_risk_datasets,
            lambda row: normalize(row.get("repo_dataset_name")),
        ),
    }

    dataset_by_id = {
        dataset.get("dataset_id"): dataset
        for dataset in source_scan.get("datasets") or []
        if dataset.get("dataset_id")
    }
    data_source_by_id = {
        data_source.get("data_source_id"): data_source
        for data_source in source_scan.get("data_sources") or []
        if data_source.get("data_source_id")
    }
    error_by_id = {
        error.get("dashboard_id"): error
        for error in source_scan.get("errors") or []
        if error.get("dashboard_id")
    }
    status_by_id, status_by_name = load_dashboard_status(dashboard_status_rows)
    blockers_by_dashboard_name, blockers_by_dataset_id, blockers_by_dataset_name = load_blockers(
        blocker_rows
    )

    dashboard_by_id = {
        dashboard.get("dashboard_id"): dashboard
        for dashboard in source_scan.get("dashboards") or []
        if dashboard.get("dashboard_id")
    }
    dashboard_by_name = defaultdict(list)
    for dashboard in source_scan.get("dashboards") or []:
        dashboard_by_name[dashboard.get("dashboard_name")].append(dashboard)
    for error in source_scan.get("errors") or []:
        dashboard_by_name[error.get("dashboard_name")].append(
            {
                "dashboard_id": error.get("dashboard_id"),
                "dashboard_name": error.get("dashboard_name"),
                "dataset_ids": [],
            }
        )

    rows = []
    existing_keys = set()
    dashboards = list(source_scan.get("dashboards") or [])
    dashboards.extend(
        {
            "dashboard_id": error.get("dashboard_id"),
            "dashboard_name": error.get("dashboard_name"),
            "dataset_ids": [],
        }
        for error in source_scan.get("errors") or []
        if error.get("dashboard_id") not in dashboard_by_id
    )

    for dashboard in dashboards:
        dashboard_id = dashboard.get("dashboard_id")
        dashboard_name = dashboard.get("dashboard_name")
        dashboard_status, dashboard_issue_summary = select_dashboard_status(
            dashboard, error_by_id, status_by_id
        )
        dataset_ids = dashboard.get("dataset_ids") or []

        for dataset_id in dataset_ids:
            dataset = dataset_by_id.get(dataset_id)
            source_dataset_name = dataset.get("name") if dataset else ""
            source_dataset_identifier = source_dataset_name or dataset_id
            related_blockers = list(blockers_by_dataset_id.get(dataset_id, []))
            related_blockers.extend(
                row
                for row in blockers_by_dataset_name.get(normalize(source_dataset_name), [])
                if dashboard_name in split_dashboard_names(row.get("dashboard_names"))
            )
            blocker_type, blocker_detail = infer_dataset_blocker(
                dataset or {}, data_source_by_id, related_blockers
            )
            candidate = find_target_candidate(dataset_id, source_dataset_name, lookups)
            row = {
                "dashboard_name": dashboard_name,
                "dashboard_id": dashboard_id,
                "dashboard_status": dashboard_status,
                "dashboard_issue_summary": dashboard_issue_summary,
                "source_dataset_name": source_dataset_name,
                "source_dataset_id": dataset_id,
                "source_dataset_identifier": source_dataset_identifier,
                "source_import_mode": dataset.get("import_mode") if dataset else "",
                "source_data_sources": format_data_sources(dataset or {}, data_source_by_id),
                "blocker_type": blocker_type,
                "blocker_detail": blocker_detail,
                **candidate,
            }
            row["recommendation"] = recommendation_for(row)
            rows.append(row)
            existing_keys.add((dashboard_id, dataset_id, normalize(source_dataset_identifier)))

        if (
            not dataset_ids
            and dashboard_id in error_by_id
            and not blockers_by_dashboard_name.get(dashboard_name)
        ):
            candidate = find_target_candidate("", "", lookups)
            row = {
                "dashboard_name": dashboard_name,
                "dashboard_id": dashboard_id,
                "dashboard_status": dashboard_status,
                "dashboard_issue_summary": dashboard_issue_summary,
                "source_dataset_name": "",
                "source_dataset_id": "",
                "source_dataset_identifier": "",
                "source_import_mode": "",
                "source_data_sources": [],
                "blocker_type": "DEPENDENCY_SCAN_ERROR",
                "blocker_detail": error_by_id[dashboard_id].get("error"),
                **candidate,
            }
            row["recommendation"] = recommendation_for(row)
            rows.append(row)

    for blocker in blocker_rows:
        source_dataset_name = blocker.get("dataset_name") or blocker.get("dataset_identifier") or ""
        source_dataset_id = blocker.get("dataset_id") or ""
        for dashboard_name in split_dashboard_names(blocker.get("dashboard_names")):
            dashboards_for_name = dashboard_by_name.get(dashboard_name) or [{}]
            for dashboard in dashboards_for_name[:1]:
                dashboard_id = dashboard.get("dashboard_id") or ""
                key = (dashboard_id, source_dataset_id, normalize(source_dataset_name))
                if key in existing_keys:
                    continue
                status_row = status_by_id.get(dashboard_id) or (
                    status_by_name.get(dashboard_name) or [{}]
                )[0]
                dashboard_status = status_row.get("status") or "Dependency error"
                dashboard_issue_summary = status_row.get("issue_summary") or blocker.get("detail") or ""
                candidate = find_target_candidate(source_dataset_id, source_dataset_name, lookups)
                row = {
                    "dashboard_name": dashboard_name,
                    "dashboard_id": dashboard_id,
                    "dashboard_status": dashboard_status,
                    "dashboard_issue_summary": dashboard_issue_summary,
                    "source_dataset_name": blocker.get("dataset_name") or "",
                    "source_dataset_id": source_dataset_id,
                    "source_dataset_identifier": blocker.get("dataset_identifier") or source_dataset_name,
                    "source_import_mode": "",
                    "source_data_sources": [
                        item
                        for item in [
                            "{} ({})".format(blocker.get("data_source_name"), blocker.get("data_source_id"))
                            if blocker.get("data_source_name") or blocker.get("data_source_id")
                            else ""
                        ]
                        if item
                    ],
                    "blocker_type": blocker.get("issue_type") or "DEPENDENCY_BLOCKER",
                    "blocker_detail": blocker.get("detail") or "",
                    **candidate,
                }
                row["recommendation"] = recommendation_for(row)
                rows.append(row)
                existing_keys.add(key)

    return sorted(
        rows,
        key=lambda row: (
            row.get("dashboard_name") or "",
            row.get("source_dataset_name") or row.get("source_dataset_identifier") or "",
            row.get("source_dataset_id") or "",
        ),
    )


def write_markdown(path, rows, source_scan, target_inventory, bif_risk_count):
    summary = {
        "Dashboards in source scan": source_scan.get("dashboard_summary_count"),
        "Dashboards dependency-described": source_scan.get("dependency_described_dashboard_count"),
        "Source dependency errors": source_scan.get("dependency_scan_error_count"),
        "Target datasets scanned": target_inventory.get("dataset_count"),
        "Target dashboards scanned": target_inventory.get("dashboard_count"),
        "Target folder members scanned": target_inventory.get("folder_member_count"),
        "bif-risk repo datasets inspected": bif_risk_count,
        "Matrix rows": len(rows),
    }
    blocker_counts = defaultdict(int)
    candidate_counts = defaultdict(int)
    for row in rows:
        blocker_counts[row.get("blocker_type") or ""] += 1
        candidate_counts[row.get("target_candidate_type") or ""] += 1

    columns = [
        "Dashboard",
        "Source dataset",
        "Blocker type",
        "Target candidate",
        "Recommendation",
    ]
    lines = ["# QuickSight Migration Matrix", ""]
    lines.append("## Scan Summary")
    lines.append("")
    for key, value in summary.items():
        lines.append(f"- {key}: {value}")
    lines.append("")
    lines.append("## Blocker Summary")
    lines.append("")
    for key, value in sorted(blocker_counts.items()):
        lines.append(f"- {key or 'blank'}: {value}")
    lines.append("")
    lines.append("## Target Candidate Summary")
    lines.append("")
    for key, value in sorted(candidate_counts.items()):
        lines.append(f"- {key or 'blank'}: {value}")
    lines.append("")
    lines.append("## Matrix")
    lines.append("")
    lines.append("| " + " | ".join(columns) + " |")
    lines.append("| " + " | ".join("---" for _ in columns) + " |")
    for row in rows:
        candidate = row.get("target_dataset_name") or row.get("bif_risk_dataset") or row.get(
            "target_candidate_type"
        )
        source_dataset = row.get("source_dataset_name") or row.get("source_dataset_identifier") or row.get(
            "source_dataset_id"
        )
        values = [
            row.get("dashboard_name"),
            source_dataset,
            row.get("blocker_type"),
            candidate,
            row.get("recommendation"),
        ]
        lines.append("| " + " | ".join(markdown_cell(value) for value in values) + " |")
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def markdown_cell(value):
    text = stringify(value)
    return text.replace("|", "\\|").replace("\n", " ")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build dashboard-to-dataset migration matrix for QuickSight."
    )
    parser.add_argument("--source-scan", required=True, help="Path to source dashboard_exportability_scan.json")
    parser.add_argument("--target-inventory", required=True, help="Path to target_inventory.json")
    parser.add_argument(
        "--bif-risk-root",
        default="../bif-risk",
        help="Path to bif-risk repo root, used for repo-managed dataset candidates",
    )
    parser.add_argument(
        "--dashboard-status-csv",
        help="Optional dashboard_exportability_by_status.csv to enrich statuses",
    )
    parser.add_argument(
        "--dataset-blockers-csv",
        help="Optional dataset_export_blockers.csv to add missing/file-source/S3 blocker rows",
    )
    parser.add_argument(
        "--output-dir",
        help="Output directory. Defaults to the source scan folder.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    source_scan_path = Path(args.source_scan)
    target_inventory_path = Path(args.target_inventory)
    output_dir = Path(args.output_dir) if args.output_dir else source_scan_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)

    source_scan = read_json(source_scan_path)
    target_inventory = read_json(target_inventory_path)
    bif_risk_datasets = load_bif_risk_datasets(args.bif_risk_root)
    dashboard_status_rows = read_csv(args.dashboard_status_csv)
    blocker_rows = read_csv(args.dataset_blockers_csv)

    rows = build_matrix(
        source_scan,
        target_inventory,
        bif_risk_datasets,
        dashboard_status_rows,
        blocker_rows,
    )
    fieldnames = [
        "dashboard_name",
        "dashboard_id",
        "dashboard_status",
        "dashboard_issue_summary",
        "source_dataset_name",
        "source_dataset_id",
        "source_dataset_identifier",
        "source_import_mode",
        "source_data_sources",
        "blocker_type",
        "blocker_detail",
        "target_candidate_type",
        "target_dataset_name",
        "target_dataset_id",
        "target_dataset_arn",
        "bif_risk_dataset",
        "bif_risk_table_refs",
        "recommendation",
    ]

    write_json(
        output_dir / "migration_matrix.json",
        {
            "source_scan": str(source_scan_path),
            "target_inventory": str(target_inventory_path),
            "bif_risk_root": args.bif_risk_root,
            "row_count": len(rows),
            "rows": rows,
        },
    )
    write_csv(output_dir / "migration_matrix.csv", rows, fieldnames)
    write_markdown(
        output_dir / "migration_matrix.md",
        rows,
        source_scan,
        target_inventory,
        len(bif_risk_datasets),
    )

    print(f"Migration matrix rows: {len(rows)}", flush=True)
    print(f"Migration matrix CSV: {output_dir / 'migration_matrix.csv'}", flush=True)
    print(f"Migration matrix markdown: {output_dir / 'migration_matrix.md'}", flush=True)


if __name__ == "__main__":
    main()
