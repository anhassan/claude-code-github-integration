"""
Per-dashboard dataset state evidence for the Risk migration business validation.

For each dashboard in --dashboards-file, enumerate the datasets referenced in
its central definition and report:

  * source dataset name + last_updated_time
  * central dataset name + last_updated_time + import_mode
  * last completed SPICE ingestion: row count, ingestion time, status
  * source `LastUpdatedTime` of the dashboard itself vs central

Output: one CSV row per (dashboard, dataset) covering all reported issue
themes (drawdown rows, PV staleness, country exposure freshness, etc.). The
script is read-only — only describe/list APIs.

This is the evidence pass for the post-reconcile business feedback round.
"""

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def fmt_dt(value):
    if not value:
        return ""
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def read_id_file(path):
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        resource_id, _, label = line.partition(",")
        rows.append({"id": resource_id.strip(), "label": label.strip()})
    return rows


def list_dashboard_datasets(qs, account_id, dashboard_id):
    """Return [{Identifier, DataSetArn, DataSetId}] from a central dashboard's
    DataSetIdentifierDeclarations."""
    try:
        response = qs.describe_dashboard_definition(
            AwsAccountId=account_id, DashboardId=dashboard_id
        )
    except ClientError as error:
        return None, error.response.get("Error", {})
    declarations = (
        response.get("Definition", {}).get("DataSetIdentifierDeclarations", []) or []
    )
    out = []
    for entry in declarations:
        arn = entry.get("DataSetArn") or ""
        out.append(
            {
                "identifier": entry.get("Identifier"),
                "arn": arn,
                "id": arn.rsplit("/", 1)[-1] if arn else "",
            }
        )
    return out, None


def describe_dataset(qs, account_id, dataset_id):
    try:
        return qs.describe_data_set(AwsAccountId=account_id, DataSetId=dataset_id)
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def latest_completed_ingestion(qs, account_id, dataset_id):
    """Return the most recent ingestion with row counts, or None."""
    try:
        response = qs.list_ingestions(AwsAccountId=account_id, DataSetId=dataset_id)
    except ClientError as error:
        return None, error.response.get("Error", {})
    ingestions = response.get("Ingestions", []) or []
    if not ingestions:
        return None, None
    # list_ingestions returns most-recent-first; first COMPLETED one wins.
    for ing in ingestions:
        if ing.get("IngestionStatus") == "COMPLETED":
            return ing, None
    return ingestions[0], None


def find_source_dataset_by_name(qs, account_id, name, cache):
    """Find a dataset in the source account by name (since IDs in source vs
    central differ for the same logical dataset). Uses a simple list cache."""
    if cache.get("loaded"):
        return cache.get(name)
    items = []
    next_token = None
    while True:
        kwargs = {"AwsAccountId": account_id}
        if next_token:
            kwargs["NextToken"] = next_token
        try:
            response = qs.list_data_sets(**kwargs)
        except ClientError:
            break
        items.extend(response.get("DataSetSummaries", []) or [])
        next_token = response.get("NextToken")
        if not next_token:
            break
    by_name = {}
    for item in items:
        nm = item.get("Name") or ""
        # last write wins on duplicate names (rare)
        by_name[nm] = item
    cache["loaded"] = True
    cache.update(by_name)
    return cache.get(name)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Per-dashboard dataset state evidence (read-only)."
    )
    parser.add_argument("--source-profile", required=True)
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--source-account-id", default="840529182937")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument(
        "--dashboards-file",
        default="exports/risk-dashboard-migration/migrated_dashboard_ids.txt",
    )
    parser.add_argument(
        "--output-root",
        default="exports/risk-dashboard-migration",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    source_session = session_for(args.source_profile, args.region)
    target_session = session_for(args.target_profile, args.region)
    source_qs = source_session.client("quicksight", region_name=args.region)
    target_qs = target_session.client("quicksight", region_name=args.region)

    dashboards = read_id_file(args.dashboards_file)
    print(f"Auditing dataset state for {len(dashboards)} dashboards", flush=True)

    source_dataset_cache = {}
    rows = []
    for entry in dashboards:
        dashboard_id = entry["id"]
        label = entry["label"]
        # Source dashboard version + LastUpdatedTime
        source_dash_info = {}
        try:
            sdash = source_qs.describe_dashboard(
                AwsAccountId=args.source_account_id, DashboardId=dashboard_id
            )
            sd = sdash.get("Dashboard", {}) or {}
            source_dash_info = {
                "source_last_updated": fmt_dt(sd.get("LastUpdatedTime")),
                "source_latest_version": (sd.get("Version") or {}).get("VersionNumber"),
            }
        except ClientError as error:
            source_dash_info = {"source_error": error.response.get("Error", {}).get("Code")}

        try:
            tdash = target_qs.describe_dashboard(
                AwsAccountId=args.target_account_id, DashboardId=dashboard_id
            )
            td = tdash.get("Dashboard", {}) or {}
            central_dash_info = {
                "central_last_updated": fmt_dt(td.get("LastUpdatedTime")),
                "central_latest_version": (td.get("Version") or {}).get("VersionNumber"),
            }
        except ClientError as error:
            central_dash_info = {"central_error": error.response.get("Error", {}).get("Code")}

        datasets, ds_error = list_dashboard_datasets(
            target_qs, args.target_account_id, dashboard_id
        )
        if ds_error:
            rows.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_label": label,
                    **source_dash_info,
                    **central_dash_info,
                    "dataset_error": ds_error.get("Code"),
                }
            )
            print(f"  [{label}] dataset list error: {ds_error.get('Code')}", flush=True)
            continue

        for ds in datasets:
            central_id = ds["id"]
            row = {
                "dashboard_id": dashboard_id,
                "dashboard_label": label,
                **source_dash_info,
                **central_dash_info,
                "dataset_identifier": ds["identifier"],
                "central_dataset_id": central_id,
            }

            central_desc = describe_dataset(target_qs, args.target_account_id, central_id)
            if "_error" in central_desc:
                row["central_dataset_status"] = "MISSING"
                row["central_dataset_error"] = central_desc["_error"].get("Code")
            else:
                cds = central_desc.get("DataSet", {}) or {}
                row["central_dataset_name"] = cds.get("Name")
                row["central_dataset_last_updated"] = fmt_dt(cds.get("LastUpdatedTime"))
                row["central_dataset_import_mode"] = cds.get("ImportMode")
                row["central_dataset_consumed_spice_bytes"] = cds.get(
                    "ConsumedSpiceCapacityInBytes"
                )

                ingestion, ing_error = latest_completed_ingestion(
                    target_qs, args.target_account_id, central_id
                )
                if ingestion:
                    row["latest_ingestion_status"] = ingestion.get("IngestionStatus")
                    row["latest_ingestion_time"] = fmt_dt(ingestion.get("CreatedTime"))
                    row["latest_ingestion_rows"] = (
                        ingestion.get("RowInfo", {}) or {}
                    ).get("RowsIngested")

            # Try to find the source dataset by name and capture its LastUpdatedTime
            name_to_find = row.get("central_dataset_name") or ds["identifier"]
            try:
                src_summary = find_source_dataset_by_name(
                    source_qs,
                    args.source_account_id,
                    name_to_find,
                    source_dataset_cache,
                )
                if src_summary and "DataSetId" in src_summary:
                    row["source_dataset_id"] = src_summary.get("DataSetId")
                    row["source_dataset_last_updated"] = fmt_dt(
                        src_summary.get("LastUpdatedTime")
                    )
                    row["source_dataset_import_mode"] = src_summary.get("ImportMode")
            except Exception as error:
                row["source_dataset_lookup_error"] = str(error)

            rows.append(row)

        print(
            f"  [{label}] {len(datasets)} datasets",
            flush=True,
        )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_root) / f"dataset-evidence-{run_id}"
    write_csv(
        out_dir / "dataset_evidence.csv",
        rows,
        [
            "dashboard_id",
            "dashboard_label",
            "source_last_updated",
            "source_latest_version",
            "central_last_updated",
            "central_latest_version",
            "dataset_identifier",
            "central_dataset_id",
            "central_dataset_name",
            "central_dataset_status",
            "central_dataset_error",
            "central_dataset_last_updated",
            "central_dataset_import_mode",
            "central_dataset_consumed_spice_bytes",
            "latest_ingestion_status",
            "latest_ingestion_time",
            "latest_ingestion_rows",
            "source_dataset_id",
            "source_dataset_last_updated",
            "source_dataset_import_mode",
            "source_dataset_lookup_error",
            "source_error",
            "central_error",
            "dataset_error",
        ],
    )
    print(f"Evidence: {out_dir}/dataset_evidence.csv", flush=True)


if __name__ == "__main__":
    main()
