"""
Scan QuickSight dashboards for asset-bundle export blockers.

By default this does a read-only dependency scan. Use --run-export-jobs when you
need AWS to prove exportability by starting asset-bundle export jobs.
"""

import argparse
import json
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import boto3

from export_qs_bundle_for_review import (
    FAILED_STATUSES,
    SUCCESS_STATUS,
    collect_values_for_key,
    describe_dashboard,
    describe_dataset,
    describe_data_source,
    get_session,
    slugify,
    start_export_job,
    wait_for_export_job,
    write_json,
    AssetBundleExportFailed,
)


def list_dashboards(qs_client, account_id):
    dashboards = []
    paginator = qs_client.get_paginator("list_dashboards")
    for page in paginator.paginate(AwsAccountId=account_id):
        dashboards.extend(page.get("DashboardSummaryList", []))
    return dashboards


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def get_dashboard_dataset_arns(dashboard_response):
    return (
        dashboard_response.get("Dashboard", {})
        .get("Version", {})
        .get("DataSetArns", [])
    )


def summarize_dataset(dataset_response):
    dataset = dataset_response.get("DataSet", {})
    data_source_arns = sorted(set(collect_values_for_key(dataset, "DataSourceArn")))
    s3_physical_table_ids = [
        table_id
        for table_id, table_def in dataset.get("PhysicalTableMap", {}).items()
        if "S3Source" in table_def
    ]
    return {
        "dataset_id": dataset.get("DataSetId"),
        "name": dataset.get("Name"),
        "arn": dataset.get("Arn"),
        "import_mode": dataset.get("ImportMode"),
        "data_source_arns": data_source_arns,
        "has_s3_source": bool(s3_physical_table_ids),
        "s3_physical_table_ids": s3_physical_table_ids,
    }


def summarize_data_source(data_source_response, data_source_arn):
    data_source = data_source_response.get("DataSource", {})
    params = data_source.get("DataSourceParameters") or {}
    s3_params = params.get("S3Parameters") or {}
    manifest_location = s3_params.get("ManifestFileLocation") or {}
    return {
        "data_source_id": data_source.get("DataSourceId", data_source_arn.split("/")[-1]),
        "name": data_source.get("Name"),
        "arn": data_source.get("Arn", data_source_arn),
        "type": data_source.get("Type"),
        "status": data_source.get("Status"),
        "has_manifest_file_location": bool(
            manifest_location.get("Bucket") and manifest_location.get("Key")
        ),
        "manifest_bucket": manifest_location.get("Bucket"),
        "manifest_key": manifest_location.get("Key"),
    }


def dependency_scan(qs_client, account_id, dashboards):
    dashboard_rows = []
    dataset_map = {}
    data_source_map = {}
    dataset_dashboards = defaultdict(list)
    data_source_dashboards = defaultdict(set)
    errors = []

    for idx, dashboard_summary in enumerate(dashboards, start=1):
        dashboard_id = dashboard_summary["DashboardId"]
        print(
            f"[{idx}/{len(dashboards)}] Inspecting {dashboard_summary.get('Name')} ({dashboard_id})",
            flush=True,
        )
        try:
            dashboard_response = describe_dashboard(qs_client, account_id, dashboard_id)
            dashboard = dashboard_response["Dashboard"]
            dataset_arns = get_dashboard_dataset_arns(dashboard_response)
            dataset_ids = [arn.split("/")[-1] for arn in dataset_arns]

            for dataset_arn in dataset_arns:
                dataset_id = dataset_arn.split("/")[-1]
                dataset_dashboards[dataset_id].append(
                    {
                        "dashboard_id": dashboard_id,
                        "dashboard_name": dashboard.get("Name"),
                    }
                )
                if dataset_id not in dataset_map:
                    dataset_map[dataset_id] = summarize_dataset(
                        describe_dataset(qs_client, account_id, dataset_arn)
                    )

                for data_source_arn in dataset_map[dataset_id]["data_source_arns"]:
                    data_source_id = data_source_arn.split("/")[-1]
                    data_source_dashboards[data_source_id].add(dashboard_id)
                    if data_source_id not in data_source_map:
                        data_source_map[data_source_id] = summarize_data_source(
                            describe_data_source(qs_client, account_id, data_source_arn),
                            data_source_arn,
                        )

            s3_dataset_ids = [
                dataset_id
                for dataset_id in dataset_ids
                if dataset_map.get(dataset_id, {}).get("has_s3_source")
            ]
            s3_data_source_ids = sorted(
                {
                    data_source_arn.split("/")[-1]
                    for dataset_id in s3_dataset_ids
                    for data_source_arn in dataset_map[dataset_id]["data_source_arns"]
                    if data_source_map.get(data_source_arn.split("/")[-1], {}).get("type") == "S3"
                }
            )
            dashboard_rows.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard.get("Name"),
                    "version_number": dashboard.get("Version", {}).get("VersionNumber"),
                    "dataset_count": len(dataset_ids),
                    "dataset_ids": dataset_ids,
                    "s3_dataset_ids": sorted(s3_dataset_ids),
                    "s3_data_source_ids": s3_data_source_ids,
                    "has_s3_dependency": bool(s3_dataset_ids or s3_data_source_ids),
                }
            )
        except Exception as error:
            errors.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard_summary.get("Name"),
                    "error": str(error),
                }
            )

    for dataset_id, dataset in dataset_map.items():
        dataset["used_by_dashboard_count"] = len(dataset_dashboards[dataset_id])
        dataset["used_by_dashboards"] = dataset_dashboards[dataset_id]

    for data_source_id, data_source in data_source_map.items():
        data_source["used_by_dashboard_count"] = len(data_source_dashboards[data_source_id])
        data_source["used_by_dashboard_ids"] = sorted(data_source_dashboards[data_source_id])

    s3_datasets = [
        dataset for dataset in dataset_map.values() if dataset.get("has_s3_source")
    ]
    s3_data_sources = [
        data_source for data_source in data_source_map.values() if data_source.get("type") == "S3"
    ]
    dashboards_with_s3 = [
        dashboard for dashboard in dashboard_rows if dashboard["has_s3_dependency"]
    ]

    return {
        "dashboard_count": len(dashboard_rows),
        "dependency_scan_error_count": len(errors),
        "dashboards_with_s3_dependency_count": len(dashboards_with_s3),
        "unique_dataset_count": len(dataset_map),
        "unique_s3_dataset_count": len(s3_datasets),
        "unique_data_source_count": len(data_source_map),
        "unique_s3_data_source_count": len(s3_data_sources),
        "dashboards": dashboard_rows,
        "datasets": sorted(dataset_map.values(), key=lambda item: item.get("name") or ""),
        "s3_datasets": sorted(s3_datasets, key=lambda item: item.get("name") or ""),
        "data_sources": sorted(data_source_map.values(), key=lambda item: item.get("name") or ""),
        "s3_data_sources": sorted(s3_data_sources, key=lambda item: item.get("name") or ""),
        "errors": errors,
    }


def run_export_jobs(qs_client, account_id, region, dashboards, poll_seconds, timeout_seconds):
    export_rows = []
    failure_dataset_counter = Counter()
    failure_data_source_counter = Counter()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    for idx, dashboard in enumerate(dashboards, start=1):
        dashboard_id = dashboard["dashboard_id"]
        dashboard_name = dashboard["dashboard_name"]
        job_id = f"scan-export-{dashboard_id}-{run_id}"
        print(
            f"[{idx}/{len(dashboards)}] Export test {dashboard_name} ({dashboard_id})",
            flush=True,
        )
        try:
            start_export_job(
                qs_client,
                account_id,
                region,
                dashboard_id,
                job_id,
                include_permissions=False,
            )
            response = wait_for_export_job(
                qs_client,
                account_id,
                job_id,
                poll_seconds,
                timeout_seconds,
            )
            export_rows.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard_name,
                    "job_id": job_id,
                    "status": SUCCESS_STATUS,
                    "download_url_present": bool(response.get("DownloadUrl")),
                }
            )
        except AssetBundleExportFailed as error:
            failed_resource_arns = [
                item.get("Arn")
                for item in error.response.get("Errors", [])
                if item.get("Arn")
            ]
            failed_dataset_ids = []
            failed_data_source_ids = []
            for arn in failed_resource_arns:
                if ":dataset/" in arn:
                    dataset_id = arn.split("/")[-1]
                    failed_dataset_ids.append(dataset_id)
                    failure_dataset_counter[dataset_id] += 1
                if ":datasource/" in arn:
                    data_source_id = arn.split("/")[-1]
                    failed_data_source_ids.append(data_source_id)
                    failure_data_source_counter[data_source_id] += 1

            export_rows.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard_name,
                    "job_id": job_id,
                    "status": error.response.get("JobStatus"),
                    "errors": error.response.get("Errors", []),
                    "failed_dataset_ids": failed_dataset_ids,
                    "failed_data_source_ids": failed_data_source_ids,
                }
            )
        except Exception as error:
            export_rows.append(
                {
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard_name,
                    "job_id": job_id,
                    "status": "ERROR",
                    "error": str(error),
                }
            )

    failures = [row for row in export_rows if row["status"] != SUCCESS_STATUS]
    successes = [row for row in export_rows if row["status"] == SUCCESS_STATUS]
    return {
        "export_job_count": len(export_rows),
        "export_success_count": len(successes),
        "export_failure_count": len(failures),
        "failed_dataset_counts": dict(failure_dataset_counter),
        "failed_data_source_counts": dict(failure_data_source_counter),
        "exports": export_rows,
    }


def parse_args():
    parser = argparse.ArgumentParser(
        description="Scan QuickSight dashboards for exportability and shared blockers."
    )
    parser.add_argument("--profile", help="AWS profile to use")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--account-id", help="QuickSight AWS account id")
    parser.add_argument(
        "--output-root",
        default="exports/quicksight-account-scan",
        help="Root folder for scan output",
    )
    parser.add_argument(
        "--run-export-jobs",
        action="store_true",
        help="Actually start asset-bundle export jobs for each dashboard.",
    )
    parser.add_argument(
        "--export-only-s3-dependencies",
        action="store_true",
        help="When --run-export-jobs is set, only test dashboards with S3 dependencies.",
    )
    parser.add_argument(
        "--poll-seconds",
        type=int,
        default=10,
        help="Seconds between export status checks when --run-export-jobs is set.",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=1800,
        help="Maximum seconds to wait for each export job.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    session = get_session(args.profile, args.region)
    qs_client = session.client("quicksight", region_name=args.region)

    account_id = args.account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = Path(args.output_root) / f"{account_id}-{run_id}"
    output_dir.mkdir(parents=True, exist_ok=True)

    dashboards = list_dashboards(qs_client, account_id)
    scan = dependency_scan(qs_client, account_id, dashboards)
    result = {
        "scan_type": "quicksight_dashboard_exportability",
        "profile": args.profile,
        "region": args.region,
        "account_id": account_id,
        "caller_identity": caller_identity,
        "created_at": run_id,
        "run_export_jobs": args.run_export_jobs,
        "dashboard_summary_count": len(dashboards),
        "dependency_described_dashboard_count": scan["dashboard_count"],
        **scan,
    }
    write_json(output_dir / "dependency_scan_partial.json", result)
    print(f"Dependency scan written: {output_dir / 'dependency_scan_partial.json'}", flush=True)

    if args.run_export_jobs:
        export_dashboards = result["dashboards"]
        if args.export_only_s3_dependencies:
            export_dashboards = [
                dashboard
                for dashboard in export_dashboards
                if dashboard["has_s3_dependency"]
            ]
        result["export_jobs"] = run_export_jobs(
            qs_client,
            account_id,
            args.region,
            export_dashboards,
            args.poll_seconds,
            args.timeout_seconds,
        )

    write_json(output_dir / "dashboard_exportability_scan.json", result)

    csv_path = output_dir / "dashboard_exportability_scan.csv"
    with csv_path.open("w", encoding="utf-8") as file:
        file.write(
            "dashboard_id,dashboard_name,dataset_count,has_s3_dependency,s3_dataset_count,s3_data_source_count\n"
        )
        for dashboard in result["dashboards"]:
            file.write(
                "{},{},{},{},{},{}\n".format(
                    dashboard["dashboard_id"],
                    json.dumps(dashboard["dashboard_name"]),
                    dashboard["dataset_count"],
                    dashboard["has_s3_dependency"],
                    len(dashboard["s3_dataset_ids"]),
                    len(dashboard["s3_data_source_ids"]),
                )
            )

    print(f"Dashboard summaries listed: {result['dashboard_summary_count']}", flush=True)
    print(f"Dashboards dependency-described: {result['dependency_described_dashboard_count']}", flush=True)
    print(f"Dashboard dependency errors: {result['dependency_scan_error_count']}", flush=True)
    print(f"Dashboards with S3 dependencies: {result['dashboards_with_s3_dependency_count']}", flush=True)
    print(f"Unique datasets: {result['unique_dataset_count']}", flush=True)
    print(f"Unique S3 datasets: {result['unique_s3_dataset_count']}", flush=True)
    print(f"Unique S3 data sources: {result['unique_s3_data_source_count']}", flush=True)
    if args.run_export_jobs:
        export_jobs = result["export_jobs"]
        print(f"Export successes: {export_jobs['export_success_count']}", flush=True)
        print(f"Export failures: {export_jobs['export_failure_count']}", flush=True)
    print(f"Scan folder: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
