"""
End-to-end verification of the Risk dashboard migration.

For every dashboard ID in `migrated_dashboard_ids.txt` and every analysis ID in
`migrated_analysis_ids.txt`, this script reports:

  * existence in source (840529182937, read-only) and central (200967598245)
  * Name and LastUpdatedTime in both accounts, to spot drift
  * version numbers, latest published vs current
  * permissions in central — whether AWS_SSO_QS_AUTHOR_RISK is granted
  * folder membership in central — whether the resource is in bif-risk-dev
  * for dashboards: SourceEntityArn (which analysis backs the published version)
  * a per-row `verdict` summarizing the row: OK / DRIFT / MISSING / NO_GRANT /
    NOT_IN_FOLDER (multiple verdicts are joined with `|`)

The script is read-only — it never calls update/create/delete APIs. Use this
to confirm a clean post-reconcile state, or to find what still needs work.
"""

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


def write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
        f.write("\n")


def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def read_id_file(path):
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        resource_id, _, label = line.partition(",")
        rows.append({"id": resource_id.strip(), "label": label.strip()})
    return rows


def list_folder_member_ids(qs, account_id, folder_id):
    member_arns = []
    next_token = None
    while True:
        kwargs = {"AwsAccountId": account_id, "FolderId": folder_id}
        if next_token:
            kwargs["NextToken"] = next_token
        try:
            response = qs.list_folder_members(**kwargs)
        except ClientError as error:
            return None, error.response.get("Error", {})
        member_arns.extend(response.get("FolderMemberList", []) or [])
        next_token = response.get("NextToken")
        if not next_token:
            break
    member_ids = {(m.get("MemberArn") or "").rsplit("/", 1)[-1] for m in member_arns}
    return member_ids, None


def safe_describe_dashboard(qs, account_id, dashboard_id):
    try:
        return qs.describe_dashboard(AwsAccountId=account_id, DashboardId=dashboard_id)
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def safe_describe_dashboard_permissions(qs, account_id, dashboard_id):
    try:
        return qs.describe_dashboard_permissions(
            AwsAccountId=account_id, DashboardId=dashboard_id
        )
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def safe_describe_analysis(qs, account_id, analysis_id):
    try:
        return qs.describe_analysis(AwsAccountId=account_id, AnalysisId=analysis_id)
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def safe_describe_analysis_permissions(qs, account_id, analysis_id):
    try:
        return qs.describe_analysis_permissions(
            AwsAccountId=account_id, AnalysisId=analysis_id
        )
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def principals_grant_owner(perms_response, owner_principal_arn):
    if "_error" in perms_response:
        return None
    return any(
        entry.get("Principal") == owner_principal_arn
        for entry in perms_response.get("Permissions", []) or []
    )


def fmt_dt(value):
    if not value:
        return ""
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


def audit_dashboards(
    rows,
    source_qs,
    target_qs,
    source_account,
    target_account,
    region,
    folder_member_ids,
    owner_group,
):
    owner_arn = f"arn:aws:quicksight:{region}:{target_account}:group/default/{owner_group}"
    audited = []
    for row in rows:
        dashboard_id = row["id"]
        record = {
            "kind": "dashboard",
            "id": dashboard_id,
            "label": row["label"],
        }

        source_desc = safe_describe_dashboard(source_qs, source_account, dashboard_id)
        if "_error" in source_desc:
            record["source_status"] = "MISSING"
            record["source_error"] = source_desc["_error"]
        else:
            src = source_desc.get("Dashboard", {}) or {}
            record["source_status"] = "OK"
            record["source_name"] = src.get("Name")
            record["source_last_updated"] = fmt_dt(src.get("LastUpdatedTime"))
            ver = src.get("Version", {}) or {}
            record["source_latest_version"] = ver.get("VersionNumber")
            record["source_source_entity_arn"] = ver.get("SourceEntityArn")

        target_desc = safe_describe_dashboard(target_qs, target_account, dashboard_id)
        if "_error" in target_desc:
            record["central_status"] = "MISSING"
            record["central_error"] = target_desc["_error"]
        else:
            ctr = target_desc.get("Dashboard", {}) or {}
            record["central_status"] = "OK"
            record["central_name"] = ctr.get("Name")
            record["central_last_updated"] = fmt_dt(ctr.get("LastUpdatedTime"))
            ver = ctr.get("Version", {}) or {}
            record["central_latest_version"] = ver.get("VersionNumber")
            record["central_version_status"] = ver.get("Status")
            record["central_source_entity_arn"] = ver.get("SourceEntityArn")

            perms = safe_describe_dashboard_permissions(target_qs, target_account, dashboard_id)
            if "_error" in perms:
                record["owner_grant"] = None
                record["central_principals"] = []
                record["permissions_error"] = perms["_error"]
            else:
                record["owner_grant"] = any(
                    entry.get("Principal") == owner_arn
                    for entry in perms.get("Permissions", []) or []
                )
                record["central_principals"] = [
                    entry.get("Principal") for entry in perms.get("Permissions", []) or []
                ]

            if folder_member_ids is None:
                record["in_folder"] = None
            else:
                record["in_folder"] = dashboard_id in folder_member_ids

        verdicts = []
        if record.get("central_status") != "OK":
            verdicts.append("MISSING_IN_CENTRAL")
        else:
            if record.get("owner_grant") is False:
                verdicts.append("NO_OWNER_GRANT")
            if record.get("in_folder") is False:
                verdicts.append("NOT_IN_FOLDER")
            if record.get("source_status") == "OK":
                # Drift signal: source updated noticeably after central
                src_dt = record.get("source_last_updated") or ""
                ctr_dt = record.get("central_last_updated") or ""
                if src_dt and ctr_dt and src_dt > ctr_dt:
                    verdicts.append("SOURCE_NEWER")
        record["verdict"] = "|".join(verdicts) if verdicts else "OK"
        audited.append(record)
    return audited


def audit_analyses(
    rows,
    target_qs,
    target_account,
    region,
    folder_member_ids,
    owner_group,
):
    owner_arn = f"arn:aws:quicksight:{region}:{target_account}:group/default/{owner_group}"
    audited = []
    for row in rows:
        analysis_id = row["id"]
        record = {
            "kind": "analysis",
            "id": analysis_id,
            "label": row["label"],
        }
        desc = safe_describe_analysis(target_qs, target_account, analysis_id)
        if "_error" in desc:
            record["central_status"] = "MISSING"
            record["central_error"] = desc["_error"]
            record["verdict"] = "MISSING_IN_CENTRAL"
            audited.append(record)
            continue
        analysis = desc.get("Analysis", {}) or {}
        record["central_status"] = analysis.get("Status")
        record["central_name"] = analysis.get("Name")
        record["central_last_updated"] = fmt_dt(analysis.get("LastUpdatedTime"))

        perms = safe_describe_analysis_permissions(target_qs, target_account, analysis_id)
        if "_error" in perms:
            record["owner_grant"] = None
            record["central_principals"] = []
        else:
            record["owner_grant"] = any(
                entry.get("Principal") == owner_arn
                for entry in perms.get("Permissions", []) or []
            )
            record["central_principals"] = [
                entry.get("Principal") for entry in perms.get("Permissions", []) or []
            ]

        if folder_member_ids is None:
            record["in_folder"] = None
        else:
            record["in_folder"] = analysis_id in folder_member_ids

        verdicts = []
        if record.get("owner_grant") is False:
            verdicts.append("NO_OWNER_GRANT")
        if record.get("in_folder") is False:
            verdicts.append("NOT_IN_FOLDER")
        if record.get("central_status") not in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
            verdicts.append(f"STATUS:{record.get('central_status')}")
        record["verdict"] = "|".join(verdicts) if verdicts else "OK"
        audited.append(record)
    return audited


def parse_args():
    parser = argparse.ArgumentParser(
        description="Verify Risk migration state across source + central QuickSight."
    )
    parser.add_argument("--source-profile", required=True)
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--source-account-id", default="840529182937")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument(
        "--dashboards-file",
        default="exports/risk-dashboard-migration/migrated_dashboard_ids.txt",
    )
    parser.add_argument(
        "--analyses-file",
        default="exports/risk-dashboard-migration/migrated_analysis_ids.txt",
    )
    parser.add_argument("--owner-group", default="AWS_SSO_QS_AUTHOR_RISK")
    parser.add_argument("--folder-id", default="bif-risk-dev")
    parser.add_argument(
        "--output-root",
        default="exports/risk-dashboard-migration",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    source_session = session_for(args.source_profile, args.region)
    target_session = session_for(args.target_profile, args.region)
    source_qs = source_session.client("quicksight", region_name=args.region)
    target_qs = target_session.client("quicksight", region_name=args.region)

    dashboards = read_id_file(args.dashboards_file)
    analyses = read_id_file(args.analyses_file)
    print(
        f"Auditing {len(dashboards)} dashboards and {len(analyses)} analyses",
        flush=True,
    )

    folder_member_ids, folder_error = list_folder_member_ids(
        target_qs, args.target_account_id, args.folder_id
    )
    if folder_error:
        print(f"WARNING: list_folder_members failed for {args.folder_id}: {folder_error}", flush=True)

    dashboard_records = audit_dashboards(
        dashboards,
        source_qs,
        target_qs,
        args.source_account_id,
        args.target_account_id,
        args.region,
        folder_member_ids,
        args.owner_group,
    )
    analysis_records = audit_analyses(
        analyses,
        target_qs,
        args.target_account_id,
        args.region,
        folder_member_ids,
        args.owner_group,
    )

    for record in dashboard_records + analysis_records:
        print(
            f"  [{record['kind']:9}] {record['id'][:36]:36} {record['verdict']:30} {record.get('label','')[:50]}",
            flush=True,
        )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_root) / f"verify-{run_id}"
    write_json(
        out_dir / "verify.json",
        {
            "source_account_id": args.source_account_id,
            "target_account_id": args.target_account_id,
            "region": args.region,
            "owner_group": args.owner_group,
            "folder_id": args.folder_id,
            "dashboards": dashboard_records,
            "analyses": analysis_records,
        },
    )
    dashboard_csv_rows = []
    for record in dashboard_records:
        dashboard_csv_rows.append(
            {
                "id": record.get("id"),
                "label": record.get("label"),
                "source_status": record.get("source_status"),
                "source_name": record.get("source_name"),
                "source_last_updated": record.get("source_last_updated"),
                "source_latest_version": record.get("source_latest_version"),
                "central_status": record.get("central_status"),
                "central_name": record.get("central_name"),
                "central_last_updated": record.get("central_last_updated"),
                "central_latest_version": record.get("central_latest_version"),
                "central_version_status": record.get("central_version_status"),
                "central_source_entity_arn": record.get("central_source_entity_arn"),
                "owner_grant": record.get("owner_grant"),
                "in_folder": record.get("in_folder"),
                "verdict": record.get("verdict"),
            }
        )
    write_csv(
        out_dir / "verify_dashboards.csv",
        dashboard_csv_rows,
        [
            "id",
            "label",
            "source_status",
            "source_name",
            "source_last_updated",
            "source_latest_version",
            "central_status",
            "central_name",
            "central_last_updated",
            "central_latest_version",
            "central_version_status",
            "central_source_entity_arn",
            "owner_grant",
            "in_folder",
            "verdict",
        ],
    )
    analysis_csv_rows = []
    for record in analysis_records:
        analysis_csv_rows.append(
            {
                "id": record.get("id"),
                "label": record.get("label"),
                "central_status": record.get("central_status"),
                "central_name": record.get("central_name"),
                "central_last_updated": record.get("central_last_updated"),
                "owner_grant": record.get("owner_grant"),
                "in_folder": record.get("in_folder"),
                "verdict": record.get("verdict"),
            }
        )
    write_csv(
        out_dir / "verify_analyses.csv",
        analysis_csv_rows,
        [
            "id",
            "label",
            "central_status",
            "central_name",
            "central_last_updated",
            "owner_grant",
            "in_folder",
            "verdict",
        ],
    )
    print(f"Verify output: {out_dir}", flush=True)


if __name__ == "__main__":
    main()
