"""
Strip latent structural bugs from migrated central QuickSight dashboards +
analyses, then optionally call rewrite_parsedate_calc_fields on the cleaned
definition.

Why: ValidationStrategy.Mode=LENIENT during migration let dashboards land
with structures the validator should have rejected. update_dashboard runs
strict validation and rejects these latent bugs, blocking any subsequent
update (parseDate rewrite, future business-driven changes, etc.).

Bugs handled:

  1. CalculatedFields whose Expression references `MissingColumnId_*`
     or whose DataSetIdentifier is `MissingDataSetId_*`.
     Action: drop the calc field. Log the name + dataset.

  2. DataSetIdentifierDeclarations whose Identifier is `MissingDataSetId_*`.
     Action: drop the declaration. Log.

  3. FilterGroups whose only Filter is incomplete:
     - TopBottomFilter without AggregationSortConfigurations
     - TimeRangeFilter / DrillDownTimeRangeFilter referencing missing columns
     Action: drop the entire FilterGroup. Log.

  4. Within visuals, field-well entries (and visual SelectedFieldOptions /
     DataPathOptions) whose Column.ColumnName matches
     `MissingColumnId_*`. Action: drop those entries.

  5. VisualCustomActions whose action body has no Selected{Fields,Columns,
     FieldOptions}. Action: drop the action.

After cleanup, dry-run first (writes per-resource diff JSON). With --apply,
runs update_dashboard / update_analysis on the cleaned definition; on success,
calls update_dashboard_published_version so viewers see the result.

Important: this script DROPS broken references. Visuals that consumed missing
columns will render empty after cleanup. Once the missing dataset/column is
properly onboarded (e.g. AE_POS_RC), re-running the original migration is the
correct path to bring those visuals back.
"""

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


MISSING_COL = re.compile(r"MissingColumnId_")
MISSING_DS = re.compile(r"MissingDataSetId_")


def write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
        f.write("\n")


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def read_id_file(path):
    rows = []
    p = Path(path)
    if not p.exists():
        return rows
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        resource_id, _, label = line.partition(",")
        rows.append({"id": resource_id.strip(), "label": label.strip()})
    return rows


def contains_missing(obj):
    """Recursive check: does the JSON subtree contain a MissingColumnId_ or
    MissingDataSetId_ reference?"""
    s = json.dumps(obj, default=str)
    return bool(MISSING_COL.search(s)) or bool(MISSING_DS.search(s))


def strip_dataset_declarations(definition, removals):
    decls = definition.get("DataSetIdentifierDeclarations", []) or []
    keep = []
    for d in decls:
        ident = d.get("Identifier", "") or ""
        if MISSING_DS.search(ident):
            removals.append({"type": "dataset_decl", "identifier": ident})
        else:
            keep.append(d)
    definition["DataSetIdentifierDeclarations"] = keep


def strip_calc_fields(definition, removals):
    cfs = definition.get("CalculatedFields", []) or []
    keep = []
    for c in cfs:
        ds = c.get("DataSetIdentifier", "") or ""
        nm = c.get("Name", "") or ""
        expr = c.get("Expression", "") or ""
        if MISSING_DS.search(ds):
            removals.append({"type": "calc_field_missing_ds", "ds": ds, "name": nm})
            continue
        if MISSING_COL.search(expr):
            removals.append({"type": "calc_field_missing_col", "ds": ds, "name": nm, "expr_snippet": expr[:120]})
            continue
        keep.append(c)
    definition["CalculatedFields"] = keep


def filter_is_incomplete(filter_dict):
    """Returns reason string if filter is incomplete, else None."""
    for ftype, fdata in filter_dict.items():
        if not isinstance(fdata, dict):
            continue
        if ftype == "TopBottomFilter":
            if not fdata.get("AggregationSortConfigurations"):
                return "TopBottomFilter missing AggregationSortConfigurations"
        if ftype in {"TimeRangeFilter", "DrillDownTimeRangeFilter"}:
            col = (fdata.get("Column") or {}).get("ColumnName", "") or ""
            if MISSING_COL.search(col):
                return f"{ftype} on missing column {col}"
        col = (fdata.get("Column") or {}).get("ColumnName", "") or ""
        if MISSING_COL.search(col):
            return f"{ftype} on missing column {col}"
    return None


def strip_filter_groups(definition, removals):
    fgs = definition.get("FilterGroups", []) or []
    keep = []
    for fg in fgs:
        fid = fg.get("FilterGroupId", "")
        filters = fg.get("Filters", []) or []
        bad_filters = []
        good_filters = []
        for f in filters:
            reason = filter_is_incomplete(f)
            if reason:
                bad_filters.append((f, reason))
            else:
                good_filters.append(f)
        if not good_filters and bad_filters:
            # Entire group has only bad filters — drop
            for bf, r in bad_filters:
                removals.append({"type": "filter_group_dropped", "filter_group_id": fid, "reason": r})
            continue
        if bad_filters:
            # Keep good filters only
            for bf, r in bad_filters:
                removals.append({"type": "filter_dropped", "filter_group_id": fid, "reason": r})
            fg["Filters"] = good_filters
        keep.append(fg)
    definition["FilterGroups"] = keep


def strip_visual_internals(definition, removals):
    """Walk Sheets[*].Visuals[*] and strip:
      - field-well entries whose Column.ColumnName matches MissingColumnId_*
      - visual SelectedFieldOptions / DataPathOptions referencing missing cols
      - VisualCustomActions with no field selections
    Recursive depth-aware walk."""

    def column_name_of(obj):
        if not isinstance(obj, dict):
            return None
        col = obj.get("Column") or {}
        return col.get("ColumnName") if isinstance(col, dict) else None

    def is_field_well_entry_with_missing_col(obj):
        # field-well entries are dicts with one key whose value has a Column
        if not isinstance(obj, dict):
            return False
        if len(obj) != 1:
            return False
        inner = next(iter(obj.values()))
        col_name = column_name_of(inner)
        return bool(col_name and MISSING_COL.search(col_name))

    def walk_and_strip(parent_path, obj):
        if isinstance(obj, dict):
            for k in list(obj.keys()):
                v = obj[k]
                if isinstance(v, list):
                    # Filter list elements for known shapes
                    if k in {"DimensionFields", "MeasureFields", "Values", "Rows", "Columns", "Category", "Series",
                             "GroupBy", "SmallMultiples", "Colors", "GeospatialField", "TargetValues",
                             "AggregationSortConfigurations", "SelectedFieldOptions", "DataPathOptions",
                             "Filters", "CustomActions", "Actions"}:
                        new_list = []
                        for i, item in enumerate(v):
                            if is_field_well_entry_with_missing_col(item):
                                removals.append({
                                    "type": "field_well_entry_dropped",
                                    "path": f"{parent_path}/{k}[{i}]",
                                    "column": column_name_of(next(iter(item.values()))),
                                })
                                continue
                            # SelectedFieldOptions and DataPathOptions reference columns differently
                            if isinstance(item, dict):
                                # SelectedFieldOptions: {FieldId, ...} with a FieldId that may reference missing col
                                # DataPathOptions: {DataPathList: [{FieldId, FieldValue}]}
                                # Visual custom action: ensure has SelectedFields/SelectedColumns/SelectedFieldOptions
                                if k in {"CustomActions", "Actions"}:
                                    # walk action sub-bodies for ActionOperations
                                    action_ops = (item.get("ActionOperations") or [])
                                    keep_op = True
                                    if action_ops:
                                        for op in action_ops:
                                            for opk, opv in op.items():
                                                if opk == "FilterOperation":
                                                    sel = opv.get("SelectedFieldsConfiguration") or {}
                                                    if not (
                                                        sel.get("SelectedFields")
                                                        or sel.get("SelectedColumns")
                                                        or sel.get("SelectedFieldOptions")
                                                    ):
                                                        keep_op = False
                                                        removals.append({
                                                            "type": "custom_action_dropped",
                                                            "path": f"{parent_path}/{k}[{i}]",
                                                            "reason": "FilterOperation missing field selection",
                                                        })
                                    if not keep_op:
                                        continue
                                # Strip items that contain missing col anywhere in their subtree
                                if contains_missing(item):
                                    removals.append({
                                        "type": "list_item_dropped",
                                        "path": f"{parent_path}/{k}[{i}]",
                                        "reason": "contains MissingColumnId or MissingDataSetId",
                                    })
                                    continue
                            new_list.append(item)
                        obj[k] = new_list
                    else:
                        for i, item in enumerate(v):
                            walk_and_strip(f"{parent_path}/{k}[{i}]", item)
                elif isinstance(v, dict):
                    walk_and_strip(f"{parent_path}/{k}", v)

    sheets = definition.get("Sheets", []) or []
    for i, sh in enumerate(sheets):
        walk_and_strip(f"Sheets[{i}]", sh)


def cleanup_definition(definition):
    removals = []
    strip_dataset_declarations(definition, removals)
    strip_calc_fields(definition, removals)
    strip_filter_groups(definition, removals)
    strip_visual_internals(definition, removals)
    return definition, removals


def update_dashboard(qs, account_id, dashboard_id, name, definition, dashboard_publish_options=None, theme_arn=None):
    params = {
        "AwsAccountId": account_id,
        "DashboardId": dashboard_id,
        "Name": name,
        "Definition": definition,
    }
    if dashboard_publish_options:
        params["DashboardPublishOptions"] = dashboard_publish_options
    if theme_arn:
        params["ThemeArn"] = theme_arn
    return qs.update_dashboard(**params)


def update_analysis(qs, account_id, analysis_id, name, definition, theme_arn=None):
    params = {
        "AwsAccountId": account_id,
        "AnalysisId": analysis_id,
        "Name": name,
        "Definition": definition,
    }
    if theme_arn:
        params["ThemeArn"] = theme_arn
    return qs.update_analysis(**params)


def wait_dashboard_version(qs, account_id, dashboard_id, version_number, poll, timeout):
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = qs.describe_dashboard(AwsAccountId=account_id, DashboardId=dashboard_id, VersionNumber=int(version_number))
        s = r["Dashboard"]["Version"]["Status"]
        if s in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
            return s, r["Dashboard"]["Version"].get("Errors") or []
        if s in {"CREATION_FAILED", "UPDATE_FAILED", "DELETED"}:
            return s, r["Dashboard"]["Version"].get("Errors") or []
        time.sleep(poll)
    return "TIMEOUT", []


def wait_analysis(qs, account_id, analysis_id, poll, timeout):
    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = qs.describe_analysis(AwsAccountId=account_id, AnalysisId=analysis_id)
        s = r["Analysis"]["Status"]
        if s in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
            return s, r["Analysis"].get("Errors") or []
        if s in {"CREATION_FAILED", "UPDATE_FAILED", "DELETED"}:
            return s, r["Analysis"].get("Errors") or []
        time.sleep(poll)
    return "TIMEOUT", []


def publish_dashboard(qs, account_id, dashboard_id, version_number):
    try:
        qs.update_dashboard_published_version(
            AwsAccountId=account_id, DashboardId=dashboard_id, VersionNumber=int(version_number)
        )
        return {"status": "OK"}
    except ClientError as e:
        return {"status": "ERROR", "error": e.response.get("Error", {})}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Strip latent structural bugs from central dashboards/analyses."
    )
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument("--dashboards-file", default="exports/risk-dashboard-migration/blocked_dashboard_ids.txt")
    parser.add_argument("--analyses-file", default="exports/risk-dashboard-migration/blocked_analysis_ids.txt")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--poll-seconds", type=int, default=5)
    parser.add_argument("--timeout-seconds", type=int, default=600)
    parser.add_argument("--output-root", default="exports/risk-dashboard-migration")
    return parser.parse_args()


def main():
    args = parse_args()
    session = session_for(args.target_profile, args.region)
    qs = session.client("quicksight", region_name=args.region)

    dashboards = read_id_file(args.dashboards_file)
    analyses = read_id_file(args.analyses_file)
    print(f"Processing {len(dashboards)} dashboards + {len(analyses)} analyses", flush=True)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_root) / f"cleanup-{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)
    summary = {"dashboards": [], "analyses": []}

    for entry in dashboards:
        did = entry["id"]
        label = entry["label"]
        rec = {"id": did, "label": label}
        try:
            dash = qs.describe_dashboard(AwsAccountId=args.target_account_id, DashboardId=did)
            name = dash["Dashboard"]["Name"]
            defn = qs.describe_dashboard_definition(AwsAccountId=args.target_account_id, DashboardId=did)
            current_def = defn["Definition"]
            current_publish_options = defn.get("DashboardPublishOptions")
            current_theme_arn = defn.get("ThemeArn")
        except ClientError as e:
            rec["error"] = e.response.get("Error", {})
            summary["dashboards"].append(rec)
            print(f"  [{label}] describe failed", flush=True)
            continue

        cleaned, removals = cleanup_definition(current_def)
        rec["removal_count"] = len(removals)
        rec["removals"] = removals
        write_json(out_dir / f"dashboard-{did}-cleanup.json", rec)

        if not args.apply:
            rec["apply_result"] = {"status": "dry_run"}
            print(f"  [{label}] removals={len(removals)} dry_run", flush=True)
            summary["dashboards"].append(rec)
            continue

        try:
            resp = update_dashboard(
                qs, args.target_account_id, did, name, cleaned,
                dashboard_publish_options=current_publish_options,
                theme_arn=current_theme_arn,
            )
            rec["apply_result"] = {
                "status": "OK_API",
                "version_arn": resp.get("VersionArn"),
                "creation_status": resp.get("CreationStatus"),
            }
            ver_arn = resp.get("VersionArn", "") or ""
            ver_no = ver_arn.rsplit("/", 1)[-1] if ver_arn else ""
            if ver_no:
                status, errors = wait_dashboard_version(
                    qs, args.target_account_id, did, ver_no, args.poll_seconds, args.timeout_seconds
                )
                rec["wait_status"] = status
                rec["wait_errors"] = errors
                if status in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
                    rec["publish_result"] = publish_dashboard(qs, args.target_account_id, did, ver_no)
        except ClientError as e:
            rec["apply_result"] = {"status": "ERROR", "error": e.response.get("Error", {})}
        except Exception as e:
            rec["apply_result"] = {"status": "ERROR", "error_type": type(e).__name__, "error_message": str(e)[:1000]}

        write_json(out_dir / f"dashboard-{did}-cleanup.json", rec)
        summary["dashboards"].append(rec)
        print(
            f"  [{label}] removals={len(removals)} apply={rec['apply_result'].get('status')} wait={rec.get('wait_status')}",
            flush=True,
        )

    for entry in analyses:
        aid = entry["id"]
        label = entry["label"]
        rec = {"id": aid, "label": label}
        try:
            an = qs.describe_analysis(AwsAccountId=args.target_account_id, AnalysisId=aid)
            name = an["Analysis"]["Name"]
            defn = qs.describe_analysis_definition(AwsAccountId=args.target_account_id, AnalysisId=aid)
            current_def = defn["Definition"]
            theme_arn = defn.get("ThemeArn")
        except ClientError as e:
            rec["error"] = e.response.get("Error", {})
            summary["analyses"].append(rec)
            print(f"  [analysis {label}] describe failed", flush=True)
            continue

        cleaned, removals = cleanup_definition(current_def)
        rec["removal_count"] = len(removals)
        rec["removals"] = removals
        write_json(out_dir / f"analysis-{aid}-cleanup.json", rec)

        if not args.apply:
            rec["apply_result"] = {"status": "dry_run"}
            print(f"  [analysis {label}] removals={len(removals)} dry_run", flush=True)
            summary["analyses"].append(rec)
            continue

        try:
            resp = update_analysis(qs, args.target_account_id, aid, name, cleaned, theme_arn=theme_arn)
            rec["apply_result"] = {"status": "OK_API", "arn": resp.get("Arn"), "update_status": resp.get("UpdateStatus")}
            status, errors = wait_analysis(qs, args.target_account_id, aid, args.poll_seconds, args.timeout_seconds)
            rec["wait_status"] = status
            rec["wait_errors"] = errors
        except ClientError as e:
            rec["apply_result"] = {"status": "ERROR", "error": e.response.get("Error", {})}
        except Exception as e:
            rec["apply_result"] = {"status": "ERROR", "error_type": type(e).__name__, "error_message": str(e)[:1000]}

        write_json(out_dir / f"analysis-{aid}-cleanup.json", rec)
        summary["analyses"].append(rec)
        print(
            f"  [analysis {label}] removals={len(removals)} apply={rec['apply_result'].get('status')} wait={rec.get('wait_status')}",
            flush=True,
        )

    write_json(out_dir / "summary.json", summary)
    print(f"Output: {out_dir}", flush=True)


if __name__ == "__main__":
    main()
