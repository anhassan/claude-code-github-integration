import boto3
from pprint import pprint

qs_client = boto3.client("quicksight",region_name="us-east-1")

def ls_ds(next_token="",aws_account_id=""):
    """List all the datasets in a given aws account"""

    args = {
        "AwsAccountId" : aws_account_id
    }
    if next_token:
        args["NextToken"] = next_token
    
    ds_list = qs_client.list_data_sets(**args)
    return ds_list

def get_ds_from_response(ds_metadata):
    """Get Dataset Arn, Id and Name from a list of all the datesets provided"""

    return [ [ds["Arn"],ds["DataSetId"],ds["Name"]] for ds in ds_metadata["DataSetSummaries"]]

def get_dataset_details(dataset_name,aws_account_id="207662059077"):
    """Get Dataset Arn, Id given a Dataset name"""
    all_ds = []
    ds_metadata = ls_ds("",aws_account_id)
    all_ds += get_ds_from_response(ds_metadata)

    while ds_metadata.get('NextToken',''):
        ds_metadata = ls_ds(ds_metadata['NextToken'],aws_account_id)
        all_ds += get_ds_from_response(ds_metadata)
    
    ds_details = [ds for ds in all_ds if ds[2] == dataset_name]
    if ds_details:
        return ds_details
    return None
    

pprint(get_dataset_details("composite_ds_pipeline"))