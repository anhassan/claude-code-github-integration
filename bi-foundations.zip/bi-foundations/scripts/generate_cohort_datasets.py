"""Generate bif-risk dataset folders for the SSG/EPM/ARS/TPR cohort.

Reads source dataset dumps from ~/.tmp/cohort_source_dump and writes
metadata.yaml + s3_manifest.yaml (for S3) or metadata.yaml + query.sql
(for Athena) into c:/Users/nabed/workspace/bi/bif-risk/dev/datasets/<slug>/.

Schemas come from source PhysicalTableMap.InputColumns merged with
LogicalTableMap.CastColumnTypeOperation transforms. CastColumnTypeOperation
Format hints are emitted as dict-style metadata entries to drive the
bi-foundations publisher's per-column Format handling (see PtT precedent).

CreateColumnsOperation handling:
  - Athena (CustomSql): push the ifelse logic into the CustomSql wrapper.
    The publisher's CustomSql is the authoritative source-of-truth.
  - S3 (managed S3 source): cannot compute in the loader. We emit
    a TODO list to STDERR; the caller must decide per dataset whether
    to (a) skip the column and replace via dashboard-side calc fields,
    or (b) defer provisioning until the publisher gains computed-column
    support.
"""
import json
import os
import re
import sys
from pathlib import Path

BIF_RISK_DATASETS = Path("c:/Users/nabed/workspace/bi/bif-risk/dev/datasets")
DUMP_DIR = Path(os.path.expanduser("~/.tmp/cohort_source_dump"))

S3_DATASETS = {
    "vol_dv01":             ("Vol_DV01",            "s3://cppib-awb-prod-ir-shared/daily_production/Murex_Greeks/QuickSight/Murex_dv01.csv"),
    "vol_greeks":           ("Vol_Greeks",          "s3://cppib-awb-prod-ir-shared/daily_production/Murex_Greeks/QuickSight/Greeks_Data_vol.csv"),
    "vol_greeks_upt":       ("Vol_Greeks_upt",      "s3://cppib-awb-prod-ir-shared/daily_production/Murex_Greeks/QuickSight/Greeks_Data_vol.csv"),
    "ssg_correlation":      ("SSG_Correlation",     "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/Correlation.csv"),
    "ssg_rc":               ("SSG_RC",              "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/SSG_RC.csv"),
    "cmf_ssg_risk_by_type": ("CMF_SSG_RiskByType",  "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/SSG_Risk_by_Type.csv"),
    "epm_supplementary":    ("EPM Dashboard",       "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/EPM_Supplementary_data.csv"),
    "iodp":                 ("IODP",                "s3://cppib-awb-prod-ir-shared/daily_production/CMF/EPM Dashboard/QuickSight/IODP.csv"),
}

ATHENA_DATASETS = {
    "rmv_analytics_tpr": "rmv_analytics_tpr",
    "limit_sql":         "limit_sql",
}


def collect_transforms(ltm):
    casts = {}
    creates = []
    for _, logical in ltm.items():
        for t in logical.get("DataTransforms", []):
            cast = t.get("CastColumnTypeOperation")
            if cast:
                col = cast["ColumnName"]
                new_type = cast["NewColumnType"]
                sub = cast.get("SubType")
                fmt = cast.get("Format")
                full_type = f"{new_type}.{sub}" if sub else new_type
                casts[col] = (full_type, fmt)
            create = t.get("CreateColumnsOperation")
            if create:
                for col in create["Columns"]:
                    creates.append({"name": col["ColumnName"], "expr": col["Expression"]})
    return casts, creates


def build_columns(ptm, ltm):
    casts, _ = collect_transforms(ltm)
    cols = {}
    for _, physical in ptm.items():
        src = physical.get("S3Source") or physical.get("CustomSql") or physical.get("RelationalTable") or {}
        for c in src.get("InputColumns", []) or src.get("Columns", []):
            name = c["Name"]
            if name in casts:
                cols[name] = casts[name]
            else:
                cols[name] = (c["Type"], None)
    return cols


def get_s3_upload_settings(ptm):
    for _, physical in ptm.items():
        if "S3Source" in physical:
            us = physical["S3Source"]["UploadSettings"]
            return {
                "format": us.get("Format", "CSV"),
                "start_from_row": us.get("StartFromRow", 1),
                "contains_header": us.get("ContainsHeader", True),
                "text_qualifier": us.get("TextQualifier", "DOUBLE_QUOTE"),
                "delimiter": us.get("Delimiter", ","),
            }
    return None


def quote_name(name):
    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name):
        return name
    return f'"{name}"'


def render_column_entry(name, type_spec):
    full_type, fmt = type_spec
    key = quote_name(name)
    if fmt:
        return f'  {key}: {{type: {full_type}, format: "{fmt}"}}'
    return f"  {key}: {full_type}"


def write_s3_dataset(slug, central_name, s3_uri):
    payload = json.loads((DUMP_DIR / f"{slug}.json").read_text())
    cols = build_columns(payload["PhysicalTableMap"], payload["LogicalTableMap"])
    _, creates = collect_transforms(payload["LogicalTableMap"])
    us = get_s3_upload_settings(payload["PhysicalTableMap"])
    if us is None:
        raise RuntimeError(f"{slug}: no S3Source upload settings")

    if creates:
        print(
            f"  WARN {slug}: source has {len(creates)} computed column(s) "
            f"not migrated: {[c['name'] for c in creates]}",
            file=sys.stderr,
        )

    dest = BIF_RISK_DATASETS / slug
    dest.mkdir(parents=True, exist_ok=True)
    ds_id = f"awb-{slug.replace('_', '-')}-s3-source"

    lines = [
        f"name: {central_name}",
        "import_mode: SPICE",
        "force_sync: true",
        "workspaces:",
        "  - bif-risk",
        f"data_source_id: {ds_id}",
        'dataset_source: "S3"',
        "columns:",
    ]
    for k, spec in cols.items():
        lines.append(render_column_entry(k, spec))
    (dest / "metadata.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")

    manifest_lines = [
        "data_uris:",
        f'  - "{s3_uri}"',
        "manifest_location:",
        f'  key: "bif-risk/s3-manifests/{slug}/manifest.json"',
        "upload_settings:",
        f"  format: {us['format']}",
        f"  start_from_row: {us['start_from_row']}",
        f"  contains_header: {'true' if us['contains_header'] else 'false'}",
        f'  text_qualifier: "{us["text_qualifier"]}"',
        f'  delimiter: "{us["delimiter"]}"',
    ]
    (dest / "s3_manifest.yaml").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")
    print(f"  Wrote S3 dataset: {dest}")


def write_athena_dataset(slug, central_name):
    payload = json.loads((DUMP_DIR / f"{slug}.json").read_text())
    cols = build_columns(payload["PhysicalTableMap"], payload["LogicalTableMap"])
    _, creates = collect_transforms(payload["LogicalTableMap"])

    sql = None
    for _, physical in payload["PhysicalTableMap"].items():
        if "CustomSql" in physical:
            sql = physical["CustomSql"]["SqlQuery"]
            break
        if "RelationalTable" in physical:
            rt = physical["RelationalTable"]
            cols_list = ", ".join(quote_name(c) for c in cols.keys())
            sql = f'SELECT {cols_list} FROM "{rt["Schema"]}"."{rt["Name"]}"'
            break
    if sql is None:
        raise RuntimeError(f"{slug}: no CustomSql or RelationalTable")

    if creates:
        print(
            f"  WARN {slug}: Athena dataset has {len(creates)} computed "
            f"columns. Push them into the SQL manually: {[c['name'] for c in creates]}",
            file=sys.stderr,
        )

    dest = BIF_RISK_DATASETS / slug
    dest.mkdir(parents=True, exist_ok=True)

    lines = [
        f"name: {central_name}",
        "import_mode: SPICE",
        "force_sync: true",
        "workspaces:",
        "  - bif-risk",
        "columns:",
    ]
    for k, spec in cols.items():
        lines.append(render_column_entry(k, spec))
    (dest / "metadata.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (dest / "query.sql").write_text(sql.replace("\r\n", "\n") + "\n", encoding="utf-8")
    print(f"  Wrote Athena dataset: {dest}")


def main():
    print("S3 datasets:")
    for slug, (name, uri) in S3_DATASETS.items():
        write_s3_dataset(slug, name, uri)
    print()
    print("Athena datasets:")
    for slug, name in ATHENA_DATASETS.items():
        write_athena_dataset(slug, name)


if __name__ == "__main__":
    main()
