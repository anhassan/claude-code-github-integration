"""
Build an inventory of QuickSight S3 datasets that need manifest remediation.

The source scan can tell us that a dashboard is blocked because a QuickSight
S3 data source has no ManifestFileLocation. It cannot recover the original
local manifest file. This script captures everything QuickSight can still tell
us: dataset ids/names, schemas, upload settings, source dashboards, and target
ids to use in the central account. Data owners then fill in the real S3 URIs or
URI prefixes in the generated locations template.
"""

import argparse
import csv
import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import boto3


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def read_json(path):
    with Path(path).open(encoding="utf-8") as file:
        return json.load(file)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=str)
        file.write("\n")


def json_value(value):
    if value in (None, "", [], {}):
        return ""
    if isinstance(value, (list, dict)):
        return json.dumps(value, default=str, sort_keys=True)
    return str(value)


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json_value(row.get(key)) for key in fieldnames})


def markdown_cell(value):
    text = json_value(value)
    return text.replace("|", "\\|").replace("\n", " ")


def write_markdown(path, rows):
    status_counts = defaultdict(int)
    for row in rows:
        status_counts[row.get("status") or "UNKNOWN"] += 1

    lines = [
        "# QuickSight S3 Manifest Remediation Inventory",
        "",
        "This inventory lists S3-backed QuickSight datasets that cannot migrate by asset bundle because the source S3 data source has no S3 `ManifestFileLocation`. QuickSight still exposes the dataset schema and upload settings, but the original local manifest file path is not recoverable from the API.",
        "",
        "## Summary",
        "",
        f"- S3 manifest datasets: {len(rows)}",
    ]
    for status, count in sorted(status_counts.items()):
        lines.append(f"- {status}: {count}")
    lines.extend(
        [
            "",
            "## Owner Action",
            "",
            "Fill `s3_manifest_locations_template.csv` with the approved central manifest bucket/key and the real source data `s3://` URI or URI prefix for each dataset. A dataset remains blocked until either `data_uris` or `data_uri_prefixes` is populated.",
            "",
            "## Dataset Inventory",
            "",
            "| Dataset | Used By Dashboards | Format | Header | Text Qualifier | Target Dataset ID | Target Data Source ID |",
            "| --- | --- | --- | --- | --- | --- | --- |",
        ]
    )
    for row in rows:
        settings = row.get("source_upload_settings") or {}
        values = [
            row.get("source_dataset_name"),
            ", ".join(row.get("source_dashboard_names") or []),
            settings.get("Format") or settings.get("format"),
            settings.get("ContainsHeader") if "ContainsHeader" in settings else settings.get("contains_header"),
            settings.get("TextQualifier") or settings.get("text_qualifier"),
            row.get("target_dataset_id"),
            row.get("target_data_source_id"),
        ]
        lines.append("| " + " | ".join(markdown_cell(value) for value in values) + " |")
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def slugify(value):
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "-", (value or "").strip())
    safe = re.sub(r"-+", "-", safe).strip("-")
    return safe.lower() or "dataset"


def sanitize_qs_id(value, max_length=512):
    safe = re.sub(r"[^A-Za-z0-9_-]+", "-", (value or "").strip())
    safe = re.sub(r"-+", "-", safe).strip("-")
    return (safe or "quicksight-resource")[:max_length]


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def split_list(value):
    if not value:
        return []
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    except Exception:
        pass
    return [item.strip() for item in str(value).split(",") if item.strip()]


def is_s3_manifest_blocker(row):
    return "S3_MANIFEST" in (row.get("blocker_type") or "")


def group_s3_blocker_rows(matrix_rows):
    grouped = defaultdict(list)
    for row in matrix_rows:
        if not is_s3_manifest_blocker(row):
            continue
        dataset_id = row.get("source_dataset_id")
        if dataset_id:
            grouped[dataset_id].append(row)
    return grouped


def extract_s3_sources(dataset):
    sources = []
    for table_id, table_def in (dataset.get("PhysicalTableMap") or {}).items():
        s3_source = table_def.get("S3Source")
        if not s3_source:
            continue
        data_source_arn = s3_source.get("DataSourceArn") or ""
        sources.append(
            {
                "physical_table_id": table_id,
                "data_source_arn": data_source_arn,
                "data_source_id": data_source_arn.split("/")[-1],
                "input_columns": s3_source.get("InputColumns") or [],
                "upload_settings": s3_source.get("UploadSettings") or {},
            }
        )
    return sources


def describe_data_source(qs_client, account_id, data_source_id):
    try:
        response = qs_client.describe_data_source(
            AwsAccountId=account_id,
            DataSourceId=data_source_id,
        )
        data_source = response.get("DataSource") or {}
        params = data_source.get("DataSourceParameters") or {}
        s3_params = params.get("S3Parameters") or {}
        manifest_location = s3_params.get("ManifestFileLocation") or {}
        return {
            "data_source_id": data_source.get("DataSourceId") or data_source_id,
            "name": data_source.get("Name"),
            "arn": data_source.get("Arn"),
            "type": data_source.get("Type"),
            "has_manifest_file_location": bool(
                manifest_location.get("Bucket") and manifest_location.get("Key")
            ),
            "manifest_bucket": manifest_location.get("Bucket"),
            "manifest_key": manifest_location.get("Key"),
            "error": "",
        }
    except Exception as error:
        return {
            "data_source_id": data_source_id,
            "name": "",
            "arn": "",
            "type": "",
            "has_manifest_file_location": None,
            "manifest_bucket": "",
            "manifest_key": "",
            "error": str(error),
        }


def target_manifest_key(prefix, dataset_name, dataset_id):
    parts = [part for part in [prefix.strip("/") if prefix else "", f"{slugify(dataset_name)}-{dataset_id}", "manifest.json"] if part]
    return "/".join(parts)


def build_inventory_row(
    qs_client,
    account_id,
    target_account_id,
    manifest_bucket,
    manifest_prefix,
    dataset_id,
    grouped_rows,
):
    first = grouped_rows[0]
    dataset_name = first.get("source_dataset_name") or first.get("source_dataset_identifier") or dataset_id
    dashboard_names = sorted({row.get("dashboard_name") for row in grouped_rows if row.get("dashboard_name")})
    dashboard_ids = sorted({row.get("dashboard_id") for row in grouped_rows if row.get("dashboard_id")})

    try:
        response = qs_client.describe_data_set(
            AwsAccountId=account_id,
            DataSetId=dataset_id,
        )
        dataset = response.get("DataSet") or {}
        s3_sources = extract_s3_sources(dataset)
        data_sources = [
            describe_data_source(qs_client, account_id, source["data_source_id"])
            for source in s3_sources
            if source.get("data_source_id")
        ]
        upload_settings = s3_sources[0]["upload_settings"] if s3_sources else {}
        input_columns = s3_sources[0]["input_columns"] if s3_sources else []
        status = "NEEDS_DATA_LOCATION"
        error = ""
    except Exception as error_obj:
        dataset = {}
        s3_sources = []
        data_sources = []
        upload_settings = {}
        input_columns = []
        status = "SOURCE_DESCRIBE_ERROR"
        error = str(error_obj)

    target_data_source_id = sanitize_qs_id(f"{dataset_id}-s3-source")
    target_dataset_id = sanitize_qs_id(dataset_id)
    row = {
        "status": status,
        "error": error,
        "source_account_id": account_id,
        "target_account_id": target_account_id,
        "source_dataset_id": dataset_id,
        "source_dataset_name": dataset.get("Name") or dataset_name,
        "source_dataset_arn": dataset.get("Arn"),
        "source_import_mode": dataset.get("ImportMode") or first.get("source_import_mode"),
        "source_dashboard_names": dashboard_names,
        "source_dashboard_ids": dashboard_ids,
        "source_s3_sources": s3_sources,
        "source_data_sources": data_sources,
        "source_upload_settings": upload_settings,
        "source_input_columns": input_columns,
        "source_output_columns": dataset.get("OutputColumns") or [],
        "target_dataset_id": target_dataset_id,
        "target_dataset_name": dataset.get("Name") or dataset_name,
        "target_dataset_arn": f"arn:aws:quicksight:us-east-1:{target_account_id}:dataset/{target_dataset_id}",
        "target_data_source_id": target_data_source_id,
        "target_data_source_name": f"{dataset.get('Name') or dataset_name} S3 manifest",
        "manifest_bucket": manifest_bucket or "",
        "manifest_key": target_manifest_key(
            manifest_prefix,
            dataset.get("Name") or dataset_name,
            dataset_id,
        ),
        "data_uris": [],
        "data_uri_prefixes": [],
        "notes": "Fill data_uris or data_uri_prefixes before provisioning.",
        "source_dataset": dataset,
    }
    return row


def load_target_dataset_ids(target_inventory_path):
    if not target_inventory_path:
        return set()
    inventory = read_json(target_inventory_path)
    return {
        dataset.get("dataset_id")
        for dataset in inventory.get("datasets", [])
        if dataset.get("dataset_id")
    }


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build S3 manifest remediation inventory for QuickSight datasets."
    )
    parser.add_argument("--migration-matrix", required=True, help="Path to migration_matrix_27_dashboard_scope.csv or migration_matrix.csv")
    parser.add_argument("--profile", help="Source AWS profile")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--source-account-id", default="840529182937")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument("--target-inventory", help="Optional target_inventory.json used to flag target id collisions")
    parser.add_argument("--manifest-bucket", help="Central S3 bucket where manifest JSON files will be stored")
    parser.add_argument(
        "--manifest-prefix",
        default="bif-risk/s3-manifests",
        help="Central S3 prefix for generated manifest JSON files",
    )
    parser.add_argument("--output-dir", help="Output directory. Defaults to the migration matrix folder.")
    return parser.parse_args()


def main():
    args = parse_args()
    matrix_path = Path(args.migration_matrix)
    output_dir = Path(args.output_dir) if args.output_dir else matrix_path.parent
    output_dir.mkdir(parents=True, exist_ok=True)

    session = session_for(args.profile, args.region)
    account_id = args.source_account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)
    qs_client = session.client("quicksight", region_name=args.region)

    matrix_rows = read_csv(matrix_path)
    grouped = group_s3_blocker_rows(matrix_rows)
    target_dataset_ids = load_target_dataset_ids(args.target_inventory)

    rows = []
    for idx, (dataset_id, grouped_rows) in enumerate(sorted(grouped.items()), start=1):
        print(
            f"[{idx}/{len(grouped)}] Inspecting source S3 dataset {grouped_rows[0].get('source_dataset_name')} ({dataset_id})",
            flush=True,
        )
        row = build_inventory_row(
            qs_client,
            account_id,
            args.target_account_id,
            args.manifest_bucket,
            args.manifest_prefix,
            dataset_id,
            grouped_rows,
        )
        row["target_dataset_id_exists"] = row["target_dataset_id"] in target_dataset_ids
        if row["target_dataset_id_exists"]:
            row["notes"] = f"Target dataset id {row['target_dataset_id']} already exists; confirm whether to update or choose a new id."
        rows.append(row)

    created_at = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    payload = {
        "inventory_type": "quicksight_s3_manifest_remediation",
        "created_at": created_at,
        "source_profile": args.profile,
        "source_account_id": account_id,
        "target_account_id": args.target_account_id,
        "region": args.region,
        "caller_identity": caller_identity,
        "migration_matrix": str(matrix_path),
        "row_count": len(rows),
        "rows": rows,
    }

    write_json(output_dir / "s3_manifest_inventory.json", payload)
    write_csv(
        output_dir / "s3_manifest_inventory.csv",
        rows,
        [
            "status",
            "source_dataset_name",
            "source_dataset_id",
            "source_import_mode",
            "source_dashboard_names",
            "source_data_sources",
            "source_upload_settings",
            "source_input_columns",
            "source_output_columns",
            "target_dataset_id",
            "target_dataset_name",
            "target_data_source_id",
            "target_data_source_name",
            "target_dataset_id_exists",
            "manifest_bucket",
            "manifest_key",
            "data_uris",
            "data_uri_prefixes",
            "notes",
            "error",
        ],
    )
    write_csv(
        output_dir / "s3_manifest_locations_template.csv",
        rows,
        [
            "source_dataset_name",
            "source_dataset_id",
            "source_dashboard_names",
            "manifest_bucket",
            "manifest_key",
            "data_uris",
            "data_uri_prefixes",
            "notes",
        ],
    )
    write_markdown(output_dir / "s3_manifest_inventory_summary.md", rows)

    print(f"S3 manifest datasets: {len(rows)}", flush=True)
    print(f"Inventory JSON: {output_dir / 's3_manifest_inventory.json'}", flush=True)
    print(f"Locations template: {output_dir / 's3_manifest_locations_template.csv'}", flush=True)
    print(f"Summary markdown: {output_dir / 's3_manifest_inventory_summary.md'}", flush=True)


if __name__ == "__main__":
    main()
