# scripts/risk_promotion_common.py
"""Shared pure helpers for risk dashboard promotion tooling.

No AWS calls. Reads dataset metadata.yaml files and parses QuickSight
dashboard definitions to resolve a dashboard's dataset dependency closure.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None


def norm(name: str) -> str:
    name = (name or "").lower()
    name = re.sub(r"\.(csv|xlsx|xls|json|parquet)$", "", name)
    name = re.sub(r"[^a-z0-9]+", "_", name).strip("_")
    return name


def _id_variants(slug: str, name: str, env: str) -> set[str]:
    """All dataset-id forms that could appear in a definition for this slug."""
    # Publisher physicalTableMap/dataset id: f"{name}_{env}".replace("_","-")
    # per quicksight_mgr/cfg.py (ALL underscores -> hyphens, e.g. rmv-position-dev).
    # Kept alongside f"{name}-{env}" below, which preserves internal underscores;
    # both are plausible id forms, so we index both. All map to the same slug.
    derived = f"{name}_{env}".replace("_", "-")
    return {
        slug,
        name,
        derived,
        f"{name}-{env}",
        norm(slug),
        norm(name),
        norm(derived),
    }


def load_dataset_index(datasets_dir: Path, env: str) -> dict[str, str]:
    """Map every candidate dataset-id form -> slug folder name."""
    index: dict[str, str] = {}
    for meta in sorted(Path(datasets_dir).glob("*/metadata.yaml")):
        slug = meta.parent.name
        data = yaml.safe_load(meta.read_text()) or {}
        name = data.get("name", slug)
        for variant in _id_variants(slug, name, env):
            index.setdefault(variant, slug)
    return index


def dataset_id_to_slug(dataset_id: str, index: dict[str, str]) -> str | None:
    if dataset_id in index:
        return index[dataset_id]
    return index.get(norm(dataset_id))


def extract_dataset_arns(definition: dict[str, Any]) -> list[tuple[str, str]]:
    """Return [(dataset_id, account_id)] from a dashboard definition."""
    decls = (
        definition.get("Definition", {})
        .get("DataSetIdentifierDeclarations", [])
    )
    out: list[tuple[str, str]] = []
    for d in decls:
        arn = d.get("DataSetArn", "")
        # arn:aws:quicksight:<region>:<account>:dataset/<id>
        m = re.match(r"arn:aws:quicksight:[^:]*:(\d+):dataset/(.+)$", arn)
        if m:
            out.append((m.group(2), m.group(1)))
    return out


def expand_join_dependencies(
    slugs: list[str], datasets_dir: Path, index: dict[str, str]
) -> tuple[list[str], list[str]]:
    """Transitively add dataset->dataset join dependencies to a slug closure.

    Dataset metadata.yaml may declare joins whose right_dataset is another
    managed dataset; the publisher resolves it at sync time, so the target must
    exist in the same env folder (uat sync failed when vol_greeks joined
    fx_rate and only vol_greeks was promoted). Returns (expanded_slugs,
    unresolved_join_refs); expanded preserves input order with dependencies
    appended in discovery order.
    """
    datasets_dir = Path(datasets_dir)
    expanded = list(slugs)
    unresolved: list[str] = []
    frontier = list(slugs)
    while frontier:
        slug = frontier.pop(0)
        meta = datasets_dir / slug / "metadata.yaml"
        if not meta.exists():
            continue
        data = yaml.safe_load(meta.read_text()) or {}
        for join in data.get("joins") or []:
            ref = (join or {}).get("right_dataset")
            if not ref:
                continue
            dep = dataset_id_to_slug(ref, index)
            if dep is None:
                if ref not in unresolved:
                    unresolved.append(ref)
            elif dep not in expanded:
                expanded.append(dep)
                frontier.append(dep)
    return expanded, unresolved
