"""
Audit and reconcile permissions + folder membership on analyses created by
`migrate_qs_dashboard_definition.py`.

The migrate script creates the central analysis but does not grant any
permissions and does not add the analysis to a folder. As a result, only the
IAM principal that ran the migration can open the analysis. This script:

  1. Discovers every migrated analysis by walking
     `exports/quicksight-definition-migration/<dashboard>/<run>/target_analysis_result.json`
     (latest run per dashboard).
  2. Calls `describe_analysis` / `describe_analysis_permissions` /
     `list_folder_members` to capture current state in central.
  3. Computes the diff vs target state: owner group has CO_OWNER permissions
     and the analysis is a member of the target folder.
  4. Writes an audit JSON + CSV to
     `exports/quicksight-definition-migration/reconcile-<ts>/`.
  5. With `--apply`, calls `update_analysis_permissions` and
     `create_folder_membership(MemberType=ANALYSIS)` to bring the actual state
     into line.

Co-owner permission set follows the QuickSight "Co-owner" preset documented at
https://docs.aws.amazon.com/quicksight/latest/APIReference/qs-iam-policy-examples.html
"""

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


ANALYSIS_CO_OWNER_ACTIONS = [
    "quicksight:RestoreAnalysis",
    "quicksight:UpdateAnalysisPermissions",
    "quicksight:DeleteAnalysis",
    "quicksight:QueryAnalysis",
    "quicksight:DescribeAnalysisPermissions",
    "quicksight:DescribeAnalysis",
    "quicksight:UpdateAnalysis",
]


DASHBOARD_CO_OWNER_ACTIONS = [
    "quicksight:DescribeDashboard",
    "quicksight:ListDashboardVersions",
    "quicksight:UpdateDashboardPermissions",
    "quicksight:QueryDashboard",
    "quicksight:UpdateDashboard",
    "quicksight:DeleteDashboard",
    "quicksight:DescribeDashboardPermissions",
    "quicksight:UpdateDashboardPublishedVersion",
]


def write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
        f.write("\n")


def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def group_arn(account_id, region, group_name, namespace="default"):
    return f"arn:aws:quicksight:{region}:{account_id}:group/{namespace}/{group_name}"


def discover_migrated_analyses(exports_root: Path):
    """Walk the definition-migration export root and yield one record per
    dashboard for the *latest* run that produced a target analysis.

    Two discovery sources are combined:

      1. Per-dashboard run directories containing
         `target_analysis_result.json` (most recent run wins).
      2. Top-level `definition_migration_summary_*.json` files that record
         `target_analysis_id` on each result entry (catches dashboards whose
         latest run was blocked but whose earlier APPLIED summary still names
         the central analysis).
    """
    by_analysis_id = {}

    for dashboard_dir in sorted(p for p in exports_root.iterdir() if p.is_dir()):
        run_dirs = sorted(
            (p for p in dashboard_dir.iterdir() if p.is_dir()),
            key=lambda p: p.name,
        )
        for run_dir in reversed(run_dirs):
            result_path = run_dir / "target_analysis_result.json"
            if not result_path.exists():
                continue
            try:
                payload = json.loads(result_path.read_text(encoding="utf-8"))
            except Exception as error:
                by_analysis_id.setdefault(
                    f"_unreadable_{dashboard_dir.name}",
                    {
                        "dashboard_dir": dashboard_dir.name,
                        "run_dir": run_dir.name,
                        "status": "UNREADABLE_RESULT",
                        "error": str(error),
                        "source": "run_dir",
                    },
                )
                break

            response = payload.get("response") or {}
            params = payload.get("params") or {}
            analysis_id = response.get("AnalysisId") or params.get("AnalysisId") or ""
            analysis_name = params.get("Name") or ""
            action = payload.get("action")
            if not analysis_id or action == "dry_run":
                break
            by_analysis_id[analysis_id] = {
                "dashboard_dir": dashboard_dir.name,
                "run_dir": run_dir.name,
                "analysis_id": analysis_id,
                "analysis_name": analysis_name,
                "action": action,
                "status": "DISCOVERED",
                "source": "run_dir",
            }
            break

    for summary_path in sorted(exports_root.glob("definition_migration_summary_*.json")):
        try:
            payload = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        for entry in payload.get("results", []) or []:
            analysis_id = entry.get("target_analysis_id") or ""
            if not analysis_id:
                continue
            if entry.get("status") not in {"APPLIED"}:
                continue
            if analysis_id in by_analysis_id:
                continue
            by_analysis_id[analysis_id] = {
                "dashboard_dir": entry.get("dashboard_name") or "",
                "run_dir": summary_path.name,
                "analysis_id": analysis_id,
                "analysis_name": "",
                "action": "summary_inferred",
                "status": "DISCOVERED",
                "source": "summary",
            }

    return list(by_analysis_id.values())


def read_extra_ids_file(path):
    if not path:
        return []
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        analysis_id, _, label = line.partition(",")
        rows.append(
            {
                "dashboard_dir": label.strip() or "(extra)",
                "run_dir": "extra-ids",
                "analysis_id": analysis_id.strip(),
                "analysis_name": label.strip(),
                "action": "extra_file",
                "status": "DISCOVERED",
                "source": "extra_file",
            }
        )
    return rows


def read_dashboard_ids_file(path):
    if not path:
        return []
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        dashboard_id, _, label = line.partition(",")
        rows.append(
            {
                "dashboard_id": dashboard_id.strip(),
                "label": label.strip(),
            }
        )
    return rows


def describe_analysis_safe(qs, account_id, analysis_id):
    try:
        return qs.describe_analysis(AwsAccountId=account_id, AnalysisId=analysis_id)
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def describe_analysis_permissions_safe(qs, account_id, analysis_id):
    try:
        return qs.describe_analysis_permissions(
            AwsAccountId=account_id, AnalysisId=analysis_id
        )
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def describe_dashboard_safe(qs, account_id, dashboard_id):
    try:
        return qs.describe_dashboard(AwsAccountId=account_id, DashboardId=dashboard_id)
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def describe_dashboard_permissions_safe(qs, account_id, dashboard_id):
    try:
        return qs.describe_dashboard_permissions(
            AwsAccountId=account_id, DashboardId=dashboard_id
        )
    except ClientError as error:
        return {"_error": error.response.get("Error", {})}


def list_folder_member_ids(qs, account_id, folder_id):
    """Return the set of MemberId values currently in the folder, regardless of
    MemberType."""
    member_ids = set()
    next_token = None
    while True:
        kwargs = {"AwsAccountId": account_id, "FolderId": folder_id}
        if next_token:
            kwargs["NextToken"] = next_token
        try:
            response = qs.list_folder_members(**kwargs)
        except ClientError as error:
            return None, error.response.get("Error", {})
        for member in response.get("FolderMemberList", []) or []:
            arn = member.get("MemberArn") or ""
            if arn:
                member_ids.add(arn.rsplit("/", 1)[-1])
        next_token = response.get("NextToken")
        if not next_token:
            break
    return member_ids, None


def audit_record(qs, account_id, region, record, owner_group, folder_id, folder_member_ids):
    """Augment a discovery record with current central state and the planned diff."""
    analysis_id = record.get("analysis_id")
    if not analysis_id:
        return record

    describe = describe_analysis_safe(qs, account_id, analysis_id)
    if "_error" in describe:
        record["central_status"] = "NOT_FOUND" if describe["_error"].get("Code") == "ResourceNotFoundException" else "DESCRIBE_ERROR"
        record["central_error"] = describe["_error"]
        return record

    analysis = describe.get("Analysis", {}) or {}
    record["central_status"] = analysis.get("Status")
    record["central_name"] = analysis.get("Name")
    record["central_arn"] = analysis.get("Arn")

    perms = describe_analysis_permissions_safe(qs, account_id, analysis_id)
    if "_error" in perms:
        record["permissions_error"] = perms["_error"]
        record["current_principals"] = []
    else:
        record["current_principals"] = [
            {
                "Principal": entry.get("Principal"),
                "Actions": sorted(entry.get("Actions", []) or []),
            }
            for entry in perms.get("Permissions", []) or []
        ]

    owner_group_arn = group_arn(account_id, region, owner_group)
    record["target_owner_principal"] = owner_group_arn

    existing_principals = {entry["Principal"] for entry in record["current_principals"]}
    record["owner_already_granted"] = owner_group_arn in existing_principals

    if folder_member_ids is None:
        record["folder_membership_check"] = "FOLDER_LIST_FAILED"
        record["analysis_in_folder"] = None
    else:
        record["folder_membership_check"] = "OK"
        record["analysis_in_folder"] = analysis_id in folder_member_ids

    planned_actions = []
    if not record["owner_already_granted"]:
        planned_actions.append("grant_owner")
    if record["analysis_in_folder"] is False:
        planned_actions.append("add_to_folder")
    record["planned_actions"] = planned_actions
    return record


def apply_fix(qs, account_id, region, record, owner_group, folder_id):
    """Apply the planned actions. Returns the record annotated with apply results."""
    analysis_id = record.get("analysis_id")
    results = {}

    if "grant_owner" in record.get("planned_actions", []):
        try:
            response = qs.update_analysis_permissions(
                AwsAccountId=account_id,
                AnalysisId=analysis_id,
                GrantPermissions=[
                    {
                        "Principal": group_arn(account_id, region, owner_group),
                        "Actions": ANALYSIS_CO_OWNER_ACTIONS,
                    }
                ],
            )
            results["grant_owner"] = {
                "status": "OK",
                "http_status": response.get("Status"),
            }
        except ClientError as error:
            results["grant_owner"] = {
                "status": "ERROR",
                "error": error.response.get("Error", {}),
            }

    if "add_to_folder" in record.get("planned_actions", []):
        try:
            qs.create_folder_membership(
                AwsAccountId=account_id,
                FolderId=folder_id,
                MemberId=analysis_id,
                MemberType="ANALYSIS",
            )
            results["add_to_folder"] = {"status": "OK"}
        except ClientError as error:
            code = error.response.get("Error", {}).get("Code")
            if code == "ResourceExistsException":
                results["add_to_folder"] = {"status": "ALREADY_EXISTS"}
            else:
                results["add_to_folder"] = {
                    "status": "ERROR",
                    "error": error.response.get("Error", {}),
                }

    record["apply_results"] = results
    return record


def audit_dashboard(qs, account_id, region, record, owner_group, folder_id, folder_member_ids):
    dashboard_id = record.get("dashboard_id")
    if not dashboard_id:
        return record
    describe = describe_dashboard_safe(qs, account_id, dashboard_id)
    if "_error" in describe:
        record["central_status"] = "NOT_FOUND" if describe["_error"].get("Code") == "ResourceNotFoundException" else "DESCRIBE_ERROR"
        record["central_error"] = describe["_error"]
        return record
    dashboard = describe.get("Dashboard", {}) or {}
    record["central_status"] = (dashboard.get("Version") or {}).get("Status")
    record["central_name"] = dashboard.get("Name")

    perms = describe_dashboard_permissions_safe(qs, account_id, dashboard_id)
    owner_arn = f"arn:aws:quicksight:{region}:{account_id}:group/default/{owner_group}"
    if "_error" in perms:
        record["permissions_error"] = perms["_error"]
        record["current_principals"] = []
    else:
        record["current_principals"] = [
            {"Principal": entry.get("Principal"), "Actions": sorted(entry.get("Actions", []) or [])}
            for entry in perms.get("Permissions", []) or []
        ]
    record["target_owner_principal"] = owner_arn
    record["owner_already_granted"] = owner_arn in {p["Principal"] for p in record.get("current_principals", [])}
    record["dashboard_in_folder"] = (
        None if folder_member_ids is None else dashboard_id in folder_member_ids
    )
    planned_actions = []
    if not record["owner_already_granted"]:
        planned_actions.append("grant_owner")
    if record["dashboard_in_folder"] is False:
        planned_actions.append("add_to_folder")
    record["planned_actions"] = planned_actions
    return record


def apply_fix_dashboard(qs, account_id, region, record, owner_group, folder_id):
    dashboard_id = record.get("dashboard_id")
    results = {}
    if "grant_owner" in record.get("planned_actions", []):
        try:
            response = qs.update_dashboard_permissions(
                AwsAccountId=account_id,
                DashboardId=dashboard_id,
                GrantPermissions=[
                    {
                        "Principal": f"arn:aws:quicksight:{region}:{account_id}:group/default/{owner_group}",
                        "Actions": DASHBOARD_CO_OWNER_ACTIONS,
                    }
                ],
            )
            results["grant_owner"] = {"status": "OK", "http_status": response.get("Status")}
        except ClientError as error:
            results["grant_owner"] = {"status": "ERROR", "error": error.response.get("Error", {})}
    if "add_to_folder" in record.get("planned_actions", []):
        try:
            qs.create_folder_membership(
                AwsAccountId=account_id,
                FolderId=folder_id,
                MemberId=dashboard_id,
                MemberType="DASHBOARD",
            )
            results["add_to_folder"] = {"status": "OK"}
        except ClientError as error:
            code = error.response.get("Error", {}).get("Code")
            if code == "ResourceExistsException":
                results["add_to_folder"] = {"status": "ALREADY_EXISTS"}
            else:
                results["add_to_folder"] = {"status": "ERROR", "error": error.response.get("Error", {})}
    record["apply_results"] = results
    return record


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Audit and (optionally) reconcile permissions + folder membership "
            "on analyses (and optionally dashboards) created by "
            "migrate_qs_dashboard_definition.py."
        )
    )
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument(
        "--exports-root",
        default="exports/quicksight-definition-migration",
        help="Root directory containing per-dashboard subdirectories",
    )
    parser.add_argument(
        "--owner-group",
        default="AWS_SSO_QS_AUTHOR_RISK",
        help="QuickSight group name to grant CO_OWNER permissions on each resource",
    )
    parser.add_argument(
        "--folder-id",
        default="bif-risk-dev",
        help="Target folder for membership",
    )
    parser.add_argument(
        "--dashboards-file",
        default="",
        help=(
            "Optional path to a text file listing dashboard IDs to reconcile "
            "(grant owner + folder membership). One ID per line; optional "
            "', label' suffix. When set, the script reconciles BOTH analyses "
            "(from --extra-ids-file + exports discovery) AND dashboards."
        ),
    )
    parser.add_argument(
        "--extra-ids-file",
        default="",
        help=(
            "Optional path to a text file listing additional analysis IDs to "
            "audit (one per line; optional ', label' suffix). Use this for "
            "analyses that were rebound via UpdateAnalysis in apply_patches.py "
            "and aren't picked up by the export-directory scan."
        ),
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply the planned actions. Without --apply, only the audit is written.",
    )
    parser.add_argument(
        "--output-root",
        default="exports/quicksight-definition-migration",
        help="Where the reconcile-<ts> output directory is written",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    session = session_for(args.target_profile, args.region)
    qs = session.client("quicksight", region_name=args.region)

    exports_root = Path(args.exports_root)
    if not exports_root.exists():
        raise SystemExit(f"Exports root does not exist: {exports_root}")

    records = discover_migrated_analyses(exports_root)
    records.extend(read_extra_ids_file(args.extra_ids_file))
    print(f"Discovered {len(records)} analysis records to audit", flush=True)

    folder_member_ids, folder_error = list_folder_member_ids(
        qs, args.target_account_id, args.folder_id
    )
    if folder_error:
        print(f"WARNING: list_folder_members failed for {args.folder_id}: {folder_error}", flush=True)

    audited = []
    for record in records:
        if record.get("status") not in {"DISCOVERED"}:
            audited.append(record)
            continue
        record = audit_record(
            qs,
            args.target_account_id,
            args.region,
            record,
            args.owner_group,
            args.folder_id,
            folder_member_ids,
        )
        audited.append(record)
        planned = record.get("planned_actions") or []
        print(
            f"  {record['analysis_id']}: central={record.get('central_status')}, "
            f"planned={planned}",
            flush=True,
        )

    if args.apply:
        for record in audited:
            if record.get("planned_actions"):
                apply_fix(
                    qs,
                    args.target_account_id,
                    args.region,
                    record,
                    args.owner_group,
                    args.folder_id,
                )

    dashboard_audited = []
    if args.dashboards_file:
        dashboard_rows = read_dashboard_ids_file(args.dashboards_file)
        print(f"Auditing {len(dashboard_rows)} dashboards", flush=True)
        for row in dashboard_rows:
            row = audit_dashboard(
                qs,
                args.target_account_id,
                args.region,
                row,
                args.owner_group,
                args.folder_id,
                folder_member_ids,
            )
            dashboard_audited.append(row)
            print(
                f"  dashboard {row.get('dashboard_id')}: central={row.get('central_status')}, "
                f"planned={row.get('planned_actions')}",
                flush=True,
            )
        if args.apply:
            for row in dashboard_audited:
                if row.get("planned_actions"):
                    apply_fix_dashboard(
                        qs,
                        args.target_account_id,
                        args.region,
                        row,
                        args.owner_group,
                        args.folder_id,
                    )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_root) / f"reconcile-{run_id}"
    write_json(
        out_dir / "audit.json",
        {
            "target_account_id": args.target_account_id,
            "region": args.region,
            "owner_group": args.owner_group,
            "folder_id": args.folder_id,
            "apply": args.apply,
            "records": audited,
        },
    )

    csv_rows = []
    for record in audited:
        csv_rows.append(
            {
                "dashboard_dir": record.get("dashboard_dir"),
                "analysis_id": record.get("analysis_id"),
                "central_name": record.get("central_name"),
                "central_status": record.get("central_status"),
                "owner_already_granted": record.get("owner_already_granted"),
                "analysis_in_folder": record.get("analysis_in_folder"),
                "planned_actions": ",".join(record.get("planned_actions") or []),
                "apply_results": json.dumps(record.get("apply_results") or {}, default=str),
            }
        )
    write_csv(
        out_dir / "audit.csv",
        csv_rows,
        [
            "dashboard_dir",
            "analysis_id",
            "central_name",
            "central_status",
            "owner_already_granted",
            "analysis_in_folder",
            "planned_actions",
            "apply_results",
        ],
    )

    if dashboard_audited:
        write_json(out_dir / "audit_dashboards.json", dashboard_audited)
        write_csv(
            out_dir / "audit_dashboards.csv",
            [
                {
                    "dashboard_id": row.get("dashboard_id"),
                    "label": row.get("label"),
                    "central_name": row.get("central_name"),
                    "central_status": row.get("central_status"),
                    "owner_already_granted": row.get("owner_already_granted"),
                    "dashboard_in_folder": row.get("dashboard_in_folder"),
                    "planned_actions": ",".join(row.get("planned_actions") or []),
                    "apply_results": json.dumps(row.get("apply_results") or {}, default=str),
                }
                for row in dashboard_audited
            ],
            [
                "dashboard_id",
                "label",
                "central_name",
                "central_status",
                "owner_already_granted",
                "dashboard_in_folder",
                "planned_actions",
                "apply_results",
            ],
        )
    print(f"Reconcile output: {out_dir}", flush=True)


if __name__ == "__main__":
    main()
