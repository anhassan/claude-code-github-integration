"""
Read-only 3-way audit of bif-risk dataset ImportMode + refresh schedules.

For every dataset configured in bif-risk (`dev/datasets/*/metadata.yaml`) it
compares three views:

  * declared  - import_mode / refresh_schedule in the repo metadata.yaml
  * central   - runtime ImportMode + refresh schedules in fabric central
                (200967598245), anchored to the dataset that lives in the
                `bif-risk-dev` folder (resolves fabric name collisions)
  * source    - runtime ImportMode + refresh schedules in the source risk-prod
                account (840529182937)

Source datasets are matched to central datasets via the authoritative
`DataSetIdentifierDeclaration` join across migrated dashboards (the same
Identifier string appears in both the source and central dashboard
definitions). When a dataset is not referenced by any migrated dashboard the
audit falls back to a normalized-name match and flags the lower confidence.

The script only calls list/describe APIs - never create/update/delete.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import ClientError

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

SOURCE_PROFILE = "CPPIB-Quicksight-Admin-840529182937"
CENTRAL_PROFILE = "CPPIB-Quicksight-Admin-200967598245"
SOURCE_ACCOUNT = "840529182937"
CENTRAL_ACCOUNT = "200967598245"
FOLDER_ID = "bif-risk-dev"

RISK_DATASETS = Path("c:/Users/nabed/workspace/bi/bif-risk/dev/datasets")


def norm(name: str) -> str:
    name = (name or "").lower()
    name = re.sub(r"\.(csv|xlsx|xls|json|parquet)$", "", name)
    name = re.sub(r"[^a-z0-9]+", "_", name).strip("_")
    return name


def session(profile: str):
    return boto3.Session(profile_name=profile, region_name="us-east-1").client("quicksight")


def safe(fn, **kw):
    try:
        return fn(**kw), None
    except ClientError as err:
        return None, err.response.get("Error", {})


def list_data_sets(qs, account: str) -> list[dict[str, Any]]:
    out, tok = [], None
    while True:
        kw = {"AwsAccountId": account, "MaxResults": 100}
        if tok:
            kw["NextToken"] = tok
        r = qs.list_data_sets(**kw)
        for s in r.get("DataSetSummaries", []):
            out.append(
                {
                    "Id": s.get("DataSetId"),
                    "Name": s.get("Name"),
                    "Mode": s.get("ImportMode"),
                    "LastUpdated": str(s.get("LastUpdatedTime")),
                }
            )
        tok = r.get("NextToken")
        if not tok:
            break
    return out


def list_folder_dataset_ids(qs, account: str, folder_id: str) -> set[str]:
    out, tok = set(), None
    while True:
        kw = {"AwsAccountId": account, "FolderId": folder_id, "MaxResults": 100}
        if tok:
            kw["NextToken"] = tok
        r = qs.list_folder_members(**kw)
        for m in r.get("FolderMemberList", []):
            arn = m.get("MemberArn") or ""
            if ":dataset/" in arn:
                out.add(arn.rsplit("/", 1)[-1])
        tok = r.get("NextToken")
        if not tok:
            break
    return out


def read_id_file(path: Path) -> list[str]:
    ids = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        ids.append(line.partition(",")[0].strip())
    return ids


def load_configs() -> dict[str, dict[str, Any]]:
    cfgs = {}
    for d in sorted(p for p in RISK_DATASETS.iterdir() if p.is_dir()):
        meta = d / "metadata.yaml"
        if not meta.is_file():
            continue
        raw = meta.read_text(encoding="utf-8")
        if yaml:
            y = yaml.safe_load(raw) or {}
            sched = y.get("refresh_schedule")
            cfgs[d.name] = {
                "dir": d.name,
                "name": y.get("name", d.name),
                "import_mode": y.get("import_mode"),
                "refresh_schedule": sched,
            }
        else:  # pragma: no cover
            name = re.search(r"^name:\s*([^\s#]+)", raw, re.M)
            im = re.search(r"^import_mode:\s*([^\s#]+)", raw, re.M)
            cfgs[d.name] = {
                "dir": d.name,
                "name": name.group(1) if name else d.name,
                "import_mode": im.group(1) if im else None,
                "refresh_schedule": "PRESENT" if "refresh_schedule:" in raw else None,
            }
    return cfgs


def build_dashboard_dataset_map(source_qs, central_qs, dashboard_ids: list[str]):
    """central_dataset_id -> Counter(source_dataset_id) from dashboard decl joins."""
    central_to_source: dict[str, Counter] = defaultdict(Counter)
    for did in dashboard_ids:
        s, _ = safe(source_qs.describe_dashboard_definition, AwsAccountId=SOURCE_ACCOUNT, DashboardId=did)
        c, _ = safe(central_qs.describe_dashboard_definition, AwsAccountId=CENTRAL_ACCOUNT, DashboardId=did)
        if not s or not c:
            continue
        s_decls = {
            d.get("Identifier"): (d.get("DataSetArn") or "").rsplit("/", 1)[-1]
            for d in s.get("Definition", {}).get("DataSetIdentifierDeclarations", []) or []
        }
        c_decls = {
            d.get("Identifier"): (d.get("DataSetArn") or "").rsplit("/", 1)[-1]
            for d in c.get("Definition", {}).get("DataSetIdentifierDeclarations", []) or []
        }
        for ident in set(s_decls) & set(c_decls):
            if s_decls[ident] and c_decls[ident]:
                central_to_source[c_decls[ident]][s_decls[ident]] += 1
    return central_to_source


def get_schedules(qs, account: str, dataset_id: str, cache: dict):
    key = f"{account}:{dataset_id}"
    if key in cache:
        return cache[key]
    data, err = safe(qs.list_refresh_schedules, AwsAccountId=account, DataSetId=dataset_id)
    result = []
    if data:
        for s in data.get("RefreshSchedules", []) or []:
            freq = s.get("ScheduleFrequency", {}) or {}
            result.append(
                {
                    "ScheduleId": s.get("ScheduleId"),
                    "RefreshType": s.get("RefreshType"),
                    "Interval": freq.get("Interval"),
                    "Timezone": freq.get("Timezone"),
                    "TimeOfTheDay": freq.get("TimeOfTheDay"),
                }
            )
    cache[key] = {"schedules": result, "error": err}
    return cache[key]


def sched_signature(schedules: list[dict]) -> set:
    return {
        (s.get("RefreshType"), s.get("Interval"), s.get("Timezone"), s.get("TimeOfTheDay"))
        for s in schedules
    }


def declared_sched_signature(sched) -> set:
    if not sched:
        return set()
    items = sched if isinstance(sched, list) else [sched]
    out = set()
    for s in items:
        freq = s.get("ScheduleFrequency", {}) or {}
        out.add((s.get("RefreshType"), freq.get("Interval"), freq.get("Timezone"), freq.get("TimeOfTheDay")))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--dashboards-file",
        type=Path,
        default=Path("exports/risk-dashboard-migration/migrated_dashboard_ids.txt"),
    )
    ap.add_argument("--output-root", type=Path, default=Path("exports/risk-dashboard-migration"))
    args = ap.parse_args()

    source_qs = session(SOURCE_PROFILE)
    central_qs = session(CENTRAL_PROFILE)

    print("Loading bif-risk configs...", flush=True)
    cfgs = load_configs()
    print(f"  {len(cfgs)} datasets", flush=True)

    print("Listing datasets in both accounts...", flush=True)
    central = list_data_sets(central_qs, CENTRAL_ACCOUNT)
    source = list_data_sets(source_qs, SOURCE_ACCOUNT)
    folder_ids = list_folder_dataset_ids(central_qs, CENTRAL_ACCOUNT, FOLDER_ID)
    print(f"  central={len(central)} source={len(source)} folder_members={len(folder_ids)}", flush=True)

    central_by_id = {x["Id"]: x for x in central}
    source_by_id = {x["Id"]: x for x in source}
    central_folder_by_name: dict[str, list[dict]] = defaultdict(list)
    for x in central:
        if x["Id"] in folder_ids:
            central_folder_by_name[x["Name"]].append(x)
    source_by_norm: dict[str, list[dict]] = defaultdict(list)
    for x in source:
        source_by_norm[norm(x["Name"])].append(x)

    print("Building dashboard dataset map...", flush=True)
    dash_ids = read_id_file(args.dashboards_file)
    central_to_source = build_dashboard_dataset_map(source_qs, central_qs, dash_ids)
    print(f"  mapped {len(central_to_source)} central datasets via dashboards", flush=True)

    sched_cache: dict[str, Any] = {}
    rows = []
    for name in sorted(cfgs):
        cfg = cfgs[name]
        ds_name = cfg["name"]
        row: dict[str, Any] = {
            "dir": name,
            "dataset_name": ds_name,
            "declared_import_mode": cfg["import_mode"],
            "declared_schedule": declared_sched_signature(cfg["refresh_schedule"]),
        }

        # ---- central anchor: folder + name ----
        cands = central_folder_by_name.get(ds_name) or []
        if not cands:
            # config.name may differ in case from central Name
            cands = [x for x in central if x["Id"] in folder_ids and norm(x["Name"]) == norm(ds_name)]
        if len(cands) == 1:
            cen = cands[0]
            row["central_id"] = cen["Id"]
            row["central_match"] = "folder-name"
        elif len(cands) > 1:
            row["central_id"] = None
            row["central_match"] = f"AMBIGUOUS({len(cands)})"
        else:
            row["central_id"] = None
            row["central_match"] = "NOT_FOUND"

        central_mode = central_by_id.get(row.get("central_id"), {}).get("Mode")
        row["central_import_mode"] = central_mode

        # ---- source link ----
        src_id = None
        src_conf = None
        if row.get("central_id") and row["central_id"] in central_to_source:
            counts = central_to_source[row["central_id"]]
            src_id = counts.most_common(1)[0][0]
            src_conf = "dashboard-join" + ("(conflict)" if len(counts) > 1 else "")
        else:
            sm = source_by_norm.get(norm(ds_name)) or []
            if len(sm) == 1:
                src_id = sm[0]["Id"]
                src_conf = "name-unique"
            elif len(sm) > 1:
                src_conf = f"name-AMBIGUOUS({len(sm)})"
            else:
                src_conf = "NO_SOURCE_MATCH"
        row["source_id"] = src_id
        row["source_match"] = src_conf
        row["source_import_mode"] = source_by_id.get(src_id, {}).get("Mode") if src_id else None

        # ---- schedules (SPICE only) ----
        if central_mode == "SPICE" and row.get("central_id"):
            cs = get_schedules(central_qs, CENTRAL_ACCOUNT, row["central_id"], sched_cache)
            row["central_schedule"] = sched_signature(cs["schedules"])
            row["central_schedule_count"] = len(cs["schedules"])
        else:
            row["central_schedule"] = set()
            row["central_schedule_count"] = 0
        if row.get("source_import_mode") == "SPICE" and src_id:
            ss = get_schedules(source_qs, SOURCE_ACCOUNT, src_id, sched_cache)
            row["source_schedule"] = sched_signature(ss["schedules"])
            row["source_schedule_count"] = len(ss["schedules"])
        else:
            row["source_schedule"] = set()
            row["source_schedule_count"] = 0

        # ---- verdicts ----
        verdicts = []
        sm_, cm_ = row["source_import_mode"], row["central_import_mode"]
        if sm_ and cm_ and sm_ != cm_:
            verdicts.append(f"MODE_MISMATCH(src={sm_},central={cm_})")
        if sm_ == "SPICE" and cm_ == "SPICE" and row["source_schedule"] != row["central_schedule"]:
            verdicts.append("SCHEDULE_MISMATCH")
        if cfg["import_mode"] and cm_ and cfg["import_mode"] != cm_:
            verdicts.append(f"YAML_VS_CENTRAL(yaml={cfg['import_mode']},central={cm_})")
        if not src_id:
            verdicts.append("SOURCE_UNRESOLVED")
        row["verdict"] = "|".join(verdicts) if verdicts else "OK"
        rows.append(row)
        print(f"  {name:42} src={str(sm_):12} central={str(cm_):12} {row['verdict']}", flush=True)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = args.output_root / f"dataset-import-mode-audit-{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)

    def setify(o):
        if isinstance(o, set):
            return sorted(str(x) for x in o)
        return o

    json_rows = [{k: setify(v) for k, v in r.items()} for r in rows]
    (out_dir / "audit.json").write_text(json.dumps(json_rows, indent=2, default=str) + "\n", encoding="utf-8")

    with (out_dir / "audit.csv").open("w", newline="", encoding="utf-8") as f:
        cols = [
            "dir", "dataset_name", "verdict",
            "source_import_mode", "central_import_mode", "declared_import_mode",
            "source_schedule_count", "central_schedule_count",
            "central_match", "source_match", "central_id", "source_id",
        ]
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)

    verdict_counts = Counter(r["verdict"].split("|")[0] if r["verdict"] != "OK" else "OK" for r in rows)
    print("\n=== SUMMARY ===", flush=True)
    mode_mm = [r for r in rows if "MODE_MISMATCH" in r["verdict"]]
    sched_mm = [r for r in rows if "SCHEDULE_MISMATCH" in r["verdict"]]
    unresolved = [r for r in rows if not r["source_id"]]
    print(f"datasets: {len(rows)}", flush=True)
    print(f"MODE_MISMATCH (source vs central): {len(mode_mm)}", flush=True)
    for r in mode_mm:
        print(f"  - {r['dir']}: source={r['source_import_mode']} central={r['central_import_mode']} ({r['source_match']})", flush=True)
    print(f"SCHEDULE_MISMATCH (both SPICE, schedule differs): {len(sched_mm)}", flush=True)
    for r in sched_mm:
        print(f"  - {r['dir']}: src#{r['source_schedule_count']} central#{r['central_schedule_count']}", flush=True)
    print(f"SOURCE_UNRESOLVED: {len(unresolved)}", flush=True)
    print(f"\nWrote {out_dir}", flush=True)


if __name__ == "__main__":
    main()
