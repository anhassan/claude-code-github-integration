"""
Safely import a QuickSight asset bundle into a target account for review.

This is intentionally separate from import_qs_dashboards.py. It imports the
bundle, writes an audit trail, and optionally adds imported assets to a folder.
It does not recreate datasets, generate workspace config, or delete assets.
"""

import argparse
import hashlib
import json
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import boto3
from botocore.exceptions import ClientError


SUCCESS_STATUS = "SUCCESSFUL"
FAILED_STATUSES = {
    "FAILED",
    "FAILED_WITH_ERRORS",
    "FAILED_ROLLBACK_COMPLETED",
    "FAILED_ROLLBACK_ERROR",
}

FOLDER_MEMBER_TYPES = {
    "analysis": "ANALYSIS",
    "dashboard": "DASHBOARD",
    "dataset": "DATASET",
    "datasource": "DATASOURCE",
    "topic": "TOPIC",
}

DESCRIBE_BY_RESOURCE_TYPE = {
    "analysis": ("describe_analysis", "AnalysisId"),
    "dashboard": ("describe_dashboard", "DashboardId"),
    "dataset": ("describe_data_set", "DataSetId"),
    "datasource": ("describe_data_source", "DataSourceId"),
}


class AssetBundleImportFailed(RuntimeError):
    def __init__(self, response):
        self.response = response
        super().__init__(json.dumps(response, indent=2, default=str))


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def slugify(value):
    safe = "".join(char if char.isalnum() else "_" for char in value).strip("_")
    while "__" in safe:
        safe = safe.replace("__", "_")
    return safe or "quicksight-import"


def get_session(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def parse_bundle_artifacts(bundle_path):
    if not zipfile.is_zipfile(bundle_path):
        raise ValueError(f"{bundle_path} is not a zip-compatible QuickSight bundle")

    artifacts = []
    with zipfile.ZipFile(bundle_path) as bundle:
        for info in bundle.infolist():
            if info.is_dir() or not info.filename.endswith(".json"):
                continue

            path = PurePosixPath(info.filename)
            if len(path.parts) < 2:
                continue

            resource_type = path.parts[0]
            resource_id = Path(path.name).stem
            artifact = {
                "resource_type": resource_type,
                "resource_id": resource_id,
                "bundle_path": info.filename,
            }

            try:
                with bundle.open(info) as file:
                    body = json.loads(file.read().decode("utf-8"))
                artifact["name"] = body.get("name") or body.get("Name")
            except Exception as error:
                artifact["parse_error"] = str(error)

            artifacts.append(artifact)

    return artifacts


def unpack_bundle(bundle_path, output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = []
    with zipfile.ZipFile(bundle_path) as bundle:
        for info in bundle.infolist():
            if info.is_dir():
                continue

            member_path = PurePosixPath(info.filename)
            if member_path.is_absolute() or ".." in member_path.parts:
                manifest.append(
                    {
                        "bundle_path": info.filename,
                        "extracted_path": None,
                        "status": "skipped",
                        "reason": "unsafe path",
                    }
                )
                continue

            parts = list(member_path.parts)
            target_path = output_dir.joinpath(*parts)
            short_path = target_path
            status = "extracted"
            reason = None

            if len(str(target_path.resolve())) >= 240:
                digest = hashlib.sha1(info.filename.encode("utf-8")).hexdigest()[:10]
                suffix = member_path.suffix
                stem = member_path.stem[:48].rstrip("-_.") or "bundle-member"
                parts[-1] = f"{stem}-{digest}{suffix}"
                short_path = output_dir.joinpath(*parts)
                status = "extracted_with_shortened_name"
                reason = "local path would be too long on Windows"

            short_path.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(info) as source, short_path.open("wb") as target:
                target.write(source.read())

            manifest.append(
                {
                    "bundle_path": info.filename,
                    "extracted_path": str(short_path.relative_to(output_dir)),
                    "status": status,
                    "reason": reason,
                }
            )

    write_json(output_dir / "_extraction_manifest.json", manifest)


def check_existing_assets(qs_client, account_id, artifacts, resource_id_prefix=""):
    rows = []
    for artifact in artifacts:
        resource_type = artifact["resource_type"]
        if resource_type not in DESCRIBE_BY_RESOURCE_TYPE:
            continue

        method_name, id_kwarg = DESCRIBE_BY_RESOURCE_TYPE[resource_type]
        target_id = f"{resource_id_prefix}{artifact['resource_id']}"
        kwargs = {"AwsAccountId": account_id, id_kwarg: target_id}
        try:
            getattr(qs_client, method_name)(**kwargs)
            exists = True
            error = None
        except ClientError as client_error:
            code = client_error.response.get("Error", {}).get("Code")
            if code == "ResourceNotFoundException":
                exists = False
                error = None
            else:
                exists = None
                error = str(client_error)

        rows.append(
            {
                **artifact,
                "target_resource_id": target_id,
                "exists_in_target": exists,
                "error": error,
            }
        )
    return rows


def patch_bundle_exclude_datasets(bundle_path, names_to_exclude, output_path):
    """Return a new bundle zip at *output_path* with the named datasets removed.

    Removed entries:
    - ``dataset/<dataset-id>.json``      for each excluded dataset id
    - ``refreshSchedule/<dataset-id>--refresh-schedule--*.json``

    DataSetIdentifierDeclarations inside the analysis/dashboard JSON are left
    intact so that QuickSight can still validate the schema.  Visuals that
    reference excluded datasets will show errors in the UI, but the import will
    succeed.
    """
    names_set = set(names_to_exclude)

    # Pass 1: resolve dataset names → ids from the bundle
    excluded_ids = set()
    with zipfile.ZipFile(bundle_path, "r") as zin:
        for info in zin.infolist():
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            if path.parts[0] == "dataset" and path.suffix == ".json":
                try:
                    body = json.loads(zin.read(info.filename).decode("utf-8"))
                    ds_name = body.get("name") or body.get("Name") or ""
                    if ds_name in names_set:
                        excluded_ids.add(path.stem)
                except Exception:
                    pass

    if not excluded_ids:
        print(
            f"Warning: none of the requested datasets {sorted(names_set)} were found in the bundle.",
            flush=True,
        )

    # Pass 2: copy all entries except those belonging to excluded dataset ids
    excluded_entries = []
    kept_count = 0
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle_path, "r") as zin, zipfile.ZipFile(
        output_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as zout:
        for info in zin.infolist():
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            resource_type = path.parts[0] if path.parts else ""

            exclude = False
            if resource_type == "dataset" and path.stem in excluded_ids:
                exclude = True
            elif resource_type == "refreshSchedule":
                ds_id = path.stem.split("--refresh-schedule--")[0]
                if ds_id in excluded_ids:
                    exclude = True

            if exclude:
                excluded_entries.append(info.filename)
            else:
                zout.writestr(info, zin.read(info.filename))
                kept_count += 1

    print(
        f"Bundle patched: {kept_count} entries kept, {len(excluded_entries)} excluded",
        flush=True,
    )
    for entry in excluded_entries:
        print(f"  excluded: {entry}", flush=True)
    return excluded_entries


def build_override_parameters(resource_id_prefix):
    if not resource_id_prefix:
        return None
    return {
        "ResourceIdOverrideConfiguration": {
            "PrefixForAllResources": resource_id_prefix
        }
    }


def start_import_job(
    qs_client,
    account_id,
    job_id,
    bundle_path,
    resource_id_prefix="",
    rollback=True,
    lenient=True,
):
    params = {
        "AwsAccountId": account_id,
        "AssetBundleImportJobId": job_id,
        "AssetBundleImportSource": {"Body": bundle_path.read_bytes()},
        "FailureAction": "ROLLBACK" if rollback else "DO_NOTHING",
    }

    override_parameters = build_override_parameters(resource_id_prefix)
    if override_parameters:
        params["OverrideParameters"] = override_parameters

    if lenient:
        params["OverrideValidationStrategy"] = {
            "StrictModeForAllResources": False
        }

    return qs_client.start_asset_bundle_import_job(**params)


def wait_for_import_job(qs_client, account_id, job_id, poll_seconds, timeout_seconds):
    started_at = time.time()
    while True:
        response = qs_client.describe_asset_bundle_import_job(
            AwsAccountId=account_id,
            AssetBundleImportJobId=job_id,
        )
        status = response["JobStatus"]
        print(f"Import job {job_id}: {status}", flush=True)

        if status == SUCCESS_STATUS:
            return response
        if status in FAILED_STATUSES:
            raise AssetBundleImportFailed(response)
        if time.time() - started_at > timeout_seconds:
            raise TimeoutError(
                f"Import job {job_id} did not finish within {timeout_seconds} seconds"
            )

        time.sleep(poll_seconds)


def add_imported_assets_to_folder(qs_client, account_id, folder_id, artifacts, resource_id_prefix=""):
    results = []
    for artifact in artifacts:
        member_type = FOLDER_MEMBER_TYPES.get(artifact["resource_type"])
        if not member_type:
            continue

        member_id = f"{resource_id_prefix}{artifact['resource_id']}"
        try:
            response = qs_client.create_folder_membership(
                AwsAccountId=account_id,
                FolderId=folder_id,
                MemberId=member_id,
                MemberType=member_type,
            )
            status = "ADDED"
            error = None
        except ClientError as client_error:
            code = client_error.response.get("Error", {}).get("Code")
            if code == "ResourceExistsException":
                response = None
                status = "ALREADY_EXISTS"
                error = None
            else:
                response = None
                status = "ERROR"
                error = str(client_error)

        print(
            f"Folder membership {folder_id}: {status} {member_type} {member_id}",
            flush=True,
        )
        results.append(
            {
                **artifact,
                "member_id": member_id,
                "member_type": member_type,
                "folder_id": folder_id,
                "status": status,
                "error": error,
                "response": response,
            }
        )

    return results


def build_output_dir(output_root, label, dashboard_id, run_id):
    return Path(output_root) / f"{slugify(label)}-{dashboard_id}" / run_id


def parse_args():
    parser = argparse.ArgumentParser(
        description="Safely import a QuickSight bundle for review."
    )
    parser.add_argument("--profile", help="AWS profile to use")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--account-id", help="Target QuickSight AWS account id")
    parser.add_argument("--bundle-path", required=True, help="Path to bundle.qs")
    parser.add_argument("--label", help="Human-readable import label")
    parser.add_argument("--dashboard-id", help="Dashboard id in the bundle")
    parser.add_argument(
        "--folder-id",
        help="Optional QuickSight folder id to add imported assets to after import",
    )
    parser.add_argument(
        "--resource-id-prefix",
        default="",
        help="Optional prefix to prepend to every imported resource id",
    )
    parser.add_argument(
        "--output-root",
        default="exports/quicksight-import",
        help="Root folder for import audit output",
    )
    parser.add_argument(
        "--job-id",
        help="Optional QuickSight import job id. Defaults to a generated id.",
    )
    parser.add_argument(
        "--poll-seconds",
        type=int,
        default=10,
        help="Seconds between import status checks",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=1800,
        help="Maximum seconds to wait for the import job",
    )
    parser.add_argument(
        "--precheck-only",
        action="store_true",
        help="Only parse the bundle and check target id collisions; do not import.",
    )
    parser.add_argument(
        "--allow-existing",
        action="store_true",
        help="Allow import to proceed even when target ids already exist.",
    )
    parser.add_argument(
        "--do-nothing-on-failure",
        action="store_true",
        help="Use QuickSight DO_NOTHING failure action instead of ROLLBACK.",
    )
    parser.add_argument(
        "--strict-validation",
        action="store_true",
        help="Do not request lenient validation for dashboards and analyses.",
    )
    parser.add_argument(
        "--exclude-datasets",
        nargs="*",
        metavar="DATASET_NAME",
        default=None,
        help=(
            "Dataset names to strip from the bundle before importing. "
            "Use when the dashboard references datasets that no longer exist in QuickSight "
            "(e.g. --exclude-datasets TFM_Posdata TFM_PNL_SA). "
            "A patched bundle is written to the import audit folder as bundle_patched.qs."
        ),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    bundle_path = Path(args.bundle_path)
    if not bundle_path.exists():
        raise FileNotFoundError(bundle_path)

    session = get_session(args.profile, args.region)
    qs_client = session.client("quicksight", region_name=args.region)

    account_id = args.account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)

    artifacts = parse_bundle_artifacts(bundle_path)
    dashboard_artifacts = [
        artifact for artifact in artifacts if artifact["resource_type"] == "dashboard"
    ]
    dashboard_id = args.dashboard_id or (
        dashboard_artifacts[0]["resource_id"] if dashboard_artifacts else "unknown"
    )
    label = args.label or (
        dashboard_artifacts[0].get("name") if dashboard_artifacts else bundle_path.parent.name
    )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    job_id = args.job_id or f"import-{dashboard_id}-{run_id}"
    output_dir = build_output_dir(args.output_root, label, dashboard_id, run_id)

    existing_assets = check_existing_assets(
        qs_client, account_id, artifacts, args.resource_id_prefix
    )
    existing_count = sum(1 for asset in existing_assets if asset["exists_in_target"])

    write_json(
        output_dir / "request.json",
        {
            "profile": args.profile,
            "region": args.region,
            "account_id": account_id,
            "caller_identity": caller_identity,
            "bundle_path": str(bundle_path),
            "label": label,
            "dashboard_id": dashboard_id,
            "job_id": job_id,
            "folder_id": args.folder_id,
            "resource_id_prefix": args.resource_id_prefix,
            "failure_action": "DO_NOTHING"
            if args.do_nothing_on_failure
            else "ROLLBACK",
            "lenient_validation": not args.strict_validation,
        },
    )
    write_json(output_dir / "bundle_artifacts.json", artifacts)
    write_json(output_dir / "target_asset_precheck.json", existing_assets)

    unpack_bundle(bundle_path, output_dir / "bundle")

    print(f"Bundle artifacts: {len(artifacts)}", flush=True)
    print(f"Existing target ids: {existing_count}", flush=True)
    print(f"Import audit folder: {output_dir}", flush=True)

    if args.precheck_only:
        print("Precheck only requested; no import job started.", flush=True)
        return

    if existing_count and not args.allow_existing:
        raise RuntimeError(
            f"{existing_count} target asset id(s) already exist. "
            "Rerun with --allow-existing or --resource-id-prefix if this is intentional."
        )

    import_bundle_path = bundle_path
    if args.exclude_datasets:
        patched_path = output_dir / "bundle_patched.qs"
        print(
            f"Patching bundle to exclude datasets: {args.exclude_datasets}",
            flush=True,
        )
        patch_bundle_exclude_datasets(bundle_path, args.exclude_datasets, patched_path)
        import_bundle_path = patched_path

    start_response = start_import_job(
        qs_client,
        account_id,
        job_id,
        import_bundle_path,
        resource_id_prefix=args.resource_id_prefix,
        rollback=not args.do_nothing_on_failure,
        lenient=not args.strict_validation,
    )
    write_json(output_dir / "start_import_job_response.json", start_response)

    try:
        import_response = wait_for_import_job(
            qs_client,
            account_id,
            job_id,
            args.poll_seconds,
            args.timeout_seconds,
        )
    except AssetBundleImportFailed as error:
        write_json(output_dir / "import_job_failed_response.json", error.response)
        raise

    write_json(output_dir / "import_job_response.json", import_response)

    if args.folder_id:
        folder_results = add_imported_assets_to_folder(
            qs_client,
            account_id,
            args.folder_id,
            artifacts,
            args.resource_id_prefix,
        )
        write_json(output_dir / "folder_membership_results.json", folder_results)

    print(f"Import succeeded: {label}", flush=True)
    print(f"Import audit folder: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
