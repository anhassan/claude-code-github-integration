
import boto3
import uuid
import time
import urllib.request
import base64
import yaml
import os
import shutil

def write_yaml_to_file(yaml_content, file_name):
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, 'w') as file:
        yaml.dump(yaml_content, file, default_flow_style=False, sort_keys=False)
    print(f"YAML content written to file: {file_name}")

def write_sql_to_file(sql_content, file_name):
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, 'w') as file:
        file.write(sql_content)
    print(f"SQL content written to file: {file_name}")

def write_json_to_file(json_content, file_name):
    import json
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, 'w') as file:
        json.dump(json_content, file, indent=4)
    print(f"JSON content written to file: {file_name}")


def get_dashboard_id(dashboard_name, qs_client, aws_account_id):
    paginator = qs_client.get_paginator('list_dashboards')
    for page in paginator.paginate(AwsAccountId=aws_account_id):
        for dashboard in page['DashboardSummaryList']:
            if dashboard['Name'] == dashboard_name:
                print(f"Found Dashboard: {dashboard['Name']} with ID: {dashboard['DashboardId']}")
                return dashboard['DashboardId']
    raise ValueError(f"Dashboard with name '{dashboard_name}' not found.")


def describe_dashboard(dashboard_id, qs_client, aws_account_id):
    response = qs_client.describe_dashboard_definition(
        AwsAccountId=aws_account_id,
        DashboardId=dashboard_id
    )
    print(f"Described Dashboard: {response['Name']} with ID: {response['DashboardId']}")
    return response

def get_dataset_definition(dataset_id, qs_client, aws_account_id):
    response = qs_client.describe_data_set(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id
    )
    print(f"Described Dataset: {response['DataSet']['Name']} with ID: {response['DataSet']['DataSetId']}")
    return response

def get_dashboard_datasets(dashboard_definition, qs_client, aws_account_id):
    ds_artifacts =  dashboard_definition["Definition"]["DataSetIdentifierDeclarations"]
    datasets = []
    for ds in ds_artifacts:
        dataset_id = ds["DataSetArn"].split("/")[-1]
        dataset_definition = get_dataset_definition(dataset_id, qs_client, aws_account_id)
        datasets.append(dataset_definition)
    return datasets

def get_dataset_refresh_schedules(dataset_id, qs_client, aws_account_id):
    response = qs_client.describe_data_set_refresh_schedules(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id
    )
    print(f"Described Refresh Schedules for Dataset ID: {dataset_id} - Num of Schedules: {len(response['RefreshSchedules'])}")
    return response["RefreshSchedules"]


def get_dashboard_metadata(dashboard_id, qs_client, aws_account_id, workspace_name, env):
    dashboard_definition = describe_dashboard(dashboard_id, qs_client, aws_account_id)
    dashboard_ds_definitions = get_dashboard_datasets(dashboard_definition, qs_client, aws_account_id)

    # Dashboard Metadata
    dashboard_name = dashboard_definition["Name"]
    dashboard_folder_name = dashboard_name.replace(" ", "_").lower()
    dashboard_id = f"{dashboard_name.replace(' ', '_').lower()}-{workspace_name}-{env}"
    dashboard_override_name = f"{dashboard_name.title().replace(' ', '').lower()}/DEVELOP"

    dashboard_metadata = {
        "DashboardId": dashboard_id,
        "DashboardName" : dashboard_name,
        "DashboardCuratedName" : dashboard_override_name,
        "Folder" : dashboard_folder_name
    }

    # Datasets Metadata
    ds_metadata = []
    for ds_definition in dashboard_ds_definitions:
        ds_name = ds_definition['DataSet']['Name']
        ds_id = ds_definition['DataSet']['DataSetId']
        ds_cols = ds_definition['DataSet']['PhysicalTableMap'][list(ds_definition['DataSet']['PhysicalTableMap'].keys())[0]]['CustomSql']['Columns']
        ds_query = ds_definition['DataSet']['PhysicalTableMap'][list(ds_definition['DataSet']['PhysicalTableMap'].keys())[0]]['CustomSql']['SqlQuery']
        
        ds_metadata.append({
            "DataSetId" : ds_id,
            "DataSetCuratedId": ds_name.replace(" ","_").lower(),
            "DataSetName" : ds_name,
            "Columns" : ds_cols,
            "Query" : ds_query,
            "RefreshSchedules" : get_dataset_refresh_schedules(ds_id, qs_client, aws_account_id)
        })
    
    return dashboard_metadata, ds_metadata


def get_export_overrides(dashboard_metadata, ds_metadata):
    dashboard_overrides = [{"DashboardId": dashboard_metadata["DashboardId"], "Name" : dashboard_metadata["DashboardCuratedName"]}]
    print(f"Dashboard Overrides: {dashboard_overrides}")

    analysis_overrides = [{"AnalysisId": f"analysis-{dashboard_metadata['DashboardId']}", "Name" : dashboard_metadata["DashboardCuratedName"]}] 
    print(f"Analysis Overrides: {analysis_overrides}")

    dataset_overrides = [{"DataSetId": ds["DataSetCuratedId"], "Name" : ds["DataSetCuratedId"]} for ds in ds_metadata]
    print(f"Dataset Overrides: {dataset_overrides}")


    
    export_overrides = {
        "Dashboards" : dashboard_overrides,
        "Analyses" : analysis_overrides,
        "DataSets" : dataset_overrides
    }

    return export_overrides


def create_ds_metadata_file(ds_id, ds_cols, ds_refresh_schedules, workspace_name):
    ds_yaml_metadata_file_name = f"{env}/datasets/{ds_id}/metadata.yaml"
    ds_metadata_cols = {col["Name"] : col["Type"] for col in ds_cols}

    ds_metadata_json =  {
                    "name": ds_id,
                    "force_sync": True,
                    "import_mode": "SPICE",
                    "workspaces": [
                        workspace_name
                    ],
                    "columns": ds_metadata_cols,
                    }
    for schedule in ds_refresh_schedules:
        if schedule["RefreshType"] == "FULL_REFRESH":
            ds_metadata_json["refresh_schedule"] = {
                "ScheduleId": schedule["ScheduleId"],
                "RefreshType" : schedule["RefreshType"],
                "ScheduleFrequency": schedule["ScheduleFrequency"]
            }
    write_yaml_to_file(ds_metadata_json, ds_yaml_metadata_file_name)
    print(f"Dataset metadata YAML file created for dataset: {ds_id} at location: {ds_yaml_metadata_file_name}")
                    

def create_ds_query_file(ds_id, ds_query, env):
    ds_query_file_name = f"{env}/datasets/{ds_id}/query.sql"
    write_sql_to_file(ds_query, ds_query_file_name)
    print(f"Dataset query SQL file created for dataset: {ds_id} at location: {ds_query_file_name}")


def create_ds_config_files(ds_metadata, workspace_name="default", env="dev"):
    for ds in ds_metadata:
        ds_id = ds["DataSetCuratedId"]
        ds_cols = ds["Columns"]
        ds_query = ds["Query"]
        ds_refresh_schedules = ds["RefreshSchedules"]
        create_ds_metadata_file(ds_id, ds_cols, ds_refresh_schedules, workspace_name)
        create_ds_query_file(ds_id, ds_query, env)


def create_dashboard_config_file(dashboard_metadata, env, 
                                 ad_grp="AWS_SSO_QS_AUTHOR_MA_BI",department="Management Analytics",
                                 product_owner_name="Joanna Lei", product_owner_email="jlei@cppib.com"
                                ):
    dashboard_config_file_name = f"{env}/assets/{dashboard_metadata['DashboardId']}/config.yaml"
    dashboard_config = {
            "base_dashboard_name": dashboard_metadata["DashboardCuratedName"].replace("/DEVELOP", ""),
            "display_name": dashboard_metadata["DashboardName"],
            "id_prefix": dashboard_metadata["DashboardName"].replace(" ", "_").lower(),
            "branch": "DEVELOP",
            "version": "latest",
            "use_fixed": False,
            "force_sync": True,
            "owners": [
                ad_grp
            ],
            "finsights_detail": {
                "department": department,
                "product_owners": [
                {
                    "name": product_owner_name,
                    "email": product_owner_email
                }
                ]
            }
            }
    write_yaml_to_file(dashboard_config, dashboard_config_file_name)
    print(f"Dashboard config YAML file created for dashboard: {dashboard_metadata['DashboardName']} at location: {dashboard_config_file_name}")


def create_dashboard_export_override_file(dashboard_metadata,export_overrides):
    dashboard_export_override_file_name = f"{dashboard_metadata['DashboardName']}/overrides.json"
    write_json_to_file(export_overrides, dashboard_export_override_file_name)
    print(f"Dashboard export override JSON file created at location: {dashboard_export_override_file_name}")


def start_dashboard_export(dashboard_name, dashboard_arn, qs_client, aws_account_id):
    job_id = f"export-{aws_account_id}-{dashboard_name.replace(' ', '_')}-{int(time.time())}"
    response = qs_client.start_asset_bundle_export_job(
        AwsAccountId=aws_account_id,
        AssetBundleExportJobId=job_id,
        ResourceArns=[dashboard_arn],
        IncludeAllDependencies=True,
        ExportFormat="QUICKSIGHT_JSON",
        IncludePermissions=False,
        IncludeTags=True,
        IncludeFolderMemberships=True
    )
    print(f"Started Export For Dashboard: {dashboard_name} with JobId: {response['AssetBundleExportJobId']}")
    return response["AssetBundleExportJobId"]


def wait_for_dashboard_export(job_id, dashboard_name, qs_client, aws_account_id):
    while True:
        response = qs_client.describe_asset_bundle_export_job(
            AwsAccountId=aws_account_id,
            AssetBundleExportJobId=job_id
        )
        print(f"Checking Export Job Status for Dashboard: {dashboard_name} - JobId: {job_id} - Status: {response['JobStatus']}")
        status = response["JobStatus"]

        if status == "SUCCESSFUL":
            print(f"Export Successful for Dashboard: {dashboard_name} - JobId: {job_id}. Download URL: {response['DownloadUrl']}")
            return response["DownloadUrl"]
        elif status in ("FAILED", "FAILED_WITH_ERRORS", "FAILED_ROLLBACK_COMPLETED"):
            raise RuntimeError(f"Export failed for Dashboard: {dashboard_name} - JobId: {job_id} with Status: {status} and Response: {response}")

        time.sleep(5)

def download_exported_dashboard(download_url, dashboard_name, local_file_name):
    print(f"Downloading exported dashboard: {dashboard_name} from URL: {download_url} to local file: {local_file_name}")
    urllib.request.urlretrieve(download_url, local_file_name)
    print(f"Download completed for dashboard: {dashboard_name} and saved to: {local_file_name}")

def export_dashboard(dashboard_name, aws_account_id, region, 
                     workspace_name="default", env="dev",
                     ad_grp="AWS_SSO_QS_AUTHOR_MA_BI",department="Management Analytics",
                     product_owner_name="Joanna Lei", product_owner_email="jlei@cppib.com"
                     ):
    # Step 1: Get Dashboard ID
    qs_client = boto3.client("quicksight", region_name=region)
    dashboard_id = get_dashboard_id(dashboard_name, qs_client, aws_account_id)
    dashboard_arn = f"arn:aws:quicksight:{region}:{aws_account_id}:dashboard/{dashboard_id}"

    # Step 2: Start Dashboard Export, Wait for Completion
    job_id = start_dashboard_export(dashboard_name, dashboard_arn, qs_client, aws_account_id)
    download_url = wait_for_dashboard_export(job_id, dashboard_name, qs_client, aws_account_id)

    # Step 3: Download Exported Dashboard
    #local_file_name = f"{dashboard_name.replace(' ', '_')}_export.qs"
    local_file_name = "bundle.qs"
    download_exported_dashboard(download_url, dashboard_name, local_file_name)
    os.makedirs(dashboard_name, exist_ok=True)
    shutil.move(local_file_name, f"{dashboard_name}/{local_file_name}")

    return local_file_name


# Example Usage
dashboard_name = "Holdings Data Quality Tracker"
aws_account_id = "025219251720"
region = "us-east-1"
workspace_name = "bif-data-governance"
env = "dev"
ad_grp="AWS_SSO_QS_Author_Data_Governance"
department="Data Governance"
product_owner_name="Alan Luk"
product_owner_email="aluk@cppib.com"


export_dashboard(dashboard_name, aws_account_id, region, workspace_name, env, ad_grp, department, product_owner_name, product_owner_email)

