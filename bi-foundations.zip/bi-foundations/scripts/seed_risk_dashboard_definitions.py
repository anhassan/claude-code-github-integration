# scripts/seed_risk_dashboard_definitions.py
"""Seed migrated risk dashboard definitions into the shared definition bucket
under the 3-level {base}/{branch}/latest key that promote_asset_handler reads.

The migrated dashboards were exported under a 2-level {name}/latest key. This
script copies that object to a clean 3-level key so an assets/<slug>/config.yaml
can reference {base_dashboard_name}/{branch} — sanitizing grandfathered filter
constructs on the way (see sanitize_definition) so the managed CreateDashboard
path accepts the definition.

Read-only by default; pass --apply to perform the seed. Never mutates the live
QuickSight dashboard or the 2-level source object.
"""
from __future__ import annotations

import argparse
import json
import sys

import boto3
from botocore.exceptions import ClientError

BUCKET = "bi-foundations-published-qs-definitions"
# The QS-Admin profile can ListBucket but NOT GetObject/PutObject on the shared
# definitions bucket (verified 2026-06-02: head_object -> 403). Use the Developer
# profile, which has the S3 object access this script needs for the copy.
CENTRAL_PROFILE = "CPPIB-Developer-Dev-200967598245"


def source_key(migrated_name: str) -> str:
    return f"{migrated_name}/latest/dashboard_definition.json"


def target_key(base_dashboard_name: str, branch: str) -> str:
    return f"{base_dashboard_name}/{branch}/latest/dashboard_definition.json"


def plan_copy(bucket, migrated_name, base_dashboard_name, branch):
    return {
        "bucket": bucket,
        "copy_source": {"Bucket": bucket, "Key": source_key(migrated_name)},
        "dest_key": target_key(base_dashboard_name, branch),
    }


def sanitize_definition(doc: dict) -> tuple[dict, int]:
    """Rewrite grandfathered filter constructs the strict CreateDashboard API
    rejects. Mutates and returns doc, plus the number of filters patched.

    Pattern: CategoryFilter Configuration.CustomFilterConfiguration with
    MatchOperator DOES_NOT_EQUAL and an empty CategoryValue (and no
    ParameterName). Legacy dashboards created under LENIENT validation carry
    these ("exclude blank") filters, but the current API cannot represent
    "DOES_NOT_EQUAL empty-string" at all:
      - CustomFilterConfiguration rejects an empty CategoryValue outright
        ("Filter must define only one of Category Value or Parameter Name");
      - the *list* configurations only accept CONTAINS/DOES_NOT_CONTAIN.

    Verified-valid replacement (test-created in uat 2026-06-09, 0 errors):
    CustomFilterConfiguration with SelectAllOptions FILTER_ALL_VALUES and the
    original NullOption (no CategoryValue). This preserves the null exclusion;
    the empty-string exclusion is unrepresentable and is dropped — rows with a
    non-null empty-string value would newly show (rare to nonexistent in the
    affected columns).
    """
    patched = 0

    def walk(node):
        nonlocal patched
        if isinstance(node, dict):
            cfg = node.get("Configuration")
            if isinstance(cfg, dict):
                cfc = cfg.get("CustomFilterConfiguration")
                if (
                    isinstance(cfc, dict)
                    and cfc.get("CategoryValue", "") == ""
                    and not cfc.get("ParameterName")
                    and "SelectAllOptions" not in cfc
                ):
                    replacement = {
                        "MatchOperator": cfc.get("MatchOperator", "DOES_NOT_EQUAL"),
                        "SelectAllOptions": "FILTER_ALL_VALUES",
                    }
                    if "NullOption" in cfc:
                        replacement["NullOption"] = cfc["NullOption"]
                    cfg["CustomFilterConfiguration"] = replacement
                    patched += 1
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(doc)
    return doc, patched


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--migrated-name", required=True, help="2-level def name, e.g. 'ARS-FICC Dashboard'")
    p.add_argument("--base-dashboard-name", required=True, help="clean 3-level base, e.g. RiskARSFICC")
    p.add_argument("--branch", default="DEVELOP")
    p.add_argument("--profile", default=CENTRAL_PROFILE)
    p.add_argument("--apply", action="store_true", help="perform the seed (default: dry-run)")
    args = p.parse_args(argv)

    s3 = boto3.Session(profile_name=args.profile, region_name="us-east-1").client("s3")
    plan = plan_copy(BUCKET, args.migrated_name, args.base_dashboard_name, args.branch)

    # Verify source exists and is parseable; report what sanitization would do
    try:
        body = s3.get_object(Bucket=BUCKET, Key=plan["copy_source"]["Key"])["Body"].read()
    except ClientError as e:
        print(f"ERROR: source def not found: {plan['copy_source']['Key']} ({e})")
        return 1
    doc = json.loads(body)
    doc, patched = sanitize_definition(doc)

    # Refuse to clobber an existing seed
    try:
        s3.head_object(Bucket=BUCKET, Key=plan["dest_key"])
        print(f"ERROR: dest key already exists, refusing to overwrite: {plan['dest_key']}")
        return 1
    except ClientError as e:
        if e.response["Error"]["Code"] not in ("404", "NoSuchKey"):
            print(f"ERROR: checking dest key: {e}")
            return 1
        # 404 / NoSuchKey = dest does not exist, safe to proceed

    print(
        f"PLAN: seed\n  from {plan['copy_source']['Key']}\n  to   {plan['dest_key']}\n"
        f"  sanitized filters: {patched}"
    )
    if not args.apply:
        print("DRY-RUN — pass --apply to perform the seed")
        return 0

    s3.put_object(
        Bucket=BUCKET,
        Key=plan["dest_key"],
        Body=json.dumps(doc).encode("utf-8"),
        ContentType="application/json",
    )
    print(f"SEEDED ({patched} filters sanitized)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
