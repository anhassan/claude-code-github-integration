"""
Reconcile central SPICE refresh schedules to match the bif-risk repo YAMLs.

The publish pipeline only create-or-updates refresh schedules; it never deletes
ones that fall out of config. After the 2026-06-01 import-mode/schedule
reconciliation, central SPICE datasets can carry stale schedules (old
`daily_refresh` IDs that duplicate the new per-time IDs, or schedules a dataset
should no longer have). This tool brings each SPICE dataset's central schedules
to EXACTLY the set declared in its metadata.yaml:

  * create/update every schedule declared in the YAML (by ScheduleId)
  * delete any central schedule whose ScheduleId is not in the YAML

Scope: the SPICE datasets only (verdict SCHEDULE_MISMATCH in the audit). Flip
targets (now DIRECT_QUERY in YAML) are skipped here - their schedules are
dropped by the import-mode change at publish; verify those separately.

Read-only by default. Pass --apply to perform create/update/delete.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import boto3
import yaml
from botocore.exceptions import ClientError

CENTRAL_PROFILE = "CPPIB-Quicksight-Admin-200967598245"
CENTRAL_ACCOUNT = "200967598245"
RISK_DATASETS = Path("c:/Users/nabed/workspace/bi/bif-risk/dev/datasets")


def desired_schedules(dataset_dir: str) -> list[dict]:
    meta = RISK_DATASETS / dataset_dir / "metadata.yaml"
    cfg = yaml.safe_load(meta.read_text(encoding="utf-8")) or {}
    rs = cfg.get("refresh_schedule")
    if not rs:
        return []
    items = rs if isinstance(rs, list) else [rs]
    out = []
    for s in items:
        out.append(
            {
                "ScheduleId": s["ScheduleId"],
                "RefreshType": s["RefreshType"],
                "ScheduleFrequency": s["ScheduleFrequency"],
            }
        )
    return out


def current_schedules(qs, dataset_id: str) -> list[dict]:
    try:
        r = qs.list_refresh_schedules(AwsAccountId=CENTRAL_ACCOUNT, DataSetId=dataset_id)
    except ClientError as err:
        print(f"    list error: {err.response.get('Error', {}).get('Code')}")
        return []
    return r.get("RefreshSchedules", []) or []


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--audit-json", type=Path, required=True, help="audit.json from the import-mode audit")
    ap.add_argument("--apply", action="store_true")
    args = ap.parse_args()

    qs = boto3.Session(profile_name=CENTRAL_PROFILE, region_name="us-east-1").client("quicksight")
    rows = json.loads(args.audit_json.read_text(encoding="utf-8"))
    targets = [r for r in rows if "SCHEDULE_MISMATCH" in r["verdict"]]
    print(f"{'APPLY' if args.apply else 'DRY-RUN'}: reconciling {len(targets)} SPICE datasets\n")

    creates = updates = deletes = 0
    for r in sorted(targets, key=lambda x: x["dir"]):
        ds_id = r.get("central_id")
        if not ds_id:
            print(f"{r['dir']}: no central_id, skip")
            continue
        want = {s["ScheduleId"]: s for s in desired_schedules(r["dir"])}
        have = {s["ScheduleId"]: s for s in current_schedules(qs, ds_id)}
        to_delete = [sid for sid in have if sid not in want]
        to_create = [sid for sid in want if sid not in have]
        to_update = [sid for sid in want if sid in have]
        if not (to_delete or to_create):
            print(f"{r['dir']} ({ds_id}): OK ({len(want)} schedules)")
            continue
        print(f"{r['dir']} ({ds_id}): +{len(to_create)} create, ~{len(to_update)} update, -{len(to_delete)} delete")
        for sid in to_delete:
            print(f"    DELETE {sid}")
            deletes += 1
            if args.apply:
                qs.delete_refresh_schedule(AwsAccountId=CENTRAL_ACCOUNT, DataSetId=ds_id, ScheduleId=sid)
        for sid in to_create:
            print(f"    CREATE {sid} {want[sid]['ScheduleFrequency'].get('TimeOfTheDay')}")
            creates += 1
            if args.apply:
                qs.create_refresh_schedule(AwsAccountId=CENTRAL_ACCOUNT, DataSetId=ds_id, Schedule=want[sid])
        for sid in to_update:
            updates += 1
            if args.apply:
                qs.update_refresh_schedule(AwsAccountId=CENTRAL_ACCOUNT, DataSetId=ds_id, Schedule=want[sid])

    print(f"\nTotals: {creates} create, {updates} update, {deletes} delete "
          f"({'APPLIED' if args.apply else 'dry-run only'})")


if __name__ == "__main__":
    main()
