# scripts/verify_risk_promotion.py
"""Read-only post-sync verification of a promoted risk dashboard.

Confirms the managed-id dashboard exists in the target env account. ALS /
OpenSearch checks are listed in the design but are VPC-internal; this script
covers the QuickSight-side assertion that the publish landed.
"""
from __future__ import annotations

import argparse
import sys

import boto3
from botocore.exceptions import ClientError

ACCOUNT_BY_ENV = {
    "dev": "200967598245",
    "qa": "885014163466",
    "uat": "207662059077",
    "prod": "679601897237",
}


TERMINAL_OK = {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}


def classify_status(status: str) -> tuple[int, str]:
    """Map a dashboard Version.Status to (exit_code, label)."""
    if status in TERMINAL_OK:
        return 0, "OK"
    return 2, "NOT_READY"


def classify_error(code: str) -> tuple[int, str]:
    """Map a botocore error code to (exit_code, label)."""
    if code == "ResourceNotFoundException":
        return 1, "MISSING"
    return 2, "ERROR"


def asset_id(id_prefix: str, env: str) -> str:
    return f"{id_prefix}-bif-risk-{env}"


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--id-prefix", required=True)
    p.add_argument("--env", required=True, choices=list(ACCOUNT_BY_ENV))
    args = p.parse_args(argv)

    account = ACCOUNT_BY_ENV[args.env]
    profile = f"CPPIB-Quicksight-Admin-{account}"
    qs = boto3.Session(profile_name=profile, region_name="us-east-1").client("quicksight")
    did = asset_id(args.id_prefix, args.env)
    try:
        resp = qs.describe_dashboard(AwsAccountId=account, DashboardId=did)
        status = resp["Dashboard"]["Version"]["Status"]
        rc, label = classify_status(status)
        print(f"{label}: {did} in {account} (status {status})")
        return rc
    except ClientError as e:
        rc, label = classify_error(e.response["Error"]["Code"])
        print(f"{label}: {did} in {account}: {e}")
        return rc


if __name__ == "__main__":
    sys.exit(main())
