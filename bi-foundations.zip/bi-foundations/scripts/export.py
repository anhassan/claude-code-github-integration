import os
import json
import boto3

source_account_id = "714023498348"

client = boto3.client("quicksight", region_name="us-east-1")

_folder = "bi_biz/{}"

def export_dashboards():
    folder = _folder.format("dashboards")
    with open("dashboards.json", "r") as f:
        data = json.load(f)
    for dashboard in data["DashboardSummaryList"]:
        response = client.describe_dashboard_definition(
            AwsAccountId=source_account_id,
            DashboardId=dashboard["DashboardId"]
        )
        with open(os.path.join(folder, "{}.json".format(dashboard["DashboardId"])), "w") as f:
            json.dump(response, f, default=str)

def export_analyses():
    folder = _folder.format("analyses")
    with open("analyses.json", "r") as f:
        data = json.load(f)
    for analysis in data["analyses"]:
        response = client.describe_analysis_definition(
            AwsAccountId=source_account_id,
            AnalysisId=analysis
        )
        with open(os.path.join(folder, "{}.json".format(analysis)), "w") as f:
            json.dump(response, f, default=str, indent=4)

def export_datasets():
    folder = _folder.format("datasets")
    with open("datasets.json", "r") as f:
        data = json.load(f)
    for dataset in data["datasets"]:
        print(dataset)
        try:
            response = client.describe_data_set(
                AwsAccountId=source_account_id,
                DataSetId=dataset
            )
            with open(os.path.join(folder, "{}.json".format(dataset)), "w") as f:
                json.dump(response, f, default=str, indent=4)
        except Exception as e:
            print(e)

# export_dashboards()
export_analyses()
# export_datasets()