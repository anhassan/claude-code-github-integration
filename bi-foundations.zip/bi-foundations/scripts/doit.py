import boto3

with open('query.sql', 'r') as f:
    query = f.read()

qs_client = boto3.client('quicksight', region_name='us-east-1')

response = qs_client.create_data_set(
        AwsAccountId='200967598245',
        DataSetId='test-api-dataset',
        Name='test-api-dataset',
        PhysicalTableMap={
            "table-map-test": {
                "CustomSql": {
                    "DataSourceArn": "arn:aws:quicksight:us-east-1:200967598245:datasource/fabric_catalog_dev",
                    "Name": "custom-sql-test",
                    "SqlQuery": query
                }
            }
        },
        ImportMode="SPICE"
    )