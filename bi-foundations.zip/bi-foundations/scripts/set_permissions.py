import boto3
import uuid
from pprint import pprint

lf_client = boto3.client("lakeformation", region_name="us-east-1")

local_account_id = "471112514923"
fabric_account_id = "679601897237"
environment = "prod"

arn_kwargs = {
    "region": "us-east-1",
    "account": local_account_id,
    "qs_role_name": "aws-quicksight-service-role-v0"
}

service_role_arn = "arn:aws:iam::{account}:role/service-role/{qs_role_name}".format(**arn_kwargs)
creator_arn = "arn:aws:iam::{account}:role/AWSControlTowerExecution".format(**arn_kwargs)

view_database = "finance_accounting"
view_table = "vw_cost_insights_report"

database = "ma_cost_insights_{}".format(environment)
table = "cost_insights_report"

def build_quicksight_permissions():
    entries = []
    for user in [service_role_arn, creator_arn]:
        for db, tbl in [(view_database, view_table), (database, table)]:
            # add rlink perms
            entries.append(
                {
                    "Id": uuid.uuid4().hex,
                    "Principal": {
                        "DataLakePrincipalIdentifier": user
                    },
                    "Resource": {
                        "Database": {
                            "CatalogId": local_account_id,
                            "Name": db
                        }
                    },
                    "Permissions": [
                        "DESCRIBE"
                    ]
                }
            )
            # add shared table perms
            entries.append(
                {
                    "Id": uuid.uuid4().hex,
                    "Principal": {
                        "DataLakePrincipalIdentifier": user
                    },
                    "Resource": {
                        "Table": {
                            "CatalogId": fabric_account_id,
                            "DatabaseName": db,
                            "Name": tbl
                        }
                    },
                    "Permissions": [
                        "SELECT",
                        "DESCRIBE"
                    ]
                }
            )
    return entries

entries = build_quicksight_permissions()

pprint(entries)
lf_client.batch_grant_permissions(Entries=entries)
