import os
import json
import boto3

source_account_id = "714023498348"
target_account_id = "274628362356"

client = boto3.client("quicksight", region_name="us-east-1")

folder_arn = "arn:aws:quicksight:us-east-1:274628362356:folder/fee50ba4-16de-4a27-9cfb-9a8d67a724cb"
principal = "arn:aws:quicksight:us-east-1:{}:group/default/AWS_SSO_Developer_Management_Analytics".format(target_account_id)
theme_actions = [
    "quicksight:ListThemeVersions",
    "quicksight:UpdateThemeAlias",
    "quicksight:DescribeThemeAlias",
    "quicksight:UpdateThemePermissions",
    "quicksight:DeleteThemeAlias",
    "quicksight:DeleteTheme",
    "quicksight:ListThemeAliases",
    "quicksight:DescribeTheme",
    "quicksight:CreateThemeAlias",
    "quicksight:UpdateTheme",
    "quicksight:DescribeThemePermissions"
]

def iter_dir(directory):
    for fpath in os.listdir(directory):
        with open(os.path.join(directory, fpath), 'r') as f:
            yield json.load(f)

def import_datasets():
    for dataset_def in iter_dir("dq-recovery/datasets"):
        logical_map = dataset_def["DataSet"]["LogicalTableMap"]
        response = client.create_data_set(
            AwsAccountId=target_account_id,
            DataSetId=dataset_def["DataSet"]["DataSetId"],
            Name=dataset_def["DataSet"]["Name"],
            LogicalTableMap=logical_map,
            PhysicalTableMap={},
            FolderArns=[folder_arn],
            ImportMode="SPICE"
        )
        print(response)

def import_themes():
    for theme_def in iter_dir("bi_biz/themes"):
        theme = theme_def["Theme"]
        version = theme["Version"]
        response = client.create_theme(
            AwsAccountId=target_account_id,
            ThemeId=theme["ThemeId"],
            Name=theme["Name"],
            BaseThemeId=version["BaseThemeId"],
            Configuration=version["Configuration"],
            Permissions=[
                {
                    "Principal": principal,
                    "Actions": theme_actions
                }
            ]
        )
        print(response)

def import_analyses():
    for analysis_def in iter_dir("bi_biz/analyses"):
        validation = "LENIENT"
        print(analysis_def["AnalysisId"])
        print("Validation: {}".format(validation))
        try:
            response = client.update_analysis(
                AwsAccountId=target_account_id,
                Name="{} (LATEST, MIGRATED)".format(analysis_def["Name"]),
                AnalysisId=analysis_def["AnalysisId"],
                Definition=analysis_def["Definition"],
                # FolderArns=[folder_arn],
                ThemeArn=analysis_def["ThemeArn"],
                ValidationStrategy={"Mode": validation}
            )
            print(response)
        except client.exceptions.ResourceExistsException:
            print("Already exists")

def import_dashboards():
    for dashboard_def in iter_dir("bi_biz/dashboards"):
        validation = "LENIENT"
        print(dashboard_def["DashboardId"])
        print("Validation: {}".format(validation))
        try:
            response = client.create_dashboard(
                AwsAccountId=target_account_id,
                Name=dashboard_def["Name"],
                DashboardId=dashboard_def["DashboardId"],
                Definition=dashboard_def["Definition"],
                # FolderArns=[folder_arn],
                ThemeArn=dashboard_def["ThemeArn"],
                ValidationStrategy={"Mode": validation}
            )
            print(response)
        except client.exceptions.ResourceExistsException:
            print("Already exists")

# import_themes()
import_analyses()
# import_dashboards()
# import_datasets()