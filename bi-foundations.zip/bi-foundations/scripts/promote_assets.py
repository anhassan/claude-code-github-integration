# scripts/promote_assets.py
"""Promote a dashboard (its assets/ config + dataset dependency closure) from
one bif-risk env folder to another.

Computes the dataset closure from the dashboard's QuickSight definition
(DataSetIdentifierDeclarations), maps each dataset id back to its slug folder,
and copies assets/<slug>/ + datasets/<dep>/ from the source env folder into the
target. Dry-run by default; --apply performs the file copies. Writes a
promotion manifest under exports/risk-dashboard-migration/.

The dashboard definition is read from the shared definition bucket
(bi-foundations-published-qs-definitions/<base>/<branch>/latest) unless a local
--definition-file is given (used by tests and offline runs).
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import boto3

from scripts.risk_promotion_common import (
    load_dataset_index,
    dataset_id_to_slug,
    extract_dataset_arns,
    expand_join_dependencies,
)

BUCKET = "bi-foundations-published-qs-definitions"
# Profile used to read the dashboard definition from the shared bucket. The
# QS-Admin profile lacks S3 GetObject there (verified 2026-06-02: 403); the
# Developer profile has it. Irrelevant when --definition-file is used.
CENTRAL_PROFILE = "CPPIB-Developer-Dev-200967598245"
MANIFEST_DIR = Path(__file__).resolve().parent.parent / "exports" / "risk-dashboard-migration"


def compute_promotion(source_env_dir, target_env_dir, dashboard_slug, definition, env):
    source_env_dir = Path(source_env_dir)
    index = load_dataset_index(source_env_dir / "datasets", env=env)
    arns = extract_dataset_arns(definition)

    slugs: list[str] = []
    unresolved: list[tuple[str, str]] = []
    for dataset_id, account in arns:
        slug = dataset_id_to_slug(dataset_id, index)
        if slug is None:
            unresolved.append((dataset_id, account))
        elif slug not in slugs:
            slugs.append(slug)
    # dataset->dataset join dependencies (e.g. vol_greeks LEFT JOIN fx_rate)
    slugs, unresolved_joins = expand_join_dependencies(
        slugs, source_env_dir / "datasets", index
    )
    for ref in unresolved_joins:
        unresolved.append((ref, "join"))
    slugs.sort()

    copies = [{"rel": f"assets/{dashboard_slug}",
               "src": source_env_dir / "assets" / dashboard_slug,
               "dst": Path(target_env_dir) / "assets" / dashboard_slug}]
    for slug in slugs:
        copies.append({"rel": f"datasets/{slug}",
                       "src": source_env_dir / "datasets" / slug,
                       "dst": Path(target_env_dir) / "datasets" / slug})

    return {"dashboard_slug": dashboard_slug, "dataset_slugs": slugs,
            "unresolved": unresolved, "copies": copies}


def _load_definition(args):
    if args.definition_file:
        return json.loads(Path(args.definition_file).read_text())
    key = f"{args.base_dashboard_name}/{args.branch}/latest/dashboard_definition.json"
    s3 = boto3.Session(profile_name=args.profile, region_name="us-east-1").client("s3")
    body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read()
    return json.loads(body)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", default="c:/Users/nabed/workspace/bi/bif-risk")
    p.add_argument("--source-env", default="dev")
    p.add_argument("--target-env", required=True)
    p.add_argument("--dashboard-slug", required=True)
    p.add_argument("--base-dashboard-name", help="for fetching def from S3")
    p.add_argument("--branch", default="DEVELOP")
    p.add_argument("--definition-file", help="local def json (skips S3)")
    p.add_argument("--profile", default=CENTRAL_PROFILE)
    p.add_argument("--apply", action="store_true")
    args = p.parse_args(argv)

    if not args.definition_file and not args.base_dashboard_name:
        p.error("--base-dashboard-name is required when --definition-file is not given")

    repo = Path(args.repo)
    if not (repo / args.source_env / "datasets").is_dir():
        print(f"ERROR: --repo {repo} has no {args.source_env}/datasets; check --repo path")
        return 1
    definition = _load_definition(args)
    result = compute_promotion(
        source_env_dir=repo / args.source_env,
        target_env_dir=repo / args.target_env,
        dashboard_slug=args.dashboard_slug,
        definition=definition,
        env=args.source_env,
    )

    print(f"Dashboard: {result['dashboard_slug']}")
    print(f"Datasets ({len(result['dataset_slugs'])}): {result['dataset_slugs']}")
    if result["unresolved"]:
        print(f"UNRESOLVED dataset refs: {result['unresolved']}")
        if args.apply:
            print("Refusing to apply with unresolved deps. Reconcile first.")
            return 1

    for c in result["copies"]:
        exists = "OK" if Path(c["src"]).exists() else "MISSING-SRC"
        print(f"  {c['rel']}  [{exists}] -> {c['dst']}")

    if args.apply and not result["unresolved"]:
        for c in result["copies"]:
            src, dst = Path(c["src"]), Path(c["dst"])
            if not src.exists():
                print(f"ERROR: source missing: {src}")
                return 1
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        MANIFEST_DIR.mkdir(parents=True, exist_ok=True)
        manifest = MANIFEST_DIR / f"promotion_{args.dashboard_slug}_{args.source_env}_to_{args.target_env}_{ts}.json"
        manifest.write_text(json.dumps(
            {"dashboard": result["dashboard_slug"], "target_env": args.target_env,
             "datasets": result["dataset_slugs"]}, indent=2))
        print(f"APPLIED. Manifest: {manifest}")
    elif not args.apply:
        print("DRY-RUN — pass --apply to copy")
    return 0


if __name__ == "__main__":
    sys.exit(main())
