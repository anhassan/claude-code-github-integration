"""
Systematic rewrite of `parseDate({col})` calc fields (no format string) in
migrated Risk dashboards + analyses.

Why:
- The current AWS QuickSight validator rejects `parseDate({col})` without a
  format string. The migration script uses ValidationStrategy.Mode=LENIENT so
  dashboards land anyway, but the calc fields silently return null or wrong
  values at query time.
- Per-dashboard apply_patches.py scripts handled some of these, but the
  systematic sweep was never done. 126 instances remain across 14 dashboards.
- Made worse by publisher column-type flips: e.g. `ae_limits.business_date`
  is STRING in source but DATETIME in central; `parseDate(datetime)` fails.

What:
For each central dashboard/analysis, find every calc field matching
`parseDate({col})` (no format), look up `{col}` in the central dataset:
  * If column is DATETIME: drop the parseDate wrapper, use `{col}` directly.
  * If column is STRING: add `, 'yyyy-MM-dd'` format string (the bif-risk
    cohort migration's documented standard; per-column overrides supported
    via --format-override).
  * If column type is unknown or absent: leave the calc field alone, report
    as `unsafe`.

Safety:
- Default to dry-run; writes per-resource diff JSON. `--apply` updates the
  dashboard or analysis in place.
- A `--format-override <dataset_id>:<col>:<format>` flag lets you specify
  per-column formats when the data isn't `yyyy-MM-dd`.
- For dashboards: also calls `update_dashboard_published_version` after a
  successful `update_dashboard` so the rewrite actually reaches the
  published version that viewers see.

Inputs:
  --target-profile, --target-account-id, --region
  --dashboards-file (default: exports/risk-dashboard-migration/migrated_dashboard_ids.txt)
  --analyses-file (default: exports/risk-dashboard-migration/migrated_analysis_ids.txt)
  --format-override (repeatable)
  --apply
"""

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


NO_FORMAT_PARSEDATE = re.compile(r"parseDate\(\s*\{([^}]+)\}\s*\)")


def write_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
        f.write("\n")


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def read_id_file(path):
    rows = []
    p = Path(path)
    if not p.exists():
        return rows
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        resource_id, _, label = line.partition(",")
        rows.append({"id": resource_id.strip(), "label": label.strip()})
    return rows


def parse_format_overrides(values):
    """Format: <dataset_id>:<col>:<format>"""
    overrides = {}
    for v in values or []:
        parts = v.split(":", 2)
        if len(parts) != 3:
            raise ValueError(f"Bad --format-override: {v!r} (expected dataset_id:col:format)")
        ds_id, col, fmt = parts
        overrides[(ds_id.strip(), col.strip())] = fmt.strip()
    return overrides


def dataset_id_from_arn(arn):
    return (arn or "").rsplit("/", 1)[-1]


def build_dataset_column_type_lookup(qs, account_id, declarations):
    """Returns {dataset_identifier: {col_name: column_type}} via describe_data_set
    for each unique DataSetArn in the dashboard/analysis declarations."""
    lookup = {}
    cache_by_dataset_id = {}
    for decl in declarations or []:
        ident = decl.get("Identifier")
        arn = decl.get("DataSetArn") or ""
        ds_id = dataset_id_from_arn(arn)
        if not ds_id:
            lookup[ident] = {}
            continue
        if ds_id not in cache_by_dataset_id:
            try:
                resp = qs.describe_data_set(AwsAccountId=account_id, DataSetId=ds_id)
                cols = resp.get("DataSet", {}).get("OutputColumns", []) or []
                cache_by_dataset_id[ds_id] = {
                    (c.get("Name") or ""): {
                        "Type": c.get("Type"),
                        "SubType": c.get("SubType"),
                    }
                    for c in cols
                }
            except ClientError as error:
                cache_by_dataset_id[ds_id] = {"_error": error.response.get("Error", {})}
        lookup[ident] = cache_by_dataset_id[ds_id]
    return lookup


def find_explicit_format_for_column(definition, dataset_identifier, col):
    """Return a format string if any other calc field in this definition
    references parseDate({col}, '<format>') against the same dataset, else None."""
    pat = re.compile(
        r"parseDate\(\s*\{"
        + re.escape(col)
        + r"\}\s*,\s*['\"]([^'\"]+)['\"]\s*\)"
    )
    for c in definition.get("CalculatedFields", []) or []:
        if c.get("DataSetIdentifier") != dataset_identifier:
            continue
        expr = c.get("Expression") or ""
        m = pat.search(expr)
        if m:
            return m.group(1)
    return None


def rewrite_definition(definition, account_id, qs, format_overrides):
    """Returns (rewritten_definition, changes_list).
    changes_list is a list of {dataset_identifier, calc_field_name, before, after, action, column_type, inferred_format}"""
    declarations = definition.get("DataSetIdentifierDeclarations", []) or []
    column_types = build_dataset_column_type_lookup(qs, account_id, declarations)

    changes = []
    cfs = definition.get("CalculatedFields", []) or []
    for c in cfs:
        ds_ident = c.get("DataSetIdentifier", "")
        expr = c.get("Expression") or ""
        nm = c.get("Name") or ""

        # All distinct columns referenced via parseDate({col}) (no format)
        matches = NO_FORMAT_PARSEDATE.findall(expr)
        if not matches:
            continue

        new_expr = expr
        any_change = False
        for col in set(matches):
            ds_cols = column_types.get(ds_ident) or {}
            if "_error" in ds_cols:
                changes.append({
                    "dataset_identifier": ds_ident,
                    "calc_field": nm,
                    "column": col,
                    "action": "skipped_unsafe",
                    "reason": f"describe_data_set failed: {ds_cols['_error']}",
                    "before": expr,
                })
                continue
            col_meta = ds_cols.get(col)
            if not col_meta:
                changes.append({
                    "dataset_identifier": ds_ident,
                    "calc_field": nm,
                    "column": col,
                    "action": "skipped_unsafe",
                    "reason": "column not found in central dataset",
                    "before": expr,
                })
                continue
            col_type = col_meta.get("Type")
            # Build replacement
            if col_type == "DATETIME":
                # Drop parseDate({col}) → {col}
                replacement = "{" + col + "}"
                action = "drop_parsedate_on_datetime"
                inferred_format = None
            elif col_type == "STRING":
                # Add format string. Prefer override; else explicit-elsewhere; else yyyy-MM-dd
                override = format_overrides.get((dataset_id_from_arn(
                    next(
                        (d.get("DataSetArn") or "") for d in declarations
                        if d.get("Identifier") == ds_ident
                    )
                ), col))
                if override:
                    fmt = override
                    inferred_format = f"override({override})"
                else:
                    explicit = find_explicit_format_for_column(definition, ds_ident, col)
                    if explicit:
                        fmt = explicit
                        inferred_format = f"inferred_from_same_dataset({explicit})"
                    else:
                        fmt = "yyyy-MM-dd"
                        inferred_format = "default(yyyy-MM-dd)"
                replacement = "parseDate({" + col + "}, '" + fmt + "')"
                action = "add_format_string"
            else:
                changes.append({
                    "dataset_identifier": ds_ident,
                    "calc_field": nm,
                    "column": col,
                    "action": "skipped_unsafe",
                    "reason": f"column type {col_type!r} is not STRING or DATETIME",
                    "before": expr,
                })
                continue

            # Replace ALL occurrences of parseDate({col}) -- no format -- with replacement.
            # Use a pattern that doesn't match parseDate({col}, '...') (already-formatted).
            specific_pat = re.compile(
                r"parseDate\(\s*\{" + re.escape(col) + r"\}\s*\)"
            )
            new_expr_candidate = specific_pat.sub(replacement, new_expr)
            if new_expr_candidate != new_expr:
                changes.append({
                    "dataset_identifier": ds_ident,
                    "calc_field": nm,
                    "column": col,
                    "action": action,
                    "column_type": col_type,
                    "inferred_format": inferred_format,
                    "before": new_expr,
                    "after": new_expr_candidate,
                })
                new_expr = new_expr_candidate
                any_change = True

        if any_change:
            c["Expression"] = new_expr

    return definition, changes


def update_dashboard(qs, account_id, dashboard_id, name, definition, apply_changes,
                     dashboard_publish_options=None, theme_arn=None):
    if not apply_changes:
        return {"status": "dry_run"}
    params = {
        "AwsAccountId": account_id,
        "DashboardId": dashboard_id,
        "Name": name,
        "Definition": definition,
    }
    if dashboard_publish_options:
        params["DashboardPublishOptions"] = dashboard_publish_options
    if theme_arn:
        params["ThemeArn"] = theme_arn
    response = qs.update_dashboard(**params)
    return {
        "status": "OK",
        "version_arn": response.get("VersionArn"),
        "creation_status": response.get("CreationStatus"),
    }


def publish_dashboard_version(qs, account_id, dashboard_id, version_number, apply_changes):
    if not apply_changes:
        return {"status": "dry_run"}
    try:
        qs.update_dashboard_published_version(
            AwsAccountId=account_id,
            DashboardId=dashboard_id,
            VersionNumber=int(version_number),
        )
        return {"status": "OK"}
    except ClientError as error:
        return {"status": "ERROR", "error": error.response.get("Error", {})}


def update_analysis(qs, account_id, analysis_id, name, definition, apply_changes,
                    theme_arn=None):
    if not apply_changes:
        return {"status": "dry_run"}
    params = {
        "AwsAccountId": account_id,
        "AnalysisId": analysis_id,
        "Name": name,
        "Definition": definition,
    }
    if theme_arn:
        params["ThemeArn"] = theme_arn
    response = qs.update_analysis(**params)
    return {
        "status": "OK",
        "arn": response.get("Arn"),
        "update_status": response.get("UpdateStatus"),
    }


def wait_dashboard_version(qs, account_id, dashboard_id, version_number, poll_seconds, timeout_seconds):
    import time
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        resp = qs.describe_dashboard(
            AwsAccountId=account_id,
            DashboardId=dashboard_id,
            VersionNumber=int(version_number),
        )
        status = resp["Dashboard"]["Version"]["Status"]
        if status in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
            return status
        if status in {"CREATION_FAILED", "UPDATE_FAILED", "DELETED"}:
            return status
        time.sleep(poll_seconds)
    return "TIMEOUT"


def wait_analysis_ready(qs, account_id, analysis_id, poll_seconds, timeout_seconds):
    import time
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        resp = qs.describe_analysis(AwsAccountId=account_id, AnalysisId=analysis_id)
        status = resp["Analysis"]["Status"]
        if status in {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}:
            return status
        if status in {"CREATION_FAILED", "UPDATE_FAILED", "DELETED"}:
            return status
        time.sleep(poll_seconds)
    return "TIMEOUT"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Systematically rewrite parseDate({col}) calc fields in central Risk dashboards/analyses."
    )
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument(
        "--dashboards-file",
        default="exports/risk-dashboard-migration/migrated_dashboard_ids.txt",
    )
    parser.add_argument(
        "--analyses-file",
        default="exports/risk-dashboard-migration/migrated_analysis_ids.txt",
    )
    parser.add_argument(
        "--format-override",
        action="append",
        default=[],
        help="<dataset_id>:<col>:<format>, repeatable",
    )
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--poll-seconds", type=int, default=5)
    parser.add_argument("--timeout-seconds", type=int, default=600)
    parser.add_argument(
        "--output-root",
        default="exports/risk-dashboard-migration",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    overrides = parse_format_overrides(args.format_override)
    session = session_for(args.target_profile, args.region)
    qs = session.client("quicksight", region_name=args.region)

    dashboards = read_id_file(args.dashboards_file)
    analyses = read_id_file(args.analyses_file)
    print(f"Processing {len(dashboards)} dashboards and {len(analyses)} analyses", flush=True)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(args.output_root) / f"parsedate-rewrite-{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = {"dashboards": [], "analyses": []}

    for entry in dashboards:
        dashboard_id = entry["id"]
        label = entry["label"]
        record = {"id": dashboard_id, "label": label}
        try:
            dash = qs.describe_dashboard(
                AwsAccountId=args.target_account_id, DashboardId=dashboard_id
            )
            name = dash["Dashboard"]["Name"]
            defn = qs.describe_dashboard_definition(
                AwsAccountId=args.target_account_id, DashboardId=dashboard_id
            )
            current_def = defn["Definition"]
            current_publish_options = defn.get("DashboardPublishOptions")
            current_theme_arn = defn.get("ThemeArn")
        except ClientError as error:
            record["error"] = error.response.get("Error", {})
            summary["dashboards"].append(record)
            print(f"  [{label}] describe failed: {error}", flush=True)
            continue

        try:
            rewritten_def, changes = rewrite_definition(
                current_def, args.target_account_id, qs, overrides
            )
        except Exception as error:
            record["error"] = {"type": type(error).__name__, "message": str(error)}
            record["apply_result"] = {"status": "REWRITE_ERROR"}
            write_json(out_dir / f"dashboard-{dashboard_id}-changes.json", record)
            summary["dashboards"].append(record)
            print(f"  [{label}] rewrite error: {error}", flush=True)
            continue

        record["change_count"] = sum(1 for c in changes if c.get("action") in {"add_format_string", "drop_parsedate_on_datetime"})
        record["unsafe_count"] = sum(1 for c in changes if c.get("action") == "skipped_unsafe")
        record["changes"] = changes

        if record["change_count"] == 0:
            record["apply_result"] = {"status": "no_changes"}
            write_json(out_dir / f"dashboard-{dashboard_id}-changes.json", record)
            summary["dashboards"].append(record)
            print(f"  [{label}] no changes (unsafe: {record['unsafe_count']})", flush=True)
            continue

        if args.apply:
            try:
                upd = update_dashboard(
                    qs, args.target_account_id, dashboard_id, name, rewritten_def, True,
                    dashboard_publish_options=current_publish_options,
                    theme_arn=current_theme_arn,
                )
                record["apply_result"] = upd
                ver_arn = upd.get("version_arn") or ""
                ver_no = ver_arn.rsplit("/", 1)[-1] if ver_arn else ""
                if ver_no:
                    status = wait_dashboard_version(
                        qs,
                        args.target_account_id,
                        dashboard_id,
                        ver_no,
                        args.poll_seconds,
                        args.timeout_seconds,
                    )
                    record["wait_status"] = status
                    if status == "UPDATE_SUCCESSFUL" or status == "CREATION_SUCCESSFUL":
                        pub = publish_dashboard_version(
                            qs, args.target_account_id, dashboard_id, ver_no, True
                        )
                        record["publish_result"] = pub
            except ClientError as error:
                record["apply_result"] = {"status": "ERROR", "error": error.response.get("Error", {})}
            except Exception as error:
                record["apply_result"] = {"status": "ERROR", "error_type": type(error).__name__, "error_message": str(error)[:1000]}
        else:
            record["apply_result"] = {"status": "dry_run"}

        write_json(out_dir / f"dashboard-{dashboard_id}-changes.json", record)
        summary["dashboards"].append(record)
        print(
            f"  [{label}] changes={record['change_count']} unsafe={record['unsafe_count']} apply={record.get('apply_result',{}).get('status')}",
            flush=True,
        )

    for entry in analyses:
        analysis_id = entry["id"]
        label = entry["label"]
        record = {"id": analysis_id, "label": label}
        try:
            an = qs.describe_analysis(
                AwsAccountId=args.target_account_id, AnalysisId=analysis_id
            )
            name = an["Analysis"]["Name"]
            defn = qs.describe_analysis_definition(
                AwsAccountId=args.target_account_id, AnalysisId=analysis_id
            )
            current_def = defn["Definition"]
            analysis_theme_arn = defn.get("ThemeArn")
        except ClientError as error:
            record["error"] = error.response.get("Error", {})
            summary["analyses"].append(record)
            print(f"  [analysis {label}] describe failed: {error}", flush=True)
            continue

        try:
            rewritten_def, changes = rewrite_definition(
                current_def, args.target_account_id, qs, overrides
            )
        except Exception as error:
            record["error"] = {"type": type(error).__name__, "message": str(error)}
            record["apply_result"] = {"status": "REWRITE_ERROR"}
            write_json(out_dir / f"analysis-{analysis_id}-changes.json", record)
            summary["analyses"].append(record)
            print(f"  [analysis {label}] rewrite error: {error}", flush=True)
            continue

        record["change_count"] = sum(1 for c in changes if c.get("action") in {"add_format_string", "drop_parsedate_on_datetime"})
        record["unsafe_count"] = sum(1 for c in changes if c.get("action") == "skipped_unsafe")
        record["changes"] = changes

        if record["change_count"] == 0:
            record["apply_result"] = {"status": "no_changes"}
            write_json(out_dir / f"analysis-{analysis_id}-changes.json", record)
            summary["analyses"].append(record)
            print(f"  [analysis {label}] no changes (unsafe: {record['unsafe_count']})", flush=True)
            continue

        if args.apply:
            try:
                upd = update_analysis(
                    qs, args.target_account_id, analysis_id, name, rewritten_def, True,
                    theme_arn=analysis_theme_arn,
                )
                record["apply_result"] = upd
                status = wait_analysis_ready(
                    qs, args.target_account_id, analysis_id, args.poll_seconds, args.timeout_seconds
                )
                record["wait_status"] = status
            except ClientError as error:
                record["apply_result"] = {"status": "ERROR", "error": error.response.get("Error", {})}
            except Exception as error:
                record["apply_result"] = {"status": "ERROR", "error_type": type(error).__name__, "error_message": str(error)[:1000]}
        else:
            record["apply_result"] = {"status": "dry_run"}

        write_json(out_dir / f"analysis-{analysis_id}-changes.json", record)
        summary["analyses"].append(record)
        print(
            f"  [analysis {label}] changes={record['change_count']} unsafe={record['unsafe_count']} apply={record.get('apply_result',{}).get('status')}",
            flush=True,
        )

    write_json(out_dir / "summary.json", summary)
    print(f"Output: {out_dir}", flush=True)


if __name__ == "__main__":
    main()
