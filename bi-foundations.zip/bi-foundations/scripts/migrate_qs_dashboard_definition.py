"""
Migrate QuickSight dashboards by definition remap instead of dependency bundle.

This is for dashboards whose asset-bundle export is blocked by S3 data sources
created from local manifests. The script reads source dashboard/analysis
definitions, remaps DataSetIdentifierDeclarations to target dataset ARNs, and
optionally creates/updates the target analysis and dashboard.
"""

import argparse
import copy
import csv
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


FAILED_VERSION_STATUSES = {"CREATION_FAILED", "UPDATE_FAILED", "DELETED"}
SUCCESS_VERSION_STATUSES = {"CREATION_SUCCESSFUL", "UPDATE_SUCCESSFUL"}

ANALYSIS_CO_OWNER_ACTIONS = [
    "quicksight:RestoreAnalysis",
    "quicksight:UpdateAnalysisPermissions",
    "quicksight:DeleteAnalysis",
    "quicksight:QueryAnalysis",
    "quicksight:DescribeAnalysisPermissions",
    "quicksight:DescribeAnalysis",
    "quicksight:UpdateAnalysis",
]


DATASET_UUID_PATTERN = (
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
)
DATASET_UUID_RE = re.compile(DATASET_UUID_PATTERN)
MISSING_DATASET_ID_RE = re.compile(
    r"(?:MissingDataSetId_)+(" + DATASET_UUID_PATTERN + r")"
)
MISSING_DATASET_IDENTIFIER_RE = re.compile(
    r"^(?:MissingDataSetId_)+(" + DATASET_UUID_PATTERN + r")$"
)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=str)
        file.write("\n")


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def read_json(path):
    with Path(path).open(encoding="utf-8") as file:
        return json.load(file)


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def parse_column_aliases(values):
    aliases = {}
    for value in values or []:
        if ":" not in value or "=" not in value:
            raise ValueError(
                "Column aliases must use DATASET_IDENTIFIER:SOURCE_COLUMN=TARGET_COLUMN, "
                f"got {value!r}"
            )
        identifier, rest = value.split(":", 1)
        source_column, target_column = rest.split("=", 1)
        identifier = identifier.strip()
        source_column = source_column.strip()
        target_column = target_column.strip()
        if not identifier or not source_column or not target_column:
            raise ValueError(
                "Column aliases must include a dataset identifier, source column, "
                f"and target column, got {value!r}"
            )
        aliases.setdefault(identifier, {})[source_column] = target_column
    return aliases


def slugify(value):
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", (value or "").strip())
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or "dashboard"


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "_", (value or "").lower()).strip("_")


def arn_resource_id(arn):
    return (arn or "").split("/")[-1]


def load_target_inventory(path):
    if not path:
        return {"by_id": {}, "by_name": {}, "by_normalized_name": {}}
    inventory = read_json(path)
    by_id = {}
    by_name = {}
    by_normalized_name = {}
    for dataset in inventory.get("datasets", []):
        dataset_id = dataset.get("dataset_id")
        name = dataset.get("name")
        if dataset_id:
            by_id[dataset_id] = dataset
        if name:
            by_name.setdefault(name, dataset)
            by_normalized_name.setdefault(normalize(name), dataset)
    return {
        "by_id": by_id,
        "by_name": by_name,
        "by_normalized_name": by_normalized_name,
    }


def index_dataset_map(path):
    by_id = {}
    by_name = {}
    if not path:
        return by_id, by_name

    path = Path(path)
    if path.suffix.lower() == ".csv":
        rows = read_csv(path)
    else:
        payload = read_json(path)
        rows = payload.get("rows") or payload.get("results") or []

    for row in rows:
        source_dataset_id = row.get("source_dataset_id")
        source_dataset_name = row.get("source_dataset_name")
        target_dataset_arn = (
            row.get("target_dataset_arn")
            or row.get("target_data_set_arn")
            or row.get("target_arn")
        )
        target_dataset_id = row.get("target_dataset_id") or arn_resource_id(target_dataset_arn)
        if not target_dataset_arn and target_dataset_id and row.get("target_account_id"):
            target_dataset_arn = "arn:aws:quicksight:us-east-1:{}:dataset/{}".format(
                row["target_account_id"],
                target_dataset_id,
            )

        candidate = {
            "target_dataset_arn": target_dataset_arn,
            "target_dataset_id": target_dataset_id,
            "target_dataset_name": row.get("target_dataset_name") or source_dataset_name,
            "source": str(path),
        }
        if source_dataset_id and target_dataset_arn:
            by_id[source_dataset_id] = candidate
        if source_dataset_name and target_dataset_arn:
            by_name[source_dataset_name] = candidate
            by_name[normalize(source_dataset_name)] = candidate
    return by_id, by_name


def describe_dataset_name(qs_client, account_id, dataset_id):
    try:
        response = qs_client.describe_data_set(
            AwsAccountId=account_id,
            DataSetId=dataset_id,
        )
        return response.get("DataSet", {}).get("Name") or ""
    except Exception:
        return ""


def target_dataset_exists(qs_client, account_id, target_dataset_arn):
    target_dataset_id = arn_resource_id(target_dataset_arn)
    try:
        response = qs_client.describe_data_set(
            AwsAccountId=account_id,
            DataSetId=target_dataset_id,
        )
        return True, response.get("DataSet", {})
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
            return False, {}
        raise


def resolve_target_dataset(
    target_qs_client,
    target_account_id,
    target_region,
    source_dataset_id,
    source_dataset_name,
    explicit_map_by_id,
    explicit_map_by_name,
    target_inventory,
):
    candidate = explicit_map_by_id.get(source_dataset_id)
    if not candidate and source_dataset_name:
        candidate = explicit_map_by_name.get(source_dataset_name) or explicit_map_by_name.get(
            normalize(source_dataset_name)
        )
    reason = "explicit_dataset_map" if candidate else ""

    if not candidate and source_dataset_id in target_inventory["by_id"]:
        dataset = target_inventory["by_id"][source_dataset_id]
        candidate = {
            "target_dataset_arn": dataset.get("arn"),
            "target_dataset_id": dataset.get("dataset_id"),
            "target_dataset_name": dataset.get("name"),
        }
        reason = "target_inventory_id_match"

    if not candidate and source_dataset_name in target_inventory["by_name"]:
        dataset = target_inventory["by_name"][source_dataset_name]
        candidate = {
            "target_dataset_arn": dataset.get("arn"),
            "target_dataset_id": dataset.get("dataset_id"),
            "target_dataset_name": dataset.get("name"),
        }
        reason = "target_inventory_name_match"

    if not candidate and normalize(source_dataset_name) in target_inventory["by_normalized_name"]:
        dataset = target_inventory["by_normalized_name"][normalize(source_dataset_name)]
        candidate = {
            "target_dataset_arn": dataset.get("arn"),
            "target_dataset_id": dataset.get("dataset_id"),
            "target_dataset_name": dataset.get("name"),
        }
        reason = "target_inventory_normalized_name_match"

    if not candidate:
        assumed_arn = f"arn:aws:quicksight:{target_region}:{target_account_id}:dataset/{source_dataset_id}"
        exists, dataset = target_dataset_exists(
            target_qs_client,
            target_account_id,
            assumed_arn,
        )
        if exists:
            candidate = {
                "target_dataset_arn": assumed_arn,
                "target_dataset_id": source_dataset_id,
                "target_dataset_name": dataset.get("Name"),
            }
            reason = "target_describe_same_id_match"

    if not candidate:
        return {
            "source_dataset_id": source_dataset_id,
            "source_dataset_name": source_dataset_name,
            "target_dataset_arn": "",
            "target_dataset_id": "",
            "target_dataset_name": "",
            "target_exists": False,
            "resolution": "UNMAPPED",
        }

    exists, target_dataset = target_dataset_exists(
        target_qs_client,
        target_account_id,
        candidate["target_dataset_arn"],
    )
    return {
        "source_dataset_id": source_dataset_id,
        "source_dataset_name": source_dataset_name,
        "target_dataset_arn": candidate["target_dataset_arn"],
        "target_dataset_id": candidate.get("target_dataset_id") or arn_resource_id(candidate["target_dataset_arn"]),
        "target_dataset_name": candidate.get("target_dataset_name") or target_dataset.get("Name") or "",
        "target_exists": exists,
        "resolution": reason if exists else "TARGET_NOT_FOUND",
    }


PRESERVE_EMPTY_STRING_KEYS = {"CategoryValue"}

UUID_PREFIXED_COLUMN_REF = re.compile(
    r"\{([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\."
    r"([a-zA-Z_][a-zA-Z0-9_]*)\}"
)


def remove_invalid_definition_values(value):
    if isinstance(value, dict):
        for key in [
            key
            for key, item in value.items()
            if item == "" and key not in PRESERVE_EMPTY_STRING_KEYS
        ]:
            del value[key]
        for nested in value.values():
            remove_invalid_definition_values(nested)
    elif isinstance(value, list):
        value[:] = [item for item in value if item != ""]
        for item in value:
            remove_invalid_definition_values(item)


def backfill_required_filter_fields(definition):
    """Add API-required fields that legacy source dashboards may omit.

    Source dashboards created/edited under earlier QuickSight versions can be
    served via UpdateDashboard/UpdateAnalysis with optional fields elided, but
    CreateDashboard / CreateAnalysis reject them. Backfilling with safe defaults
    keeps semantics unchanged for properly-configured filters; for filters that
    were author-broken at source (no Limit + no ParameterName), uses Limit=10
    as a least-surprise default.
    """
    def visit(obj):
        if isinstance(obj, dict):
            tbf = obj.get("TopBottomFilter")
            if isinstance(tbf, dict):
                if "AggregationSortConfigurations" not in tbf:
                    tbf["AggregationSortConfigurations"] = []
                if "Limit" not in tbf and "ParameterName" not in tbf:
                    tbf["Limit"] = 10
            for value in obj.values():
                visit(value)
        elif isinstance(obj, list):
            for item in obj:
                visit(item)

    visit(definition)


def collect_field_ids(value, found=None):
    if found is None:
        found = set()
    if isinstance(value, dict):
        field_id = value.get("FieldId")
        if isinstance(field_id, str):
            found.add(field_id)
        for nested in value.values():
            collect_field_ids(nested, found)
    elif isinstance(value, list):
        for item in value:
            collect_field_ids(item, found)
    return found


def prune_dangling_tooltip_fields(definition):
    """Drop tooltip field items whose FieldId no longer exists on the visual.

    Authors can remove a field from a visual while its tooltip entry persists;
    QuickSight renders such entries as no-ops, but UpdateAnalysis/UpdateDashboard
    reject them ("The Field ID referred in the tooltip is invalid") even under
    LENIENT validation. Pruning them is render-neutral.
    """
    for sheet in definition.get("Sheets", []) or []:
        for visual in sheet.get("Visuals", []) or []:
            for body in visual.values():
                if not isinstance(body, dict):
                    continue
                chart = body.get("ChartConfiguration")
                if not isinstance(chart, dict):
                    continue
                tooltip_fields = (
                    (chart.get("Tooltip") or {})
                    .get("FieldBasedTooltip", {})
                    .get("TooltipFields")
                )
                if not tooltip_fields:
                    continue
                visual_field_ids = collect_field_ids(
                    {key: value for key, value in chart.items() if key != "Tooltip"}
                )
                tooltip_fields[:] = [
                    item
                    for item in tooltip_fields
                    if "FieldTooltipItem" not in item
                    or item["FieldTooltipItem"].get("FieldId") in visual_field_ids
                ]


def strip_stale_uuid_column_prefixes(definition):
    for calc_field in definition.get("CalculatedFields", []) or []:
        expression = calc_field.get("Expression")
        if not expression:
            continue
        rewritten = UUID_PREFIXED_COLUMN_REF.sub(r"{\2}", expression)
        if rewritten != expression:
            calc_field["Expression"] = rewritten


def collapse_stacked_missing_dataset_ids(definition):
    """Make repeated MissingDataSetId_ prefixes idempotent.

    QuickSight can persist invalid dataset references as
    MissingDataSetId_<uuid>. If a migrated/partially-migrated definition is
    passed through again, those placeholders can stack. Collapse them before
    orphan detection and before writing patched definitions so repeated runs do
    not produce MissingDataSetId_MissingDataSetId_... chains.
    """

    def visit(obj):
        if isinstance(obj, dict):
            for key, value in list(obj.items()):
                if isinstance(value, str):
                    obj[key] = MISSING_DATASET_ID_RE.sub(r"MissingDataSetId_\1", value)
                else:
                    visit(value)
        elif isinstance(obj, list):
            for index, value in enumerate(obj):
                if isinstance(value, str):
                    obj[index] = MISSING_DATASET_ID_RE.sub(
                        r"MissingDataSetId_\1", value
                    )
                else:
                    visit(value)

    visit(definition)


def build_target_logical_table_map(target_qs_client, target_account_id, definition):
    target_lt_by_identifier = {}
    for decl in definition.get("DataSetIdentifierDeclarations", []) or []:
        identifier = decl.get("Identifier")
        arn = decl.get("DataSetArn") or ""
        if not identifier or not arn:
            continue
        dataset_id = arn_resource_id(arn)
        try:
            described = target_qs_client.describe_data_set(
                AwsAccountId=target_account_id,
                DataSetId=dataset_id,
            )
        except ClientError:
            continue
        lt_keys = list((described.get("DataSet", {}).get("LogicalTableMap") or {}).keys())
        if lt_keys:
            target_lt_by_identifier[identifier] = lt_keys[0]
    return target_lt_by_identifier


def _rebuild_field_id(old_field_id, central_lt, column_name):
    if not old_field_id:
        return old_field_id
    if "." not in old_field_id:
        return f"{central_lt}.{column_name}.{old_field_id}"
    parts = old_field_id.rsplit(".", 2)
    if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
        return f"{central_lt}.{column_name}.{parts[1]}.{parts[2]}"
    _, rest = old_field_id.split(".", 1)
    return f"{central_lt}.{rest}"


def collect_field_id_rewrites(definition, target_lt_by_identifier):
    rewrites = {}

    # Calc-field-backed visual fields use FieldIds shaped as
    # <calc_field_uuid>.<idx>.<ts> in source (no embedded column name).
    # Rewriting those to <central_lt>.<column>.<idx>.<ts> makes QS resolve
    # them as dataset columns and apply numeric formatting to the calc
    # field's string output. Preserve source FieldIds for columns that
    # match a dashboard-level CalculatedField.
    calc_field_keys = {
        (cf.get("DataSetIdentifier"), cf.get("Name"))
        for cf in (definition.get("CalculatedFields") or [])
        if cf.get("DataSetIdentifier") and cf.get("Name")
    }

    def visit(obj):
        if isinstance(obj, dict):
            column = obj.get("Column")
            if isinstance(column, dict):
                ds_identifier = column.get("DataSetIdentifier")
                column_name = column.get("ColumnName")
                is_calc_field = (ds_identifier, column_name) in calc_field_keys
                if (
                    ds_identifier
                    and column_name
                    and ds_identifier in target_lt_by_identifier
                    and not is_calc_field
                ):
                    central_lt = target_lt_by_identifier[ds_identifier]
                    for key in ("FieldId", "HierarchyId"):
                        old = obj.get(key)
                        if isinstance(old, str) and old:
                            new = _rebuild_field_id(old, central_lt, column_name)
                            if new != old and old not in rewrites:
                                rewrites[old] = new
            for value in obj.values():
                visit(value)
        elif isinstance(obj, list):
            for item in obj:
                visit(item)

    visit(definition)
    return rewrites


def apply_column_aliases(definition, column_aliases):
    if not column_aliases:
        return

    def visit(obj):
        if isinstance(obj, dict):
            column = obj.get("Column")
            if isinstance(column, dict):
                ds_identifier = column.get("DataSetIdentifier")
                column_name = column.get("ColumnName")
                target_name = (
                    column_aliases.get(ds_identifier, {}).get(column_name)
                    if ds_identifier and column_name
                    else None
                )
                if target_name:
                    column["ColumnName"] = target_name
            for value in obj.values():
                visit(value)
        elif isinstance(obj, list):
            for item in obj:
                visit(item)

    visit(definition)


def apply_field_id_rewrites(definition, rewrites):
    if not rewrites:
        return

    def visit(obj):
        if isinstance(obj, dict):
            for key, value in list(obj.items()):
                if isinstance(value, str):
                    new_value = rewrites.get(value)
                    if new_value is not None:
                        obj[key] = new_value
                else:
                    visit(value)
        elif isinstance(obj, list):
            for index, value in enumerate(obj):
                if isinstance(value, str):
                    new_value = rewrites.get(value)
                    if new_value is not None:
                        obj[index] = new_value
                else:
                    visit(value)

    visit(definition)


def remap_definition(
    definition_response,
    mapping_rows,
    target_lt_by_identifier=None,
    column_aliases=None,
):
    patched = copy.deepcopy(definition_response)
    definition = patched.get("Definition") or {}
    by_source_arn_id = {
        row["source_dataset_id"]: row["target_dataset_arn"]
        for row in mapping_rows
        if row.get("target_dataset_arn")
    }

    declarations = []
    for declaration in definition.get("DataSetIdentifierDeclarations", []):
        source_dataset_arn = declaration.get("DataSetArn") or ""
        source_dataset_id = arn_resource_id(source_dataset_arn)
        target_arn = by_source_arn_id.get(source_dataset_id)
        if target_arn:
            declarations.append(
                {
                    "Identifier": declaration["Identifier"],
                    "DataSetArn": target_arn,
                }
            )
        else:
            declarations.append(declaration)

    if declarations:
        definition["DataSetIdentifierDeclarations"] = declarations
    collapse_stacked_missing_dataset_ids(definition)
    strip_stale_uuid_column_prefixes(definition)
    apply_column_aliases(definition, column_aliases)
    if target_lt_by_identifier:
        rewrites = collect_field_id_rewrites(definition, target_lt_by_identifier)
        apply_field_id_rewrites(definition, rewrites)
    remove_invalid_definition_values(definition)
    backfill_required_filter_fields(definition)
    prune_dangling_tooltip_fields(definition)
    return patched


def get_source_analysis_id(dashboard_response):
    source_arn = (
        dashboard_response.get("Dashboard", {})
        .get("Version", {})
        .get("SourceEntityArn")
    )
    if source_arn and ":analysis/" in source_arn:
        return source_arn.split("/")[-1]
    return ""


AWS_MANAGED_THEME_ARN_PREFIX = "arn:aws:quicksight::aws:theme/"


def managed_theme_arn(definition):
    """Return the source ThemeArn when it is an AWS-managed theme.

    Managed theme ARNs are account-agnostic, so they can be applied verbatim in
    the target account. Custom themes are account-scoped resources that would
    need their own migration; dropping them (with the source look reverting to
    the default) is preferable to a hard failure, so they are skipped here.
    """
    theme_arn = definition.get("ThemeArn") or ""
    if theme_arn.startswith(AWS_MANAGED_THEME_ARN_PREFIX):
        return theme_arn
    return None


def create_or_update_analysis(qs_client, account_id, analysis_id, name, definition, apply_changes):
    params = {
        "AwsAccountId": account_id,
        "AnalysisId": analysis_id,
        "Name": name,
        "Definition": definition["Definition"],
        "ValidationStrategy": {"Mode": "LENIENT"},
    }
    if managed_theme_arn(definition):
        params["ThemeArn"] = managed_theme_arn(definition)
    if not apply_changes:
        return {"action": "dry_run", "params": params}

    try:
        qs_client.describe_analysis(AwsAccountId=account_id, AnalysisId=analysis_id)
        response = qs_client.update_analysis(**params)
        action = "updated"
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
            raise
        response = qs_client.create_analysis(**params)
        action = "created"
    return {"action": action, "response": response, "params": params}


def create_or_update_dashboard(qs_client, account_id, dashboard_id, name, definition, apply_changes):
    params = {
        "AwsAccountId": account_id,
        "DashboardId": dashboard_id,
        "Name": name,
        "Definition": definition["Definition"],
        "ValidationStrategy": {"Mode": "LENIENT"},
    }
    if definition.get("DashboardPublishOptions"):
        params["DashboardPublishOptions"] = definition["DashboardPublishOptions"]
    if managed_theme_arn(definition):
        params["ThemeArn"] = managed_theme_arn(definition)

    if not apply_changes:
        return {"action": "dry_run", "params": params}

    try:
        qs_client.describe_dashboard(AwsAccountId=account_id, DashboardId=dashboard_id)
        response = qs_client.update_dashboard(**params)
        action = "updated"
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
            raise
        response = qs_client.create_dashboard(**params)
        action = "created"
    return {"action": action, "response": response, "params": params}


def wait_for_dashboard_version(qs_client, account_id, dashboard_id, version_number, poll_seconds, timeout_seconds):
    started_at = time.time()
    while True:
        response = qs_client.describe_dashboard(
            AwsAccountId=account_id,
            DashboardId=dashboard_id,
            VersionNumber=int(version_number),
        )
        status = response["Dashboard"]["Version"]["Status"]
        print(f"Dashboard {dashboard_id} version {version_number}: {status}", flush=True)
        if status in SUCCESS_VERSION_STATUSES:
            return response
        if status in FAILED_VERSION_STATUSES:
            raise RuntimeError(json.dumps(response, indent=2, default=str))
        if time.time() - started_at > timeout_seconds:
            raise TimeoutError(f"Dashboard {dashboard_id} version {version_number} did not finish within {timeout_seconds} seconds")
        time.sleep(poll_seconds)


def canonical_dataset_identifier(value):
    if not isinstance(value, str):
        return None
    if DATASET_UUID_RE.fullmatch(value):
        return value
    missing_match = MISSING_DATASET_IDENTIFIER_RE.fullmatch(value)
    if missing_match:
        return missing_match.group(1)
    return None


def find_orphan_dataset_uuid_refs(definitions, declared_uuids):
    """Scan describe_*_definition responses for orphan dataset references.

    The targeted pattern: visuals/calc fields contain `Column` blocks with
    DataSetIdentifier set to a UUID instead of a friendly Identifier name —
    meaning the source dashboard's author referenced a dataset that was
    never declared in DataSetIdentifierDeclarations. Source QuickSight
    tolerated this; current validator does not.

    We walk the tree (not generic JSON regex — that catches FieldId /
    FilterId / VisualId UUIDs too) and collect only `DataSetIdentifier`
    values that look like dataset UUIDs.

    Returns the set of candidate orphan UUIDs (does not yet check whether they
    are real source datasets; that's resolve_orphan_uuids' job).
    """
    candidates = set()

    def walk(node):
        if isinstance(node, dict):
            ident = node.get("DataSetIdentifier")
            canonical_ident = canonical_dataset_identifier(ident)
            if canonical_ident:
                candidates.add(canonical_ident)
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    for definition in definitions:
        if not definition:
            continue
        walk(definition)
    return candidates - set(declared_uuids or [])


def resolve_orphan_uuids(orphan_uuids, source_qs_client, source_account_id):
    """For each orphan UUID, classify as either a valid source dataset
    (resolvable via describe_data_set) or stale (ResourceNotFoundException /
    permission error / not a dataset UUID at all — e.g. a FieldId UUID that
    happened to match the regex).

    Returns:
      valid_orphans: {uuid: {"Name": ..., "arn": ...}}
      stale_orphans: set of UUIDs that did not resolve as source datasets
    """
    valid_orphans = {}
    stale_orphans = set()
    for uid in orphan_uuids:
        try:
            ds = source_qs_client.describe_data_set(
                AwsAccountId=source_account_id, DataSetId=uid
            )["DataSet"]
            valid_orphans[uid] = {
                "Name": ds.get("Name", "") or uid,
                "arn": f"arn:aws:quicksight:us-east-1:{source_account_id}:dataset/{uid}",
            }
        except ClientError:
            stale_orphans.add(uid)
    return valid_orphans, stale_orphans


def inject_orphan_declarations(definitions, valid_orphans):
    """Add synthetic DataSetIdentifierDeclarations for each valid orphan UUID
    into every supplied definition's DataSetIdentifierDeclarations list.

    This is what makes the existing remap_definition logic pick up these
    orphan references: by the time remap iterates declarations, the orphans
    are present alongside the originally-declared datasets, so the source
    ARN -> central ARN remap applies uniformly.

    Identifier name: source dataset Name. If that collides with an existing
    Identifier, suffix with the short UUID.
    """
    for definition_obj in definitions:
        if not definition_obj:
            continue
        defn = definition_obj.get("Definition") or {}
        decls = defn.get("DataSetIdentifierDeclarations") or []
        existing_ids = {arn_resource_id(d.get("DataSetArn") or "") for d in decls}
        existing_names = {d.get("Identifier") for d in decls}
        for uid, info in valid_orphans.items():
            if uid in existing_ids:
                continue
            ident = info["Name"] or uid
            if ident in existing_names:
                ident = f"{ident}__{uid[:8]}"
            decls.append(
                {
                    "Identifier": ident,
                    "DataSetArn": info["arn"],
                }
            )
            existing_ids.add(uid)
            existing_names.add(ident)
        defn["DataSetIdentifierDeclarations"] = decls


def parse_excluded_uuid_arg(values):
    """Parse repeated --exclude-source-uuid args of the form <uuid>:<reason>.
    Returns {uuid: reason}. Reasons are recorded in the output summary so the
    decision to exclude is auditable.
    """
    excluded = {}
    for value in values or []:
        if ":" not in value:
            raise ValueError(
                f"--exclude-source-uuid must be <uuid>:<reason>, got {value!r}"
            )
        uid, _, reason = value.partition(":")
        uid = uid.strip()
        reason = reason.strip()
        if not uid or not reason:
            raise ValueError(
                f"--exclude-source-uuid both UUID and reason must be non-empty: {value!r}"
            )
        if not DATASET_UUID_RE.fullmatch(uid):
            raise ValueError(
                f"--exclude-source-uuid UUID {uid!r} is not a valid dataset UUID"
            )
        excluded[uid] = reason
    return excluded


def add_dashboard_to_folder(qs_client, account_id, folder_id, dashboard_id, apply_changes):
    if not folder_id:
        return {"status": "skipped", "reason": "no folder id"}
    if not apply_changes:
        return {"status": "dry_run", "folder_id": folder_id, "dashboard_id": dashboard_id}
    try:
        qs_client.create_folder_membership(
            AwsAccountId=account_id,
            FolderId=folder_id,
            MemberId=dashboard_id,
            MemberType="DASHBOARD",
        )
        return {"status": "added"}
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") == "ResourceExistsException":
            return {"status": "already_exists"}
        raise


def add_analysis_to_folder(qs_client, account_id, folder_id, analysis_id, apply_changes):
    if not folder_id:
        return {"status": "skipped", "reason": "no folder id"}
    if not apply_changes:
        return {"status": "dry_run", "folder_id": folder_id, "analysis_id": analysis_id}
    try:
        qs_client.create_folder_membership(
            AwsAccountId=account_id,
            FolderId=folder_id,
            MemberId=analysis_id,
            MemberType="ANALYSIS",
        )
        return {"status": "added"}
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") == "ResourceExistsException":
            return {"status": "already_exists"}
        raise


def grant_analysis_owner(qs_client, account_id, region, analysis_id, owner_group, apply_changes):
    if not owner_group:
        return {"status": "skipped", "reason": "no owner group"}
    principal = f"arn:aws:quicksight:{region}:{account_id}:group/default/{owner_group}"
    if not apply_changes:
        return {
            "status": "dry_run",
            "analysis_id": analysis_id,
            "principal": principal,
        }
    try:
        response = qs_client.update_analysis_permissions(
            AwsAccountId=account_id,
            AnalysisId=analysis_id,
            GrantPermissions=[
                {"Principal": principal, "Actions": ANALYSIS_CO_OWNER_ACTIONS}
            ],
        )
        return {"status": "granted", "http_status": response.get("Status")}
    except ClientError as error:
        return {
            "status": "error",
            "error": error.response.get("Error", {}),
        }


def migrate_dashboard(
    source_qs_client,
    target_qs_client,
    source_account_id,
    target_account_id,
    target_region,
    dashboard_id,
    id_prefix,
    explicit_map_by_id,
    explicit_map_by_name,
    target_inventory,
    output_root,
    apply_changes,
    folder_id,
    poll_seconds,
    timeout_seconds,
    column_aliases,
    analysis_owner_group,
    excluded_source_uuids,
):
    dashboard_response = source_qs_client.describe_dashboard(
        AwsAccountId=source_account_id,
        DashboardId=dashboard_id,
    )
    dashboard = dashboard_response["Dashboard"]
    dashboard_name = dashboard.get("Name") or dashboard_id
    version_number = dashboard.get("Version", {}).get("VersionNumber")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = Path(output_root) / f"{slugify(dashboard_name)}-{dashboard_id}" / run_id
    output_dir.mkdir(parents=True, exist_ok=True)

    dashboard_definition = source_qs_client.describe_dashboard_definition(
        AwsAccountId=source_account_id,
        DashboardId=dashboard_id,
        VersionNumber=version_number,
    )
    write_json(output_dir / "source_dashboard.json", dashboard_response)
    write_json(output_dir / "source_dashboard_definition.json", dashboard_definition)

    source_analysis_id = get_source_analysis_id(dashboard_response)
    analysis_definition = None
    analysis_name = f"{dashboard_name} Analysis"
    if source_analysis_id:
        try:
            analysis_definition = source_qs_client.describe_analysis_definition(
                AwsAccountId=source_account_id,
                AnalysisId=source_analysis_id,
            )
            write_json(output_dir / "source_analysis_definition.json", analysis_definition)
            try:
                analysis = source_qs_client.describe_analysis(
                    AwsAccountId=source_account_id,
                    AnalysisId=source_analysis_id,
                )
                analysis_name = analysis.get("Analysis", {}).get("Name") or analysis_name
            except Exception:
                pass
        except Exception as error:
            write_json(output_dir / "source_analysis_definition_error.json", {"error": str(error)})

    # Make repeated MissingDataSetId_ placeholders stable before orphan
    # resolution and before producing patched definitions. This matters when a
    # source dashboard already contains partially-migrated missing references.
    collapse_stacked_missing_dataset_ids(dashboard_definition)
    if analysis_definition:
        collapse_stacked_missing_dataset_ids(analysis_definition)

    declarations_by_id = {}
    for source_def in (dashboard_definition, analysis_definition):
        if not source_def:
            continue
        for declaration in source_def.get("Definition", {}).get("DataSetIdentifierDeclarations", []) or []:
            arn = declaration.get("DataSetArn") or ""
            source_dataset_id = arn_resource_id(arn)
            if source_dataset_id and source_dataset_id not in declarations_by_id:
                declarations_by_id[source_dataset_id] = declaration

    # Orphan UUID normalization: scan the full source dashboard + analysis JSON
    # for dataset UUIDs not in the declarations list. Valid ones (resolvable in
    # source) get injected as synthetic declarations so the dataset_map applies
    # uniformly. Stale ones (no longer in source) MUST be explicitly excused
    # via --exclude-source-uuid <uuid>:<reason> -- the migration fails loudly
    # otherwise to prevent silent corruption from going to central. UUID-shaped
    # strings that aren't dataset UUIDs at all (e.g. FieldId UUIDs) also land
    # in stale_orphans on describe_data_set ResourceNotFoundException; either
    # excuse them or trust that they don't reference a dataset ARN.
    orphan_uuids = find_orphan_dataset_uuid_refs(
        [dashboard_definition, analysis_definition],
        set(declarations_by_id.keys()),
    )
    valid_orphans, stale_orphans = resolve_orphan_uuids(
        orphan_uuids, source_qs_client, source_account_id
    )
    unexcused_stale = sorted(stale_orphans - set(excluded_source_uuids or {}))
    if unexcused_stale:
        raise RuntimeError(
            "Source dashboard contains references to "
            f"{len(unexcused_stale)} stale or non-dataset UUIDs that this "
            "script cannot resolve: " + ", ".join(unexcused_stale) + ". "
            "If these are stale dataset references in calc fields/visuals, "
            "pass --exclude-source-uuid <uuid>:<reason> for each to "
            "explicitly acknowledge (the reason is recorded in the run "
            "summary). If they are FieldId UUIDs that happen to match the "
            "regex, the same flag is the right escape hatch."
        )
    inject_orphan_declarations(
        [dashboard_definition, analysis_definition], valid_orphans
    )
    for uid, info in valid_orphans.items():
        if uid in declarations_by_id:
            continue
        declarations_by_id[uid] = {
            "Identifier": info["Name"] or uid,
            "DataSetArn": info["arn"],
        }
    write_json(
        output_dir / "orphan_uuid_resolution.json",
        {
            "valid_orphans": valid_orphans,
            "stale_orphans_excused": {
                uid: (excluded_source_uuids or {}).get(uid)
                for uid in sorted(stale_orphans & set(excluded_source_uuids or {}))
            },
        },
    )

    mapping_rows = []
    for declaration in declarations_by_id.values():
        source_dataset_arn = declaration.get("DataSetArn") or ""
        source_dataset_id = arn_resource_id(source_dataset_arn)
        source_dataset_name = describe_dataset_name(
            source_qs_client,
            source_account_id,
            source_dataset_id,
        )
        mapping = resolve_target_dataset(
            target_qs_client,
            target_account_id,
            target_region,
            source_dataset_id,
            source_dataset_name or declaration.get("Identifier"),
            explicit_map_by_id,
            explicit_map_by_name,
            target_inventory,
        )
        mapping_rows.append(
            {
                "identifier": declaration.get("Identifier"),
                "source_dataset_arn": source_dataset_arn,
                **mapping,
            }
        )

    write_csv(
        output_dir / "dataset_mapping_precheck.csv",
        mapping_rows,
        [
            "identifier",
            "source_dataset_name",
            "source_dataset_id",
            "source_dataset_arn",
            "target_dataset_name",
            "target_dataset_id",
            "target_dataset_arn",
            "target_exists",
            "resolution",
        ],
    )
    write_json(output_dir / "dataset_mapping_precheck.json", mapping_rows)

    blocking_rows = [
        row
        for row in mapping_rows
        if not row.get("target_dataset_arn") or not row.get("target_exists")
    ]
    patched_declarations = []
    for row in mapping_rows:
        if row.get("target_dataset_arn") and row.get("identifier"):
            patched_declarations.append(
                {
                    "Identifier": row["identifier"],
                    "DataSetArn": row["target_dataset_arn"],
                }
            )
    target_lt_by_identifier = build_target_logical_table_map(
        target_qs_client,
        target_account_id,
        {"DataSetIdentifierDeclarations": patched_declarations},
    )
    write_json(output_dir / "target_logical_table_map.json", target_lt_by_identifier)

    patched_dashboard_definition = remap_definition(
        dashboard_definition,
        mapping_rows,
        target_lt_by_identifier,
        column_aliases,
    )
    write_json(output_dir / "patched_dashboard_definition.json", patched_dashboard_definition)
    patched_analysis_definition = None
    if analysis_definition:
        patched_analysis_definition = remap_definition(
            analysis_definition,
            mapping_rows,
            target_lt_by_identifier,
            column_aliases,
        )
        write_json(output_dir / "patched_analysis_definition.json", patched_analysis_definition)

    result = {
        "dashboard_id": dashboard_id,
        "dashboard_name": dashboard_name,
        "target_dashboard_id": f"{id_prefix}{dashboard_id}",
        "target_analysis_id": f"{id_prefix}{source_analysis_id}" if source_analysis_id else "",
        "dataset_count": len(mapping_rows),
        "unmapped_or_missing_target_dataset_count": len(blocking_rows),
        "output_dir": str(output_dir),
        "apply": apply_changes,
    }
    if blocking_rows:
        result["status"] = "BLOCKED_UNMAPPED_DATASETS"
        result["blocking_datasets"] = blocking_rows
        return result

    if not apply_changes:
        result["status"] = "DRY_RUN_OK"
        return result

    target_analysis_id = result["target_analysis_id"]
    if patched_analysis_definition and target_analysis_id:
        analysis_result = create_or_update_analysis(
            target_qs_client,
            target_account_id,
            target_analysis_id,
            analysis_name,
            patched_analysis_definition,
            apply_changes,
        )
        write_json(output_dir / "target_analysis_result.json", analysis_result)
        result["analysis_result"] = {
            "action": analysis_result["action"],
            "target_analysis_id": target_analysis_id,
        }

        analysis_permission_result = grant_analysis_owner(
            target_qs_client,
            target_account_id,
            target_region,
            target_analysis_id,
            analysis_owner_group,
            apply_changes,
        )
        write_json(output_dir / "target_analysis_permission_result.json", analysis_permission_result)
        result["analysis_permission_result"] = analysis_permission_result

        analysis_folder_result = add_analysis_to_folder(
            target_qs_client,
            target_account_id,
            folder_id,
            target_analysis_id,
            apply_changes,
        )
        write_json(output_dir / "target_analysis_folder_result.json", analysis_folder_result)
        result["analysis_folder_result"] = analysis_folder_result

    dashboard_result = create_or_update_dashboard(
        target_qs_client,
        target_account_id,
        result["target_dashboard_id"],
        dashboard_name,
        patched_dashboard_definition,
        apply_changes,
    )
    write_json(output_dir / "target_dashboard_result.json", dashboard_result)

    version_arn = dashboard_result.get("response", {}).get("VersionArn", "")
    version_number = version_arn.split("/")[-1] if version_arn else ""
    if version_number:
        wait_for_dashboard_version(
            target_qs_client,
            target_account_id,
            result["target_dashboard_id"],
            version_number,
            poll_seconds,
            timeout_seconds,
        )
        target_qs_client.update_dashboard_published_version(
            AwsAccountId=target_account_id,
            DashboardId=result["target_dashboard_id"],
            VersionNumber=int(version_number),
        )

    folder_result = add_dashboard_to_folder(
        target_qs_client,
        target_account_id,
        folder_id,
        result["target_dashboard_id"],
        apply_changes,
    )
    write_json(output_dir / "folder_membership_result.json", folder_result)

    result["dashboard_result"] = {
        "action": dashboard_result["action"],
        "target_dashboard_id": result["target_dashboard_id"],
        "version_number": version_number,
    }
    result["folder_result"] = folder_result
    result["status"] = "APPLIED"
    return result


def parse_args():
    parser = argparse.ArgumentParser(
        description="Migrate QuickSight dashboard definitions with target dataset remapping."
    )
    parser.add_argument("--source-profile", required=True)
    parser.add_argument("--target-profile", required=True)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--source-account-id", default="840529182937")
    parser.add_argument("--target-account-id", default="200967598245")
    parser.add_argument("--dashboard-id", nargs="+", required=True)
    parser.add_argument("--dataset-map", help="Inventory/provision JSON or CSV with source_dataset_id -> target_dataset_arn")
    parser.add_argument("--target-inventory", help="target_inventory.json for existing target dataset candidates")
    parser.add_argument("--folder-id", default="bif-risk-dev")
    parser.add_argument(
        "--analysis-owner-group",
        default="",
        help=(
            "QuickSight group name in the target account to grant CO_OWNER "
            "permissions on each created/updated analysis. Empty disables the "
            "grant. Example for bif-risk dev central: AWS_SSO_QS_AUTHOR_RISK."
        ),
    )
    parser.add_argument(
        "--exclude-source-uuid",
        action="append",
        default=[],
        help=(
            "<uuid>:<reason>, repeatable. Explicitly excuse a UUID found in "
            "the source dashboard's calc fields/visuals that does NOT "
            "resolve as a current source dataset. Without this flag, the "
            "migration aborts on any unresolvable orphan UUID (no silent "
            "stripping). Use for known-stale source refs (e.g. deleted "
            "datasets) AND for FieldId UUIDs that happen to match the "
            "dataset-UUID regex. The reason is recorded in the run summary."
        ),
    )
    parser.add_argument("--id-prefix", default="", help="Optional prefix for target dashboard and analysis ids")
    parser.add_argument("--output-root", default="exports/quicksight-definition-migration")
    parser.add_argument("--apply", action="store_true", help="Create/update target analysis/dashboard")
    parser.add_argument("--poll-seconds", type=int, default=10)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    parser.add_argument(
        "--column-alias",
        action="append",
        default=[],
        help=(
            "Rewrite a dashboard field column during remap. Format: "
            "DATASET_IDENTIFIER:SOURCE_COLUMN=TARGET_COLUMN. "
            "Can be passed multiple times."
        ),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    source_session = session_for(args.source_profile, args.region)
    target_session = session_for(args.target_profile, args.region)
    source_qs_client = source_session.client("quicksight", region_name=args.region)
    target_qs_client = target_session.client("quicksight", region_name=args.region)

    explicit_map_by_id, explicit_map_by_name = index_dataset_map(args.dataset_map)
    target_inventory = load_target_inventory(args.target_inventory)
    column_aliases = parse_column_aliases(args.column_alias)
    excluded_source_uuids = parse_excluded_uuid_arg(args.exclude_source_uuid)

    results = []
    for idx, dashboard_id in enumerate(args.dashboard_id, start=1):
        print(
            f"[{idx}/{len(args.dashboard_id)}] {'Applying' if args.apply else 'Dry-run'} dashboard definition migration {dashboard_id}",
            flush=True,
        )
        try:
            result = migrate_dashboard(
                source_qs_client,
                target_qs_client,
                args.source_account_id,
                args.target_account_id,
                args.region,
                dashboard_id,
                args.id_prefix,
                explicit_map_by_id,
                explicit_map_by_name,
                target_inventory,
                args.output_root,
                args.apply,
                args.folder_id,
                args.poll_seconds,
                args.timeout_seconds,
                column_aliases,
                args.analysis_owner_group,
                excluded_source_uuids,
            )
        except Exception as error:
            result = {
                "dashboard_id": dashboard_id,
                "status": "ERROR",
                "error": str(error),
            }
            print(f"  ERROR: {error}", flush=True)
        print(
            f"  {result.get('status')}: {result.get('dashboard_name', dashboard_id)}",
            flush=True,
        )
        results.append(result)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    summary_path = Path(args.output_root) / f"definition_migration_summary_{run_id}.json"
    write_json(
        summary_path,
        {
            "source_profile": args.source_profile,
            "target_profile": args.target_profile,
            "source_account_id": args.source_account_id,
            "target_account_id": args.target_account_id,
            "region": args.region,
            "folder_id": args.folder_id,
            "analysis_owner_group": args.analysis_owner_group,
            "excluded_source_uuids": excluded_source_uuids,
            "apply": args.apply,
            "result_count": len(results),
            "results": results,
        },
    )
    print(f"Definition migration summary: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
