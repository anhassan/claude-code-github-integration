"""
Read-only source-vs-central QuickSight comparison for Risk dashboard migration.

The script only uses list/describe APIs. It does not call create, update,
delete, publish, import, export, or ingestion APIs.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import ClientError


SOURCE_PROFILE = "CPPIB-Quicksight-Admin-840529182937"
CENTRAL_PROFILE = "CPPIB-Quicksight-Admin-200967598245"
SOURCE_ACCOUNT = "840529182937"
CENTRAL_ACCOUNT = "200967598245"

SUSPICIOUS_CALC_RE = re.compile(
    r"(drawdown|limit|threshold|utili[sz]ation|risk|contribution|pv|vol|dva|"
    r"business[_ ]?date|comparison|analysis|supplement|format|country|sector)",
    re.IGNORECASE,
)
RAW_UUID_DS_RE = re.compile(
    r'"DataSetIdentifier"\s*:\s*"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"',
    re.IGNORECASE,
)
UUID_FIELD_REF_RE = re.compile(
    r"\{[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.",
    re.IGNORECASE,
)
# toString(...round(...)...) — the Issue-2 precision class. QS toString of a
# DECIMAL column pads to 4dp regardless of round(), so a string-building calc
# field renders e.g. "3815.0000M" instead of "3815.0M". Source==central exprs
# don't surface in calc diffs, so detect the pattern directly.
TOSTRING_ROUND_RE = re.compile(r"toString\s*\(\s*round\s*\(", re.IGNORECASE)
# parseDate({col}) with no format string — passes publish validation but the
# runtime query fails (date gate returns nothing).
PARSEDATE_NOFORMAT_RE = re.compile(r"parseDate\s*\(\s*\{[^}]*\}\s*\)", re.IGNORECASE)
# parseFloat( is not a valid QS function — must be parseDecimal(.
PARSEFLOAT_RE = re.compile(r"parseFloat\s*\(", re.IGNORECASE)


@dataclass(frozen=True)
class DashboardScope:
    dashboard_id: str
    name: str
    group: str


def load_scope(path: Path | None, include_all: bool) -> list[DashboardScope]:
    if include_all:
        path = Path("exports/risk-dashboard-migration/migrated_dashboard_ids.txt")

    if path:
        rows: list[DashboardScope] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            dashboard_id, _, label = line.partition(",")
            rows.append(DashboardScope(dashboard_id.strip(), label.strip(), "all-risk"))
        return rows

    # Business feedback + blocked/strip affected scope.
    items = [
        ("5936aa46-b4b1-4070-94b8-7b5ab4d0938c", "AE 3.0 Dashboard", "business+blocked"),
        ("03765564-6c02-4e93-9b45-b1b59ace7148", "AE Sub-Program Dashboards", "business+blocked"),
        ("9d43ccc3-ad73-47ef-9c9d-8c5349f65f2d", "ARS-FICC Dashboard", "business"),
        ("e6af3d23-30cb-46aa-8b7f-c81fbd051189", "ARS-QE Dashboard", "business+blocked"),
        ("c7d2f851-5ce8-48f8-a172-d6dd44efd05b", "ARS - Volatility Report", "business"),
        ("fbc4834b-615d-4194-b496-4a6e273f145a", "ARS-Volatility Ex Gamma", "related"),
        ("fdc78f9a-3532-4f34-8307-d9b80de439dc", "CMF Enhanced Beta Report", "business"),
        ("e024fea3-faba-4624-ae84-873748a95ec2", "CMF ISRC Report", "business"),
        ("d4b0468a-8da0-4d29-b3c5-b25221d90699", "EPM Dashboard", "business"),
        ("0dfb159c-6844-4f94-a594-fce3758cd128", "Public Market Risk Dashboard", "business"),
        ("e94c1391-53df-4ebe-ac40-52750c667396", "SSG Dashboard", "business"),
        ("04e1ea7a-da78-4421-913c-5a98dea1fd91", "Public Credit Alpha", "blocked"),
        ("f4881f1f-d6cc-42bb-80e5-6ff25a0ccf5b", "Tactical Positioning", "blocked"),
        ("1e27d052-93e4-42ae-9847-cb688b7f08c5", "TFM Financing & Balance Sheet Management", "blocked"),
        ("bc3857df-5ff3-48cf-9cf2-230f720b4c44", "LRA Risk Report", "blocked"),
        ("c4b21c4a-961b-40a4-852a-2c06dc84a0a7", "AE Transactions", "strip-affected"),
        ("e3c871da-d4cb-47ec-9dbc-3235b069d8b4", "FX Dashboard (Prelim)", "blocked"),
        ("ed17aa1f-21a9-44c1-af76-a707fa763b7e", "TFM AI Factor", "strip-affected"),
        ("80fa7b35-4b98-4a57-8432-85b69578945d", "CMF Insight Dashboard (new)", "strip-affected"),
        ("5246384c-1e01-4d1a-8c8a-51c4f2bd7a97", "Total Portfolio Risk Dashboard", "strip-affected"),
    ]
    return [DashboardScope(*item) for item in items]


def session(profile: str, region: str):
    return boto3.Session(profile_name=profile, region_name=region)


def arn_id(arn: str) -> str:
    return (arn or "").rsplit("/", 1)[-1]


def safe_call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except ClientError as err:
        return None, err.response.get("Error", {})


def walk(value: Any):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from walk(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk(item)


def get_nested(obj: dict[str, Any], *keys: str):
    cur: Any = obj
    for key in keys:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def count_visuals(definition: dict[str, Any]) -> int:
    total = 0
    for sheet in definition.get("Sheets", []) or []:
        total += len(sheet.get("Visuals", []) or [])
    return total


def count_actions(definition: dict[str, Any]) -> int:
    total = 0
    for obj in walk(definition):
        actions = obj.get("Actions")
        if isinstance(actions, list):
            total += len(actions)
    return total


def count_broken_filter_actions(definition: dict[str, Any]) -> int:
    total = 0
    for obj in walk(definition):
        for action in obj.get("Actions", []) or []:
            for operation in action.get("ActionOperations", []) or []:
                filter_operation = operation.get("FilterOperation")
                if not isinstance(filter_operation, dict):
                    continue
                selected = filter_operation.get("SelectedFieldsConfiguration") or {}
                if not selected.get("SelectedFields") and not selected.get("SelectedColumns") and not selected.get(
                    "SelectedFieldOptions"
                ):
                    total += 1
    return total


def count_incomplete_top_bottom(definition: dict[str, Any]) -> int:
    total = 0
    for group in definition.get("FilterGroups", []) or []:
        for filter_obj in group.get("Filters", []) or []:
            top_bottom = filter_obj.get("TopBottomFilter")
            if isinstance(top_bottom, dict) and not top_bottom.get("AggregationSortConfigurations"):
                total += 1
    return total


def calc_index(definition: dict[str, Any]) -> dict[tuple[str, str], str]:
    out = {}
    for calc in definition.get("CalculatedFields", []) or []:
        ds = calc.get("DataSetIdentifier") or ""
        name = calc.get("Name") or ""
        expr = calc.get("Expression") or ""
        out[(ds, name)] = expr
    return out


def count_min_zero_axes(definition: dict[str, Any]) -> int:
    """Count axis Range blocks pinned to Minimum=0.

    A central SPICE visual that honors Minimum=0 clips negative bars that the
    source's render engine shows. Surfaced for review, not asserted as a bug.
    """
    total = 0
    for obj in walk(definition):
        min_max = obj.get("MinMax")
        if isinstance(min_max, dict) and min_max.get("Minimum") in (0, 0.0, "0", "0.0"):
            total += 1
    return total


def find_precision_calc_fields(definition: dict[str, Any]) -> list[str]:
    """Names of calc fields that build display strings via toString(round())."""
    names = []
    for calc in definition.get("CalculatedFields", []) or []:
        if TOSTRING_ROUND_RE.search(calc.get("Expression") or ""):
            ds = calc.get("DataSetIdentifier") or ""
            names.append(f"{ds}.{calc.get('Name')}")
    return names


def find_runtime_calc_defects(definition: dict[str, Any]) -> dict[str, list[str]]:
    """Calc fields carrying parseDate-without-format or parseFloat survivals."""
    parsedate = []
    parsefloat = []
    for calc in definition.get("CalculatedFields", []) or []:
        expr = calc.get("Expression") or ""
        ds = calc.get("DataSetIdentifier") or ""
        label = f"{ds}.{calc.get('Name')}"
        if PARSEDATE_NOFORMAT_RE.search(expr):
            parsedate.append(label)
        if PARSEFLOAT_RE.search(expr):
            parsefloat.append(label)
    return {"parsedate_no_format": parsedate, "parsefloat": parsefloat}


def central_last_ingestion(central_qs, dataset_id: str, import_mode: str, cache: dict[str, Any]):
    """Ingestion freshness for a central SPICE dataset; cached.

    Reports the latest COMPLETED ingestion's age (the real freshness signal —
    a QUEUED/RUNNING ingestion in front of it is in progress, not stale) plus
    the very latest status so genuine FAILEDs surface.
    """
    if import_mode != "SPICE" or not dataset_id:
        return None
    if dataset_id in cache:
        return cache[dataset_id]
    data, err = safe_call(
        central_qs.list_ingestions,
        AwsAccountId=CENTRAL_ACCOUNT,
        DataSetId=dataset_id,
        MaxResults=10,
    )
    result = None
    if data and data.get("Ingestions"):
        ingestions = data["Ingestions"]
        latest = ingestions[0]
        completed = next((i for i in ingestions if i.get("IngestionStatus") == "COMPLETED"), None)
        completed_age = None
        if completed and completed.get("CreatedTime"):
            completed_age = round(
                (datetime.now(timezone.utc) - completed["CreatedTime"]).total_seconds() / 3600, 1
            )
        result = {
            "latest_status": latest.get("IngestionStatus"),
            "last_completed": str(completed.get("CreatedTime")) if completed else None,
            "completed_age_hours": completed_age,
            "rows": get_nested(completed or {}, "RowInfo", "RowsIngested"),
        }
    cache[dataset_id] = result
    return result


def find_raw_dataset_identifiers(definition_json: str) -> int:
    return len(RAW_UUID_DS_RE.findall(definition_json))


def describe_dataset(qs, account_id: str, arn: str, cache: dict[str, Any]):
    dataset_id = arn_id(arn)
    if not dataset_id:
        return None, {"Code": "MissingDataSetArn"}
    key = f"{account_id}:{dataset_id}"
    if key in cache:
        if isinstance(cache[key], dict) and cache[key].get("_error"):
            return None, cache[key]["_error"]
        return cache[key], None
    data, err = safe_call(qs.describe_data_set, AwsAccountId=account_id, DataSetId=dataset_id)
    if err:
        cache[key] = {"_error": err, "_dataset_id": dataset_id}
        return None, err
    dataset = data.get("DataSet", {})
    cols = {}
    for col in dataset.get("OutputColumns", []) or []:
        cols[col.get("Name", "")] = col.get("Type", "")
    payload = {
        "dataset_id": dataset_id,
        "name": dataset.get("Name", ""),
        "import_mode": dataset.get("ImportMode", ""),
        "columns": cols,
        "logical_tables": {
            key: {
                "alias": value.get("Alias", ""),
                "source": value.get("Source", {}),
            }
            for key, value in (dataset.get("LogicalTableMap") or {}).items()
        },
    }
    cache[key] = payload
    return payload, None


def compact_paths(errors: list[dict[str, Any]], limit: int = 5) -> list[str]:
    paths = []
    for error in errors[:limit]:
        entity = (error.get("ViolatedEntities") or [{}])[0]
        paths.append(f"{error.get('Type')}: {entity.get('Path', '')}")
    return paths


def summarize_dashboard(
    scope: DashboardScope,
    source_qs,
    central_qs,
    dataset_cache: dict[str, Any],
    ingestion_cache: dict[str, Any],
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "dashboard_id": scope.dashboard_id,
        "name": scope.name,
        "group": scope.group,
    }

    source_dash, source_dash_err = safe_call(
        source_qs.describe_dashboard,
        AwsAccountId=SOURCE_ACCOUNT,
        DashboardId=scope.dashboard_id,
    )
    central_dash, central_dash_err = safe_call(
        central_qs.describe_dashboard,
        AwsAccountId=CENTRAL_ACCOUNT,
        DashboardId=scope.dashboard_id,
    )
    row["source_dashboard_error"] = source_dash_err
    row["central_dashboard_error"] = central_dash_err
    if source_dash:
        dash = source_dash["Dashboard"]
        version = dash.get("Version", {})
        row["source_name"] = dash.get("Name")
        row["source_last_updated"] = str(dash.get("LastUpdatedTime"))
        row["source_version"] = version.get("VersionNumber")
        row["source_status"] = version.get("Status")
    if central_dash:
        dash = central_dash["Dashboard"]
        version = dash.get("Version", {})
        row["central_name"] = dash.get("Name")
        row["central_last_updated"] = str(dash.get("LastUpdatedTime"))
        row["central_version"] = version.get("VersionNumber")
        row["central_status"] = version.get("Status")

    source_def_resp, source_def_err = safe_call(
        source_qs.describe_dashboard_definition,
        AwsAccountId=SOURCE_ACCOUNT,
        DashboardId=scope.dashboard_id,
    )
    central_def_resp, central_def_err = safe_call(
        central_qs.describe_dashboard_definition,
        AwsAccountId=CENTRAL_ACCOUNT,
        DashboardId=scope.dashboard_id,
    )
    row["source_definition_error"] = source_def_err
    row["central_definition_error"] = central_def_err
    if not source_def_resp or not central_def_resp:
        return row

    source_def = source_def_resp.get("Definition", {})
    central_def = central_def_resp.get("Definition", {})
    source_json = json.dumps(source_def, default=str, ensure_ascii=False)
    central_json = json.dumps(central_def, default=str, ensure_ascii=False)

    row["source_validation_errors"] = Counter(e.get("Type") for e in source_def_resp.get("Errors", []) or [])
    row["central_validation_errors"] = Counter(e.get("Type") for e in central_def_resp.get("Errors", []) or [])
    row["central_error_examples"] = compact_paths(central_def_resp.get("Errors", []) or [])
    row["definition_metrics"] = {
        "source_visuals": count_visuals(source_def),
        "central_visuals": count_visuals(central_def),
        "source_filter_groups": len(source_def.get("FilterGroups", []) or []),
        "central_filter_groups": len(central_def.get("FilterGroups", []) or []),
        "source_calculated_fields": len(source_def.get("CalculatedFields", []) or []),
        "central_calculated_fields": len(central_def.get("CalculatedFields", []) or []),
        "source_actions": count_actions(source_def),
        "central_actions": count_actions(central_def),
        "source_broken_filter_actions": count_broken_filter_actions(source_def),
        "central_broken_filter_actions": count_broken_filter_actions(central_def),
        "source_incomplete_top_bottom_filters": count_incomplete_top_bottom(source_def),
        "central_incomplete_top_bottom_filters": count_incomplete_top_bottom(central_def),
    }
    row["pattern_counts"] = {
        "source_missing_dataset_refs": source_json.count("MissingDataSetId_"),
        "central_missing_dataset_refs": central_json.count("MissingDataSetId_"),
        "source_missing_column_refs": source_json.count("MissingColumnId_"),
        "central_missing_column_refs": central_json.count("MissingColumnId_"),
        "source_raw_uuid_dataset_identifiers": find_raw_dataset_identifiers(source_json),
        "central_raw_uuid_dataset_identifiers": find_raw_dataset_identifiers(central_json),
        "source_uuid_field_refs": len(UUID_FIELD_REF_RE.findall(source_json)),
        "central_uuid_field_refs": len(UUID_FIELD_REF_RE.findall(central_json)),
    }
    runtime_defects = find_runtime_calc_defects(central_def)
    row["rendering_checks"] = {
        "source_min_zero_axes": count_min_zero_axes(source_def),
        "central_min_zero_axes": count_min_zero_axes(central_def),
        "central_precision_calc_fields": find_precision_calc_fields(central_def),
        "central_parsedate_no_format": runtime_defects["parsedate_no_format"],
        "central_parsefloat": runtime_defects["parsefloat"],
    }

    source_decls = {
        item.get("Identifier"): item.get("DataSetArn")
        for item in source_def.get("DataSetIdentifierDeclarations", []) or []
    }
    central_decls = {
        item.get("Identifier"): item.get("DataSetArn")
        for item in central_def.get("DataSetIdentifierDeclarations", []) or []
    }
    row["source_dataset_identifiers"] = sorted(source_decls)
    row["central_dataset_identifiers"] = sorted(central_decls)
    row["dataset_identifier_missing_in_central"] = sorted(set(source_decls) - set(central_decls))
    row["dataset_identifier_added_in_central"] = sorted(set(central_decls) - set(source_decls))

    dataset_diffs = []
    stale_datasets = []
    for identifier in sorted(set(source_decls) & set(central_decls)):
        source_ds, source_ds_err = describe_dataset(source_qs, SOURCE_ACCOUNT, source_decls[identifier], dataset_cache)
        central_ds, central_ds_err = describe_dataset(central_qs, CENTRAL_ACCOUNT, central_decls[identifier], dataset_cache)
        if source_ds_err or central_ds_err:
            dataset_diffs.append(
                {
                    "identifier": identifier,
                    "source_dataset_error": source_ds_err,
                    "central_dataset_error": central_ds_err,
                }
            )
            continue
        ingest = central_last_ingestion(
            central_qs, central_ds["dataset_id"], central_ds["import_mode"], ingestion_cache
        )
        if ingest and (
            ingest.get("completed_age_hours") is None
            or ingest["completed_age_hours"] > 24
            or ingest.get("latest_status") == "FAILED"
        ):
            stale_datasets.append({"identifier": identifier, **ingest})
        source_cols = source_ds["columns"]
        central_cols = central_ds["columns"]
        missing_cols = sorted(set(source_cols) - set(central_cols))
        extra_cols = sorted(set(central_cols) - set(source_cols))
        type_mismatches = sorted(
            {
                name: {"source": source_cols[name], "central": central_cols[name]}
                for name in set(source_cols) & set(central_cols)
                if source_cols[name] != central_cols[name]
            }.items()
        )
        if missing_cols or extra_cols or type_mismatches or source_ds["name"] != central_ds["name"]:
            dataset_diffs.append(
                {
                    "identifier": identifier,
                    "source_dataset_id": source_ds["dataset_id"],
                    "source_dataset_name": source_ds["name"],
                    "central_dataset_id": central_ds["dataset_id"],
                    "central_dataset_name": central_ds["name"],
                    "source_column_count": len(source_cols),
                    "central_column_count": len(central_cols),
                    "missing_columns_in_central": missing_cols[:40],
                    "extra_columns_in_central": extra_cols[:40],
                    "type_mismatches": [
                        {"column": name, **types} for name, types in type_mismatches[:30]
                    ],
                    "source_has_dataset_join": any(
                        "JoinInstruction" in table.get("source", {}) for table in source_ds["logical_tables"].values()
                    ),
                    "central_has_dataset_join": any(
                        "JoinInstruction" in table.get("source", {}) for table in central_ds["logical_tables"].values()
                    ),
                }
            )
    row["dataset_diffs"] = dataset_diffs
    row["stale_datasets"] = stale_datasets

    source_calcs = calc_index(source_def)
    central_calcs = calc_index(central_def)
    calc_diffs = []
    for key in sorted(set(source_calcs) | set(central_calcs)):
        source_expr = source_calcs.get(key)
        central_expr = central_calcs.get(key)
        if source_expr == central_expr:
            continue
        ds, name = key
        interesting = (
            SUSPICIOUS_CALC_RE.search(name or "")
            or SUSPICIOUS_CALC_RE.search(source_expr or "")
            or SUSPICIOUS_CALC_RE.search(central_expr or "")
            or UUID_FIELD_REF_RE.search(source_expr or "")
            or UUID_FIELD_REF_RE.search(central_expr or "")
            or "parseDecimal('0')" in (central_expr or "")
            or "MissingColumnId_" in (central_expr or "")
            or "MissingDataSetId_" in (central_expr or "")
        )
        if interesting:
            calc_diffs.append(
                {
                    "dataset_identifier": ds,
                    "name": name,
                    "source_expression": source_expr,
                    "central_expression": central_expr,
                }
            )
    row["suspicious_calc_diffs"] = calc_diffs[:80]

    return row


def finding_severity(row: dict[str, Any]) -> str:
    central_errors = sum(row.get("central_validation_errors", {}).values())
    patterns = row.get("pattern_counts", {})
    metrics = row.get("definition_metrics", {})
    checks = row.get("rendering_checks", {})
    if central_errors or patterns.get("central_missing_column_refs") or patterns.get("central_missing_dataset_refs"):
        return "high"
    if metrics.get("source_broken_filter_actions") or metrics.get("source_incomplete_top_bottom_filters"):
        return "high"
    # Runtime-failing calc fields and stale SPICE caches are user-visible.
    if checks.get("central_parsedate_no_format") or checks.get("central_parsefloat"):
        return "high"
    if row.get("stale_datasets"):
        return "high"
    if (
        row.get("dataset_diffs")
        or row.get("suspicious_calc_diffs")
        or checks.get("central_precision_calc_fields")
        or checks.get("central_min_zero_axes")
    ):
        return "medium"
    return "low"


def json_safe(obj: Any) -> Any:
    if isinstance(obj, Counter):
        return dict(obj)
    if isinstance(obj, dict):
        return {key: json_safe(value) for key, value in obj.items()}
    if isinstance(obj, list):
        return [json_safe(item) for item in obj]
    return obj


def md_list(items: list[str]) -> str:
    if not items:
        return "none"
    return ", ".join(f"`{item}`" for item in items)


def write_report(results: list[dict[str, Any]], path: Path) -> None:
    lines = [
        "# Source vs Central QuickSight Comparison",
        "",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%SZ')}",
        "",
        "Read-only comparison using `describe`/`list` QuickSight APIs only.",
        "",
        "## Executive Summary",
        "",
    ]
    severity_counts = Counter(finding_severity(row) for row in results)
    lines.append(
        f"- Dashboards compared: **{len(results)}**. High-risk: **{severity_counts['high']}**, "
        f"medium-risk: **{severity_counts['medium']}**, low/no obvious diff: **{severity_counts['low']}**."
    )
    strict_error_rows = [row for row in results if sum(row.get("central_validation_errors", {}).values())]
    lines.append(f"- Central definitions with validation errors: **{len(strict_error_rows)}**.")
    source_bug_rows = [
        row
        for row in results
        if row.get("definition_metrics", {}).get("source_broken_filter_actions")
        or row.get("definition_metrics", {}).get("source_incomplete_top_bottom_filters")
        or row.get("pattern_counts", {}).get("source_raw_uuid_dataset_identifiers")
    ]
    lines.append(f"- Source definitions with incomplete filters/actions or raw UUID dataset refs: **{len(source_bug_rows)}**.")
    runtime_rows = [
        row
        for row in results
        if row.get("rendering_checks", {}).get("central_parsedate_no_format")
        or row.get("rendering_checks", {}).get("central_parsefloat")
    ]
    stale_rows = [row for row in results if row.get("stale_datasets")]
    min_zero_rows = [row for row in results if row.get("rendering_checks", {}).get("central_min_zero_axes")]
    precision_rows = [row for row in results if row.get("rendering_checks", {}).get("central_precision_calc_fields")]
    lines.append(f"- Central dashboards with runtime-failing calc fields (parseDate/parseFloat): **{len(runtime_rows)}**.")
    lines.append(f"- Central dashboards with stale/incomplete SPICE datasets: **{len(stale_rows)}**.")
    lines.append(f"- Central dashboards with axis Min=0 blocks: **{len(min_zero_rows)}**.")
    lines.append(f"- Central dashboards with toString(round()) precision-class calc fields: **{len(precision_rows)}**.")
    lines.append("")
    lines.append("## Dashboard Findings")
    lines.append("")

    for row in sorted(results, key=lambda item: ({"high": 0, "medium": 1, "low": 2}[finding_severity(item)], item["name"])):
        sev = finding_severity(row)
        lines.extend(
            [
                f"### {row['name']} (`{row['dashboard_id']}`) - {sev.upper()}",
                "",
                f"- Source: v{row.get('source_version')} updated `{row.get('source_last_updated')}`.",
                f"- Central: v{row.get('central_version')} updated `{row.get('central_last_updated')}`.",
            ]
        )
        central_errors = row.get("central_validation_errors", {})
        if central_errors:
            lines.append(
                "- Central validation errors: "
                + ", ".join(f"`{key}`={value}" for key, value in sorted(central_errors.items()))
            )
            examples = row.get("central_error_examples", [])
            if examples:
                lines.append("- Examples: " + "; ".join(f"`{item}`" for item in examples[:3]))
        patterns = row.get("pattern_counts", {})
        notable_patterns = [
            f"{key}={value}"
            for key, value in patterns.items()
            if value
        ]
        if notable_patterns:
            lines.append("- Pattern counts: " + ", ".join(f"`{item}`" for item in notable_patterns))
        metrics = row.get("definition_metrics", {})
        metric_diffs = []
        for base in ["visuals", "filter_groups", "calculated_fields", "actions"]:
            source_value = metrics.get(f"source_{base}")
            central_value = metrics.get(f"central_{base}")
            if source_value != central_value:
                metric_diffs.append(f"{base}: source {source_value}, central {central_value}")
        if metric_diffs:
            lines.append("- Definition object count differences: " + "; ".join(metric_diffs))
        if metrics.get("source_incomplete_top_bottom_filters") or metrics.get("source_broken_filter_actions"):
            lines.append(
                f"- Source authoring defects: incomplete TopBottomFilters={metrics.get('source_incomplete_top_bottom_filters')}, "
                f"broken filter actions={metrics.get('source_broken_filter_actions')}."
            )

        checks = row.get("rendering_checks", {})
        parsedate = checks.get("central_parsedate_no_format") or []
        parsefloat = checks.get("central_parsefloat") or []
        if parsedate:
            lines.append(
                f"- **Runtime-failing calc fields** (parseDate without format, {len(parsedate)}): "
                + md_list(parsedate[:10])
            )
        if parsefloat:
            lines.append(
                f"- **Runtime-failing calc fields** (parseFloat, {len(parsefloat)}): "
                + md_list(parsefloat[:10])
            )
        precision = checks.get("central_precision_calc_fields") or []
        if precision:
            lines.append(
                f"- Precision-class calc fields (toString(round(...)), {len(precision)}): "
                + md_list(precision[:10])
                + " — verify 1dp display vs source."
            )
        if checks.get("central_min_zero_axes"):
            lines.append(
                f"- Axis Min=0 blocks in central: {checks.get('central_min_zero_axes')} "
                f"(source {checks.get('source_min_zero_axes')}) — review for clipped negatives."
            )
        stale = row.get("stale_datasets", [])
        if stale:
            lines.append("- **Stale / failed central SPICE datasets:**")
            for item in stale[:10]:
                lines.append(
                    f"  - `{item['identifier']}`: latest={item.get('latest_status')}, "
                    f"last_completed={item.get('last_completed')} ({item.get('completed_age_hours')}h ago)"
                )

        dataset_diffs = row.get("dataset_diffs", [])
        if dataset_diffs:
            lines.append("- Dataset/schema differences:")
            for diff in dataset_diffs[:8]:
                if diff.get("source_dataset_error") or diff.get("central_dataset_error"):
                    lines.append(
                        f"  - `{diff['identifier']}` describe error: source={diff.get('source_dataset_error')}, "
                        f"central={diff.get('central_dataset_error')}"
                    )
                    continue
                details = []
                missing = diff.get("missing_columns_in_central") or []
                extra = diff.get("extra_columns_in_central") or []
                type_mismatches = diff.get("type_mismatches") or []
                if missing:
                    details.append("missing in central " + md_list(missing[:12]))
                if extra:
                    details.append("extra in central " + md_list(extra[:8]))
                if type_mismatches:
                    details.append(
                        "type mismatches "
                        + ", ".join(
                            f"`{item['column']}` {item['source']}->{item['central']}"
                            for item in type_mismatches[:6]
                        )
                    )
                if diff.get("source_has_dataset_join") != diff.get("central_has_dataset_join"):
                    details.append(
                        f"join differs source={diff.get('source_has_dataset_join')} central={diff.get('central_has_dataset_join')}"
                    )
                if details:
                    lines.append(
                        f"  - `{diff['identifier']}` source `{diff.get('source_dataset_name')}` "
                        f"({diff.get('source_column_count')} cols) -> central `{diff.get('central_dataset_name')}` "
                        f"({diff.get('central_column_count')} cols): " + "; ".join(details)
                    )
        calc_diffs = row.get("suspicious_calc_diffs", [])
        if calc_diffs:
            lines.append("- Suspicious calculated-field differences:")
            for diff in calc_diffs[:8]:
                source_expr = (diff.get("source_expression") or "").replace("\r", " ").replace("\n", " ")
                central_expr = (diff.get("central_expression") or "").replace("\r", " ").replace("\n", " ")
                if len(source_expr) > 160:
                    source_expr = source_expr[:157] + "..."
                if len(central_expr) > 160:
                    central_expr = central_expr[:157] + "..."
                lines.append(
                    f"  - `{diff['dataset_identifier']}.{diff['name']}` source=`{source_expr}` central=`{central_expr}`"
                )
        lines.append("")

    lines.extend(
        [
            "## Recommended Fix Order",
            "",
            "1. Fix central dataset shape mismatches that directly explain business misses: AE `ae_pos` + `AE_POS_RC`, IODP `Program Name`, and any limit/drawdown datasets with missing or wrong date columns.",
            "2. Stop using stub mappings for missing source datasets unless there is explicit owner sign-off. `TFM_Posdata` is absent in source; map to a real replacement or remove/exclude at import with documentation.",
            "3. Normalize raw UUID dataset identifiers during migration for valid datasets, especially TFM AI Factor's `ELLM_vol/var` and `ELLM_DV01` filter references.",
            "4. Repair source-authored incomplete structures with owners: CMF Insight TopBottomFilters and TPR visual filter actions.",
            "5. Re-run source-to-central migration only after the target datasets and migration aliases are corrected, then verify strict definition errors and business visuals separately.",
        ]
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--scope-file", type=Path)
    parser.add_argument("--all-risk", action="store_true", help="Compare all dashboards from migrated_dashboard_ids.txt")
    parser.add_argument("--output-root", type=Path, default=Path("exports/risk-dashboard-migration"))
    return parser.parse_args()


def main():
    args = parse_args()
    source_qs = session(SOURCE_PROFILE, args.region).client("quicksight")
    central_qs = session(CENTRAL_PROFILE, args.region).client("quicksight")
    scope = load_scope(args.scope_file, args.all_risk)

    dataset_cache: dict[str, Any] = {}
    ingestion_cache: dict[str, Any] = {}
    results = []
    for idx, item in enumerate(scope, start=1):
        print(f"[{idx}/{len(scope)}] comparing {item.name} ({item.dashboard_id})", flush=True)
        results.append(summarize_dashboard(item, source_qs, central_qs, dataset_cache, ingestion_cache))

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = args.output_root / f"source-central-compare-{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "comparison.json"
    md_path = out_dir / "comparison_report.md"
    json_path.write_text(json.dumps(json_safe(results), indent=2, default=str, ensure_ascii=False) + "\n", encoding="utf-8")
    write_report(results, md_path)
    print(f"Wrote {json_path}")
    print(f"Wrote {md_path}")


if __name__ == "__main__":
    main()
