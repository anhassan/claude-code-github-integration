"""Generate onboarding xls files for the 5 shulisandra tables.

Mirrors `risk_market_monitor.xls` (empty source, populated trusted) but omits the
`trusted_table_type=iceberg` row so the tables register as plain Parquet.

Schemas pulled from source-account Glue (840529182937, db=shulisandra) on 2026-05-21.
"""
from pathlib import Path

import xlwt

OUT_DIR = Path(r"c:/Users/nabed/workspace/risk/df-pipeline-onboard-risk/Schema/risk")

TABLES = {
    "trump_market_monitor_2": {
        "columns": [
            ("ticker_code", "string", False),
            ("business_date", "date", False),
            ("last_price", "double", False),
            ("label", "string", False),
            ("event_no", "int", False),
            ("event_description", "string", False),
            ("prev_last_price", "double", False),
            ("dod_return", "double", False),
            ("ref_price", "double", False),
            ("bps_value", "double", False),
            ("first_non_null_price_before", "double", False),
            ("percent_return", "double", False),
        ],
    },
    "trump_market_monitor_corelation_2": {
        "columns": [
            ("business_date", "date", False),
            ("ticker_1_code", "string", False),
            ("ticker_1_name", "string", False),
            ("ticker_1_last_price", "double", False),
            ("ticker_1_prev_last_price", "double", False),
            ("ticker_1_dod", "double", False),
            ("ticker_2_code", "string", False),
            ("ticker_2_name", "string", False),
            ("ticker_2_last_price", "double", False),
            ("ticker_2_prev_last_price", "double", False),
            ("ticker_2_dod", "double", False),
            ("rolling_period_in_days", "int", False),
            ("rolling_period_label", "string", False),
            ("correlation", "double", False),
        ],
    },
    "trump_market_monitor_percentile_2": {
        "columns": [
            ("business_date", "date", False),
            ("last_price", "double", False),
            ("percentile_rank_1y", "double", False),
            ("percentile_rank_2y", "double", False),
            ("percentile_rank_5y", "double", False),
            ("ticker_code", "string", True),
        ],
    },
    "trump_market_monitor_lookback_corelation_percentile": {
        "columns": [
            ("business_date", "date", False),
            ("ticker_1_code", "string", False),
            ("ticker_2_code", "string", False),
            ("lookback_period", "string", False),
            ("corelation_rolling_period_label", "string", False),
            ("percentile", "bigint", False),
            ("percentile_value", "double", False),
        ],
    },
    "trump_market_monitor_slope_percentile_ranks": {
        "columns": [
            ("business_date", "date", False),
            ("ticker_code_1", "string", False),
            ("ticker_code_2", "string", False),
            ("rolling_period_days", "int", False),
            ("rolling_period_display_label", "string", False),
            ("price1", "double", False),
            ("price2", "double", False),
            ("price_difference", "double", False),
            ("percentile_rank", "double", False),
        ],
    },
}

TABLE_INFO_DEFAULTS = {
    "trusted_db_name": "df_trusted_{env}",
    "trusted_table_name": "datasource_datasetName",
    "trusted_location": "s3://cppib-data-fabric-trusted-{env}/datasource/datasource_datasetname/",
    "trusted_write_mode": "overwrite",
}


def build_table_info_rows(dataset_name: str) -> list[tuple]:
    rows = [("Name", "value", "Required", "Default")]
    location = f"s3://cppib-risk-enriched-{{env}}/research/shulisandra/{dataset_name}"
    fields = [
        ("data_source_name", "risk", "", ""),
        ("dataset_name", dataset_name, "", ""),
        ("trusted_db_name", "risk_{env}", "", TABLE_INFO_DEFAULTS["trusted_db_name"]),
        ("trusted_table_name", dataset_name, "", TABLE_INFO_DEFAULTS["trusted_table_name"]),
        ("trusted_location", location, "", TABLE_INFO_DEFAULTS["trusted_location"]),
        ("trusted_write_mode", "", "", TABLE_INFO_DEFAULTS["trusted_write_mode"]),
        ("trusted_meta_required", "no", "", ""),
    ]
    rows.extend(fields)
    return rows


def build_column_info_rows(columns: list[tuple]) -> list[tuple]:
    rows = [("trusted_column_name", "trusted_column_type", "trusted_is_partition_key")]
    for col_name, col_type, is_partition in columns:
        partition_value = 1 if is_partition else ""
        rows.append((col_name, col_type, partition_value))
    return rows


def write_xls(dataset_name: str, columns: list[tuple]) -> Path:
    wb = xlwt.Workbook(encoding="utf-8")
    ti = wb.add_sheet("table_info")
    for r, row in enumerate(build_table_info_rows(dataset_name)):
        for c, val in enumerate(row):
            ti.write(r, c, val)
    ci = wb.add_sheet("column_info")
    for r, row in enumerate(build_column_info_rows(columns)):
        for c, val in enumerate(row):
            ci.write(r, c, val)
    out = OUT_DIR / f"risk_{dataset_name}.xls"
    wb.save(str(out))
    return out


if __name__ == "__main__":
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for name, spec in TABLES.items():
        path = write_xls(name, spec["columns"])
        print(f"wrote {path}")
