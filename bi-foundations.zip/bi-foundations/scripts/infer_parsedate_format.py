"""
Verify parseDate format strings by sampling actual row values from the source.

For each (central_dataset_id, column_name) pair that was rewritten by
rewrite_parsedate_calc_fields.py with the default 'yyyy-MM-dd' format,
inspect the central dataset:

- If Athena CustomSql: wrap inner SQL with `SELECT <col> FROM (<sql>) WHERE
  <col> IS NOT NULL LIMIT 5` and run via the quicksight_wg_dev workgroup.
- If Athena RelationalTable: SELECT <col> FROM <schema>.<table> LIMIT 5.
- If S3 (manifest-based): NOT_SAMPLED for now; manifest-source datasets
  store their data in SPICE only and require a different sampling approach.

Match sample values against common format patterns. Emit a report listing
inferred format per dataset and flag mismatches with the default
'yyyy-MM-dd' so we can pass --format-override on the next rewrite pass.
"""

import argparse
import csv
import json
import re
import time
from pathlib import Path

import boto3


# Pattern -> Java SimpleDateFormat (QuickSight parseDate uses Java format)
# Ordered most-restrictive first so unambiguous patterns win.
FORMAT_PATTERNS = [
    (re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})?$"), "yyyy-MM-dd'T'HH:mm:ss"),
    (re.compile(r"^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}$"), "yyyy-MM-dd HH:mm:ss"),
    (re.compile(r"^\d{4}-\d{2}-\d{2}$"), "yyyy-MM-dd"),
    (re.compile(r"^\d{4}/\d{2}/\d{2}$"), "yyyy/MM/dd"),
    (re.compile(r"^\d{2}-\d{2}-\d{4}$"), "dd-MM-yyyy"),
    (re.compile(r"^\d{2}/\d{2}/\d{4}$"), "MM/dd/yyyy_OR_dd/MM/yyyy_AMBIGUOUS"),
    (re.compile(r"^\d{8}$"), "yyyyMMdd"),
    (re.compile(r"^\d{2}-[A-Za-z]{3}-\d{4}$"), "dd-MMM-yyyy"),
]


def infer_format(values):
    """Return (best_format, evidence) given a list of sample string values."""
    if not values:
        return None, "no samples"
    formats_seen = []
    for v in values:
        v = v.strip() if isinstance(v, str) else ""
        for pat, fmt in FORMAT_PATTERNS:
            if pat.match(v):
                formats_seen.append(fmt)
                break
        else:
            formats_seen.append(f"UNKNOWN({v!r})")
    # Pick the most common
    from collections import Counter
    counts = Counter(formats_seen)
    most_common, n = counts.most_common(1)[0]
    return most_common, dict(counts)


def athena_query(athena, workgroup, query, output_location=None, poll=2.0, timeout=120):
    kwargs = {"QueryString": query, "WorkGroup": workgroup}
    if output_location:
        kwargs["ResultConfiguration"] = {"OutputLocation": output_location}
    resp = athena.start_query_execution(**kwargs)
    qid = resp["QueryExecutionId"]
    started = time.time()
    while True:
        st = athena.get_query_execution(QueryExecutionId=qid)["QueryExecution"]["Status"]
        state = st["State"]
        if state in ("SUCCEEDED", "FAILED", "CANCELLED"):
            if state != "SUCCEEDED":
                return None, st.get("StateChangeReason", state)
            break
        if time.time() - started > timeout:
            return None, f"timeout after {timeout}s (state={state})"
        time.sleep(poll)
    rows = []
    paginator = athena.get_paginator("get_query_results")
    for page in paginator.paginate(QueryExecutionId=qid):
        for r in page["ResultSet"]["Rows"]:
            rows.append([c.get("VarCharValue", "") for c in r["Data"]])
    return rows, None


def list_pairs_from_rewrite_output(out_dir, qs_client, account_id):
    """Return list of {dataset_id, column, source_refs} dicts for every
    (central_dataset, column) pair that was rewritten."""
    pairs = {}
    for fp in Path(out_dir).glob("*.json"):
        kind = "dashboard" if "dashboard-" in fp.name else "analysis"
        rid = fp.name.replace(f"{kind}-", "").replace("-changes.json", "")
        with fp.open(encoding="utf-8") as f:
            d = json.load(f)
        decls = {}
        try:
            if kind == "dashboard":
                r = qs_client.describe_dashboard_definition(AwsAccountId=account_id, DashboardId=rid)
            else:
                r = qs_client.describe_analysis_definition(AwsAccountId=account_id, AnalysisId=rid)
            for dec in r.get("Definition", {}).get("DataSetIdentifierDeclarations", []) or []:
                decls[dec.get("Identifier", "")] = dec.get("DataSetArn", "")
        except Exception:
            continue
        for c in d.get("changes", []) or []:
            sid = c.get("dataset_identifier", "")
            col = c.get("column", "")
            arn = decls.get(sid, "")
            if not arn:
                continue
            dsid = arn.split(":dataset/")[-1]
            key = (dsid, col)
            pairs.setdefault(key, {"dataset_id": dsid, "column": col, "refs": []})
            pairs[key]["refs"].append({"kind": kind, "resource_id": rid, "source_id": sid, "calc_name": c.get("calc_name", "")})
    return list(pairs.values())


def build_sample_query(ds, col):
    """Build SELECT col sample query from a central dataset's PhysicalTableMap."""
    ptm = ds.get("PhysicalTableMap") or {}
    for k, v in ptm.items():
        if "CustomSql" in v:
            sql = v["CustomSql"].get("SqlQuery", "")
            cs = v["CustomSql"]
            if sql:
                # Wrap. Quote col with double-quotes for case-sensitive ids.
                return f'SELECT "{col}" AS v FROM ({sql}) AS sub WHERE "{col}" IS NOT NULL LIMIT 5', "CustomSql", cs.get("DataSourceArn", "")
        if "RelationalTable" in v:
            rt = v["RelationalTable"]
            schema = rt.get("Schema", "")
            name = rt.get("Name", "")
            ref = f'"{schema}"."{name}"' if schema else f'"{name}"'
            return f'SELECT "{col}" AS v FROM {ref} WHERE "{col}" IS NOT NULL LIMIT 5', "RelationalTable", rt.get("DataSourceArn", "")
        if "S3Source" in v:
            return None, "S3Source", v["S3Source"].get("DataSourceArn", "")
    return None, "unknown", ""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--target-profile", required=True,
                   help="AWS profile with describe access to the central QS resources (dashboards/analyses/datasets).")
    p.add_argument("--target-account-id", default="200967598245")
    p.add_argument("--athena-profile",
                   help="AWS profile with Lake Formation access to underlying tables for Athena sample queries. Defaults to --target-profile.")
    p.add_argument("--region", default="us-east-1")
    p.add_argument("--rewrite-output-dir", required=True,
                   help="Directory written by rewrite_parsedate_calc_fields.py")
    p.add_argument("--workgroup", default="quicksight_wg_dev")
    p.add_argument("--output-location", default="s3://aws-athena-query-results-200967598245-us-east-1/")
    p.add_argument("--default-format", default="yyyy-MM-dd")
    p.add_argument("--output", required=True, help="Output JSON path")
    args = p.parse_args()

    qs_sess = boto3.Session(profile_name=args.target_profile, region_name=args.region)
    qs = qs_sess.client("quicksight")
    athena_sess = boto3.Session(profile_name=args.athena_profile or args.target_profile, region_name=args.region)
    athena = athena_sess.client("athena")

    pairs = list_pairs_from_rewrite_output(args.rewrite_output_dir, qs, args.target_account_id)
    print(f"Sampling {len(pairs)} unique (central_dataset, column) pairs...")

    results = []
    ds_cache = {}
    for i, pair in enumerate(pairs, 1):
        dsid = pair["dataset_id"]
        col = pair["column"]
        if dsid not in ds_cache:
            try:
                ds_cache[dsid] = qs.describe_data_set(AwsAccountId=args.target_account_id, DataSetId=dsid)["DataSet"]
            except Exception as e:
                ds_cache[dsid] = {"_error": str(e)}
        ds = ds_cache[dsid]
        if "_error" in ds:
            results.append({**pair, "status": "DESCRIBE_FAILED", "error": ds["_error"]})
            continue
        query, kind, src_arn = build_sample_query(ds, col)
        if not query:
            results.append({**pair, "status": "NOT_SAMPLED", "physical_kind": kind, "source": src_arn})
            print(f"  [{i}/{len(pairs)}] {dsid}/{col}: NOT_SAMPLED ({kind})")
            continue
        print(f"  [{i}/{len(pairs)}] {dsid}/{col}: querying Athena ({kind})... ", end="", flush=True)
        rows, err = athena_query(athena, args.workgroup, query, output_location=args.output_location)
        if err:
            results.append({**pair, "status": "QUERY_FAILED", "physical_kind": kind, "error": err, "query": query[:200]})
            print(f"FAILED ({err[:80]})")
            continue
        values = [r[0] for r in rows[1:]] if rows else []  # Skip header row
        fmt, evidence = infer_format(values)
        matches_default = fmt == args.default_format
        results.append({**pair, "status": "OK", "physical_kind": kind, "samples": values,
                        "inferred_format": fmt, "evidence": evidence,
                        "matches_default": matches_default})
        flag = "OK" if matches_default else f"DIFFERS (got {fmt})"
        print(f"{flag} | samples={values[:3]}")

    Path(args.output).write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print(f"\nWrote {args.output}")
    # Summary
    ok = [r for r in results if r["status"] == "OK"]
    differs = [r for r in ok if not r.get("matches_default")]
    not_sampled = [r for r in results if r["status"] == "NOT_SAMPLED"]
    failed = [r for r in results if r["status"] in ("QUERY_FAILED", "DESCRIBE_FAILED")]
    print(f"\nSummary: {len(ok)} sampled, {len(differs)} differ from default '{args.default_format}', {len(not_sampled)} not sampled, {len(failed)} failed")
    if differs:
        print("\n--format-override args for next rewrite pass:")
        for r in differs:
            print(f"  --format-override '{r['dataset_id']}:{r['column']}:{r['inferred_format']}'")


if __name__ == "__main__":
    main()
