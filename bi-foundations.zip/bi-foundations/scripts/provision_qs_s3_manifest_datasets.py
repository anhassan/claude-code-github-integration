"""
Provision central QuickSight S3 data sources and datasets from manifest inventory.

Input comes from build_qs_s3_manifest_inventory.py. That inventory still needs
real data_uris or data_uri_prefixes filled in by Risk/data owners before this
script can apply changes.
"""

import argparse
import copy
import csv
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import ClientError


DATASET_COPY_FIELDS = [
    "LogicalTableMap",
    "ColumnGroups",
    "FieldFolders",
    "PerformanceConfiguration",
    "DataSetUsageConfiguration",
]


def read_json(path):
    with Path(path).open(encoding="utf-8") as file:
        return json.load(file)


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=str)
        file.write("\n")


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def parse_list(value):
    if not value:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
    except Exception:
        pass
    return [
        item.strip()
        for item in re.split(r"[;\n,]+", str(value))
        if item.strip()
    ]


def session_for(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def load_inventory(path):
    payload = read_json(path)
    rows = payload.get("rows", [])
    if not rows:
        raise ValueError(f"No rows found in {path}")
    return payload, rows


def apply_location_overrides(rows, locations_csv):
    if not locations_csv:
        return rows

    overrides = {
        row["source_dataset_id"]: row
        for row in read_csv(locations_csv)
        if row.get("source_dataset_id")
    }
    updated = []
    for row in rows:
        clone = copy.deepcopy(row)
        override = overrides.get(row.get("source_dataset_id"))
        if override:
            for key in [
                "manifest_bucket",
                "manifest_key",
                "data_uris",
                "data_uri_prefixes",
                "notes",
            ]:
                if override.get(key):
                    clone[key] = override[key]
        updated.append(clone)
    return updated


def selected_rows(rows, dataset_ids, dataset_names, limit):
    selected = []
    id_set = set(dataset_ids or [])
    name_set = set(dataset_names or [])
    for row in rows:
        if id_set and row.get("source_dataset_id") not in id_set:
            continue
        if name_set and row.get("source_dataset_name") not in name_set:
            continue
        selected.append(row)
        if limit and len(selected) >= limit:
            break
    return selected


def get_upload_setting(settings, key):
    return settings.get(key) or settings.get(key[:1].lower() + key[1:])


def manifest_text_qualifier(value):
    if value in (None, "", "NONE"):
        return None
    if value == "DOUBLE_QUOTE":
        return '"'
    if value == "SINGLE_QUOTE":
        return "'"
    return value


def build_manifest(row):
    uris = parse_list(row.get("data_uris"))
    prefixes = parse_list(row.get("data_uri_prefixes"))
    if not uris and not prefixes:
        raise ValueError("At least one data URI or URI prefix is required")

    file_locations = []
    if uris:
        file_locations.append({"URIs": uris})
    if prefixes:
        file_locations.append({"URIPrefixes": prefixes})

    settings = row.get("source_upload_settings") or {}
    manifest_settings = {}
    file_format = get_upload_setting(settings, "Format")
    if file_format:
        manifest_settings["format"] = file_format

    if file_format != "JSON":
        delimiter = get_upload_setting(settings, "Delimiter")
        if delimiter is not None:
            manifest_settings["delimiter"] = delimiter

        text_qualifier = manifest_text_qualifier(
            get_upload_setting(settings, "TextQualifier")
        )
        if text_qualifier:
            manifest_settings["textqualifier"] = text_qualifier

        contains_header = get_upload_setting(settings, "ContainsHeader")
        if contains_header is not None:
            manifest_settings["containsHeader"] = (
                "true" if bool(contains_header) else "false"
            )

    return {
        "fileLocations": file_locations,
        "globalUploadSettings": manifest_settings,
    }


def replace_data_source_arns(value, target_data_source_arn):
    if isinstance(value, dict):
        for key, nested in value.items():
            if key == "DataSourceArn":
                value[key] = target_data_source_arn
            else:
                replace_data_source_arns(nested, target_data_source_arn)
    elif isinstance(value, list):
        for item in value:
            replace_data_source_arns(item, target_data_source_arn)


def build_dataset_params(row, account_id, target_data_source_arn):
    source_dataset = row.get("source_dataset") or {}
    if not source_dataset:
        raise ValueError("Inventory row has no source_dataset payload")

    physical_table_map = copy.deepcopy(source_dataset.get("PhysicalTableMap") or {})
    if not physical_table_map:
        raise ValueError("Source dataset has no PhysicalTableMap")
    replace_data_source_arns(physical_table_map, target_data_source_arn)

    params = {
        "AwsAccountId": account_id,
        "DataSetId": row["target_dataset_id"],
        "Name": row["target_dataset_name"],
        "PhysicalTableMap": physical_table_map,
        "ImportMode": source_dataset.get("ImportMode") or row.get("source_import_mode") or "SPICE",
    }
    for field in DATASET_COPY_FIELDS:
        if source_dataset.get(field):
            params[field] = copy.deepcopy(source_dataset[field])
    return params


def put_manifest(s3_client, bucket, key, manifest, apply_changes):
    body = json.dumps(manifest, indent=2)
    if not apply_changes:
        return {"dry_run": True, "bucket": bucket, "key": key}
    return s3_client.put_object(
        Bucket=bucket,
        Key=key,
        Body=body.encode("utf-8"),
        ContentType="application/json",
    )


def create_or_update_data_source(qs_client, account_id, row, apply_changes):
    params = {
        "AwsAccountId": account_id,
        "DataSourceId": row["target_data_source_id"],
        "Name": row["target_data_source_name"],
        "Type": "S3",
        "DataSourceParameters": {
            "S3Parameters": {
                "ManifestFileLocation": {
                    "Bucket": row["manifest_bucket"],
                    "Key": row["manifest_key"],
                }
            }
        },
    }
    if not apply_changes:
        return {
            "action": "dry_run",
            "arn": f"arn:aws:quicksight:us-east-1:{account_id}:datasource/{row['target_data_source_id']}",
            "params": params,
        }

    try:
        existing = qs_client.describe_data_source(
            AwsAccountId=account_id,
            DataSourceId=row["target_data_source_id"],
        )
        qs_client.update_data_source(**params)
        action = "updated"
        arn = existing["DataSource"]["Arn"]
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
            raise
        response = qs_client.create_data_source(**params)
        action = "created"
        arn = response["Arn"]
    return {"action": action, "arn": arn, "params": params}


def create_or_update_dataset(qs_client, account_id, row, target_data_source_arn, apply_changes):
    params = build_dataset_params(row, account_id, target_data_source_arn)
    if not apply_changes:
        return {
            "action": "dry_run",
            "arn": f"arn:aws:quicksight:us-east-1:{account_id}:dataset/{row['target_dataset_id']}",
            "params": params,
        }

    try:
        existing = qs_client.describe_data_set(
            AwsAccountId=account_id,
            DataSetId=row["target_dataset_id"],
        )
        qs_client.update_data_set(**params)
        action = "updated"
        arn = existing["DataSet"]["Arn"]
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
            raise
        response = qs_client.create_data_set(**params)
        action = "created"
        arn = response["Arn"]
    return {"action": action, "arn": arn, "params": params}


def add_folder_membership(qs_client, account_id, folder_id, member_id, member_type, apply_changes):
    if not folder_id:
        return {"status": "skipped", "reason": "no folder id"}
    if not apply_changes:
        return {"status": "dry_run", "folder_id": folder_id, "member_id": member_id, "member_type": member_type}
    try:
        qs_client.create_folder_membership(
            AwsAccountId=account_id,
            FolderId=folder_id,
            MemberId=member_id,
            MemberType=member_type,
        )
        return {"status": "added"}
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") == "ResourceExistsException":
            return {"status": "already_exists"}
        raise


def start_ingestion(qs_client, account_id, dataset_id, apply_changes):
    ingestion_id = "manual-migration-{}".format(
        datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    )
    if not apply_changes:
        return {"status": "dry_run", "ingestion_id": ingestion_id}
    response = qs_client.create_ingestion(
        AwsAccountId=account_id,
        DataSetId=dataset_id,
        IngestionId=ingestion_id,
        IngestionType="FULL_REFRESH",
    )
    return {"status": "started", "ingestion_id": ingestion_id, "response": response}


def wait_for_ingestion(qs_client, account_id, dataset_id, ingestion_id, poll_seconds, timeout_seconds):
    started_at = time.time()
    while True:
        response = qs_client.describe_ingestion(
            AwsAccountId=account_id,
            DataSetId=dataset_id,
            IngestionId=ingestion_id,
        )
        status = response["Ingestion"]["IngestionStatus"]
        print(f"Ingestion {dataset_id}/{ingestion_id}: {status}", flush=True)
        if status in {"COMPLETED", "FAILED", "CANCELLED"}:
            return response
        if time.time() - started_at > timeout_seconds:
            raise TimeoutError(f"Ingestion {ingestion_id} did not finish within {timeout_seconds} seconds")
        time.sleep(poll_seconds)


def provision_row(qs_client, s3_client, account_id, row, output_dir, apply_changes, folder_id, start_spice_ingestion, wait_ingestion, poll_seconds, timeout_seconds):
    manifest = build_manifest(row)
    manifest_path = output_dir / "manifests" / row["source_dataset_id"] / "manifest.json"
    write_json(manifest_path, manifest)

    if not row.get("manifest_bucket") or not row.get("manifest_key"):
        raise ValueError("manifest_bucket and manifest_key are required")

    manifest_result = put_manifest(
        s3_client,
        row["manifest_bucket"],
        row["manifest_key"],
        manifest,
        apply_changes,
    )
    data_source_result = create_or_update_data_source(
        qs_client,
        account_id,
        row,
        apply_changes,
    )
    dataset_result = create_or_update_dataset(
        qs_client,
        account_id,
        row,
        data_source_result["arn"],
        apply_changes,
    )

    folder_results = [
        add_folder_membership(
            qs_client,
            account_id,
            folder_id,
            row["target_data_source_id"],
            "DATASOURCE",
            apply_changes,
        ),
        add_folder_membership(
            qs_client,
            account_id,
            folder_id,
            row["target_dataset_id"],
            "DATASET",
            apply_changes,
        ),
    ]

    ingestion_result = {"status": "skipped"}
    if start_spice_ingestion and (row.get("source_import_mode") or "").upper() == "SPICE":
        ingestion_result = start_ingestion(
            qs_client,
            account_id,
            row["target_dataset_id"],
            apply_changes,
        )
        if apply_changes and wait_ingestion:
            ingestion_result["final_response"] = wait_for_ingestion(
                qs_client,
                account_id,
                row["target_dataset_id"],
                ingestion_result["ingestion_id"],
                poll_seconds,
                timeout_seconds,
            )

    return {
        "source_dataset_id": row["source_dataset_id"],
        "source_dataset_name": row["source_dataset_name"],
        "target_dataset_id": row["target_dataset_id"],
        "target_dataset_arn": dataset_result["arn"],
        "target_data_source_id": row["target_data_source_id"],
        "target_data_source_arn": data_source_result["arn"],
        "manifest_path": str(manifest_path),
        "manifest_s3_uri": f"s3://{row['manifest_bucket']}/{row['manifest_key']}",
        "manifest_result": manifest_result,
        "data_source_result": data_source_result,
        "dataset_result": dataset_result,
        "folder_results": folder_results,
        "ingestion_result": ingestion_result,
    }


def parse_args():
    parser = argparse.ArgumentParser(
        description="Create/update target QuickSight S3 manifest data sources and datasets."
    )
    parser.add_argument("--inventory", required=True, help="s3_manifest_inventory.json")
    parser.add_argument("--locations-csv", help="Optional filled s3_manifest_locations_template.csv")
    parser.add_argument("--profile", help="Target AWS profile")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--account-id", default="200967598245")
    parser.add_argument("--folder-id", default="bif-risk-dev")
    parser.add_argument("--dataset-id", nargs="*", help="Limit to source dataset ids")
    parser.add_argument("--dataset-name", nargs="*", help="Limit to source dataset names")
    parser.add_argument("--limit", type=int, help="Limit number of rows processed")
    parser.add_argument("--output-root", default="exports/quicksight-s3-manifest-provision")
    parser.add_argument("--apply", action="store_true", help="Write S3 manifests and mutate QuickSight resources")
    parser.add_argument("--start-ingestion", action="store_true", help="Start a SPICE ingestion after create/update")
    parser.add_argument("--wait-ingestion", action="store_true", help="Wait for started ingestions to finish")
    parser.add_argument("--poll-seconds", type=int, default=15)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    return parser.parse_args()


def main():
    args = parse_args()
    inventory_path = Path(args.inventory)
    inventory, rows = load_inventory(inventory_path)
    rows = apply_location_overrides(rows, args.locations_csv)
    rows = selected_rows(rows, args.dataset_id, args.dataset_name, args.limit)
    if not rows:
        raise ValueError("No inventory rows selected")

    session = session_for(args.profile, args.region)
    account_id = args.account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)
    qs_client = session.client("quicksight", region_name=args.region)
    s3_client = session.client("s3", region_name=args.region)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = Path(args.output_root) / f"{account_id}-{run_id}"
    output_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for idx, row in enumerate(rows, start=1):
        print(
            f"[{idx}/{len(rows)}] {'Applying' if args.apply else 'Dry-run'} S3 dataset {row.get('source_dataset_name')} ({row.get('source_dataset_id')})",
            flush=True,
        )
        try:
            result = provision_row(
                qs_client,
                s3_client,
                account_id,
                row,
                output_dir,
                args.apply,
                args.folder_id,
                args.start_ingestion,
                args.wait_ingestion,
                args.poll_seconds,
                args.timeout_seconds,
            )
            result["status"] = "APPLIED" if args.apply else "DRY_RUN_OK"
        except Exception as error:
            result = {
                "source_dataset_id": row.get("source_dataset_id"),
                "source_dataset_name": row.get("source_dataset_name"),
                "status": "ERROR",
                "error": str(error),
            }
            print(f"  ERROR: {error}", flush=True)
        results.append(result)

    write_json(
        output_dir / "provision_results.json",
        {
            "inventory": str(inventory_path),
            "locations_csv": args.locations_csv,
            "target_profile": args.profile,
            "target_account_id": account_id,
            "region": args.region,
            "folder_id": args.folder_id,
            "apply": args.apply,
            "caller_identity": caller_identity,
            "source_inventory_metadata": {
                key: inventory.get(key)
                for key in ["source_account_id", "target_account_id", "region", "migration_matrix"]
            },
            "row_count": len(results),
            "results": results,
        },
    )

    ok_count = sum(1 for result in results if result["status"] in {"APPLIED", "DRY_RUN_OK"})
    error_count = len(results) - ok_count
    print(f"Rows processed: {len(results)}", flush=True)
    print(f"Successful/dry-run rows: {ok_count}", flush=True)
    print(f"Error rows: {error_count}", flush=True)
    print(f"Provision audit folder: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
