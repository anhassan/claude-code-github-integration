from pprint import pprint

import boto3
import time 
import base64
import yaml
import os

def read_overrides_from_json_file(file_path):
    import json
    with open(file_path, "r") as f:
        overrides = json.load(f)
    return overrides

def read_exported_dashboard_file(file_path):
    with open(file_path, "rb") as f:
        dashboard_data = f.read()
    return dashboard_data

def write_yaml_to_file(yaml_content, file_name):
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, 'w') as file:
        yaml.dump(yaml_content, file, default_flow_style=False, sort_keys=False)
    print(f"YAML content written to file: {file_name}")

def write_sql_to_file(sql_content, file_name):
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, 'w') as file:
        file.write(sql_content)
    print(f"SQL content written to file: {file_name}")

def unzip_dashboard_export_file(dashboard_name):
    from pathlib import Path
    import shutil

    qs_bundle_file = Path(f"{dashboard_name}/bundle.qs")
    qs_zip_bundle_file = Path(f"{dashboard_name}/bundle.zip")
    output_bundle_dir = Path("bundle")
    
    if not (qs_zip_bundle_file.exists() and output_bundle_dir.exists()) :

        shutil.copy(qs_bundle_file, qs_zip_bundle_file)
        print(f"Copied {qs_bundle_file} to {qs_zip_bundle_file}")

        shutil.unpack_archive(qs_zip_bundle_file, output_bundle_dir)
        print(f"Unpacked {qs_zip_bundle_file} to {output_bundle_dir}")

        shutil.move(output_bundle_dir, Path(dashboard_name))
        print(f"Moved {output_bundle_dir} to {dashboard_name}/{output_bundle_dir}")


def get_all_file_paths_in_bundle(dashboard_name):
    from pathlib import Path
    all_file_paths = []

    bundle_dir = Path(f"{dashboard_name}/bundle")
    all_files = list(bundle_dir.rglob("*"))
    print(f"All files in {bundle_dir}:")
    for file_path in all_files:
        all_file_paths.append(file_path)
        print(f"Found file: {file_path}")
    
    return [str(file_path) for file_path in all_file_paths if ".json" in file_path.name]


def get_dashboard_artifacts_from_bundle_files(file_paths):
    artifacts = {}
    for file_path in file_paths:
        if "dashboard" in file_path:
            artifacts["dashboardId"] = file_path.split("\\")[-1].replace(".json", "")
        elif "analysis" in file_path:
            artifacts["analysisId"] = file_path.split("\\")[-1].replace(".json", "")
        elif "dataset" in file_path:
            ds_id = file_path.split("\\")[-1].replace(".json", "")
            if "datasetIds" not in artifacts:
                artifacts["datasetIds"] = [ds_id]
            else:
                artifacts["datasetIds"].append(ds_id)
        elif "refreshSchedule" in file_path:
            refresh_schedule_info = file_path.split("\\")[-1].replace(".json", "")
            refresh_schedule_id = refresh_schedule_info.split("--refresh-schedule--")[-1]
            ds_id = refresh_schedule_info.split("--refresh-schedule--")[0]

            if "refreshArtifacts" not in artifacts:
                artifacts["refreshArtifacts"] = [{ds_id : [refresh_schedule_id]}]
            else:
                for existing_artifact in artifacts["refreshArtifacts"]:
                    if ds_id in existing_artifact.keys():
                        existing_artifact[ds_id].append(refresh_schedule_id)
                        break
                else:
                    artifacts["refreshArtifacts"].append({ds_id: [refresh_schedule_id]})

    return artifacts


def get_dashboard_artifacts_from_bundle(dashboard_name):
    unzip_dashboard_export_file(dashboard_name)
    file_paths = get_all_file_paths_in_bundle(dashboard_name)
    artifacts = get_dashboard_artifacts_from_bundle_files(file_paths)
    print(f"Extracted Artifacts from Dashboard Bundle: {artifacts}")
    return artifacts


def get_datasource_arn(datasource_name, aws_account_id, qs_client):
    ds_metadata = []
    response = qs_client.list_data_sources(
        AwsAccountId=aws_account_id
    )
    ds_metadata.extend(response["DataSources"])
    print(f"Fetching DataSources for Account: {aws_account_id} - Fetched {len(response['DataSources'])} DataSources")

    while "NextToken" in response:
        response = qs_client.list_data_sources(
            AwsAccountId=aws_account_id,
            NextToken=response["NextToken"]
        )
        ds_metadata.extend(response["DataSources"])
        print(f"Fetching DataSources for Account: {aws_account_id} - Fetched {len(response['DataSources'])} DataSources")

    for ds in ds_metadata:
        if ds["Name"] == datasource_name:
            print(f"Found DataSource with Name: {datasource_name} - ARN: {ds['Arn']}")
            return ds["Arn"]
    raise ValueError(f"DataSource with name {datasource_name} not found in Account: {aws_account_id}")

def get_dataset_config(ds_definition):
    ds_name = ds_definition['Name']
    ds_id = ds_definition['DataSetId']
    ds_cols = ds_definition['PhysicalTableMap'][list(ds_definition['PhysicalTableMap'].keys())[0]]['CustomSql']['Columns']
    ds_query = ds_definition['PhysicalTableMap'][list(ds_definition['PhysicalTableMap'].keys())[0]]['CustomSql']['SqlQuery']

    ds_metadata_cols = {col["Name"] : col["Type"] for col in ds_cols}

    ds_metadata_json =  {
                    "name": ds_id,
                    "force_sync": True,
                    "import_mode": "SPICE",
                    "workspaces": [
                        workspace_name
                    ],
                    "columns": ds_metadata_cols,
                    }
    print(f"Constructed dataset config for dataset: {ds_id} - Config: {ds_metadata_json}")
    return ds_metadata_json, ds_query

def get_dataset_definition(dataset_id, qs_client, aws_account_id):
    response = qs_client.describe_data_set(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id
    )
    print(f"Described Dataset: {response['DataSet']['Name']} with ID: {response['DataSet']['DataSetId']}")
    return response

def recreate_dataset_from_definition(dataset_definition, datasource_arn, qs_client, aws_account_id):
    cols_to_drop = ["Arn", "CreatedTime", "LastUpdatedTime", "ConsumedSpiceCapacityInBytes", "OutputColumns"]
    original_ds_id = dataset_definition["DataSetId"]
    
    dataset_definition_copy = {k: v for k, v in dataset_definition.items() if k not in cols_to_drop}
    original_ds_id = dataset_definition["DataSetId"]
    new_ds_id = dataset_definition["Name"].replace(" ", "_").lower()

    dataset_definition_copy["AwsAccountId"] = aws_account_id
    dataset_definition_copy["DataSetId"] = new_ds_id
    dataset_definition_copy["Name"] = new_ds_id

    # Change datasource to Fabric Catalog Access in case the dataset is a data fabric dataset
    dataset_physical_table_map = dataset_definition_copy["PhysicalTableMap"]
    is_dataset_datafabric = "CustomSql" in dataset_physical_table_map[list(dataset_physical_table_map.keys())[0]].keys()
    if is_dataset_datafabric:
        print(f"Dataset is a data fabric dataset. Updating datasource to {datasource_arn}")
        dataset_definition_copy["PhysicalTableMap"][list(dataset_physical_table_map.keys())[0]]["CustomSql"]["DataSourceArn"] = datasource_arn

    # Create or Update dataset based on whether it already exists or not
    try:
        # Update dataset if it already exists
        existing_ds = get_dataset_definition(dataset_definition_copy["DataSetId"], qs_client, aws_account_id)
        print(f"Dataset with ID: {dataset_definition_copy['DataSetId']} already exists. Skipping creation.")

        response = qs_client.update_data_set(**dataset_definition_copy)
        print(f"Updated Dataset with ID: {response['DataSetId']}")
    except Exception as e:
        # Create dataset only if it doesn't already exist
        print(f"Dataset with ID: {dataset_definition_copy['DataSetId']} does not exist. Proceeding with creation.")
        
        response = qs_client.create_data_set(**dataset_definition_copy)
        print(f"Created Dataset with ID: {response['DataSetId']}")
    
    ds_config, ds_query = get_dataset_config(dataset_definition)
    
    return response, original_ds_id, new_ds_id, ds_config, ds_query


def recreate_datasets(artifacts, qs_client, aws_account_id):
    datasource_name = "Fabric Catalog Access"
    datasource_arn = get_datasource_arn(datasource_name, aws_account_id, qs_client)
    dataset_id_mappings = {}
    for dataset_id in artifacts["datasetIds"]:
        ds_def = get_dataset_definition(dataset_id, qs_client, aws_account_id)
        response, original_ds_id, new_ds_id, ds_config, ds_query = recreate_dataset_from_definition(ds_def["DataSet"], datasource_arn, qs_client, aws_account_id)
        dataset_id_mappings[original_ds_id] = {
            "new_ds_id": new_ds_id,
            "ds_config": ds_config,
            "ds_query": ds_query
        }
    return dataset_id_mappings

def delete_dataset(dataset_id, qs_client, aws_account_id):
    response = qs_client.delete_data_set(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id
    )
    print(f"Deleted Dataset with ID: {dataset_id} - Response: {response}")
    return response


def get_dataset_refresh_schedule_definition(dataset_id, refresh_schedule_id, qs_client, aws_account_id):
    response = qs_client.describe_refresh_schedule(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id,
        ScheduleId=refresh_schedule_id
    )
    print(f"Described Refresh Schedule with ID: {response['RefreshSchedule']['ScheduleId']} for Dataset: {dataset_id}")
    return response

def recreate_refresh_schedule(dataset_id, refresh_schedule_definition, qs_client, aws_account_id, schedule_num=1):
    refresh_schedule_id = f"{dataset_id}-refresh-schedule-{schedule_num}"
    
    refresh_schedule_definition_copy = {}
    refresh_schedule_definition_copy["AwsAccountId"] = aws_account_id
    refresh_schedule_definition_copy["DataSetId"] = dataset_id
    refresh_schedule_definition_copy["Schedule"] = refresh_schedule_definition["RefreshSchedule"]
    refresh_schedule_definition_copy["Schedule"]["ScheduleId"] = refresh_schedule_id
    print(f"Constructed Refresh Schedule definition for Refresh Schedule: {refresh_schedule_id} - Definition: {refresh_schedule_definition_copy}")

    try:
        existing_schedule = get_dataset_refresh_schedule_definition(dataset_id, refresh_schedule_id, qs_client, aws_account_id)
        print(f"Refresh Schedule with ID: {refresh_schedule_id} already exists for Dataset: {dataset_id}. Skipping creation.")
        qs_client.update_refresh_schedule(**refresh_schedule_definition_copy)
        print(f"Updated Refresh Schedule with ID: {refresh_schedule_id} for Dataset: {dataset_id}")
    except Exception as e:
        print(f"Refresh Schedule with ID: {refresh_schedule_id} does not exist for Dataset: {dataset_id}. Proceeding with creation.")
        response = qs_client.create_refresh_schedule(**refresh_schedule_definition_copy)
        print(f"Created Refresh Schedule with ID: {response['ScheduleId']} for Dataset: {dataset_id}")
        return response


def recreate_dataset_refresh_schedules(artifacts, dataset_id_mappings, qs_client, aws_account_id):
    for refresh_artifact in artifacts["refreshArtifacts"]:
        for dataset_id, refresh_schedule_ids in refresh_artifact.items():
            for idx, refresh_schedule_id in enumerate(refresh_schedule_ids):
                refresh_schedule_definition = get_dataset_refresh_schedule_definition(dataset_id, refresh_schedule_id, qs_client, aws_account_id)
                if refresh_schedule_definition["RefreshSchedule"]["RefreshType"] == "FULL_REFRESH":
                    new_ds_id = dataset_id_mappings[dataset_id]["new_ds_id"]
                    schedule_num = idx + 1
                    recreate_refresh_schedule(new_ds_id, refresh_schedule_definition, qs_client, aws_account_id, schedule_num=schedule_num)
                    dataset_id_mappings[dataset_id]["ds_config"]["refresh_schedule"] = {
                                                            "ScheduleId": f"{new_ds_id}-refresh-schedule-{schedule_num}",
                                                            "RefreshType" : refresh_schedule_definition["RefreshSchedule"]["RefreshType"],
                                                            "ScheduleFrequency": refresh_schedule_definition["RefreshSchedule"]["ScheduleFrequency"]
                                                        }
    return dataset_id_mappings


def delete_refresh_schedule(dataset_id, refresh_schedule_id, qs_client, aws_account_id):
    response = qs_client.delete_refresh_schedule(
        AwsAccountId=aws_account_id,
        DataSetId=dataset_id,
        ScheduleId=refresh_schedule_id
    )
    print(f"Deleted Refresh Schedule with ID: {refresh_schedule_id} for Dataset: {dataset_id} - Response: {response}")
    return response


def write_dataset_config_files(dataset_id_mappings, workspace_name, env):
    for original_ds_id, ds_info in dataset_id_mappings.items():
        new_ds_id = ds_info["new_ds_id"]
        ds_config = ds_info["ds_config"]
        ds_query = ds_info["ds_query"]

        ds_yaml_metadata_file_name = f"{env}/datasets/{new_ds_id}/metadata.yaml"
        write_yaml_to_file(ds_config, ds_yaml_metadata_file_name)
        print(f"Dataset metadata YAML file created for dataset: {new_ds_id} at location: {ds_yaml_metadata_file_name}")

        ds_sql_query_file_name = f"{env}/datasets/{new_ds_id}/query.sql"
        write_sql_to_file(ds_query, ds_sql_query_file_name)
        print(f"Dataset SQL query file created for dataset: {new_ds_id} at location: {ds_sql_query_file_name}")


def get_analysis_definition(analysis_id, qs_client, aws_account_id):
    response = qs_client.describe_analysis_definition(
        AwsAccountId=aws_account_id,
        AnalysisId=analysis_id
    )
    print(f"Described Analysis: {response['Name']} with ID: {response['AnalysisId']}")
    return response


def update_analysis(artifacts, dataset_id_mappings, qs_client, aws_account_id):
    analysis_definition = get_analysis_definition(artifacts["analysisId"], qs_client, aws_account_id)

    cols_to_select = ["Definition"]
    
    analysis_definition_copy = {k: v for k, v in analysis_definition.items() if k  in cols_to_select}

    updated_dataset_declarations = []
    for ds_declaration in analysis_definition_copy["Definition"]["DataSetIdentifierDeclarations"]:
        original_ds_id = ds_declaration["DataSetArn"].split("/")[-1]
        if original_ds_id in dataset_id_mappings.keys():
            new_ds_id = dataset_id_mappings[original_ds_id]["new_ds_id"]
            updated_dataset_declarations.append({
                "Identifier": ds_declaration["Identifier"],
                "DataSetArn": ds_declaration["DataSetArn"].replace(original_ds_id, new_ds_id)
            })
        else:
            updated_dataset_declarations.append(ds_declaration)

    analysis_definition_copy["Definition"]["DataSetIdentifierDeclarations"] = updated_dataset_declarations
    
    analysis_definition_copy["AwsAccountId"] = aws_account_id
    analysis_definition_copy["AnalysisId"] = analysis_definition["AnalysisId"]
    analysis_definition_copy["Name"] = analysis_definition["Name"]

    # Update the analysis
    response = qs_client.update_analysis(**analysis_definition_copy)
    print(f"Updated Analysis with ID: {response['AnalysisId']}")
    
    return response


def describe_dashboard(dashboard_id, qs_client, aws_account_id):
    response = qs_client.describe_dashboard_definition(
        AwsAccountId=aws_account_id,
        DashboardId=dashboard_id
    )
    print(f"Described Dashboard: {response['Name']} with ID: {response['DashboardId']}")
    return response


def write_dashboard_config_file(artifacts, workspace_name, env, qs_client,
                                ad_grp="AWS_SSO_QS_AUTHOR_MA_BI",department="Management Analytics",
                                product_owner_name="Joanna Lei", product_owner_email="jlei@cppib.com"
                                ):
    dashboard_id = artifacts["dashboardId"]
    dashboard_definition = describe_dashboard(dashboard_id, qs_client, aws_account_id)

    # Dashboard Metadata
    dashboard_name = dashboard_definition["Name"]
    dashboard_folder_name = dashboard_name.replace(" ", "_").lower()
    dashboard_id = f"{dashboard_name.replace(' ', '_').lower()}-{workspace_name}-{env}"
    dashboard_override_name = f"{dashboard_name.title().replace(' ', '').lower()}/DEVELOP"

    dashboard_metadata = {
        "DashboardId": dashboard_id,
        "DashboardName" : dashboard_name,
        "DashboardCuratedName" : dashboard_override_name,
        "Folder" : dashboard_folder_name
    }

    dashboard_config_file_name = f"{env}/assets/{dashboard_metadata['DashboardId']}/config.yaml"
    dashboard_config = {
            "base_dashboard_name": dashboard_metadata["DashboardCuratedName"].replace("/DEVELOP", ""),
            "display_name": dashboard_metadata["DashboardName"],
            "id_prefix": dashboard_metadata["DashboardName"].replace(" ", "_").lower(),
            "branch": "DEVELOP",
            "version": "latest",
            "use_fixed": False,
            "force_sync": True,
            "owners": [
                ad_grp
            ],
            "finsights_detail": {
                "department": department,
                "product_owners": [
                {
                    "name": product_owner_name,
                    "email": product_owner_email
                }
                ]
            }
            }
    write_yaml_to_file(dashboard_config, dashboard_config_file_name)
    print(f"Dashboard config YAML file created for dashboard: {dashboard_metadata['DashboardName']} at location: {dashboard_config_file_name}")


def delete_dashboard(dashboard_id, qs_client, aws_account_id):
    response = qs_client.delete_dashboard(
        AwsAccountId=aws_account_id,
        DashboardId=dashboard_id
    )
    print(f"Deleted Dashboard with ID: {dashboard_id} - Response: {response}")
    return response

def move_qs_asset_to_workspace(workspace_name, member_id, member_type, aws_account_id, region, env, qs_client):
    qs_client.create_folder_membership(
        AwsAccountId=aws_account_id,
        FolderId=f"{workspace_name}-{env}",
        MemberId=member_id,
        MemberType=member_type
    )
    print(f"Moved {member_type} with Id: {member_id} to Workspace: {workspace_name}-{env} in Account: {aws_account_id}")


def move_qs_assets_to_workspace(artifacts, dataset_id_mappings, workspace_name, aws_account_id, region, env, qs_client):
    for original_ds_id, ds_info in dataset_id_mappings.items():
        move_qs_asset_to_workspace(workspace_name, ds_info["new_ds_id"], "DATASET", aws_account_id, region, env, qs_client)

    move_qs_asset_to_workspace(workspace_name, artifacts["analysisId"], "ANALYSIS", aws_account_id, region, env, qs_client)


def delete_qs_assets(artifacts, dataset_id_mappings, qs_client, aws_account_id):
    for refresh_artifact in artifacts["refreshArtifacts"]:
        for dataset_id, refresh_schedule_ids in refresh_artifact.items():
            for refresh_schedule_id in refresh_schedule_ids:
                delete_refresh_schedule(dataset_id, refresh_schedule_id, qs_client, aws_account_id)

    for dataset_id in artifacts["datasetIds"]:
            delete_dataset(dataset_id, qs_client, aws_account_id)
    
    delete_dashboard(artifacts["dashboardId"], qs_client, aws_account_id)



def start_dashboard_import(dashboard_name, dashboard_export_data, override_params, aws_account_id, region, qs_client):

    import_job_id = f"import-{dashboard_name.replace(' ', '_')}-{int(time.time())}"
    response = qs_client.start_asset_bundle_import_job(
        AwsAccountId=aws_account_id,
        AssetBundleImportJobId=import_job_id,
        AssetBundleImportSource={ "Body": dashboard_export_data },  # or {"S3Uri": "s3://bucket/key.qs"}
        # FailureAction="",                   # or "DO_NOTHING"
        # OverrideParameters = override_params
    )
    print(f"Started Import For Dashboard: {dashboard_name} with JobId: {response['AssetBundleImportJobId']}")
    return response['AssetBundleImportJobId']


def wait_for_dashboard_import(job_id, dashboard_name, aws_account_id, qs_client):
    while True:
        response = qs_client.describe_asset_bundle_import_job(
            AwsAccountId=aws_account_id,
            AssetBundleImportJobId=job_id
        )
        status = response["JobStatus"]
        print(f"Checking Import Job Status for Dashboard: {dashboard_name} - JobId: {job_id} - Status: {status}")
        if status == "SUCCESSFUL":
            print(f"Import Successful for Dashboard: {dashboard_name} - JobId: {job_id}")
            print(f"Import Response: {response}")
            return response
        elif status in ("FAILED", "FAILED_WITH_ERRORS", "FAILED_ROLLBACK_COMPLETED"):
            raise RuntimeError(f"Import failed for Dashboard: {dashboard_name} - JobId: {job_id} with Status: {status}:\n" + str(response))

        time.sleep(5)


def import_dashboard(dashboard_name, workspace_name, aws_account_id, region, env, 
                     ad_grp="AWS_SSO_QS_AUTHOR_MA_BI",department="Management Analytics", 
                     product_owner_name="Joanna Lei", product_owner_email="joanna.lei@example.com"
                     ):
    # Step 1: Read Dashboard Export File
    dashboard_export_file_path = f"{dashboard_name}/bundle.qs"
    dashboard_export_data = read_exported_dashboard_file(dashboard_export_file_path)

    # Step 2: Start Dashboard Import and Wait for Completion
    qs_client = boto3.client("quicksight", region_name=region)
    override_params = []
    job_id = start_dashboard_import(dashboard_name, dashboard_export_data, override_params, aws_account_id, region, qs_client)
    import_response = wait_for_dashboard_import(job_id, dashboard_name, aws_account_id, qs_client)

    # Step 3: Get Dashboard Artifacts from Bundle
    artifacts = get_dashboard_artifacts_from_bundle(dashboard_name)

    # Step 4: Recreate Datasets and Refresh Schedules in Target Account
    dataset_id_mappings = recreate_datasets(artifacts, qs_client, aws_account_id)
    dataset_id_mappings = recreate_dataset_refresh_schedules(artifacts, dataset_id_mappings, qs_client, aws_account_id)

    # Step 5: Write Dataset Config Files to be used for Dashboard Deployment
    write_dataset_config_files(dataset_id_mappings, workspace_name, env)

    # Step 6: Update Analysis with new dataset IDs
    update_analysis(artifacts, dataset_id_mappings, qs_client, aws_account_id)

    # Step 7: Write Dashboard Config File for Dashboard Deployment
    write_dashboard_config_file(artifacts, workspace_name, env, qs_client, 
                                ad_grp=ad_grp, department=department, product_owner_name=product_owner_name, 
                                product_owner_email=product_owner_email
                                )

    # Step 8: Move Datasets and Analysis to Target Workspace
    move_qs_assets_to_workspace(artifacts, dataset_id_mappings, workspace_name, aws_account_id, region, env, qs_client)

    # Step 9: Delete Imported QS Artifacts after recreation through the pipeline
    delete_qs_assets(artifacts, dataset_id_mappings, qs_client, aws_account_id)

    return import_response


# Example Usage

dashboard_name = "Holdings Data Quality Tracker"
workspace_name = "bif-data-governance"
aws_account_id = "200967598245"
region = "us-east-1"
env = "dev"
ad_grp="AWS_SSO_QS_Author_Data_Governance"
department="Data Governance"
product_owner_name="Alan Luk"
product_owner_email="aluk@cppib.com"


import_dashboard(dashboard_name, workspace_name, aws_account_id, region, env, 
                 ad_grp=ad_grp, department=department, product_owner_name=product_owner_name,
                 product_owner_email=product_owner_email)



