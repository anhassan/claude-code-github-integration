"""
Scan a target QuickSight account for datasets, dashboards, data sources, and
folder membership.

This is read-only. It is intended to create the target-side input for migration
planning before importing bundles from another account.
"""

import argparse
import csv
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from export_qs_bundle_for_review import collect_values_for_key, get_session, write_json


def json_value(value):
    if value in (None, "", [], {}):
        return ""
    if isinstance(value, (list, dict)):
        return json.dumps(value, default=str, sort_keys=True)
    return str(value)


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json_value(row.get(key)) for key in fieldnames})


def paginated(client, operation_name, result_key, **kwargs):
    try:
        paginator = client.get_paginator(operation_name)
        for page in paginator.paginate(**kwargs):
            yield from page.get(result_key, [])
        return
    except Exception:
        pass

    operation = getattr(client, operation_name)
    next_token = None
    while True:
        request = dict(kwargs)
        if next_token:
            request["NextToken"] = next_token
        page = operation(**request)
        yield from page.get(result_key, [])
        next_token = page.get("NextToken")
        if not next_token:
            break


def resolve_account_id(session):
    identity = session.client("sts").get_caller_identity()
    return identity["Account"], identity


def summarize_data_source(data_source_response, fallback_summary=None):
    data_source = data_source_response.get("DataSource") or fallback_summary or {}
    params = data_source.get("DataSourceParameters") or {}
    s3_params = params.get("S3Parameters") or {}
    manifest_location = s3_params.get("ManifestFileLocation") or {}
    data_source_id = data_source.get("DataSourceId")
    arn = data_source.get("Arn")
    if not data_source_id and arn:
        data_source_id = arn.split("/")[-1]

    return {
        "data_source_id": data_source_id,
        "name": data_source.get("Name"),
        "arn": arn,
        "type": data_source.get("Type"),
        "status": data_source.get("Status"),
        "created_time": data_source.get("CreatedTime"),
        "last_updated_time": data_source.get("LastUpdatedTime"),
        "has_manifest_file_location": bool(
            manifest_location.get("Bucket") and manifest_location.get("Key")
        ),
        "manifest_bucket": manifest_location.get("Bucket"),
        "manifest_key": manifest_location.get("Key"),
    }


def summarize_dataset(dataset_response, fallback_summary=None):
    dataset = dataset_response.get("DataSet") or fallback_summary or {}
    physical_table_map = dataset.get("PhysicalTableMap") or {}
    logical_table_map = dataset.get("LogicalTableMap") or {}
    data_source_arns = sorted(set(collect_values_for_key(dataset, "DataSourceArn")))

    physical_table_types = []
    s3_physical_table_ids = []
    for table_id, table_def in physical_table_map.items():
        if "S3Source" in table_def:
            physical_table_types.append("S3Source")
            s3_physical_table_ids.append(table_id)
        if "CustomSql" in table_def:
            physical_table_types.append("CustomSql")
        if "RelationalTable" in table_def:
            physical_table_types.append("RelationalTable")

    return {
        "dataset_id": dataset.get("DataSetId"),
        "name": dataset.get("Name"),
        "arn": dataset.get("Arn"),
        "import_mode": dataset.get("ImportMode"),
        "created_time": dataset.get("CreatedTime"),
        "last_updated_time": dataset.get("LastUpdatedTime"),
        "column_count": len(dataset.get("OutputColumns") or []),
        "physical_table_count": len(physical_table_map),
        "logical_table_count": len(logical_table_map),
        "physical_table_types": sorted(set(physical_table_types)),
        "data_source_arns": data_source_arns,
        "data_source_ids": sorted({arn.split("/")[-1] for arn in data_source_arns}),
        "has_s3_source": bool(s3_physical_table_ids),
        "s3_physical_table_ids": s3_physical_table_ids,
    }


def summarize_dashboard(dashboard_response, fallback_summary=None):
    dashboard = dashboard_response.get("Dashboard") or fallback_summary or {}
    version = dashboard.get("Version") or {}
    dataset_arns = version.get("DataSetArns") or []
    return {
        "dashboard_id": dashboard.get("DashboardId"),
        "name": dashboard.get("Name"),
        "arn": dashboard.get("Arn"),
        "version_number": version.get("VersionNumber"),
        "created_time": dashboard.get("CreatedTime"),
        "last_updated_time": dashboard.get("LastUpdatedTime"),
        "published_version_number": dashboard.get("PublishedVersionNumber"),
        "source_entity_arn": version.get("SourceEntityArn"),
        "dataset_count": len(dataset_arns),
        "dataset_ids": [arn.split("/")[-1] for arn in dataset_arns],
        "dataset_arns": dataset_arns,
    }


def folder_member_type(member):
    arn = member.get("MemberArn") or ""
    resource_part = arn.split(":", 5)[-1]
    resource_type = resource_part.split("/", 1)[0]
    return resource_type.upper() if resource_type else member.get("MemberType")


def enrich_folder_members(folder_members):
    enriched = []
    for member in folder_members:
        enriched.append(
            {
                **member,
                "MemberType": member.get("MemberType") or folder_member_type(member),
            }
        )
    return enriched


def scan_target(qs_client, account_id, folder_id=None):
    errors = []

    data_source_summaries = list(
        paginated(qs_client, "list_data_sources", "DataSources", AwsAccountId=account_id)
    )
    data_sources = []
    for idx, summary in enumerate(data_source_summaries, start=1):
        data_source_id = summary.get("DataSourceId") or (summary.get("Arn") or "").split("/")[-1]
        print(
            f"[data source {idx}/{len(data_source_summaries)}] Inspecting {summary.get('Name')} ({data_source_id})",
            flush=True,
        )
        try:
            response = qs_client.describe_data_source(
                AwsAccountId=account_id,
                DataSourceId=data_source_id,
            )
            data_sources.append(summarize_data_source(response, summary))
        except (BotoCoreError, ClientError, Exception) as error:
            data_sources.append(summarize_data_source({}, summary))
            errors.append(
                {
                    "resource_type": "data_source",
                    "resource_id": data_source_id,
                    "name": summary.get("Name"),
                    "error": str(error),
                }
            )

    dataset_summaries = list(
        paginated(qs_client, "list_data_sets", "DataSetSummaries", AwsAccountId=account_id)
    )
    datasets = []
    for idx, summary in enumerate(dataset_summaries, start=1):
        dataset_id = summary.get("DataSetId") or (summary.get("Arn") or "").split("/")[-1]
        print(
            f"[dataset {idx}/{len(dataset_summaries)}] Inspecting {summary.get('Name')} ({dataset_id})",
            flush=True,
        )
        try:
            response = qs_client.describe_data_set(
                AwsAccountId=account_id,
                DataSetId=dataset_id,
            )
            datasets.append(summarize_dataset(response, summary))
        except (BotoCoreError, ClientError, Exception) as error:
            datasets.append(summarize_dataset({}, summary))
            errors.append(
                {
                    "resource_type": "dataset",
                    "resource_id": dataset_id,
                    "name": summary.get("Name"),
                    "error": str(error),
                }
            )

    dashboard_summaries = list(
        paginated(qs_client, "list_dashboards", "DashboardSummaryList", AwsAccountId=account_id)
    )
    dashboards = []
    for idx, summary in enumerate(dashboard_summaries, start=1):
        dashboard_id = summary.get("DashboardId") or (summary.get("Arn") or "").split("/")[-1]
        print(
            f"[dashboard {idx}/{len(dashboard_summaries)}] Inspecting {summary.get('Name')} ({dashboard_id})",
            flush=True,
        )
        try:
            response = qs_client.describe_dashboard(
                AwsAccountId=account_id,
                DashboardId=dashboard_id,
            )
            dashboards.append(summarize_dashboard(response, summary))
        except (BotoCoreError, ClientError, Exception) as error:
            dashboards.append(summarize_dashboard({}, summary))
            errors.append(
                {
                    "resource_type": "dashboard",
                    "resource_id": dashboard_id,
                    "name": summary.get("Name"),
                    "error": str(error),
                }
            )

    folders = list(
        paginated(qs_client, "list_folders", "FolderSummaryList", AwsAccountId=account_id)
    )

    folder = None
    folder_members = []
    if folder_id:
        print(f"[folder] Inspecting {folder_id}", flush=True)
        try:
            response = qs_client.describe_folder(AwsAccountId=account_id, FolderId=folder_id)
            folder = response.get("Folder")
        except (BotoCoreError, ClientError, Exception) as error:
            errors.append(
                {
                    "resource_type": "folder",
                    "resource_id": folder_id,
                    "error": str(error),
                }
            )
        try:
            folder_members = list(
                paginated(
                    qs_client,
                    "list_folder_members",
                    "FolderMemberList",
                    AwsAccountId=account_id,
                    FolderId=folder_id,
                )
            )
            folder_members = enrich_folder_members(folder_members)
        except (BotoCoreError, ClientError, Exception) as error:
            errors.append(
                {
                    "resource_type": "folder_members",
                    "resource_id": folder_id,
                    "error": str(error),
                }
            )

    return {
        "data_source_summary_count": len(data_source_summaries),
        "data_source_count": len(data_sources),
        "dataset_summary_count": len(dataset_summaries),
        "dataset_count": len(datasets),
        "dashboard_summary_count": len(dashboard_summaries),
        "dashboard_count": len(dashboards),
        "folder_count": len(folders),
        "folder_id": folder_id,
        "folder": folder,
        "folder_member_count": len(folder_members),
        "data_sources": sorted(data_sources, key=lambda row: row.get("name") or ""),
        "datasets": sorted(datasets, key=lambda row: row.get("name") or ""),
        "dashboards": sorted(dashboards, key=lambda row: row.get("name") or ""),
        "folders": sorted(folders, key=lambda row: row.get("Name") or row.get("FolderId") or ""),
        "folder_members": folder_members,
        "errors": errors,
    }


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "_", (value or "").lower()).strip("_")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Scan a target QuickSight account for migration planning."
    )
    parser.add_argument("--profile", help="AWS profile to use")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--account-id", help="QuickSight AWS account id")
    parser.add_argument("--folder-id", help="Optional QuickSight folder id to inspect")
    parser.add_argument(
        "--output-root",
        default="exports/quicksight-target-inventory",
        help="Root folder for target inventory output",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    session = get_session(args.profile, args.region)
    qs_client = session.client("quicksight", region_name=args.region)

    account_id = args.account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = Path(args.output_root) / f"{account_id}-{run_id}"
    output_dir.mkdir(parents=True, exist_ok=True)

    scan = scan_target(qs_client, account_id, args.folder_id)
    result = {
        "scan_type": "quicksight_target_inventory",
        "profile": args.profile,
        "region": args.region,
        "account_id": account_id,
        "caller_identity": caller_identity,
        "created_at": run_id,
        **scan,
    }
    write_json(output_dir / "target_inventory.json", result)

    write_csv(
        output_dir / "target_datasets.csv",
        result["datasets"],
        [
            "dataset_id",
            "name",
            "arn",
            "import_mode",
            "created_time",
            "last_updated_time",
            "column_count",
            "physical_table_count",
            "logical_table_count",
            "physical_table_types",
            "data_source_ids",
            "has_s3_source",
            "s3_physical_table_ids",
        ],
    )
    write_csv(
        output_dir / "target_dashboards.csv",
        result["dashboards"],
        [
            "dashboard_id",
            "name",
            "arn",
            "version_number",
            "published_version_number",
            "created_time",
            "last_updated_time",
            "dataset_count",
            "dataset_ids",
        ],
    )
    write_csv(
        output_dir / "target_data_sources.csv",
        result["data_sources"],
        [
            "data_source_id",
            "name",
            "arn",
            "type",
            "status",
            "created_time",
            "last_updated_time",
            "has_manifest_file_location",
            "manifest_bucket",
            "manifest_key",
        ],
    )
    write_csv(
        output_dir / "target_folder_members.csv",
        result["folder_members"],
        ["MemberId", "MemberType", "MemberArn"],
    )

    print(f"Target datasets: {result['dataset_count']}", flush=True)
    print(f"Target dashboards: {result['dashboard_count']}", flush=True)
    print(f"Target data sources: {result['data_source_count']}", flush=True)
    print(f"Target folders: {result['folder_count']}", flush=True)
    if args.folder_id:
        print(f"Folder members in {args.folder_id}: {result['folder_member_count']}", flush=True)
    print(f"Inventory folder: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
