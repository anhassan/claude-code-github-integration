"""
Export a QuickSight dashboard bundle for manual review.

This is a safe wrapper around the same QuickSight asset-bundle export flow used
by export_qs_dashboards.py, but without the hardcoded example execution at the
bottom of that script.
"""

import argparse
import json
import re
import time
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import boto3


FAILED_STATUSES = {"FAILED", "FAILED_WITH_ERRORS", "FAILED_ROLLBACK_COMPLETED"}
SUCCESS_STATUS = "SUCCESSFUL"


class AssetBundleExportFailed(RuntimeError):
    def __init__(self, response):
        self.response = response
        super().__init__(
            f"Export job failed with status {response.get('JobStatus')}: {response}"
        )


def slugify(value):
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or "dashboard"


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=str)
        file.write("\n")


def get_session(profile, region):
    if profile:
        return boto3.Session(profile_name=profile, region_name=region)
    return boto3.Session(region_name=region)


def resolve_account_id(session):
    sts_client = session.client("sts")
    identity = sts_client.get_caller_identity()
    return identity["Account"], identity


def get_dashboard_id_by_name(qs_client, account_id, dashboard_name):
    paginator = qs_client.get_paginator("list_dashboards")
    for page in paginator.paginate(AwsAccountId=account_id):
        for dashboard in page.get("DashboardSummaryList", []):
            if dashboard.get("Name") == dashboard_name:
                return dashboard["DashboardId"]
    raise ValueError(f"Dashboard with name '{dashboard_name}' was not found")


def describe_dashboard(qs_client, account_id, dashboard_id):
    return qs_client.describe_dashboard(AwsAccountId=account_id, DashboardId=dashboard_id)


def describe_dashboard_definition(qs_client, account_id, dashboard_id, version_number):
    kwargs = {"AwsAccountId": account_id, "DashboardId": dashboard_id}
    if version_number is not None:
        kwargs["VersionNumber"] = version_number
    return qs_client.describe_dashboard_definition(**kwargs)


def describe_analysis_definition(qs_client, account_id, analysis_arn):
    if not analysis_arn:
        return None
    analysis_id = analysis_arn.split("/")[-1]
    return qs_client.describe_analysis_definition(
        AwsAccountId=account_id,
        AnalysisId=analysis_id,
    )


def describe_dataset(qs_client, account_id, dataset_arn):
    dataset_id = dataset_arn.split("/")[-1]
    return qs_client.describe_data_set(
        AwsAccountId=account_id,
        DataSetId=dataset_id,
    )


def describe_dataset_refresh_schedules(qs_client, account_id, dataset_id):
    try:
        return qs_client.describe_data_set_refresh_schedules(
            AwsAccountId=account_id,
            DataSetId=dataset_id,
        )
    except Exception as error:
        return {"error": str(error), "DataSetId": dataset_id}


def collect_values_for_key(value, key_name):
    found = []
    if isinstance(value, dict):
        for key, nested_value in value.items():
            if key == key_name and nested_value:
                found.append(nested_value)
            found.extend(collect_values_for_key(nested_value, key_name))
    elif isinstance(value, list):
        for item in value:
            found.extend(collect_values_for_key(item, key_name))
    return found


def describe_data_source(qs_client, account_id, data_source_arn):
    data_source_id = data_source_arn.split("/")[-1]
    return qs_client.describe_data_source(
        AwsAccountId=account_id,
        DataSourceId=data_source_id,
    )


def export_definition_fallback(
    qs_client,
    account_id,
    dashboard_id,
    dashboard_response,
    output_dir,
):
    dashboard = dashboard_response["Dashboard"]
    version = dashboard.get("Version", {})
    version_number = version.get("VersionNumber")
    source_analysis_arn = version.get("SourceEntityArn")
    dataset_arns = version.get("DataSetArns", [])

    definitions_dir = output_dir / "definitions"
    dashboard_definition = describe_dashboard_definition(
        qs_client,
        account_id,
        dashboard_id,
        version_number,
    )
    write_json(definitions_dir / "dashboard_definition.json", dashboard_definition)

    analysis_definition = describe_analysis_definition(
        qs_client,
        account_id,
        source_analysis_arn,
    )
    if analysis_definition:
        write_json(definitions_dir / "analysis_definition.json", analysis_definition)

    dataset_summaries = []
    data_source_arns = set()
    for dataset_arn in dataset_arns:
        dataset_id = dataset_arn.split("/")[-1]
        dataset_response = describe_dataset(qs_client, account_id, dataset_arn)
        write_json(definitions_dir / "datasets" / f"{dataset_id}.json", dataset_response)

        refresh_schedules = describe_dataset_refresh_schedules(
            qs_client,
            account_id,
            dataset_id,
        )
        write_json(
            definitions_dir / "refresh_schedules" / f"{dataset_id}.json",
            refresh_schedules,
        )

        dataset = dataset_response.get("DataSet", {})
        data_source_arns.update(collect_values_for_key(dataset, "DataSourceArn"))
        dataset_summaries.append(
            {
                "dataset_id": dataset_id,
                "name": dataset.get("Name"),
                "import_mode": dataset.get("ImportMode"),
                "data_source_arns": sorted(
                    set(collect_values_for_key(dataset, "DataSourceArn"))
                ),
            }
        )

    data_source_summaries = []
    for data_source_arn in sorted(data_source_arns):
        data_source_id = data_source_arn.split("/")[-1]
        try:
            data_source_response = describe_data_source(
                qs_client,
                account_id,
                data_source_arn,
            )
            write_json(
                definitions_dir / "data_sources" / f"{data_source_id}.json",
                data_source_response,
            )
            data_source = data_source_response.get("DataSource", {})
            data_source_summaries.append(
                {
                    "data_source_id": data_source_id,
                    "name": data_source.get("Name"),
                    "type": data_source.get("Type"),
                    "arn": data_source.get("Arn"),
                }
            )
        except Exception as error:
            data_source_summaries.append(
                {
                    "data_source_id": data_source_id,
                    "arn": data_source_arn,
                    "error": str(error),
                }
            )

    summary = {
        "export_type": "definition_fallback",
        "dashboard_id": dashboard_id,
        "dashboard_name": dashboard.get("Name"),
        "version_number": version_number,
        "source_analysis_arn": source_analysis_arn,
        "dataset_count": len(dataset_summaries),
        "datasets": dataset_summaries,
        "data_source_count": len(data_source_summaries),
        "data_sources": data_source_summaries,
    }
    write_json(output_dir / "definition_export_summary.json", summary)
    return summary


def start_export_job(
    qs_client,
    account_id,
    region,
    dashboard_id,
    job_id,
    include_permissions,
):
    dashboard_arn = (
        f"arn:aws:quicksight:{region}:{account_id}:dashboard/{dashboard_id}"
    )
    return qs_client.start_asset_bundle_export_job(
        AwsAccountId=account_id,
        AssetBundleExportJobId=job_id,
        ResourceArns=[dashboard_arn],
        IncludeAllDependencies=True,
        ExportFormat="QUICKSIGHT_JSON",
        IncludePermissions=include_permissions,
        IncludeTags=True,
        IncludeFolderMemberships=True,
        ValidationStrategy={"StrictModeForAllResources": False},
    )


def wait_for_export_job(qs_client, account_id, job_id, poll_seconds, timeout_seconds):
    started_at = time.time()
    while True:
        response = qs_client.describe_asset_bundle_export_job(
            AwsAccountId=account_id,
            AssetBundleExportJobId=job_id,
        )
        status = response["JobStatus"]
        print(f"Export job {job_id}: {status}", flush=True)

        if status == SUCCESS_STATUS:
            return response
        if status in FAILED_STATUSES:
            raise AssetBundleExportFailed(response)
        if time.time() - started_at > timeout_seconds:
            raise TimeoutError(
                f"Export job {job_id} did not finish within {timeout_seconds} seconds"
            )

        time.sleep(poll_seconds)


def download_bundle(download_url, bundle_path):
    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading bundle to {bundle_path}", flush=True)
    urllib.request.urlretrieve(download_url, bundle_path)


def patch_bundle_exclude_datasets(bundle_path, names_to_exclude, output_path):
    """Return a new bundle zip at *output_path* with the named datasets removed.

    Removed entries:
    - ``dataset/<dataset-id>.json``      for each excluded dataset id
    - ``refreshSchedule/<dataset-id>--refresh-schedule--*.json``

    DataSetIdentifierDeclarations inside the analysis/dashboard JSON are left
    intact so that QuickSight can still validate the schema.  Visuals that
    reference excluded datasets will show errors in the UI, but the import will
    succeed.
    """
    names_set = set(names_to_exclude)

    # Pass 1: resolve dataset names → ids from the bundle
    excluded_ids = set()
    with zipfile.ZipFile(bundle_path, "r") as zin:
        for info in zin.infolist():
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            if path.parts[0] == "dataset" and path.suffix == ".json":
                try:
                    body = json.loads(zin.read(info.filename).decode("utf-8"))
                    ds_name = body.get("name") or body.get("Name") or ""
                    if ds_name in names_set:
                        excluded_ids.add(path.stem)
                except Exception:
                    pass

    if not excluded_ids:
        print(
            f"Warning: none of the requested datasets {sorted(names_set)} were found in the bundle.",
            flush=True,
        )

    # Pass 2: copy all entries except those belonging to excluded dataset ids
    excluded_entries = []
    kept_count = 0
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle_path, "r") as zin, zipfile.ZipFile(
        output_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as zout:
        for info in zin.infolist():
            if info.is_dir():
                zout.mkdir(info.filename) if hasattr(zout, "mkdir") else None
                continue
            path = PurePosixPath(info.filename)
            resource_type = path.parts[0] if path.parts else ""

            exclude = False
            if resource_type == "dataset" and path.stem in excluded_ids:
                exclude = True
            elif resource_type == "refreshSchedule":
                # filename pattern: <dataset-id>--refresh-schedule--<schedule-id>.json
                ds_id = path.stem.split("--refresh-schedule--")[0]
                if ds_id in excluded_ids:
                    exclude = True

            if exclude:
                excluded_entries.append(info.filename)
            else:
                zout.writestr(info, zin.read(info.filename))
                kept_count += 1

    print(
        f"Bundle patched: {kept_count} entries kept, {len(excluded_entries)} excluded",
        flush=True,
    )
    for entry in excluded_entries:
        print(f"  excluded: {entry}", flush=True)
    return excluded_entries


def unpack_bundle(bundle_path, unpack_dir):
    if not zipfile.is_zipfile(bundle_path):
        raise ValueError(f"{bundle_path} is not a zip-compatible QuickSight bundle")

    unpack_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle_path) as bundle:
        bundle.extractall(unpack_dir)

    json_files = sorted(str(path.relative_to(unpack_dir)) for path in unpack_dir.rglob("*.json"))
    return {
        "unpack_dir": str(unpack_dir),
        "json_file_count": len(json_files),
        "json_files": json_files,
    }


def build_output_dir(output_root, dashboard_name, dashboard_id, run_id):
    name_part = slugify(dashboard_name or dashboard_id)
    return Path(output_root) / f"{name_part}-{dashboard_id}" / run_id


def parse_args():
    parser = argparse.ArgumentParser(
        description="Export a QuickSight dashboard bundle and unpack it for review."
    )
    parser.add_argument("--profile", help="AWS profile to use")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument(
        "--account-id",
        help="QuickSight AWS account id. Defaults to the caller identity account.",
    )

    dashboard = parser.add_mutually_exclusive_group(required=True)
    dashboard.add_argument("--dashboard-id", help="QuickSight dashboard id")
    dashboard.add_argument("--dashboard-name", help="QuickSight dashboard name")

    parser.add_argument(
        "--output-root",
        default="exports/quicksight",
        help="Root directory for exported bundles",
    )
    parser.add_argument(
        "--job-id",
        help="Optional QuickSight export job id. Defaults to a generated id.",
    )
    parser.add_argument(
        "--poll-seconds",
        type=int,
        default=5,
        help="Seconds between export status checks",
    )
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=1800,
        help="Maximum seconds to wait for the export job",
    )
    parser.add_argument(
        "--include-permissions",
        action="store_true",
        help="Include permissions in the bundle. Defaults to false to match the repo script.",
    )
    parser.add_argument(
        "--no-unpack",
        action="store_true",
        help="Download bundle.qs only; do not unpack it for inspection.",
    )
    parser.add_argument(
        "--definition-only",
        action="store_true",
        help="Skip asset bundle export and write dashboard/analysis/dataset definitions only.",
    )
    parser.add_argument(
        "--no-definition-fallback",
        action="store_true",
        help="Do not export definitions if asset bundle export fails.",
    )
    parser.add_argument(
        "--exclude-datasets",
        nargs="*",
        metavar="DATASET_NAME",
        default=None,
        help=(
            "Dataset names to strip from the exported bundle before unpacking/importing. "
            "Use when the dashboard references datasets that no longer exist in QuickSight "
            "(e.g. --exclude-datasets TFM_Posdata TFM_PNL_SA). "
            "A patched bundle is saved alongside the original as bundle_patched.qs."
        ),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    session = get_session(args.profile, args.region)
    qs_client = session.client("quicksight", region_name=args.region)

    account_id = args.account_id
    caller_identity = None
    if not account_id:
        account_id, caller_identity = resolve_account_id(session)

    dashboard_id = args.dashboard_id
    if not dashboard_id:
        dashboard_id = get_dashboard_id_by_name(
            qs_client, account_id, args.dashboard_name
        )

    dashboard_response = describe_dashboard(qs_client, account_id, dashboard_id)
    dashboard = dashboard_response["Dashboard"]
    dashboard_name = dashboard.get("Name") or args.dashboard_name or dashboard_id

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    job_id = args.job_id or f"export-{dashboard_id}-{run_id}".replace(":", "-")
    output_dir = build_output_dir(args.output_root, dashboard_name, dashboard_id, run_id)

    write_json(
        output_dir / "request.json",
        {
            "profile": args.profile,
            "region": args.region,
            "account_id": account_id,
            "caller_identity": caller_identity,
            "dashboard_id": dashboard_id,
            "dashboard_name": dashboard_name,
            "job_id": job_id,
            "include_permissions": args.include_permissions,
        },
    )
    write_json(output_dir / "dashboard.json", dashboard_response)

    if args.definition_only:
        summary = export_definition_fallback(
            qs_client,
            account_id,
            dashboard_id,
            dashboard_response,
            output_dir,
        )
        print(f"Definition review folder: {output_dir}", flush=True)
        print(f"Datasets exported: {summary['dataset_count']}", flush=True)
        return

    start_response = start_export_job(
        qs_client,
        account_id,
        args.region,
        dashboard_id,
        job_id,
        args.include_permissions,
    )
    write_json(output_dir / "start_export_job_response.json", start_response)

    try:
        export_response = wait_for_export_job(
            qs_client,
            account_id,
            job_id,
            args.poll_seconds,
            args.timeout_seconds,
        )
    except AssetBundleExportFailed as error:
        write_json(output_dir / "export_job_failed_response.json", error.response)
        if args.no_definition_fallback:
            raise
        print("Asset bundle export failed; writing definition fallback for review.", flush=True)
        summary = export_definition_fallback(
            qs_client,
            account_id,
            dashboard_id,
            dashboard_response,
            output_dir,
        )
        print(f"Definition review folder: {output_dir}", flush=True)
        print(f"Datasets exported: {summary['dataset_count']}", flush=True)
        return
    write_json(output_dir / "export_job_response.json", export_response)

    bundle_path = output_dir / "bundle.qs"
    download_bundle(export_response["DownloadUrl"], bundle_path)

    if args.exclude_datasets:
        patched_path = output_dir / "bundle_patched.qs"
        print(
            f"Patching bundle to exclude datasets: {args.exclude_datasets}",
            flush=True,
        )
        patch_bundle_exclude_datasets(bundle_path, args.exclude_datasets, patched_path)
        bundle_path = patched_path

    if not args.no_unpack:
        summary = unpack_bundle(bundle_path, output_dir / "bundle")
        write_json(output_dir / "bundle_summary.json", summary)

    print(f"Export review folder: {output_dir}", flush=True)
    print(f"Bundle: {bundle_path}", flush=True)


if __name__ == "__main__":
    main()
